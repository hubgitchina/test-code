package cn.com.ut.biz.user.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.user.dao.UserParentDAO;
import cn.com.ut.biz.user.dao.UserPersonDAO;
import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.biz.user.service.AdminUserService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.exception.ValidateException;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.util.NickNameUtil;

/**
 * 超级管理员用户
 * 
 * @author ouyuexing
 *
 */
@Service
public class AdminUserServiceImpl implements AdminUserService {

	@Resource
	private UserParentDAO userParentDAO;
	@Autowired
	private UserPersonDAO userPersonDAO;
	@Autowired
	private UserService userService;
	@Autowired
	private Environment env;

	@Override
	public String createAdminUser(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, UserParent.user_name);
		Object email = vo.get(UserParent.email);
		Object isLock = vo.get(UserParent.is_locked);
		String userName = (String) vo.get(UserParent.user_name);
		boolean flag = userParentDAO.checkUnique(new String[] { UserParent.user_name },
				new Object[] { userName }, null, null);
		if (!flag) {
			ExceptionUtil.throwServiceException("用户名重复");
		}
		vo = new HashMap<>();
		vo.put(UserParent.email, email);
		vo.put(UserParent.is_locked, isLock);
		vo.put(UserParent.user_name, userName);
		String passwordMd5 = CommonUtil.encodeMD5(ConstantUtil.DEFAULT_ACCOUNT_PWD.getBytes());
		vo.put(UserParent.user_pwd, passwordMd5);
		vo.put(UserParent.user_type, ConstantUtil.USER_TYPE.USER_TYPE_ADMIN);
		if (CommonUtil.isEmpty((String) vo.get(UserParent.nick_name))) {
			vo.put(UserParent.nick_name, NickNameUtil.getRoundName());
		}
		String userId = userParentDAO.add(vo);
		vo.put(UserPerson.user_id, userId);
		userPersonDAO.add(vo);
		return userId;
	}

	@Override
	public void loginByPwd(User user, Map<String, Object> loginByPwd, boolean checkWrongTime) {

		if (CollectionUtil.isEmptyMap(loginByPwd)) {
			ExceptionUtil.throwValidateException("参数不能为空");
		}
		String userName = (String) loginByPwd.get("user_name");
		String userPwd = (String) loginByPwd.get("user_pwd");
		String loginType = (String) loginByPwd.get("login_type");
		if (CommonUtil.isEmpty(userName) || CommonUtil.isEmpty(userPwd)) {
			throw new ValidateException("用户名或密码不能为空！");
		}
		// 需要验证登录错误次数
		if (checkWrongTime) {
			String picCode = (String) loginByPwd.get("verification_code");
			userService.checkWrongLoginTime(userName, picCode, user.getSessionId());
		}
		// String passwordMd5 = CommonUtil.encodeMD5(userPwd.getBytes());
		Map<String, Object> userMap = null;
		if (NumberUtil.checkMobileNumber(userName)) {
			userMap = userParentDAO.getUserInfoByMobile(userName, userPwd);
		} else {
			userMap = userParentDAO.getUserInfoByUserName(userName, userPwd);
		}
		if (CollectionUtil.isEmptyMap(userMap)) {
			userService.recordWrongLoginTime(userName);
			ExceptionUtil.throwServiceException("用户名密码错误");
		}
		if (!ConstantUtil.USER_TYPE.USER_TYPE_ADMIN.equals(userMap.get(UserParent.user_type))) {
			ExceptionUtil.throwServiceException("当前用户不是管理员用户");
		}
		userService.loginDo(user, userMap, loginType);

	}

	@Override
	public void modifyAdminPwd(String adminUserId, String pwd) {

		userParentDAO.update(null, new String[] { UserParent.user_pwd }, null, null,
				new String[] { UserParent.user_type, UserParent.idx }, null, null,
				new Object[] { pwd },
				new Object[] { ConstantUtil.USER_TYPE.USER_TYPE_ADMIN, adminUserId }, null);

	}

	@Override
	public void deleteAdminUser(String userID) {

		Map<String, Object> userMap = userParentDAO.get(userID);
		if (CollectionUtil.isEmptyMap(userMap)) {
			ExceptionUtil.throwServiceException("用户不存在");
		}
		if (!ConstantUtil.USER_TYPE.USER_TYPE_ADMIN.equals(userMap.get(UserParent.user_type))) {
			ExceptionUtil.throwServiceException("当前用户不是管理员用户");
		}
		userParentDAO.delete(userID);
		userPersonDAO.delete(null, new String[] { UserPerson.user_id }, new Object[] { userID });

	}

	@Override
	public void deleteAdminUser(Set<Object> userIDs) {

		int tem = userParentDAO.delete(null, null, " id {IN} ", new int[] { userIDs.size() },
				userIDs.toArray(), null);
		if (tem != userIDs.size()) {
			ExceptionUtil.throwServiceException("userIDs 存在不正确用户");
		}
		userPersonDAO.delete(null, null, "user_id {IN}", new int[] { userIDs.size() },
				userIDs.toArray(), null);
	}

}
