package cn.com.ut.biz.ui.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 应用定制页面实体
 * 
 * @author wangpeng1
 * @since 2018年5月15日
 */
public class Page extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5716317178130409321L;
	/**
	 * 页面编辑内容
	 */
	public static final String page_edit = "page_edit";
	/**
	 * 页面名称
	 */
	public static final String page_name = "page_name";
	/**
	 * 页面编码
	 */
	public static final String page_code = "page_code";
	/**
	 * 页面显示内容
	 */
	public static final String page_view = "page_view";
	/**
	 * 模型ID
	 */
	public static final String model_id = "model_id";
	/**
	 * 父页面ID
	 */
	public static final String parent_id = "parent_id";
	/**
	 * 是否为目录（Y为目录N为文件）
	 */
	public static final String is_dir = "is_dir";
}