package cn.com.ut.biz.system.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class Config extends BaseEntity {

	private static final long serialVersionUID = 5441771982121209080L;
	public static final String config_code = "config_code";
	public static final String config_type = "config_type";
	public static final String config_name = "config_name";
	public static final String config_value = "config_value";
	public static final String config_des = "config_des";
}
