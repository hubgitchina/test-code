package cn.com.ut.biz.user.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;

import cn.com.ut.biz.system.service.DictDataService;
import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.DictionaryConstant;
import cn.com.ut.core.cache.CacheHelper;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.restful.DictBuilder;
import cn.com.ut.core.restful.ResponseWrap;
import cn.com.ut.util.UserUtil;

/**
 * 用户控制器
 * 
 * @author ouyuexing
 *
 */
@RestController
@RequestMapping(value = "/user")
public class UserCommonController {

	@Autowired
	private UserService userService;
	@Autowired
	private DictDataService dictDataService;

	public static final String KEY_BEGIN_SESSION = "s/";

	/**
	 * 全局缓存时间，超长，用于主机、创作软件
	 */
	public static final int LONG_EXPIRE_SECONDS_GLOBAL_SESSION = 60 * 20;

	@Autowired(required = false)
	private CacheHelper cacheHelper;

	/**
	 * 通过用户id获取用户名称
	 * 
	 * @param responseWrap
	 * @return
	 */
	@RequestMapping(value = "/getUserNameById", method = RequestMethod.POST)
	@ServiceComponent(session = false)
	public ResponseWrap getUserNameById(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("参数空");
		}
		String userid = (String) vo.get(DictionaryConstant.token_info.USERID);
		if (CommonUtil.isEmpty(userid)) {
			ExceptionUtil.throwValidateException("userid canot be empty");
		}
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		Map<String, Object> userMap = userService.getUserByUserId(userid);
		responseWrap.getResponseData().put("data", userMap);
		return responseWrap;
	}

	/**
	 * 通过用户id获取用户信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@RequestMapping(value = "/getUserInfo", method = RequestMethod.POST)
	@ServiceComponent(session = false)
	public ResponseWrap getUserInfo(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("参数空");
		}
		String userid = (String) vo.get(DictionaryConstant.token_info.USERID);
		if (CommonUtil.isEmpty(userid)) {
			ExceptionUtil.throwValidateException("userid canot be empty");
		}
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		Map<String, Object> userMap = userService.getUserByUserId(userid);

		DictBuilder dictBuilder = DictBuilder.build();

		dictBuilder.appendDict(UserParent.is_locked, "IS_TRUE")
				.appendDict(UserPerson.industry_nature, "CORP_TRADE")
				.appendDict(UserPerson.is_marital, "MARITAL_STATUS")
				.appendDict(UserPerson.education_level, "EDUCATION_LEVEL")
				.appendDict(UserPerson.monthly_income, "MONTHLY_INCOME");

		responseWrap.getResponseData().put("data", userMap);
		return responseWrap;
	}

	/**
	 * 通过用户id获取用户名
	 * 
	 * @param responseWrap
	 * @return
	 */
	@RequestMapping(value = "/getUserName", method = RequestMethod.POST)
	@ServiceComponent(session = false)
	public ResponseWrap getUserName(@RequestBody ResponseWrap responseWrap) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("参数空");
		}
		JSONArray userIdsArray = responseWrap.getJson().getJSONArray("userids");
		if (CollectionUtil.isEmptyCollection(userIdsArray)) {
			ExceptionUtil.throwValidateException("userids canot be empty");
		}
		@SuppressWarnings("rawtypes")
		List<Object> userIds = new ArrayList(userIdsArray);
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		List<Map<String, Object>> userList = userService.getUserName(userIds);
		responseWrap.getResponseData().put("data", userList);
		return responseWrap;
	}

	/**
	 * 根据cookies中sessionID获取登录用户信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@RequestMapping(value = "/getLoginUser", method = RequestMethod.POST)
	@ServiceComponent(session = false)
	public ResponseWrap getLoginUser(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("参数空");
		}
		String sessionId = (String) vo.get("session_id");
		if (CommonUtil.isEmpty(sessionId)) {
			ExceptionUtil.throwValidateException("session_id canot be empty");
		}
		User user = userService.getLoginUserBySessionId(sessionId);
		if (user == null) {
			ExceptionUtil.throwServiceException("用户没登录");
		}
		cacheHelper.touch(KEY_BEGIN_SESSION + user.getSessionId(),
				LONG_EXPIRE_SECONDS_GLOBAL_SESSION);
		responseWrap.getResponseData().put("data", UserUtil.userToMap(user));
		return responseWrap;
	}

	/**
	 * 检查用户是否锁定
	 * 
	 * @param response
	 * @param userName
	 * @param user
	 * @return
	 */
	@ServiceComponent(session = false)
	@GetMapping(value = "/accountLockCheck")
	public ResponseWrap accountLockCheck(HttpServletResponse response,
			@RequestParam(value = "user_name") String userName) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		int code = userService.accountLockCheck(userName);
		Map<String, Object> row = new HashMap<>();
		row.put("lock_code", code);
		responseWrap.getResponseData().put("data", row);
		return responseWrap;
	}
}