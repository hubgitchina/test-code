package cn.com.ut.biz.app.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.app.entities.AppTmp;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 应用与业务模板DAO
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface AppTmpDAO extends JdbcOperation<AppTmp> {

	/**
	 * 查询应用关联所有业务模板
	 * 
	 * @return
	 */
	List<Map<String, Object>> findTmpByAppId(String appId);
}