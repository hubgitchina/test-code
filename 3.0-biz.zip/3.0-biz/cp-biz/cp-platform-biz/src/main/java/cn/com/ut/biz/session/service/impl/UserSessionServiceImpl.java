package cn.com.ut.biz.session.service.impl;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.session.service.UserSessionService;
import cn.com.ut.biz.user.service.AdminService;
import cn.com.ut.biz.user.service.AdminUserService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.cache.CacheHelper;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.exception.ValidateException;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.util.UserUtil;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserSessionServiceImpl implements UserSessionService {

	@Autowired
	private AdminService adminService;
	@Autowired
	private AdminUserService adminUserService;
	@Autowired
	private UserService userService;
	public static final String KEY_BEGIN_SESSION = "s/";

	/**
	 * 全局缓存时间，超长，用于主机、创作软件
	 */
	public static final int LONG_EXPIRE_SECONDS_GLOBAL_SESSION = 60 * 20;

	@Autowired(required = false)
	private CacheHelper cacheHelper;

	private static final Logger logger = LoggerFactory.getLogger(UserSessionServiceImpl.class);

	/**
	 * 获取会话信息
	 */
	@ServiceComponent(session = false)
	@Override
	public Map<String, Object> getUserSession(User user, String moduleCode) {

		Map<String, Object> map = new LinkedHashMap<>();
		map.put("user_name", ConstantUtil.STR_EMPTY);
		map.put("user_type", ConstantUtil.STR_EMPTY);
		map.put("user_id", ConstantUtil.STR_EMPTY);
		map.put("position", ConstantUtil.STR_EMPTY);

		Map<String, Object> managerMap = adminService.getDetailByUserId(user.getUserId());
		if (CollectionUtil.isEmptyMap(managerMap)) {
			ExceptionUtil.throwValidateException("非管理员用户");
		}
		if (user.getUserId() == null) {
			ExceptionUtil.throwValidateException("未登录用户");
		} else {
			map.put("position", user.getPosition());
			map.put("area", user.getArea());
			map.put("user_name", user.getUserName());
			map.put("user_type", user.getUserType());
			map.put("user_id", user.getUserId());
			map.put("email", user.getEmail());
			map.put("mobile", user.getMobile());
			map.put("nick", user.getNick());
			map.put("email", user.getEmail());

		}

		return map;
	}

	@Override
	public User setLoginUserInfo(User user) {

		User vo = userService.getLoginUserBySessionId(user.getSessionId());
		if (vo == null) {
			ExceptionUtil.throwServiceException("用户没登录");
		}
		cacheHelper.touch(KEY_BEGIN_SESSION + user.getSessionId(),
				LONG_EXPIRE_SECONDS_GLOBAL_SESSION);

		JSONObject userJb = (JSONObject) JSON.toJSON(vo);
		if (!CollectionUtil.isEmptyMap(userJb)) {
			setUserByMap(user, userJb);
		}
		return vo;
	}

	@Override
	public JSONObject login(String userName, String password, String loginType, String sessionId,
			String randomCode, HttpServletResponse response) {

		if (CommonUtil.isEmpty(userName) || CommonUtil.isEmpty(password)) {
			throw new ValidateException("用户名或密码不能为空！");
		}

		Map<String, Object> parMap = new HashMap<>();
		parMap.put("user_name", userName);
		parMap.put("login_type", loginType);
		parMap.put("user_pwd", password);
		parMap.put("sid", sessionId);
		parMap.put("verification_code", randomCode);

		User user = new User();
		user.setSessionId(sessionId);
		adminUserService.loginByPwd(user, parMap, false);
		Map<String, Object> vo = UserUtil.userToMap(user);

		JSONObject data = (JSONObject) JSON.toJSON(vo);
		String userId = data.getString("user_id");
		if (CommonUtil.isEmpty(userId)) {
			ExceptionUtil.throwServiceException("获取用户失败");
		}

		Cookie cookie = new Cookie(ConstantUtil.SESSIONKEY, data.getString("sid"));
		cookie.setPath("/");
		cookie.setMaxAge(-1);
		response.addCookie(cookie);
		return data;
	}

	/**
	 * 把map数据设置到用户信息中
	 * 
	 * @param user
	 * @param userMap
	 */
	private void setUserByMap(User user, Map<String, Object> userMap) {

		user.setEmail((String) userMap.get("email"));
		user.setNick((String) userMap.get("nick_name"));
		user.setUserName((String) userMap.get("user_name"));
		user.setMobile((String) userMap.get("mobile"));
		user.setUserId((String) userMap.get("user_id"));
		user.setUserType((String) userMap.get("user_type"));
		user.setImage((String) userMap.get("user_pic"));
	}
}
