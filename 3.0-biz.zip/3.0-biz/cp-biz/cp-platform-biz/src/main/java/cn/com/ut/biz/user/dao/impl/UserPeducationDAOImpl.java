package cn.com.ut.biz.user.dao.impl;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.user.dao.UserPeducationDAO;
import cn.com.ut.biz.user.entities.UserPeducation;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 用户教育信息
 * 
 * @author ouyuexing
 *
 */
@Repository
public class UserPeducationDAOImpl extends JdbcOperationsImpl<UserPeducation>
		implements UserPeducationDAO {

	String[] COLUMNS = { UserPeducation.education_type, UserPeducation.enrollment_year,
			UserPeducation.school_name, UserPeducation.user_id };

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

}
