package cn.com.ut.biz.user.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.user.service.ThirdQQUserService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.config.thirdlogin.QQLoginModule;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.rpc.ThirdRestTemplate;

/**
 * 第三方QQ用户管理
 * 
 * @author ouyuexing
 *
 */
@Service
public class ThirdQQUserServiceImpl implements ThirdQQUserService {

	@Autowired
	private QQLoginModule qqModule;

	@Autowired
	private UserService userService;

	@Autowired
	private ThirdRestTemplate thirdRestTemplate;

	@Override
	public String getQQLoginUrl(String sessionid, String successurl) {

		Map<String, Object> reqMap = new HashMap<>();
		reqMap.put("response_type", "code");
		reqMap.put("client_id", qqModule.getPcId());
		JSONObject jb = new JSONObject();
		jb.put("vf", sessionid);
		jb.put("successurl", successurl);
		reqMap.put("state", jb.toJSONString());
		reqMap.put("redirect_uri", getCallBackEncUrl());
		return thirdRestTemplate.getReqUrl(ConstantUtil.RPC_PROJRCT.QQLOGIN,
				ConstantUtil.API_QQLOGIN.GET_CODE, reqMap);
	}

	@Override
	public String qqUserLogin(String code, User user) {

		String accessToken = getAccessTokenByCode(code);
		if (CommonUtil.isEmpty(accessToken)) {
			ExceptionUtil.throwServiceException("获取QQ用户失败");
		}
		String openid = getOpenId(accessToken);
		userService.qqLogin(user, ConstantUtil.THIRD_USER_FORM.QQ, ConstantUtil.LOGIN_TYPE.PC,
				openid, accessToken, Long.valueOf(ConstantUtil.SESSION_TIME.DEFAULT));
		return null;
	}

	/**
	 * 获取QQ的用户信息
	 * 
	 * @param openid
	 * @return
	 */
	public Map<String, Object> getQQUserInfo(String openid, String accessToken) {

		Map<String, Object> requestData = new HashMap<>();
		requestData.put("openid", openid);
		requestData.put("oauth_consumer_key", qqModule.getPcId());
		requestData.put("access_token", accessToken);
		JSONObject result = thirdRestTemplate.exchangeGetForEntity(requestData,
				ConstantUtil.RPC_PROJRCT.QQLOGIN, ConstantUtil.API_QQLOGIN.GET_USER_INFO);
		return result;
	}

	/**
	 * 获取用户的openid
	 * 
	 * @param accessToken
	 * @return
	 */
	private String getOpenId(String accessToken) {

		Map<String, Object> requestData = new HashMap<>();
		requestData.put("access_token", accessToken);
		String openResult = thirdRestTemplate.exchangeGetForString(requestData,
				ConstantUtil.RPC_PROJRCT.QQLOGIN, ConstantUtil.API_QQLOGIN.GET_USER_OPENID);
		if (CommonUtil.isNotEmpty(openResult)) {
			openResult = openResult.replace("callback(", "").replace(");", "");
			try {
				return JSON.parseObject(openResult).getString("openid");
			} catch (Exception e) {
				return null;
			}
		}
		return openResult;
	}

	private String getAccessTokenByCode(String code) {

		Map<String, Object> requestData = new HashMap<>();
		requestData.put("grant_type", "authorization_code");
		requestData.put("client_id", qqModule.getPcId());
		requestData.put("client_secret", qqModule.getPcKey());
		requestData.put("code", code);
		requestData.put("redirect_uri", getCallBackEncUrl());
		String tokenResult = thirdRestTemplate.exchangeGetForString(requestData,
				ConstantUtil.RPC_PROJRCT.QQLOGIN, ConstantUtil.API_QQLOGIN.GET_ACC_TOKEN);
		if (CommonUtil.isEmpty(tokenResult)) {
			return tokenResult;
		}
		Map<String, String> tem = patTokenResult(tokenResult);
		return tem.get("access_token");
	}

	/**
	 * 解析接口返回的数据
	 * 
	 * @param tokenResult
	 * @return
	 */
	private Map<String, String> patTokenResult(String tokenResult) {

		if (tokenResult.startsWith("callback( {")) {
			return new HashMap<>();
		}
		String[] s1 = tokenResult.split("&");
		Map<String, String> resultMap = new HashMap<>();
		for (String s2Tem : s1) {
			String[] kvarray = s2Tem.split("=");
			resultMap.put(kvarray[0], kvarray[1]);
		}
		return resultMap;
	}

	private String getCallBackEncUrl() {

		// StringBuffer urlBuf = new StringBuffer();
		// urlBuf.append(qqModule.getCallBackUrl()).append("?successurl=").append(successUrl);
		return encode(qqModule.getCallBackUrl());
	}

	private String encode(String par) {

		String ourUrlenc = null;
		try {
			ourUrlenc = URLEncoder.encode(par, "UTF-8");
		} catch (UnsupportedEncodingException e) {
		}
		return ourUrlenc;
	}

	@Override
	public Map<String, Object> getSystemAppInfo() {

		Map<String, Object> resMap = new HashMap<>();
		resMap.put("app_id", qqModule.getAppId());
		return resMap;
	}
}
