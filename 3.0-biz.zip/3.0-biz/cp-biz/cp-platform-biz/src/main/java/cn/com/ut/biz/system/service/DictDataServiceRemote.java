package cn.com.ut.biz.system.service;

import java.util.List;
import java.util.Map;

/**
 * 字典项（对外接口）
 * 
 * @author lanbin
 */
public interface DictDataServiceRemote {

	/**
	 * 查询平台的指定单个字典类型下所有(启用的)字典项 （对外接口）
	 * 
	 * @param platformId
	 *            平台ID
	 * @param dictTypeCode
	 *            字典类型code
	 * @return
	 */
	List<Map<String, Object>> findDictDataExt(String dictTypeCode);

	/**
	 * 查询平台所有字典类型下的字典项（对外接口）
	 * 
	 * @param platformId
	 * @return
	 */
	List<Map<String, Object>> findDictDataExt();

	/**
	 * 查询平台指定多个类型查询字典项（对外接口）
	 *
	 * @param platformId
	 * @return
	 */
	List<Map<String, Object>> findDictDataExt(List<Object> dictTypeCode);
}
