package cn.com.ut.biz.permission.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 用户分组与用户关系实体
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public class UserGroupAndUser extends BaseEntity {

	private static final long serialVersionUID = 6767600409570381914L;
	/**
	 * 用户id
	 */
	public static final String user_id = "user_id";
	/**
	 * 分组id
	 */
	public static final String group_id = "group_id";
}