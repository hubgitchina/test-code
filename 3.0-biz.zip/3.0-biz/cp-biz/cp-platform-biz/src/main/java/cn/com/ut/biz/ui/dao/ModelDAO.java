
//-----------------------------DAO start---------------------------------//
package cn.com.ut.biz.ui.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.ui.entities.Model;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface ModelDAO extends JdbcOperation<Model> {

}
//-----------------------------DAO end---------------------------------//