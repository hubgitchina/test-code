package cn.com.ut.biz.developer.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.developer.dao.DevInfoDAO;
import cn.com.ut.biz.developer.entities.DevInfo;
import cn.com.ut.biz.developer.service.DevInfoService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 开发者信息业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Service
public class DevInfoServiceImpl implements DevInfoService {

	@Autowired
	private DevInfoDAO devInfoDAO;

	@Override
	public String create(Map<String, Object> vo) {

		// 开发者ID，暂时先用UUID
		String devId = CommonUtil.getUUID();
		vo.put(DevInfo.dev_id, devId);

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, DevInfo.corp_name, DevInfo.link_man,
				DevInfo.link_email, DevInfo.link_phone, DevInfo.license_code,
				DevInfo.organization_code, DevInfo.tax_code, DevInfo.dev_id);

		boolean isCanAdd = devInfoDAO.checkUnique(new String[] { DevInfo.corp_name },
				new Object[] { vo.get(DevInfo.corp_name) }, null, null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("企业名称重复");
		}

		String entityId = devInfoDAO.insert(vo);

		return entityId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, DevInfo.idx, DevInfo.corp_name, DevInfo.link_man,
				DevInfo.link_email, DevInfo.link_phone, DevInfo.license_code,
				DevInfo.organization_code, DevInfo.tax_code);
		String id = (String) vo.get(DevInfo.idx);
		boolean isCanUpdate = devInfoDAO.checkUnique(new String[] { DevInfo.corp_name },
				new Object[] { vo.get(DevInfo.corp_name) }, new String[] { DevInfo.idx },
				new Object[] { id });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("企业名称重复");
		}

		devInfoDAO.update(vo);
		return id;
	}

	@Override
	public Map<String, Object> getDetail(String id) {

		ValidatorUtil.requiredFieldMiss(new Object[] { id });

		return devInfoDAO.getById(null, null,
				new String[] { DevInfo.idx, DevInfo.corp_name, DevInfo.link_man, DevInfo.link_email,
						DevInfo.link_phone, DevInfo.license_code, DevInfo.organization_code,
						DevInfo.tax_code, DevInfo.tax_append, DevInfo.dev_id, DevInfo.status,
						DevInfo.license_append, DevInfo.organization_append, DevInfo.tax_append,
						DevInfo.audit_result },
				null, id);
	}

	@Override
	public void delete(String id) {

		devInfoDAO.delete(id);

		// appInfoDAO.deleteUpdateById(null, new String[] { AppInfo.update_time
		// },
		// new Object[] { ConstantUtil.FLAG_YES, DateTimeUtil.currentDateTime()
		// }, id);
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		return devInfoDAO.findAllPage(page);
	}

	@Override
	public int submitExamine(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, DevInfo.idx);
		return devInfoDAO.submitExamine(vo);
	}

	@Override
	public int examineDevInfo(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, DevInfo.idx, DevInfo.audit_operator,
				DevInfo.audit_result);
		return devInfoDAO.examineDevInfo(vo);
	}

	@Override
	public Map<String, Object> getDevInfoByUser(User user) {

		return devInfoDAO.getDevInfoByUser(user);
	}

	@Override
	public int confirmUpdate(String id) {

		return devInfoDAO.confirmUpdate(id);
	}
}
