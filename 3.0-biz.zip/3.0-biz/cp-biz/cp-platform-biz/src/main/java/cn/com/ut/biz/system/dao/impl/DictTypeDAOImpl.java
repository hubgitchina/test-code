package cn.com.ut.biz.system.dao.impl;

import static cn.com.ut.biz.system.entities.DictType.dicttype_code;
import static cn.com.ut.biz.system.entities.DictType.dicttype_des;
import static cn.com.ut.biz.system.entities.DictType.dicttype_text;
import static cn.com.ut.biz.system.entities.DictType.group_code;
import static cn.com.ut.biz.system.entities.DictType.sort_num;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.system.dao.DictTypeDAO;
import cn.com.ut.biz.system.entities.DictData;
import cn.com.ut.biz.system.entities.DictType;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ArrayUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

@Repository
public class DictTypeDAOImpl extends JdbcOperationsImpl<DictType> implements DictTypeDAO {

	private static final String[] COLUMNS = { dicttype_code, dicttype_text, group_code,
			BaseEntity.is_use, sort_num, dicttype_des };
	private String T_DICTDATA;
	private String T_DICTTYPE;
	{
		T_DICTDATA = getTable(DictData.class);
		T_DICTTYPE = getTable(DictType.class);
	}

	/**
	 * 插入一条记录
	 * 
	 * @param vo
	 */
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	/**
	 * 更新一条记录
	 * 
	 * @param vo
	 */
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

	/**
	 * 获取一条记录
	 * 
	 * @param id
	 * @return
	 */
	public Map<String, Object> get(String id) {

		return getById(null, null, COLUMNS, NAMES, id);
	}

	/**
	 * 分页查询
	 * 
	 * @param page
	 * @return
	 */
	public List<Map<String, Object>> query(PageBean page) {

		return query(page, null, null, null, null, new String[] { DictType.is_del },
				new Object[] { "N" });
	}

	@Override
	public boolean isDictTypeCodeRepeat(String dictTypeCode, String[] pkFieldNames,
			Object[] pkFieldValues) {

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT 1 FROM ").append(T_DICTTYPE).append(" biz ")
				.append(" WHERE biz.dicttype_code = ? ");
		List<Object> args = new ArrayList<>();
		args.add(dictTypeCode);
		if (pkFieldNames != null && pkFieldNames.length > 0 && pkFieldValues != null) {
			sql.append(" AND (");
			sql.append(ArrayUtil.joinArrayElement(pkFieldNames, " OR ", "biz.", " <> ? "));
			sql.append(")");
			CollectionUtil.addArrayToCollection(pkFieldValues, args);
		}
		List<Map<String, Object>> list = query(getJdbcTemplate(), sql.toString(), null,
				args.toArray());
		return !CollectionUtil.isEmptyCollection(list);
	}

	@Override
	public List<Map<String, Object>> findByPlatformId(PageBean page) {

		StringBuilder table = new StringBuilder();
		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.appendColumns("biz", COLUMNS);
		parameterBuilder.appendColumns("biz", idx);
		table.append(T_DICTTYPE).append(" biz ");
		return queryPage(page, null, table.toString(), false, parameterBuilder.toColumns(), null,
				new String[] { "biz." + DictType.is_del }, null, null, null,
				new Object[] { ConstantUtil.FLAG_NO });
	}

	@Override
	public Map<String, Object> getDetail(String dictTypeId) {

		SQLHelper table = SQLHelper.builder();
		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.appendColumns("biz", COLUMNS);
		parameterBuilder.appendColumns("biz", idx);
		table.append(T_DICTTYPE).append(" biz ");
		return get(null, table.toSQL(), false, parameterBuilder.toColumns(), null,
				new String[] { "biz." + idx }, null, null, new Object[] { dictTypeId });
	}
}
