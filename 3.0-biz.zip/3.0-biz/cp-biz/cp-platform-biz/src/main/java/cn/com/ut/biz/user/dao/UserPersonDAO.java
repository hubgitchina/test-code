package cn.com.ut.biz.user.dao;

import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 用户信息管理数据层接口
 * 
 */
public interface UserPersonDAO extends JdbcOperation<UserPerson> {

}
