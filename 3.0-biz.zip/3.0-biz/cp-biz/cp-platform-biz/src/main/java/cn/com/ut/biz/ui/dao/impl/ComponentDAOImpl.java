package cn.com.ut.biz.ui.dao.impl;

import cn.com.ut.biz.ui.dao.ComponentDAO;
import cn.com.ut.biz.ui.entities.Component;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import org.springframework.stereotype.Repository;

import static cn.com.ut.biz.ui.entities.Component.*;

import java.util.Map;

/**
 * Created by zhouquanguo on 2018/4/25.
 */
@Repository
public class ComponentDAOImpl extends JdbcOperationsImpl<Component> implements ComponentDAO {


    private String T_COMPONENT;

    {
        T_COMPONENT = getTable(Component.class);
    }

    private static final String[] COLUMNS = {comp_name, comp_desc, comp_preview, comp_meta,
    };


    public String add(Map<String, Object> vo) {
        String id = CommonUtil.getUUID();
        add(null, COLUMNS, NAMES_ID_CT_CID, ParameterBuilder.builder().append(vo, COLUMNS)
                .append(id, DateTimeUtil.currentDateTime(), vo.get(Component.create_id)).toArray());
        return id;
    }


    public int update(Map<String, Object> vo) {
        return updateById(null, COLUMNS, NAMES_UT_UID, null,
                ParameterBuilder.builder().append(vo, COLUMNS)
                        .append(DateTimeUtil.currentDateTime(), vo.get(Component.update_id)).toArray(),
                (String) vo.get(Component.idx), cachedParameter);
    }


}
