package cn.com.ut.biz.user.dao;

import cn.com.ut.biz.user.entities.UserPVocation;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 用户工作经历
 * 
 */
public interface UserPVocationDAO extends JdbcOperation<UserPVocation> {

}
