package cn.com.ut.biz.system.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class DictType extends BaseEntity {

	private static final long serialVersionUID = 5441771982121209080L;

	public static final String dicttype_code = "dicttype_code";
	public static final String dicttype_text = "dicttype_text";
	public static final String dicttype_des = "dicttype_des";
	public static final String parent_code = "parent_code";
	public static final String group_code = "group_code";
	public static final String sort_num = "sort_num";


}
