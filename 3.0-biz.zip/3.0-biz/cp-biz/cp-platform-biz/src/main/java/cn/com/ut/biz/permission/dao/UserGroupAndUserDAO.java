package cn.com.ut.biz.permission.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 用户分组与用户关系管理数据层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface UserGroupAndUserDAO extends JdbcOperation<UserGroupAndUser> {

	/**
	 * 删除指定分组与指定用户关系
	 * 
	 * @param groupId
	 * @param users
	 * @return 影响的记录数
	 */
	int deleteUserGroupAndUser(String groupId, List<String> users);

	/**
	 * 获取用户所在组列表
	 * 
	 * @param pageBean
	 * @param userId
	 * @return 用户所在组列表
	 */
	List<Map<String, Object>> listUserRefGroups(PageBean pageBean, String userId);

	/**
	 * 删除存在于多个组的子账户
	 * 
	 * @param id
	 * @param userId
	 */
	void deleteEntAccountRepeat(String id, String userId);

	/**
	 * 删除重复的用户分组与用户关系
	 * 
	 * @param id
	 * @param userId
	 * @param groupId
	 */
	void deleteUserGroupAndUserRepeat(String id, String userId, String groupId);
}
