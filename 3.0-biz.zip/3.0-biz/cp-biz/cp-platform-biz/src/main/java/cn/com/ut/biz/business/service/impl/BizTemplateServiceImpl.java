package cn.com.ut.biz.business.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;

import cn.com.ut.biz.app.entities.AppTmp;
import cn.com.ut.biz.business.dao.BizTemplateDAO;
import cn.com.ut.biz.business.dao.BizTmpEntityDAO;
import cn.com.ut.biz.business.entities.BizTemplate;
import cn.com.ut.biz.business.entities.BizTmpEntity;
import cn.com.ut.biz.business.service.BizEntityService;
import cn.com.ut.biz.business.service.BizTemplateService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 业务实例业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Service
public class BizTemplateServiceImpl implements BizTemplateService {

	@Autowired
	private BizTemplateDAO bizTemplateDAO;

	@Autowired
	private BizTmpEntityDAO bizTmpEntityDAO;

	@Autowired
	private BizEntityService bizEntityService;

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		// entity_ids为选中业务实体ID集合字符串，通过逗号“,”拼接
		ValidatorUtil.validateMapContainsKey(vo, BizTemplate.temp_name, BizTemplate.tmp_type,
				"entity_ids");

		boolean isCanAdd = bizTemplateDAO.checkUnique(
				new String[] { BizTemplate.temp_name, BizTemplate.tmp_type },
				new Object[] { vo.get(BizTemplate.temp_name), vo.get(BizTemplate.tmp_type) }, null,
				null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("业务实例名称重复");
		}
		String templateId = bizTemplateDAO.insert(vo);

		String entityIds = TypeConvert.getStringValue(vo.get("entity_ids"));
		String[] entityIdArray = entityIds.split(",");
		List<Map<String, Object>> entityVos = new ArrayList<>(entityIdArray.length);
		Timestamp now = DateTimeUtil.currentDateTime();
		for (String entityId : entityIdArray) {
			if (CommonUtil.isEmpty(entityId)) {
				ExceptionUtil.throwServiceException("业务实体ID错误");
			}
			Map<String, Object> entityVo = Maps.newHashMapWithExpectedSize(7);
			entityVo.put(BizTmpEntity.idx, CommonUtil.getUUID());
			entityVo.put(BizTmpEntity.tmp_id, templateId);
			entityVo.put(BizTmpEntity.entity_id, entityId);
			entityVo.put(BizTmpEntity.create_id, vo.get(BizTemplate.create_id));
			entityVo.put(BizTmpEntity.create_time, now);
			entityVo.put(BizTmpEntity.update_id, vo.get(BizTemplate.create_id));
			entityVo.put(BizTmpEntity.update_time, now);
			entityVos.add(entityVo);
		}
		String[] names = new String[] { BizTmpEntity.idx, BizTmpEntity.tmp_id,
				BizTmpEntity.entity_id, BizTmpEntity.create_id, BizTmpEntity.create_time,
				BizTmpEntity.update_id, BizTmpEntity.update_time };
		bizTmpEntityDAO.addVoBatch(null, names, null, entityVos);
		return templateId;
	}

	@Override
	public String createByTemplate(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		// entity_ids为选中业务实体ID集合字符串，通过逗号“,”拼接
		ValidatorUtil.validateMapContainsKey(vo, BizTemplate.temp_name, BizTemplate.tmp_type,
				"template_ids");

		boolean isCanAdd = bizTemplateDAO.checkUnique(
				new String[] { BizTemplate.temp_name, BizTemplate.tmp_type },
				new Object[] { vo.get(BizTemplate.temp_name), vo.get(BizTemplate.tmp_type) }, null,
				null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("业务实例名称重复");
		}
		String templateId = bizTemplateDAO.insert(vo);

		String templateIds = TypeConvert.getStringValue(vo.get("template_ids"));
		List<Map<String, Object>> entityVos = bizTmpEntityDAO
				.findEntityByTmpIds(Arrays.asList(templateIds.split(",")));
		if (CollectionUtil.isEmptyCollection(entityVos)) {
			ExceptionUtil.throwServiceException("业务模板下业务实体为空");
		}
		Timestamp now = DateTimeUtil.currentDateTime();
		for (Map<String, Object> map : entityVos) {
			map.put(BizTmpEntity.idx, CommonUtil.getUUID());
			map.put(BizTmpEntity.tmp_id, templateId);
			map.put(BizTmpEntity.create_id, vo.get(BizTemplate.create_id));
			map.put(BizTmpEntity.create_time, now);
			map.put(BizTmpEntity.update_id, vo.get(BizTemplate.create_id));
			map.put(BizTmpEntity.update_time, now);
		}
		String[] names = new String[] { BizTmpEntity.idx, BizTmpEntity.tmp_id,
				BizTmpEntity.entity_id, BizTmpEntity.create_id, BizTmpEntity.create_time,
				BizTmpEntity.update_id, BizTmpEntity.update_time };
		bizTmpEntityDAO.addVoBatch(null, names, null, entityVos);
		return templateId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		// entity_ids为选中业务实体ID集合字符串，通过逗号“,”拼接
		ValidatorUtil.validateMapContainsKey(vo, BizTemplate.idx, BizTemplate.temp_name);
		String templateId = TypeConvert.getStringValue(vo.get(BizTemplate.idx));
		boolean isCanUpdate = bizTemplateDAO.checkUnique(
				new String[] { BizTemplate.temp_name, BizTemplate.tmp_type },
				new Object[] { vo.get(BizTemplate.temp_name), vo.get(BizTemplate.tmp_type) },
				new String[] { BizTemplate.idx }, new Object[] { templateId });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("业务实例名称重复");
		}
		bizTemplateDAO.update(vo);
		String addIds = TypeConvert.getStringValue(vo.get("add_ids"));
		String delIds = TypeConvert.getStringValue(vo.get("del_ids"));
		if (!CommonUtil.isEmpty(addIds)) {
			String[] entityIds = addIds.split(",");
			List<Map<String, Object>> entityVos = new ArrayList<>(entityIds.length);
			Timestamp now = DateTimeUtil.currentDateTime();
			for (String entityId : entityIds) {
				if (CommonUtil.isEmpty(entityId)) {
					ExceptionUtil.throwServiceException("业务实体ID错误");
				}
				Map<String, Object> entityVo = Maps.newHashMapWithExpectedSize(7);
				entityVo.put(BizTmpEntity.idx, CommonUtil.getUUID());
				entityVo.put(BizTmpEntity.tmp_id, templateId);
				entityVo.put(BizTmpEntity.entity_id, entityId);
				entityVo.put(BizTmpEntity.create_id, vo.get(BizTemplate.update_id));
				entityVo.put(BizTmpEntity.create_time, now);
				entityVo.put(BizTmpEntity.update_id, vo.get(BizTemplate.update_id));
				entityVo.put(BizTmpEntity.update_time, now);
				entityVos.add(entityVo);
			}
			String[] names = new String[] { BizTmpEntity.idx, BizTmpEntity.tmp_id,
					BizTmpEntity.entity_id, BizTmpEntity.create_id, BizTmpEntity.create_time,
					BizTmpEntity.update_id, BizTmpEntity.update_time };
			bizTmpEntityDAO.addVoBatch(null, names, null, entityVos);
		}
		if (!CommonUtil.isEmpty(delIds)) {
			String[] entityIds = delIds.split(",");
			// bizTmpEntityDAO.deleteBatch(Arrays.asList(entityIds),
			// BizTmpEntity.entity_id);

			// 批量删除当前模板下关联的业务实体
			Object[] params = new Object[entityIds.length + 1];
			params[0] = templateId;
			for (int i = 0; i < entityIds.length; i++) {
				params[i + 1] = entityIds[i];
			}
			bizTmpEntityDAO.delete(null, new String[] { BizTmpEntity.tmp_id },
					BizTmpEntity.entity_id + SQLHelper.IN_REPLACE, new int[] { entityIds.length },
					params, null);
		}
		return templateId;
	}

	@Override
	public List<Map<String, Object>> findAll(String tmpType) {

		String[] whereColumn = null;
		Object[] parameterArray = null;
		if (CommonUtil.isEmpty(tmpType)) {
			whereColumn = new String[] { BizTemplate.is_del };
			parameterArray = new Object[] { ConstantUtil.FLAG_NO };
		} else {
			whereColumn = new String[] { BizTemplate.tmp_type, BizTemplate.is_del };
			parameterArray = new Object[] { tmpType, ConstantUtil.FLAG_NO };
		}
		String[] names = { BizTemplate.idx, BizTemplate.temp_name, BizTemplate.tmp_desc };
		return bizTemplateDAO.queryPage(null, null, null, false, names, null, whereColumn, null,
				null, BizTemplate.create_time, parameterArray);
	}

	@Override
	public List<Map<String, Object>> findTmpEntityByUser(Map<String, Object> vo) {

		List<Map<String, Object>> tmpEntityList = bizTemplateDAO.findTmpEntityByUser(vo);
		if (CollectionUtil.isEmptyCollection(tmpEntityList)) {
			ExceptionUtil.throwValidateException("业务模板不存在");
		}

		List<Map<String, Object>> newTmpEntityList = new ArrayList<>();
		String tmpId = "";
		String tmpName = "";
		List<Map<String, Object>> entityList = new ArrayList<>();
		for (int i = 0; i < tmpEntityList.size(); i++) {
			Map<String, Object> map = tmpEntityList.get(i);
			String curTmpId = (String) map.get("tmp_id");
			String curTmpName = (String) map.get("temp_name");
			String curEntityId = (String) map.get("entity_id");
			String curEntityName = (String) map.get("entity_name");
			Map<String, Object> entityMap = Maps.newHashMapWithExpectedSize(2);
			entityMap.put("entity_id", curEntityId);
			entityMap.put("entity_name", curEntityName);
			if (CommonUtil.isEmpty(tmpName)) {
				tmpId = curTmpId;
				tmpName = curTmpName;
				entityList.add(entityMap);
			} else if (tmpName.equals(curTmpName)) {
				entityList.add(entityMap);
			}

			// 当前实体名称curTmpName不等于上一个已记录的实例名称tmpName时，证明以循环到下一个实体所包含的接口，添加之前的数据到map中
			if (!tmpName.equals(curTmpName)) {
				List<Map<String, Object>> tmpList = new ArrayList<>(entityList.size());
				tmpList.addAll(entityList);

				Map<String, Object> teMap = Maps.newLinkedHashMapWithExpectedSize(3);
				teMap.put("tmp_id", tmpId);
				teMap.put("temp_name", tmpName);
				teMap.put("entity_list", tmpList);
				newTmpEntityList.add(teMap);

				tmpId = curTmpId;
				tmpName = curTmpName;
				entityList.clear();
				entityList.add(entityMap);
			}

			// 循环到最后一个元素，即完成最后一个实体锁包含接口的遍历，将该实体接口集合加入map
			if (i == (tmpEntityList.size() - 1)) {
				Map<String, Object> tmpEntityMap = Maps.newLinkedHashMapWithExpectedSize(3);
				tmpEntityMap.put("tmp_id", tmpId);
				tmpEntityMap.put("temp_name", tmpName);
				tmpEntityMap.put("entity_list", entityList);
				newTmpEntityList.add(tmpEntityMap);
			}
		}
		return newTmpEntityList;
	}

	@Override
	public List<Map<String, Object>> getDetail(String templateId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { templateId });

		List<Map<String, Object>> tmpEntityList = bizTmpEntityDAO.queryPage(null, null, null, false,
				new String[] { BizTmpEntity.idx, BizTmpEntity.entity_id }, null,
				new String[] { BizTmpEntity.tmp_id }, null, null, null,
				new Object[] { templateId });
		List<Map<String, Object>> entityApiList = bizEntityService.findAllEntityAndAPI();
		if (!CollectionUtil.isEmptyCollection(tmpEntityList)) {
			// 循环业务实体和当前业务实例包含的业务实体，相同则添加标识is_choose为1，表示该业务实体被选中
			for (Map<String, Object> map : entityApiList) {
				for (Map<String, Object> tmpMap : tmpEntityList) {
					String entityId = (String) map.get(BizTmpEntity.entity_id);
					String tmpEntityId = (String) tmpMap.get(BizTmpEntity.entity_id);
					if (entityId.equals(tmpEntityId)) {
						map.put("is_choose", "1");
					}
				}
			}
		}
		return entityApiList;
	}

	@Override
	public void delete(String templateId) {

		bizTemplateDAO.delete(templateId);
	}

	@Override
	public int existTemplate(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, BizTemplate.temp_name);

		boolean isCanAdd = false;
		if (CommonUtil.isEmpty(vo, new String[] { BizTemplate.idx })) {
			isCanAdd = bizTemplateDAO.checkUnique(
					new String[] { BizTemplate.temp_name, BizTemplate.tmp_type },
					new Object[] { vo.get(BizTemplate.temp_name), ConstantUtil.FLAG_ZERO }, null,
					null);
		} else {
			isCanAdd = bizTemplateDAO.checkUnique(
					new String[] { BizTemplate.temp_name, BizTemplate.tmp_type },
					new Object[] { vo.get(BizTemplate.temp_name), ConstantUtil.FLAG_ZERO },
					new String[] { BizTemplate.idx }, new Object[] { vo.get(BizTemplate.idx) });
		}
		if (isCanAdd) {
			return 0;
		} else {
			return 1;
		}

	}

	@Override
	public int existAppTemplate(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, AppTmp.app_id, BizTemplate.temp_name);

		SQLHelper sqlHelper = SQLHelper.builder();
		sqlHelper.append(bizTemplateDAO.getTable()).append("bt")
				.append("LEFT JOIN t_app_tmp a ON bt.id = a.tmp_id");

		String appId = (String) vo.get(AppTmp.app_id);
		String tempName = (String) vo.get(BizTemplate.temp_name);

		boolean isCanAdd = false;
		if (CommonUtil.isEmpty(vo, new String[] { BizTemplate.idx })) {
			isCanAdd = bizTemplateDAO.checkUnique(sqlHelper.toSQL(), null,
					new String[] { "a.app_id", "bt.temp_name" }, new Object[] { appId, tempName },
					null, null);
		} else {
			isCanAdd = bizTemplateDAO.checkUnique(sqlHelper.toSQL(), null,
					new String[] { "a.app_id", "bt.temp_name" }, new Object[] { appId, tempName },
					new String[] { "bt.id" }, new Object[] { vo.get(BizTemplate.idx) });
		}
		if (isCanAdd) {
			return 0;
		} else {
			return 1;
		}
	}
}
