package cn.com.ut.biz.user.dao;

import cn.com.ut.biz.user.entities.ThirdUser;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 第三方用户关联信息
 * 
 */
public interface ThirdUserDAO extends JdbcOperation<ThirdUser> {

}
