package cn.com.ut.biz.user.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;

/**
 * 用户管理业务层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface UserService {

	/**
	 * 列出指定用户拥有的用户组集合
	 * 
	 * @param pageBean
	 * @param userId
	 *            指定用户
	 * @return
	 */
	List<Map<String, Object>> listUserRefGroups(PageBean pageBean, String userId);

	/**
	 * 获取用户关联的角色
	 * 
	 * @param pageBean
	 * @param userId
	 *            用户ID
	 * @return
	 */
	List<Map<String, Object>> listUserRefRoles(PageBean pageBean, String userId);
	
	
	
	/**
	 * 根据电话号码注册用户
	 * 
	 * @param vo
	 * @return
	 */
	String registerByMobile(Map<String, Object> vo);

	/**
	 * 根据用户名密码注册
	 * 
	 * @param vo
	 * @return
	 */
	String registerByUserName(Map<String, Object> vo);

	/**
	 * 根据手机和手机验证码登录
	 * 
	 * @param user
	 * @param loginByMobileMap
	 */
	void login(User user, Map<String, Object> loginByMobileMap);

	/**
	 * 用户名/手机 密码登录
	 * 
	 * @param user
	 * @param loginByPwd
	 * @param checkWrongTime
	 *            是否需要验证登录错误次数
	 */
	void loginByPwd(User user, Map<String, Object> loginByPwd, boolean checkWrongTime);

	/**
	 * 退出登录
	 * 
	 * @param user
	 */
	void loginOut(String sessionId);

	/**
	 * 把用户写入缓存 刷新token时候用到
	 * 
	 * @param user
	 * @param subject
	 * @param lt
	 */
	void getLoginUserByUserId(User user, String subject, Long lt);

	/**
	 * 判断用户是否锁定
	 * 
	 * @param userName
	 * @return
	 */
	int accountLockCheck(String userName);

	/**
	 * 根据手机和手机验证码登录 用户不存在则注册用户
	 * 
	 * @param user
	 * @param loginByMobileMap
	 */
	void loginR(User user, Map<String, Object> loginByMobileMap);

	/**
	 * QQ第三方登录
	 * 
	 * @param user
	 * @param openId
	 * @param accessToken
	 */
	void qqLogin(User user, String userFrom, String subject, String openId, String accessToken,
			Long lt);

	/**
	 * 微信第三方登录
	 * 
	 * @param user
	 * @param userFrom
	 * @param subject
	 * @param openId
	 * @param accessToken
	 * @param lt
	 */
	void wechatLogin(User user, String userFrom, String subject, String openId, String accessToken,
			Long lt);

	/**
	 * 新浪微博第三方登录
	 * 
	 * @param user
	 * @param userFrom
	 * @param subject
	 * @param openId
	 * @param accessToken
	 * @param lt
	 */
	void sinaWBLogin(User user, String userFrom, String subject, String openId, String accessToken,
			Long lt);

	/**
	 * 获取用户信息
	 * 
	 * @param userid
	 * @return
	 */
	Map<String, Object> getUserByUserId(String userid);

	/**
	 * 根据sessionID获取登录用户信息
	 * 
	 * @param sessionId
	 * @return
	 */
	User getLoginUserBySessionId(String sessionId);

	/**
	 * 获取用户名
	 * 
	 * @param userIds
	 * @return
	 */
	List<Map<String, Object>> getUserName(List<Object> userIds);

	/**
	 * 修改用户名
	 * 
	 * @param userId
	 * @param userPic
	 * @return
	 */
	int updateUserName(String userId, String userName);

	/**
	 * 获取用户列表
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> getUserList(PageBean page);

	/**
	 * 根据类型获取第三方登录系统需要的key
	 * 
	 * @param type
	 * @return
	 */
	Map<String, Object> getThirdSystemInfo(String type);

	/**
	 * 修改用户昵称
	 * 
	 * @param userId
	 * @param nickName
	 * @return
	 */
	int updateUserNick(String userId, String nickName);

	/**
	 * 修改用户的密码
	 * 
	 * @param userId
	 * @param json
	 * @return
	 */
	int modifyPwd(String userId, Map<String, Object> json);

	/**
	 * 修改用户的手机
	 * 
	 * @param userId
	 * @param json
	 * @return
	 */
	int modifyMobile(User user, Map<String, Object> json);

	/**
	 * 绑定手机
	 * 
	 * @param userId
	 * @param vo
	 * @return
	 */
	int bindMobile(User user, Map<String, Object> vo);

	/**
	 * 检查用户登录错误次数
	 * 
	 * @param userName
	 *            用户名/手机号
	 * @param picCode
	 *            图片验证码
	 * @param sessionId
	 */
	void checkWrongLoginTime(String userName, String picCode, String sessionId);

	/**
	 * 记录周期内用户登录错误次数
	 * 
	 * @param userName
	 */
	void recordWrongLoginTime(String userName);

	/**
	 * 登录成功后操作
	 * 
	 * @param user
	 * @param userMap
	 * @param logonType
	 */
	void loginDo(User user, Map<String, Object> userMap, String logonType);

	/**
	 * 忘记密码
	 * 
	 * @param vo
	 */
	int forgetPwd(Map<String, Object> vo);

}
