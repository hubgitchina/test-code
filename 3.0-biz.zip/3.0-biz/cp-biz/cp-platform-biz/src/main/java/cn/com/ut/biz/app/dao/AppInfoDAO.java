package cn.com.ut.biz.app.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.app.entities.AppInfo;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 应用信息DAO
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface AppInfoDAO extends JdbcOperation<AppInfo> {
	/**
	 * 查询所有的应用信息（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);

	/**
	 * 为应用生成新的ACCESS_KEY
	 * 
	 * @param vo
	 * @return
	 */
	int generateAccessKey(Map<String, Object> vo);

	/**
	 * 审核应用信息
	 * 
	 * @param vo
	 * @return
	 */
	int examineAppInfo(Map<String, Object> vo);

	/**
	 * 提交审核
	 * 
	 * @param vo
	 * @return
	 */
	int submitExamine(Map<String, Object> vo);

	/**
	 * 确认修改审核资料
	 * 
	 * @param id
	 * @return
	 */
	int confirmUpdate(String id);

	/**
	 * 应用上线
	 * 
	 * @param vo
	 * @return
	 */
	int onlineApp(Map<String, Object> vo);

	/**
	 * 应用下线
	 * 
	 * @param vo
	 * @return
	 */
	int downlineApp(Map<String, Object> vo);
}