package cn.com.ut.biz.ui.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.ui.entities.Page;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 应用定制页面DAO
 * 
 * @author wangpeng1
 * @since 2018年5月15日
 */
public interface PageDAO extends JdbcOperation<Page> {

	/**
	 * 根据目录ID查询下面关联的所有子目录和子页面
	 * 
	 * @param dirId
	 * @return
	 */
	List<Map<String, Object>> getAllChild(String dirId);
}