package cn.com.ut.biz.app.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;

/**
 * 应用信息业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface AppInfoService {

	/**
	 * 创建应用
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新应用信息
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询应用AccessKey
	 */
	Map<String, Object> getAccessKey(String id);

	/**
	 * 查询应用信息详情
	 */
	Map<String, Object> getDetail(String id);

	/**
	 * 删除应用
	 * 
	 * @param id
	 * @param appId
	 */
	void delete(String id, String appId);

	/**
	 * 根据用户查询所有应用
	 * 
	 * @param user
	 * @return
	 */
	List<Map<String, Object>> findByUser(User user);

	/**
	 * 查询所有的应用信息（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);

	/**
	 * 为应用生成新的ACCESS_KEY
	 * 
	 * @param vo
	 * @return
	 */
	String generateAccessKey(Map<String, Object> vo);

	/**
	 * 审核应用信息
	 * 
	 * @param vo
	 * @return
	 */
	int examineAppInfo(Map<String, Object> vo);

	/**
	 * 提交审核
	 * 
	 * @param vo
	 * @return
	 */
	int submitExamine(Map<String, Object> vo);

	/**
	 * 确认修改审核资料
	 * 
	 * @param id
	 * @return
	 */
	int confirmUpdate(String id);

	/**
	 * 应用上线
	 * 
	 * @param vo
	 * @return
	 */
	int onlineApp(Map<String, Object> vo);

	/**
	 * 应用下线
	 * 
	 * @param vo
	 * @return
	 */
	int downlineApp(Map<String, Object> vo);

	/**
	 * 是否已存在同名应用
	 * 
	 * @param vo
	 * @return
	 */
	int existApp(Map<String, Object> vo);
}
