package cn.com.ut.common.constant.platform;

/**
 * 常量工具类
 * 
 * @author ouyuexing
 * @since 2013-10-10
 * @update 2015-12-4
 *
 */
public class ConstantUtil extends cn.com.ut.core.common.constant.ConstantUtil {

	/**
	 * 平台COde
	 */
	public interface PLATFORM_CODE {
		/**
		 * 基础数据平台
		 */
		String BASE_DATA = "BaseData";
		/**
		 * 用户信息服务平台
		 */
		String USER_CENTER = "UserCenter";
	}

	/**
	 * 密码登录失败计算周期
	 */
	public static final int LOGIN_WRONG_CYCLE = 60 * 15;

	/**
	 * 字典项文字
	 */
	public static final String dict_fix = "_text";
	/**
	 * 其他标识:Y
	 */
	public static final String FLAG_YES = "Y";
	/**
	 * 其他标识:N
	 */
	public static final String FLAG_NO = "N";
	/**
	 * 1
	 */
	public static final String FLAG_ONE = "1";
	/**
	 * 0
	 */
	public static final String FLAG_ZERO = "0";
	/**
	 * true
	 */
	public static final String FLAG_TRUE = "true";
	/**
	 * false
	 */
	public static final String FLAG_FALSE = "false";
	/**
	 * null
	 */
	public static final String STR_NULL = "null";
	/**
	 * 空串
	 */
	public static final String STR_EMPTY = "";
	/**
	 * 空格
	 */
	public static final String STR_SPACE = " ";
	/**
	 * 换行
	 */
	public static final String STR_ENTER = "\n";
	/**
	 * 随机字符串-仅限数字和字母; 排除数字0、1和9; 排除小写字母o,l,q; 排除大写字母I,O
	 */
	public static final String RANDOM_CHAR = "2345678abcdefghijkmnprstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ";
	/**
	 * 随机字符串-仅限数字0到9
	 */
	public static final String RANDOM_NUMBER = "0123456789";

	/**
	 * 字符集 UTF-8
	 */
	public static final String CHARSET_UTF8 = "UTF-8";
	/**
	 * 字符集 ISO-8859-1
	 */
	public static final String CHARSET_ISO = "ISO-8859-1";
	/**
	 * 字符集 GBK
	 */
	public static final String CHARSET_GBK = "GBK";
	/**
	 * 字符集 US-ASCII
	 */
	public static final String CHARSET_ASCII = "US-ASCII";

	/**
	 * 分页头信息字段 page
	 */
	public static final String PAGE = "page";
	/**
	 * 分页头信息字段 pageno
	 */
	public static final String PAGE_NO = "pageno";
	/**
	 * 分页头信息字段 pagesize
	 */
	public static final String PAGE_SIZE = "pagesize";
	/**
	 * 分页头信息字段 records
	 */
	public static final String RECORDS = "records";
	/**
	 * 分页头信息字段 total
	 */
	public static final String PAGE_TOTAL = "total";
	/**
	 * 分页头信息字段 pagegroup
	 */
	public static final String PAGE_GROUP = "pagegroup";

	/**
	 * 用户类型定义:普通用户
	 */
	public static final String USER_TYPE_PERSON = "P";
	/**
	 * 用户类型定义:企业用户
	 */
	public static final String USER_TYPE_ENTERPRISE = "E";
	/**
	 * 用户类型定义:企业用户
	 */
	public static final String USER_TYPE_ADMIN = "A";
	/**
	 * 用户类型定义:企业子账户
	 */
	public static final String USER_TYPE_SUB = "US";
	/**
	 * 用户类型定义:客服
	 */
	public static final String USER_TYPE_CUSTOMSERVICE = "C";
	/**
	 * 登录类型:主机登录
	 */
	public static final String USER_LOGON_TYPE_KM = "0";
	/**
	 * 登录类型:创作软件登陆
	 */
	public static final String USER_LOGON_TYPE_KW = "1";
	/**
	 * 登录类型:浏览器
	 */
	public static final String USER_LOGON_TYPE_IE = "B";

	/**
	 * 管理员权限
	 */
	public static final String ROLE_ADMIN = "0926e968eb7c43ffb6a7ae94ed5c5106";
	/**
	 * 系统客服权限
	 */
	public static final String ROLE_CUSTOMSERVICE_COMMON = "a5f81e461c9f40f898de1173aa1b990e";

	/**
	 * 逻辑关系或
	 */
	public static final String LOGIC_OR = "OR";
	/**
	 * 逻辑关系与
	 */
	public static final String LOGIC_AND = "AND";

	/**
	 * 超时设置，分钟
	 */
	public static final int RSA_TIMEOUT_MINUTES = 0;

	/**
	 * 会话标识
	 */
	public static final String SESSIONKEY = "sessionKey";

	/**
	 * 账号类型 0：用户名
	 */
	public static final int ACCOUNT_TYPE_USERNAME = 0;
	/**
	 * 账号类型 1：邮箱
	 */
	public static final int ACCOUNT_TYPE_EMAIL = 1;
	/**
	 * 账号类型 2：手机
	 */
	public static final int ACCOUNT_TYPE_MOBILE = 2;
	/**
	 * 账号类型 -1：其他
	 */
	public static final int ACCOUNT_TYPE_OTHER = -1;

	/**
	 * 默认账户密码
	 */
	public static final String DEFAULT_ACCOUNT_PWD = "123456";

	/**
	 * 系統开始时间
	 */
	public static final String SYSTEM_START_TIME = "2015-01-01 00:00:00";

	/**
	 * project远程项目
	 */
	public interface RPC_PROJRCT {

		/**
		 * 用户中心
		 */
		String USERCENTER = "rpc.project.usercenter";

		/**
		 * 第三方QQ登录
		 */
		String QQLOGIN = "user.login.qq";

		/**
		 * 第三方微信登录
		 */
		String WECHATLOGIN = "user.login.wechat";

		/**
		 * 第三方微信转跳
		 */
		String WECHATLOGINCODE = "user.login.wechat.code";

		/**
		 * 第三方新浪微博登录
		 */
		String SINAWEIBO = "user.login.sina.weibo";
	}

	/**
	 * 用户中心API
	 */
	public interface API_USERCENTER {

		/**
		 * 创建管理员用户
		 */
		String CREATE_ADMIN_USER = "/adminUser/createAdminUser";
		/**
		 * 管理员用户登录
		 */
		String ADMIN_USER_LOGIN = "/adminUser/login";
		/**
		 * 检查用户是否锁定
		 */
		String ACCOUNT_LOCK_CHECK = "/user/accountLockCheck";
		/**
		 * 退出登录
		 */
		String LOGINOUT = "/user/loginOut";
		/**
		 * 获取登录用户的信息
		 */
		String GET_LOGIN_USER_INFO = "/user/getLoginUser";
		/**
		 * 获取用户的详细信息
		 */
		String GET_USER_INFO = "/user/getUserInfo";
		/**
		 * 修改管理员用户密码
		 */
		String MODIFY_ADMIN_PWD = "/adminUser/modifyAdminPwd";
		/**
		 * 获取图片验证码
		 */
		String GET_PICVER = "/verification/getPicver";
		/**
		 * 批量获取用户信息
		 */
		String GET_USER_NAME = "/user/getUserName";
		/**
		 * 删除一个管理员
		 */
		String DELETE_ADMIN_USER = "/adminUser/deleteAdminUser";
		/**
		 * 删除一个或多个管理员
		 */
		String DELETE_ADMIN_USERS = "/adminUser/deleteAdminUsers";

	}

	/**
	 * 缓存前缀
	 */
	public interface CACHE_PREFIX {
		/**
		 * 图片
		 */
		String PIC_DEFAULT = "PIC_DEFAULT";

		/**
		 * 短信验证码注册
		 */
		String MOBILE_REGISTER = "MOBILE_REGISTER";

		/**
		 * 短信验证码忘记密码
		 */
		String MOBILE_FORGETPWD = "MOBILE_FORGETPWD";

		/**
		 * 短信验证码手机验证码登录
		 */
		String MOBILE_LOGIN = "MOBILE_LOGIN";

		/**
		 * 用户登录错误记录前缀
		 */
		String LOGIN_WRONG_PWD_PREFIX = "LWPP";

		/**
		 * IP发送短信前缀
		 */
		String IP_SEND_MSG = "IP_SEND_MSG";

		/**
		 * 绑定手机
		 */
		String BIND_MOBILE = "BIND_MOBILE";

		/**
		 * 更换手机
		 */
		String MODIFY_MOBILE = "MODIFY_MOBILE";
	}

	/**
	 * 手机注册用户前缀
	 */
	public static final String USER_PHONE_FIX = "P_";

	/**
	 * 登录类型
	 */
	public interface THIRD_USER_FORM {

		/**
		 * QQ
		 */
		String QQ = "QQ";

		/**
		 * 微信
		 */
		String WECHAT = "WECHAT";

		/**
		 * 新浪微博
		 */
		String SINA_WEIBO = "SINA_WEIBO";
	}

	/**
	 * 注册用户类型
	 */
	public interface USER_TYPE {
		/**
		 * 普通个人用户
		 */
		String USER_TYPE_PERSON = "P";

		/**
		 * 平台管理员
		 */
		String USER_TYPE_ADMIN = "A";
	}

	/**
	 * session过期时间(秒)
	 */
	public interface SESSION_TIME {

		/**
		 * 默认
		 */
		int DEFAULT = 60 * 10;

	}

	/**
	 * 密码登录错误次数操作
	 */
	public interface LOGIN_WRONG_OPERATION {
		/**
		 * 用户锁定
		 */
		int USER_LOCK = 6;

		/**
		 * 需要验证码
		 */
		int USER_VERIFICATION_CODE = 3;
	}

	/**
	 * 验证码过期时间(秒)
	 */
	public interface VERIFICATION_TIME {
		/**
		 * 手机注册
		 */
		int MOBILE_REGISTER = 60 * 10;

		/**
		 * 图片验证码
		 */
		int PIC_DEFAULT = 60 * 2;

		/**
		 * 绑定手机
		 */
		int BIND_MOBILE = 60 * 10;

		/**
		 * 更换手机
		 */
		int MODIFY_MOBILE = 60 * 10;

		/**
		 * 手机验证码登录
		 */
		int MOBILE_LOGIN = 60 * 10;

		/**
		 * 手机验证码忘记密码
		 */
		int MOBILE_FORGETPWD = 60 * 10;

	}

	/**
	 * 短信验证码类型
	 */
	public interface MOBILEVER_TYPE {
		/**
		 * 注册
		 */
		String MOBILE_REGISTER = "MOBILE_REGISTER";

		/**
		 * 登录
		 */
		String MOBILE_LOGIN = "MOBILE_LOGIN";

		/**
		 * 绑定手机
		 */
		String BIND_MOBILE = "BIND_MOBILE";

		/**
		 * 更换手机
		 */
		String MODIFY_MOBILE = "MODIFY_MOBILE";

		/**
		 * 忘记密码
		 */
		String FORGET_PWD = "FORGET_PWD";
	}

	/**
	 * 登录类型
	 */
	public interface LOGIN_TYPE {

		/**
		 * app
		 */
		String APP = "app";

		/**
		 * pc
		 */
		String PC = "pc";

		/**
		 * 未登录用户
		 */
		String NOT_LOGIN = "default";
	}

	/**
	 * QQ第三方登录
	 */
	public interface API_QQLOGIN {

		/**
		 * 获取用户信息
		 */
		String GET_USER_INFO = "/user/get_user_info";

		/**
		 * 获取用户openID
		 */
		String GET_USER_OPENID = "/oauth2.0/me";

		/**
		 * 获取ACCESSTOKEN
		 */
		String GET_ACC_TOKEN = "/oauth2.0/token";

		/**
		 * 获取code
		 */
		String GET_CODE = "/oauth2.0/authorize";

	}

	/**
	 * 新浪微博第三方登录
	 */
	public interface API_SINAWEIBO {

		/**
		 * 获取CODE
		 */
		String GET_CODE = "/oauth2/authorize";

		/**
		 * 获取ACCESSTOKEN
		 */
		String GET_ACC_TOKEN = "/oauth2/access_token";

		/**
		 * 获取用户信息
		 */
		String GET_USER_INFO = "/2/users/show.json";

	}

	/**
	 * 微信第三方登录
	 */
	public interface API_WECHAT {

		/**
		 * 获取CODE
		 */
		String GET_CODE = "/connect/qrconnect";

		/**
		 * 获取ACCESSTOKEN
		 */
		String GET_ACC_TOKEN = "/sns/oauth2/access_token";

		/**
		 * 获取用户信息
		 */
		String GET_USER_INFO = "/sns/userinfo";

	}

	/**
	 * 应用状态
	 */
	public static interface ApplicationStatus {

		/**
		 * 已下线
		 */
		public static final String APP_DOWNLINE = "0";
		/**
		 * 已上线
		 */
		public static final String APP_ONLINE = "1";
		/**
		 * 已停用
		 */
		public static final String APP_STOP = "-1";

	}
}
