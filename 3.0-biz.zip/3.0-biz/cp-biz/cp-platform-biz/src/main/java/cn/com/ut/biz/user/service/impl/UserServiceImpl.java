package cn.com.ut.biz.user.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.permission.dao.RoleAndUserDAO;
import cn.com.ut.biz.permission.dao.UserGroupAndUserDAO;
import cn.com.ut.biz.user.dao.ThirdUserDAO;
import cn.com.ut.biz.user.dao.UserParentDAO;
import cn.com.ut.biz.user.dao.UserPersonDAO;
import cn.com.ut.biz.user.entities.ThirdUser;
import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.biz.user.service.ThirdQQUserService;
import cn.com.ut.biz.user.service.ThirdSinaWBUserService;
import cn.com.ut.biz.user.service.ThirdWechatUserService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.cache.CacheHelper;
import cn.com.ut.core.cache.session.SessionManagerImpl;
import cn.com.ut.core.common.exception.ValidateException;
import cn.com.ut.core.common.fs.api.FsOperation;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.file.util.FileUrlUtil;
import cn.com.ut.rpc.ThirdRestTemplate;
import cn.com.ut.util.NickNameUtil;

/**
 * 用户管理
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Service
public class UserServiceImpl implements UserService {

	@Resource
	private RoleAndUserDAO roleAndUserDAO;
	@Resource
	private UserGroupAndUserDAO userGroupAndUserDAO;

	@Autowired
	private ThirdRestTemplate thirdRestTemplate;

	@Resource
	private UserParentDAO userParentDAO;

	@Autowired
	private CacheHelper cacheHelper;
	@Autowired
	private ThirdQQUserService thirdQQUserService;
	@Autowired
	private ThirdWechatUserService thirdWechatUserService;
	@Autowired
	private ThirdSinaWBUserService thirdSinaWBUserService;

	@Autowired
	private FsOperation fsOperation;
	@Autowired
	private ThirdUserDAO thirdUserDAO;
	@Autowired
	private UserPersonDAO userPersonDAO;
	@Autowired
	private Environment env;

	@Override
	public List<Map<String, Object>> listUserRefGroups(PageBean pageBean, String userId) {

		// 用户只对应一个平台，所以不需要平台ID
		return userGroupAndUserDAO.listUserRefGroups(pageBean, userId);
	}

	@Override
	public List<Map<String, Object>> listUserRefRoles(PageBean pageBean, String userId) {

		// 用户只对应一个平台，所以不需要平台ID
		return roleAndUserDAO.listUserRefRoles(pageBean, userId);
	}

	@Override
	public void loginByPwd(User user, Map<String, Object> loginByPwd, boolean checkWrongTime) {

		if (CollectionUtil.isEmptyMap(loginByPwd)) {
			ExceptionUtil.throwValidateException("参数不能为空");
		}
		String userName = (String) loginByPwd.get("user_name");
		String userPwd = (String) loginByPwd.get("user_pwd");
		String loginType = (String) loginByPwd.get("login_type");
		if (CommonUtil.isEmpty(userName) || CommonUtil.isEmpty(userPwd)) {
			throw new ValidateException("用户名或密码不能为空！");
		}
		// 需要验证登录错误次数
		if (checkWrongTime) {
			String picCode = (String) loginByPwd.get("verification_code");
			checkWrongLoginTime(userName, picCode, user.getSessionId());
		}
		// String passwordMd5 = CommonUtil.encodeMD5(userPwd.getBytes());
		Map<String, Object> userMap = null;
		if (NumberUtil.checkMobileNumber(userName)) {
			userMap = userParentDAO.getUserInfoByMobile(userName, userPwd);
		} else {
			userMap = userParentDAO.getUserInfoByUserName(userName, userPwd);
		}
		if (CollectionUtil.isEmptyMap(userMap)) {
			recordWrongLoginTime(userName);
			ExceptionUtil.throwServiceException("用户名密码错误");
		}
		loginDo(user, userMap, loginType);

	}

	@Override
	public void checkWrongLoginTime(String userName, String picCode, String sessionId) {

		int temint = accountLockCheck(userName);
		// 需要验证码
		if (temint == 1) {
			// 验证图片验证码
			String cachePicCode = cacheHelper
					.get(cn.com.ut.common.constant.platform.ConstantUtil.CACHE_PREFIX.PIC_DEFAULT
							+ sessionId);
			if (CommonUtil.isEmpty(picCode) || !picCode.equals(cachePicCode)) {
				ExceptionUtil.throwValidateException("验证码错误");
			}
			cacheHelper
					.delete(cn.com.ut.common.constant.platform.ConstantUtil.CACHE_PREFIX.PIC_DEFAULT
							+ sessionId);
		}
		if (temint == 2) {
			ExceptionUtil.throwServiceException("该账号已经锁定");
		}
	}

	@Override
	public void recordWrongLoginTime(String userName) {

		String key = cn.com.ut.common.constant.platform.ConstantUtil.CACHE_PREFIX.LOGIN_WRONG_PWD_PREFIX
				+ userName;
		Integer wrongTime = cacheHelper.get(key);
		if (wrongTime == null) {
			cacheHelper.add(key, cn.com.ut.common.constant.platform.ConstantUtil.LOGIN_WRONG_CYCLE,
					1);
			return;
		}
		wrongTime = wrongTime + 1;
		cacheHelper.replace(key, cn.com.ut.common.constant.platform.ConstantUtil.LOGIN_WRONG_CYCLE,
				wrongTime);
	}

	@Override
	public void getLoginUserByUserId(User user, String subject, Long lt) {

		String userId = user.getUserId();
		Map<String, Object> userMap = userParentDAO.getUserInfoByUserId(userId);
		if (CollectionUtil.isEmptyMap(userMap)) {
			ExceptionUtil.throwServiceException("用户不存在");
		}
		user.setLogonType(subject);
		setUserByMap(user, userMap);
		cacheHelper.set(SessionManagerImpl.KEY_BEGIN_SESSION + user.getSessionId(),
				lt.intValue() + 10, user);
	}

	@Override
	public void login(User user, Map<String, Object> loginByMobileMap) {

		if (CollectionUtil.isEmptyMap(loginByMobileMap)) {
			ExceptionUtil.throwValidateException("参数不能为空");
		}
		String mobile = (String) loginByMobileMap.get("mobile");
		String mobileCode = (String) loginByMobileMap.get("mobile_code");
		String loginType = (String) loginByMobileMap.get("login_type");
		if (CommonUtil.isEmpty(loginType, mobileCode, mobile)) {
			ExceptionUtil.throwValidateException("参数不合法");
		}
		// 验证短信验证码
		String cachePhoneCode = cacheHelper.get(
				cn.com.ut.common.constant.platform.ConstantUtil.CACHE_PREFIX.MOBILE_LOGIN + mobile);
		if (!mobileCode.equals(cachePhoneCode)) {
			ExceptionUtil.throwServiceException("短信验证码不正确");
		}
		Map<String, Object> userMap = userParentDAO.getUserInfoByMobile(mobile);
		if (CollectionUtil.isEmptyMap(userMap)) {
			ExceptionUtil.throwServiceException("用户不存在");
		}
		loginDo(user, userMap, loginType);
	}

	@Override
	public void loginR(User user, Map<String, Object> loginByMobileMap) {

		if (CollectionUtil.isEmptyMap(loginByMobileMap)) {
			ExceptionUtil.throwValidateException("参数不能为空");
		}
		String mobile = (String) loginByMobileMap.get("mobile");
		String mobileCode = (String) loginByMobileMap.get("mobile_code");
		String loginType = (String) loginByMobileMap.get("login_type");
		if (CommonUtil.isEmpty(loginType, mobileCode, mobile)) {
			ExceptionUtil.throwValidateException("参数不合法");
		}
		// 验证短信验证码
		String cachePhoneCode = cacheHelper.get(
				cn.com.ut.common.constant.platform.ConstantUtil.CACHE_PREFIX.MOBILE_LOGIN + mobile);
		if (!mobileCode.equals(cachePhoneCode)) {
			ExceptionUtil.throwServiceException("短信验证码不正确");
		}
		Map<String, Object> userMap = userParentDAO.getUserInfoByMobile(mobile);
		if (CollectionUtil.isEmptyMap(userMap)) {
			// 创建用户
			userMap = new HashMap<>();
			String userName = CommonUtil.getUUID();
			boolean flag = userParentDAO.checkUnique(new String[] { UserParent.user_name },
					new Object[] { cn.com.ut.common.constant.platform.ConstantUtil.USER_PHONE_FIX
							+ mobile },
					null, null);
			if (flag) {
				userName = cn.com.ut.common.constant.platform.ConstantUtil.USER_PHONE_FIX + mobile;
			}
			userMap.put(UserParent.user_name, userName);
			userMap.put(UserParent.mobile, mobile);
			userMap.put(UserParent.is_locked,
					cn.com.ut.common.constant.platform.ConstantUtil.FLAG_NO);
			userMap.put(UserParent.is_del, cn.com.ut.common.constant.platform.ConstantUtil.FLAG_NO);
			userMap.put(UserParent.nick_name, NickNameUtil.getRoundName());
			// userMap.put(UserParent.user_pwd,
			// CommonUtil.encodeMD5(ConstantUtil.DEFAULT_ACCOUNT_PWD.getBytes()));
			userMap.put(UserParent.user_type,
					cn.com.ut.common.constant.platform.ConstantUtil.USER_TYPE.USER_TYPE_PERSON);
			String userId = userParentDAO.add(userMap);
			userMap.put(UserPerson.user_id, userId);
			userPersonDAO.add(userMap);
		}
		loginDo(user, userMap, loginType);
	}

	@Override
	public void qqLogin(User user, String userFrom, String subject, String openId,
			String accessToken, Long lt) {

		Map<String, Object> thirdUserMap = thirdUserDAO.getByKey(null, null,
				new String[] { ThirdUser.user_id }, null,
				new String[] { ThirdUser.open_id, ThirdUser.is_del, ThirdUser.user_from },
				new Object[] { openId, cn.com.ut.common.constant.platform.ConstantUtil.FLAG_NO,
						ConstantUtil.THIRD_USER_FORM.QQ },
				null);
		// 该用户已经在我们平台注册
		if (!CollectionUtil.isEmptyMap(thirdUserMap)) {
			String userId = (String) thirdUserMap.get(ThirdUser.user_id);
			user.setUserId(userId);
			getLoginUserByUserId(user, subject, lt);
			return;
		}
		// 用户未在我们平台注册
		// 调用接口获取QQ用户的信息
		Map<String, Object> thUserInfo = thirdQQUserService.getQQUserInfo(openId, accessToken);
		if (CollectionUtil.isEmptyMap(thUserInfo)) {
			ExceptionUtil.throwServiceException("获取QQ用户信息失败");
		}
		String sexT = (String) thUserInfo.get("gender");
		String sex = "W";
		if ("男".equals(sexT)) {
			sex = "M";
		}
		Map<String, Object> userMap = new HashMap<>();
		userMap.put(UserPerson.user_pic, thUserInfo.get("figureurl_2"));
		userMap.put(UserPerson.user_sex, sex);
		userMap.put(UserParent.nick_name, thUserInfo.get("nickname"));
		userMap.put(ThirdUser.user_from, userFrom);
		userMap.put(ThirdUser.open_id, openId);
		String userId = createThirdUser(userMap);
		user.setUserId(userId);
		getLoginUserByUserId(user, subject, lt);

	}

	@Override
	public void wechatLogin(User user, String userFrom, String subject, String openId,
			String accessToken, Long lt) {

		Map<String, Object> thirdUserMap = thirdUserDAO.getByKey(null, null,
				new String[] { ThirdUser.user_id }, null,
				new String[] { ThirdUser.open_id, ThirdUser.is_del, ThirdUser.user_from },
				new Object[] { openId, cn.com.ut.common.constant.platform.ConstantUtil.FLAG_NO,
						cn.com.ut.common.constant.platform.ConstantUtil.THIRD_USER_FORM.WECHAT },
				null);
		// 该用户已经在我们平台注册
		if (!CollectionUtil.isEmptyMap(thirdUserMap)) {
			String userId = (String) thirdUserMap.get(ThirdUser.user_id);
			user.setUserId(userId);
			getLoginUserByUserId(user, subject, lt);
			return;
		}
		// 用户未在我们平台注册
		// 调用接口获取微信用户的信息
		Map<String, Object> thUserInfo = thirdWechatUserService.getWechatUserInfo(openId,
				accessToken);
		int sexT = (int) thUserInfo.get("sex");
		String sex = "W";
		if (1 == sexT) {
			sex = "M";
		}
		Map<String, Object> userMap = new HashMap<>();
		userMap.put(UserPerson.user_pic, thUserInfo.get("headimgurl"));
		userMap.put(UserPerson.user_sex, sex);
		userMap.put(UserParent.nick_name, thUserInfo.get("nickname"));
		userMap.put(ThirdUser.user_from, userFrom);
		userMap.put(ThirdUser.open_id, openId);
		String userId = createThirdUser(userMap);
		user.setUserId(userId);
		getLoginUserByUserId(user, subject, lt);

	}

	@Override
	public void sinaWBLogin(User user, String userFrom, String subject, String openId,
			String accessToken, Long lt) {

		Map<String, Object> thirdUserMap = thirdUserDAO.getByKey(null, null,
				new String[] { ThirdUser.user_id }, null,
				new String[] { ThirdUser.open_id, ThirdUser.is_del, ThirdUser.user_from },
				new Object[] { openId, ConstantUtil.FLAG_NO,
						ConstantUtil.THIRD_USER_FORM.SINA_WEIBO },
				null);
		// 该用户已经在我们平台注册
		if (!CollectionUtil.isEmptyMap(thirdUserMap)) {
			String userId = (String) thirdUserMap.get(ThirdUser.user_id);
			user.setUserId(userId);
			getLoginUserByUserId(user, subject, lt);
			return;
		}
		// 用户未在我们平台注册
		// 调用接口获取微信用户的信息
		Map<String, Object> thUserInfo = thirdSinaWBUserService.getSinaWBUserInfo(openId,
				accessToken);
		if (thUserInfo.get("id") == null) {
			ExceptionUtil.throwServiceException("获取新浪微博用户信息失败");
		}
		String sexT = (String) thUserInfo.get("gender");
		String sex = "W";
		if ("m".equals(sexT)) {
			sex = "M";
		}
		Map<String, Object> userMap = new HashMap<>();
		userMap.put(UserPerson.user_pic, thUserInfo.get("profile_image_url"));
		userMap.put(UserPerson.user_sex, sex);
		userMap.put(UserParent.nick_name, thUserInfo.get("screen_name"));
		userMap.put(ThirdUser.user_from, userFrom);
		userMap.put(ThirdUser.open_id, openId);
		String userId = createThirdUser(userMap);
		user.setUserId(userId);
		getLoginUserByUserId(user, subject, lt);
	}

	private String createThirdUser(Map<String, Object> userMap) {

		String userName = CommonUtil.getUUID();
		userMap.put(UserParent.user_name, userName);
		userMap.put(UserParent.is_locked, ConstantUtil.FLAG_NO);
		userMap.put(UserParent.is_del, ConstantUtil.FLAG_NO);
		// userMap.put(UserParent.NICK_NAME, NickNameUtil.getRoundName());
		// userMap.put(UserParent.user_pwd,
		// CommonUtil.encodeMD5(ConstantUtil.DEFAULT_ACCOUNT_PWD.getBytes()));
		userMap.put(UserParent.user_type, ConstantUtil.USER_TYPE.USER_TYPE_PERSON);
		String userId = userParentDAO.add(userMap);
		userMap.put(UserPerson.user_id, userId);
		String userPic = (String) userMap.get(UserPerson.user_pic);
		if (CommonUtil.isNotEmpty(userPic)) {
			byte[] resBy = thirdRestTemplate.downLoadFile(userPic);
			if (resBy != null) {
				String fullFileName = FileUrlUtil.getFullFileName(userId, "tem.jpg");
				String ossUrl = FileUrlUtil.getOssUrl(fullFileName);
				userMap.put(UserPerson.user_pic, fullFileName);
				InputStream in = null;
				try {
					in = new ByteArrayInputStream(resBy);
					fsOperation.fileUpload(in, ossUrl);
				} catch (IOException e) {
					ExceptionUtil.throwServiceException("下载图片失败");
				} finally {
					IOUtils.closeQuietly(in);
				}
			}
		}

		userPersonDAO.add(userMap);
		thirdUserDAO.add(userMap);
		return userId;
	}

	@Override
	public void loginDo(User user, Map<String, Object> userMap, String logonType) {

		user.setLogonType(logonType);
		setUserByMap(user, userMap);
		// 添加用户到缓存
		createSessionAndStore(user);
	}

	/**
	 * 把map数据设置到用户信息中
	 * 
	 * @param user
	 * @param userMap
	 */
	private void setUserByMap(User user, Map<String, Object> userMap) {

		user.setEmail((String) userMap.get(UserParent.email));
		user.setNick((String) userMap.get(UserParent.nick_name));
		user.setUserName((String) userMap.get(UserParent.user_name));
		user.setMobile((String) userMap.get(UserParent.mobile));
		user.setUserId((String) userMap.get(UserPerson.user_id));
		user.setUserType((String) userMap.get(UserParent.user_type));
		user.setImage((String) userMap.get(UserPerson.user_pic));
		Map<String, Object> selfMap = user.getSelf();
		if (CollectionUtil.isEmptyMap(selfMap)) {
			selfMap = new HashMap<>();
			user.setSelf(selfMap);
		}
		selfMap.put(UserPerson.user_sex, userMap.get(UserPerson.user_sex));
		Date birthDay = (Date) userMap.get(UserPerson.user_birthday);
		selfMap.put(UserPerson.user_birthday, userMap.get(UserPerson.user_birthday));
		if (birthDay != null) {
			selfMap.put(UserPerson.user_birthday, DateTimeUtil.dateToString(birthDay,
					cn.com.ut.core.common.constant.ConstantUtil.DATE_FORMAT));
		}
	}

	/**
	 * 添加缓存到服务器
	 * 
	 * @param user
	 */
	protected void createSessionAndStore(User user) {

		cacheHelper.set(SessionManagerImpl.KEY_BEGIN_SESSION + user.getSessionId(),
				ConstantUtil.SESSION_TIME.DEFAULT, user);
		// sessionManager.addGlobalSession(user,
		// ConstantUtil.SESSION_TIME.DEFAULT);
	}

	/**
	 * 清除所有会话缓存（包括本地、全局以及各应用集群服务器上的会话本地缓存）
	 * 
	 * @param user
	 */
	private void removeSessionFromCache(String sessionId) {

		if (sessionId != null) {
			cacheHelper.delete(SessionManagerImpl.KEY_BEGIN_SESSION + sessionId);
		}
		// sessionManager.clearAllSession(sessionId);
	}

	@Override
	public String registerByMobile(Map<String, Object> vo) {

		String mobile = (String) vo.get(UserParent.mobile);
		String phoneCode = (String) vo.get("mobile_code");
		if (CommonUtil.isEmpty(phoneCode, mobile)) {
			ExceptionUtil.throwValidateException("PHONE_CODE OR MOBILE CANOT BE EMPTY");
		}
		if (!NumberUtil.checkMobileNumber(mobile)) {
			ExceptionUtil.throwServiceException("参数不合法 MOBILE");
		}
		// 验证短信验证码
		String cachePhoneCode = cacheHelper.get(ConstantUtil.CACHE_PREFIX.MOBILE_REGISTER + mobile);
		if (!phoneCode.equals(cachePhoneCode)) {
			ExceptionUtil.throwServiceException("短信验证码不正确");
		}
		boolean flag = userParentDAO.checkUnique(new String[] { UserParent.mobile },
				new Object[] { mobile }, null, null);
		if (!flag) {
			ExceptionUtil.throwServiceException("该手机号已注册");
		}
		String userName = CommonUtil.getUUID();
		flag = userParentDAO.checkUnique(new String[] { UserParent.user_name },
				new Object[] { ConstantUtil.USER_PHONE_FIX + mobile }, null, null);
		if (flag) {
			userName = ConstantUtil.USER_PHONE_FIX + mobile;
		}
		vo = new HashMap<>();
		vo.put(UserParent.mobile, mobile);
		vo.put(UserParent.user_name, userName);
		vo.put(UserParent.is_locked, ConstantUtil.FLAG_NO);
		vo.put(UserParent.is_del, ConstantUtil.FLAG_NO);
		vo.put(UserParent.nick_name, NickNameUtil.getRoundName());
		// vo.put(UserParent.user_pwd,
		// CommonUtil.encodeMD5(ConstantUtil.DEFAULT_ACCOUNT_PWD.getBytes()));
		vo.put(UserParent.user_type, ConstantUtil.USER_TYPE.USER_TYPE_PERSON);
		String userId = userParentDAO.add(vo);
		vo.put(UserPerson.user_id, userId);
		userPersonDAO.add(vo);
		return userId;
	}

	@Override
	public String registerByUserName(Map<String, Object> vo) {

		String userName = (String) vo.get(UserParent.user_name);
		String picCode = (String) vo.get("verification_code");
		String pwd = (String) vo.get(UserParent.user_pwd);
		String pwdagain = (String) vo.get("user_pwd_again");
		if (CommonUtil.isEmpty(userName, picCode, pwd, pwdagain)) {
			ExceptionUtil.throwValidateException("存在空参数");
		}
		if (NumberUtil.checkMobileNumber(userName)) {
			ExceptionUtil.throwServiceException("USER_NAME 不能是电话号码");
		}
		if (!pwd.equals(pwdagain)) {
			ExceptionUtil.throwServiceException("两次密码不一致");
		}
		String sessionId = (String) vo.get("sessionId");
		// 验证图片验证码
		String cachePicCode = cacheHelper.get(ConstantUtil.CACHE_PREFIX.PIC_DEFAULT + sessionId);
		if (!picCode.equals(cachePicCode)) {
			ExceptionUtil.throwServiceException("验证码不正确");
		}
		boolean flag = userParentDAO.checkUnique(new String[] { UserParent.user_name },
				new Object[] { userName }, null, null);
		if (!flag) {
			ExceptionUtil.throwServiceException("该用户名已注册");
		}
		vo.put(UserParent.user_name, userName);
		vo.put(UserParent.is_locked, ConstantUtil.FLAG_NO);
		vo.put(UserParent.is_del, ConstantUtil.FLAG_NO);
		vo.put(UserParent.nick_name, NickNameUtil.getRoundName());
		vo.put(UserParent.user_pwd, pwd);
		vo.put(UserParent.user_type, ConstantUtil.USER_TYPE.USER_TYPE_PERSON);
		String userId = userParentDAO.add(vo);
		vo.put(UserPerson.user_id, userId);
		userPersonDAO.add(vo);
		return userId;
	}

	@Override
	public void loginOut(String sessionId) {

		removeSessionFromCache(sessionId);

	}

	@Override
	public int accountLockCheck(String userName) {

		if (CommonUtil.isEmpty(userName)) {
			ExceptionUtil.throwValidateException("userName 参数不正确");
		}
		Integer wrongTime = cacheHelper
				.get(ConstantUtil.CACHE_PREFIX.LOGIN_WRONG_PWD_PREFIX + userName);
		if (wrongTime == null) {
			return 0;
		}
		if (wrongTime >= ConstantUtil.LOGIN_WRONG_OPERATION.USER_LOCK) {
			return 2;
		}
		if (wrongTime >= ConstantUtil.LOGIN_WRONG_OPERATION.USER_VERIFICATION_CODE) {
			return 1;
		}
		return 0;
	}

	@Override
	public Map<String, Object> getUserByUserId(String userid) {

		Map<String, Object> userMap = userParentDAO.getUserInfoByUserId(userid);
		if (!CollectionUtil.isEmptyMap(userMap) && userMap.get(UserPerson.user_birthday) != null) {
			userMap.put(UserPerson.user_birthday,
					DateTimeUtil.dateToString((Date) userMap.get(UserPerson.user_birthday),
							cn.com.ut.core.common.constant.ConstantUtil.DATE_FORMAT));
		}
		return userMap;
	}

	@Override
	public User getLoginUserBySessionId(String sessionId) {

		return cacheHelper.get(SessionManagerImpl.KEY_BEGIN_SESSION + sessionId);
		// return sessionManager.loadSessionFromCache(sessionId);
	}

	@Override
	public List<Map<String, Object>> getUserName(List<Object> userIds) {

		return userParentDAO.getUserName(userIds);
	}

	@Override
	public int updateUserName(String userId, String userName) {

		if (CommonUtil.isEmpty(userId, userName)) {
			ExceptionUtil.throwValidateException("参数空");
		}

		Map<String, Object> userMap = userParentDAO.getById(null, null,
				new String[] { UserParent.update_user_name_time, UserParent.user_name }, null,
				userId);
		if (CollectionUtil.isEmptyMap(userMap)) {
			ExceptionUtil.throwServiceException("用户不存在");
		}
		int updateUserNameTime = (int) userMap.get(UserParent.update_user_name_time);
		if (updateUserNameTime >= env.getProperty("user.updateUserName.time", Integer.class, 1)) {
			ExceptionUtil.throwServiceException("用户名修改次数超过限制");
		}
		if (userName.equals(userMap.get(UserParent.user_name))) {
			ExceptionUtil.throwServiceException("用户名相同不需要修改");
		}
		if (!userParentDAO.checkUnique(new String[] { UserParent.user_name },
				new Object[] { userName }, null, null)) {
			ExceptionUtil.throwServiceException("用户名已经存在，请换一个用户名");
		}
		return userParentDAO.updateById(null,
				new String[] { UserParent.user_name, UserParent.update_user_name_time }, null,
				new Object[] { userName, updateUserNameTime + 1 }, userId);
	}

	@Override
	public List<Map<String, Object>> getUserList(PageBean page) {

		return userParentDAO.queryPage(page, null, null, false,
				new String[] { UserParent.email, UserParent.idx, UserParent.user_name,
						UserParent.nick_name, UserParent.mobile, UserParent.user_type },
				null, new String[] { UserParent.user_type }, null, null, null,
				new Object[] { cn.com.ut.core.common.constant.ConstantUtil.USER_TYPE_PERSON });
	}

	@Override
	public Map<String, Object> getThirdSystemInfo(String type) {

		switch (type) {
		case ConstantUtil.THIRD_USER_FORM.QQ:
			return thirdQQUserService.getSystemAppInfo();
		case ConstantUtil.THIRD_USER_FORM.WECHAT:
			return thirdWechatUserService.getSystemAppInfo();
		case ConstantUtil.THIRD_USER_FORM.SINA_WEIBO:
			return thirdSinaWBUserService.getSystemAppInfo();

		default:
			ExceptionUtil.throwServiceException("该类型不支持");
		}
		return null;
	}

	@Override
	public int updateUserNick(String userId, String nickName) {

		return userParentDAO.updateById(null, new String[] { UserParent.nick_name }, null,
				new Object[] { nickName }, userId);
	}

	@Override
	public int modifyPwd(String userId, Map<String, Object> json) {

		ValidatorUtil.validateMapContainsKey(json, "new_pwd", "new_pwd_again");
		if (!json.get("new_pwd").equals(json.get("new_pwd_again"))) {
			ExceptionUtil.throwServiceException("两次密码不一致");
		}
		String newUserPwdString = (String) json.get("new_pwd");
		if (newUserPwdString.length() <= 5) {
			ExceptionUtil.throwServiceException("密码长度请大于5");
		}

		Map<String, Object> userMap = userParentDAO.get(userId);
		if (CollectionUtil.isEmptyMap(userMap)) {
			ExceptionUtil.throwServiceException("用户不存在");
		}
		String oldUserPwd = (String) userMap.get(UserParent.user_pwd);
		String newUserPwd = newUserPwdString;// CommonUtil.encodeMD5(newUserPwdString.getBytes());
		if (!CommonUtil.isEmpty(oldUserPwd)) {
			ValidatorUtil.validateMapContainsKey(json, "old_pwd");
			String parOldPwd = (String) json.get("old_pwd");
			if (parOldPwd.equals(newUserPwdString)) {
				ExceptionUtil.throwServiceException("输入的原密码与新密码一致，请设置不同的密码");
			}

			if (!oldUserPwd.equals(parOldPwd)) {
				ExceptionUtil.throwServiceException("原密码错误");
			}
			if (oldUserPwd.equals(newUserPwd)) {
				ExceptionUtil.throwServiceException("新密码与原密码一致不需要修改");
			}
		}
		return userParentDAO.updateById(null, new String[] { UserParent.user_pwd }, null,
				new Object[] { newUserPwd }, userId);
	}

	@Override
	public int modifyMobile(User user, Map<String, Object> json) {

		ValidatorUtil.validateMapContainsKey(json, "new_mobile", "verification_code");
		String mobile = (String) json.get("new_mobile");
		String verificationCode = (String) json.get("verification_code");
		if (!NumberUtil.checkMobileNumber(mobile)) {
			ExceptionUtil.throwServiceException("请输入正确手机号码");
		}
		String vfCode = cacheHelper.get(ConstantUtil.CACHE_PREFIX.MODIFY_MOBILE + mobile);
		if (CommonUtil.isEmpty(vfCode) || !vfCode.equals(verificationCode)) {
			ExceptionUtil.throwServiceException("验证码不正确");
		}
		int result = userParentDAO.updateById(null, new String[] { UserParent.mobile }, null,
				new Object[] { mobile }, user.getUserId());
		if (result != 1) {
			ExceptionUtil.throwServiceException("更新失败");
		}
		user.setMobile(mobile);
		cacheHelper.delete(ConstantUtil.CACHE_PREFIX.MODIFY_MOBILE + mobile);
		cacheHelper.replace(SessionManagerImpl.KEY_BEGIN_SESSION + user.getSessionId(), user);
		return result;
	}

	@Override
	public int bindMobile(User user, Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "mobile", "verification_code");
		String mobile = (String) vo.get("mobile");
		String verificationCode = (String) vo.get("verification_code");
		if (!NumberUtil.checkMobileNumber(mobile)) {
			ExceptionUtil.throwServiceException("请输入正确手机号码");
		}
		String vfCode = cacheHelper.get(ConstantUtil.CACHE_PREFIX.BIND_MOBILE + mobile);
		if (CommonUtil.isEmpty(vfCode) || !vfCode.equals(verificationCode)) {
			ExceptionUtil.throwServiceException("验证码不正确");
		}
		Map<String, Object> userMap = userParentDAO.get(user.getUserId());
		if (CollectionUtil.isEmptyMap(userMap) || userMap.get(UserParent.mobile) != null) {
			ExceptionUtil.throwServiceException("用户已绑定手机请选择更换手机");
		}
		int result = userParentDAO.updateById(null, new String[] { UserParent.mobile }, null,
				new Object[] { mobile }, user.getUserId());
		if (result != 1) {
			ExceptionUtil.throwServiceException("更新失败");
		}
		user.setMobile(mobile);
		cacheHelper.delete(ConstantUtil.CACHE_PREFIX.BIND_MOBILE + mobile);
		cacheHelper.replace(SessionManagerImpl.KEY_BEGIN_SESSION + user.getSessionId(), user);
		return result;
	}

	@Override
	public int forgetPwd(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "new_pwd", "new_pwd_again", UserParent.user_name,
				UserParent.mobile, "code");
		if (!vo.get("new_pwd").equals(vo.get("new_pwd_again"))) {
			ExceptionUtil.throwServiceException("两次密码不一致");
		}
		String newUserPwdString = (String) vo.get("new_pwd");
		String mobile = (String) vo.get(UserParent.mobile);
		String code = (String) vo.get("code");
		String key = ConstantUtil.CACHE_PREFIX.MOBILE_FORGETPWD + mobile;
		checkCode(key, code);
		Map<String, Object> userMap = userParentDAO.getByKey(null, null, null, null,
				new String[] { UserParent.user_name, UserParent.mobile },
				new Object[] { vo.get(UserParent.user_name), vo.get(UserParent.mobile) }, null);
		if (CollectionUtil.isEmptyMap(userMap)) {
			ExceptionUtil.throwServiceException("用户不存在或者用户跟手机号码不匹配");
		}
		return userParentDAO.updateById(null, new String[] { UserParent.user_pwd }, null,
				new Object[] { newUserPwdString }, (String) userMap.get(UserParent.idx));

	}

	private void checkCode(String key, String code) {

		String cachCode = cacheHelper.get(key);
		if (CommonUtil.isEmpty(cachCode) || !cachCode.equals(code)) {
			ExceptionUtil.throwServiceException("验证码不正确");
		}
	}

}
