package cn.com.ut.biz.system.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * @version tuna
 * @author gaozhilong
 * 
 */

public interface DictTypeService extends DictTypeServiceRemote {

	/**
	 * 创建字典类型
	 */
	String create(Map<String, Object> dictTypeVo);

	/**
	 * 更新字典类型
	 * 
	 * @return 其ID有可能与原来的不一样，返回ID
	 */
	String update(Map<String, Object> dictTypeVo);

	/*
	 * 查询字典类型
	 */
	List<Map<String, Object>> find(PageBean page);

	/**
	 * 查看字典类型详情
	 */
	Map<String, Object> getDetail(String dictTypeId);

	/**
	 * 删除字典类型
	 * 
	 * @param platformId
	 * @param dictTypeId
	 * @param operator
	 */
	void delMark(String dictTypeId, String operator);
}
