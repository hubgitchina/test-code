package cn.com.ut.biz.permission.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.permission.dao.RoleAndMenuDAO;
import cn.com.ut.biz.permission.entities.Menu;
import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.annotation.Dialect;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 角色与菜单关系管理数据层实现类
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Repository
public class RoleAndMenuDAOImpl extends JdbcOperationsImpl<RoleAndMenu> implements RoleAndMenuDAO {

	private String T_ROLE;
	private String T_ROLE_MENU;
	private String T_ROLE_USER;
	private String T_ROLE_USERGROUP;
	private String T_USERGROUP;
	private String T_USERGROUP_USER;
	private String T_MENU;
	{
		T_ROLE = getTable(Role.class);
		T_ROLE_MENU = getTable(RoleAndMenu.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
		T_ROLE_USERGROUP = getTable(RoleAndUserGroup.class);
		T_USERGROUP = getTable(UserGroup.class);
		T_USERGROUP_USER = getTable(UserGroupAndUser.class);
		T_MENU = getTable(Menu.class);
	}
	private static final String[] COLUMNS = { RoleAndMenu.role_id, RoleAndMenu.menu_id,
			RoleAndMenu.is_own, RoleAndMenu.is_assign };

	@Override
	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, COLUMNS, NAMES_ID_CT_CID,
				ParameterBuilder.builder().append(vo, COLUMNS)
						.append(id, DateTimeUtil.currentDateTime(), vo.get(RoleAndMenu.create_id))
						.toArray());
		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		return updateById(null, COLUMNS, NAMES_UT_UID, null,
				ParameterBuilder.builder().append(vo, COLUMNS)
						.append(DateTimeUtil.currentDateTime(), vo.get(RoleAndMenu.update_id))
						.toArray(),
				(String) vo.get(RoleAndMenu.idx), null);
	}

	@Override
	public int deleteRoleMenusIn(String roleId, List<String> menus) {

		int size = menus.size();
		menus.add(0, roleId);
		return delete(null, null,
				RoleAndMenu.role_id + " = ? AND " + RoleAndMenu.menu_id + " {IN} ",
				new int[] { size }, menus.toArray(), null);
	}

	@Override
	public List<Map<String, Object>> listRoleMenusIn(String roleId, List<String> menus) {

		int size = menus.size();
		menus.add(0, roleId);

		return queryPage(null, null, null, false, new String[] { RoleAndMenu.menu_id }, null, null,
				RoleAndMenu.role_id + " = ? AND " + RoleAndMenu.menu_id + " {IN} ",
				new int[] { size }, null, menus.toArray());

	}

	@Override
	public void addBatch(String roleId, List<Map<String, Object>> voList) {

		StringBuilder sql = new StringBuilder();
		sql.append("insert into").append(T_ROLE_MENU)
				.append("(id,role_id,menu_id,is_own,is_assign,is_use) values(?,?,?,?,?,?)");
		List<Object[]> array = new ArrayList<>();
		for (Map<String, Object> vo : voList) {
			array.add(new Object[] { CommonUtil.getUUID(), roleId, vo.get(RoleAndMenu.menu_id),
					vo.get(RoleAndMenu.is_own), vo.get(RoleAndMenu.is_assign),
					ConstantUtil.FLAG_YES });
		}
		batchUpdate(getJdbcTemplate(), sql.toString(), array);
	}

	@Override
	public void updateBatch(String roleId, List<Map<String, Object>> voList) {

		SQLHelper sql = SQLHelper.builder();
		sql.append(" update").append(T_ROLE_MENU)
				.append(" set is_own = ?,is_assign = ?,update_id = ?,update_time = ?")
				.append(" where role_id = ? and menu_id = ?  ");

		List<Object[]> array = new ArrayList<>();
		Timestamp now = DateTimeUtil.currentDateTime();
		for (Map<String, Object> vo : voList) {
			array.add(new Object[] { vo.get(RoleAndMenu.is_own), vo.get(RoleAndMenu.is_assign),
					vo.get(BaseEntity.update_id), now, roleId, vo.get(RoleAndMenu.menu_id) });
		}
		batchUpdate(getJdbcTemplate(), sql.toSQL(), array);
	}

	@Override
	public int deleteRoleAndMenuByMenuId(String menuId) {

		return delete(null, new String[] { RoleAndMenu.menu_id }, new Object[] { menuId });
	}

	@Override
	public List<Map<String, Object>> getUserMenu(String userId) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_MENU).append("m").append("INNER JOIN").append(T_ROLE_MENU)
				.append("rm ON rm.menu_id = m.id");
		// 用户关联的角色的菜单
		table.append("WHERE rm.is_own='Y' and rm.role_id IN ( SELECT r.id FROM ").append(T_ROLE)
				.append("r").append("INNER JOIN").append(T_ROLE_USER)
				.append("ur ON ur.role_id = r.id").append("WHERE ur.user_id = ? )");

		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.appendColumns("m", BaseEntity.idx, Menu.parent_id);

		return queryPage(null, null, table.toSQL(), true, parameterBuilder.toColumns(), null, null,
				null, null, null, new Object[] { userId });
	}

	@Override
	public List<Map<String, Object>> getUserMenuByIds(List<String> menuIds) {

		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.appendColumns("m", BaseEntity.idx, Menu.parent_id, Menu.menu_url,
				Menu.menu_comment, Menu.menu_text, Menu.menu_img);

		return queryPage(null, null, T_MENU + " m", false, parameterBuilder.toColumns(), null, null,
				"m.id" + SQLHelper.IN_REPLACE, new int[] { menuIds.size() }, "m.sort_num",
				menuIds.toArray());

	}

	/**
	 * 删除在角色菜单关系表中存在但是菜单在系统菜单表中不存在，一般是系统菜单表中删除了此菜单
	 * 
	 * @param roleId
	 */
	@Override
	public void deleteRoleAndMenuNotExistByRoleId(String roleId) {

		SQLHelper sql = SQLHelper.builder();
		sql.append("delete from").append(T_ROLE_MENU)
				.append("aa where aa.role_id = ? and not EXISTS (select bb.id from").append(T_MENU)
				.append("bb where bb.id = aa.menu_id)");

		update(getJdbcTemplate(), sql.toSQL(), roleId);
	}

	/**
	 * 删除角色菜单关系表中非叶子节点且在关系表中此节点无下级
	 * 
	 * @param roleId
	 */
	@Override
	@Dialect(multiDialectSupport = true)
	public void deleteRoleAndMenuWithoutNextLevelByRoleId(String roleId) {

		SQLHelper sqlOne = SQLHelper.builder();
		SQLHelper sqlTwo = SQLHelper.builder();

		sqlOne.append("delete from").append(T_ROLE_MENU).append("aa where aa.role_id = ?")
				.append("and char_length(aa.menu_id) = 6").append("and EXISTS(select bb.id from")
				.append(T_MENU).append("bb where bb.parent_id = aa.menu_id)")
				.append("and not EXISTS (select cc.id from").append(T_ROLE_MENU)
				.append("cc where cc.role_id = aa.role_id and char_length(cc.menu_id) = 9 and substr(cc.menu_id,1,6) = aa.menu_id)");

		sqlTwo.append("delete from").append(T_ROLE_MENU).append("aa where aa.role_id = ?")
				.append("and char_length(aa.menu_id) = 3").append("and EXISTS(select bb.id from")
				.append(T_MENU).append("bb where bb.parent_id = aa.menu_id)")
				.append("and not EXISTS (select cc.id from").append(T_ROLE_MENU)
				.append("cc where cc.role_id = aa.role_id and char_length(cc.menu_id) = 6 and substr(cc.menu_id,1,3) = aa.menu_id)");

		update(getJdbcTemplate(), sqlOne.toSQL(), roleId);
		update(getJdbcTemplate(), sqlTwo.toSQL(), roleId);
	}
}
