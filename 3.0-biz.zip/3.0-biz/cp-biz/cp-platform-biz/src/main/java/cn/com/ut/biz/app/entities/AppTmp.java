package cn.com.ut.biz.app.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 应用与业务模板
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public class AppTmp extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5267416982243256800L;
	/**
	 * 应用ID
	 */
	public static final String app_id = "app_id";
	/**
	 * 模板ID
	 */
	public static final String tmp_id = "tmp_id";
}
