package cn.com.ut.biz.permission.dao.impl;

import static cn.com.ut.biz.permission.entities.UserGroup.group_class;
import static cn.com.ut.biz.permission.entities.UserGroup.group_name;
import static cn.com.ut.biz.permission.entities.UserGroup.group_note;
import static cn.com.ut.biz.permission.entities.UserGroup.group_type;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.permission.dao.UserGroupDAO;
import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 用户分组管理数据层实现类
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Repository
public class UserGroupDAOImpl extends JdbcOperationsImpl<UserGroup> implements UserGroupDAO {

	private String T_ROLE;
	private String T_ROLE_MENU;
	private String T_ROLE_USER;
	private String T_ROLE_USERGROUP;
	private String T_USERGROUP;
	private String T_USERGROUP_USER;
	private String T_USER_MANAGER;
	{
		T_ROLE = getTable(Role.class);
		T_ROLE_MENU = getTable(RoleAndMenu.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
		T_ROLE_USERGROUP = getTable(RoleAndUserGroup.class);
		T_USERGROUP = getTable(UserGroup.class);
		T_USERGROUP_USER = getTable(UserGroupAndUser.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
		T_USER_MANAGER = getTable(UserManager.class);
	}

	@Override
	public String add(Map<String, Object> vo) {

		Timestamp time = DateTimeUtil.currentDateTime();
		String id = CommonUtil.getUUID();
		add(null,
				new String[] { group_name, group_type, group_note, BaseEntity.is_use, group_class },
				NAMES,
				new Object[] { vo.get(group_name), ConstantUtil.FLAG_ONE, vo.get(group_note),
						vo.get(BaseEntity.is_use), vo.get(group_class), id, time, time,
						vo.get(create_id), vo.get(create_id) });
		return id;

	}

	@Override
	public int update(Map<String, Object> vo) {

		Timestamp time = DateTimeUtil.currentDateTime();
		return updateById(null, new String[] { group_name, group_note, BaseEntity.is_use },
				NAMES_UT_UID, new Object[] { vo.get(group_name), vo.get(group_note),
						vo.get(BaseEntity.is_use), time, vo.get(create_id) },
				(String) vo.get(BaseEntity.idx));
	}

	public List<Map<String, Object>> listRefUsers(String groupId, PageBean pageBean) {

		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.appendColumns("ugu", UserGroupAndUser.user_id);
		parameterBuilder.appendColumns("m", UserManager.real_name);
		parameterBuilder.appendColumns("m", UserManager.work_number);
		parameterBuilder.appendColumns("m", UserManager.mobile);
		parameterBuilder.appendColumns("m", UserManager.email);

		StringBuilder listRefUsersJoin = new StringBuilder();
		listRefUsersJoin.append(T_USERGROUP_USER).append(" ugu ").append(" INNER JOIN ")
				.append(T_USER_MANAGER).append(" m ON ugu.user_id = m.user_id ")
				.append(" AND ugu.group_id=? ");
		return queryPage(pageBean, null, listRefUsersJoin.toString(), false,
				parameterBuilder.toColumns(), null, null, null, null, null,
				new Object[] { groupId });
	}

	public List<Map<String, Object>> listNoRefUsers(String groupId, PageBean pageBean) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_USER_MANAGER).append(" um LEFT JOIN").append(T_USERGROUP_USER)
				.append("ugu ON ugu.user_id = um.user_id");
		return queryPage(pageBean, null, table.toSQL(), false,
				new String[] { "DISTINCT um.user_id", "um.work_number", "um.real_name" }, null,
				new String[] { "um.is_del" },
				"um.user_id not in (select user_id from " + T_USERGROUP_USER
						+ " where group_id = ? )",
				null, null, new Object[] { ConstantUtil.FLAG_NO, groupId });
	}

	public List<Map<String, Object>> findGroupsByUserId(String userId, PageBean pageBean) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_USERGROUP).append("tg where").append("exists (select 1 from")
				.append(T_USERGROUP_USER).append("where user_id = ? and group_id = tg.id)");
		table.append("or exists (select 1 from").append(T_ROLE_USER)
				.append("where user_id = ? and role_id = ?) ");
		table.append("and tg.is_use = ? and tg.group_class = ? ");

		return queryPage(pageBean, null, table.toSQL(), true,
				new String[] { BaseEntity.idx, group_name, group_type, group_note }, null, null,
				null, null, null, new Object[] { userId, userId, ConstantUtil.ROLE_ADMIN,
						ConstantUtil.FLAG_YES, ConstantUtil.FLAG_ZERO });
	}

	@Override
	public Map<String, Object> getDetail(String groupId) {

		return getByProperties(new String[] { idx }, new Object[] { groupId });
	}
}
