package cn.com.ut.biz.permission.service;

public interface UserRightService {

}
