package cn.com.ut.biz.permission.dao.impl;

import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.permission.dao.MenuDAO;
import cn.com.ut.biz.permission.entities.Menu;
import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.annotation.Dialect;
import cn.com.ut.core.common.constant.DialectConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 菜单管理数据层实现类
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Repository
public class MenuDAOImpl extends JdbcOperationsImpl<Menu> implements MenuDAO {

	private String T_ROLE;
	private String T_ROLE_MENU;
	private String T_ROLE_USER;
	private String T_ROLE_USERGROUP;
	private String T_USERGROUP;
	private String T_USERGROUP_USER;
	private String T_MENU;
	{
		T_ROLE = getTable(Role.class);
		T_ROLE_MENU = getTable(RoleAndMenu.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
		T_ROLE_USERGROUP = getTable(RoleAndUserGroup.class);
		T_USERGROUP = getTable(UserGroup.class);
		T_USERGROUP_USER = getTable(UserGroupAndUser.class);
		T_MENU = getTable(Menu.class);
	}

	private static final String[] COLUMNS = { Menu.menu_text, Menu.menu_url, Menu.menu_comment,
			Menu.parent_id, Menu.sort_num, Menu.module_id, Menu.menu_img, BaseEntity.is_use };

	@Override
	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, COLUMNS, NAMES_ID_CT_CID, ParameterBuilder.builder().append(vo, COLUMNS)
				.append(id, DateTimeUtil.currentDateTime(), vo.get(Menu.create_id)).toArray());
		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		return updateById(null, COLUMNS, NAMES_UT_UID, null,
				ParameterBuilder.builder().append(vo, COLUMNS)
						.append(DateTimeUtil.currentDateTime(), vo.get(Menu.update_id)).toArray(),
				(String) vo.get(Menu.idx), null);
	}

	@Override
	public List<Map<String, Object>> queryMenuList(String roleId) {

		StringBuilder listMenus = new StringBuilder();
		listMenus.append(" SELECT ").append("A.id").append(" , ").append("A." + Menu.menu_text)
				.append(" , ").append("A." + Menu.menu_url).append(" , ")
				.append("A." + Menu.menu_comment).append(" , ").append("A." + Menu.menu_img)
				.append(" , ").append("A." + Menu.parent_id).append(" , ")
				.append("A." + Menu.sort_num).append(" , ")
				.append("(CASE WHEN B." + RoleAndMenu.menu_id
						+ " IS NULL THEN '0' ELSE '1' END) AS IS_SEL ")
				.append(" FROM ").append(T_MENU).append(" A LEFT JOIN ").append(T_ROLE_MENU)
				.append(" B ON A.ID = B.menu_id AND B.role_id = ? ")
				.append(" ORDER BY A." + Menu.parent_id + ", A." + Menu.sort_num);
		return queryForList(getJdbcTemplate(), listMenus.toString(), roleId);
	}

	@Override
	public List<Map<String, Object>> listMenus(String roleId) {

		StringBuilder listMenusSQL = new StringBuilder();
		listMenusSQL.append(" SELECT ").append("A.id").append(" , ").append("A." + Menu.menu_text)
				.append(" , ").append("A." + Menu.menu_url).append(" , ")
				.append("A." + Menu.menu_comment).append(" , ").append("A." + Menu.menu_img)
				.append(" , ")
				.append("(CASE WHEN A." + Menu.parent_id + " IS NULL THEN '*' ELSE A."
						+ Menu.parent_id + " END) AS " + Menu.parent_id)
				.append(" , ").append("A." + Menu.sort_num).append(" , ")
				.append("(CASE WHEN B." + RoleAndMenu.menu_id
						+ " IS NULL THEN '0' ELSE '1' END) AS IS_SEL ")
				.append(" FROM ").append(T_MENU).append(" A LEFT JOIN ").append(T_ROLE_MENU)
				.append(" B ON A.ID = B.menu_id AND B.role_id = ? ")
				.append(" ORDER BY A." + Menu.parent_id + ", A." + Menu.sort_num);
		return queryForList(getJdbcTemplate(), listMenusSQL.toString(), roleId);
	}

	/**
	 * 设置同一级菜单的默认排序
	 */
	@Dialect(multiDialectSupport = true)
	public void updateMenuSortDefault() {

		// TODO mysql失效
		SQLHelper sqlOne = SQLHelper.builder();
		SQLHelper sqlTwo = SQLHelper.builder();
		if (DialectConstant.isPgsql()) {
			sqlOne.append("update ").append(T_MENU)
					.append(" set sort_num = to_number(id, '999') * 3 where length(id) = 3");
			sqlTwo.append("update ").append(T_MENU).append(
					" set sort_num = to_number(substring(id, 4, 3), '999') * 3 where length(id) = 6");
		} else {
			sqlOne.append("update ").append(T_MENU)
					.append(" set sort_num = CAST(id AS SIGNED) * 3 where length(id) = 3");
			sqlTwo.append("update ").append(T_MENU).append(
					" set sort_num = CAST(substring(id, 4, 3) AS SIGNED) * 3 where length(id) = 6");
		}
		update(getJdbcTemplate(), sqlOne.toSQL());
		update(getJdbcTemplate(), sqlTwo.toSQL());
	}

	@Override
	public List<Map<String, Object>> queryAllBackgroundMenu(PageBean page) {

		String[] selectColumnArray = new String[] { Menu.idx, Menu.menu_text, Menu.menu_url,
				Menu.menu_comment };
		String orderBy = Menu.idx + "," + Menu.sort_num;
		return queryPage(page, null, null, false, selectColumnArray, null, null, null, null,
				orderBy, null);
	}

	@Override
	public List<Map<String, Object>> queryBackgroundMenu(String parentId, PageBean page) {

		String[] selectColumnArray = new String[] { Menu.idx, Menu.menu_text, Menu.sort_num,
				Menu.menu_comment, Menu.menu_url };
		if (CommonUtil.isNotEmpty(parentId)) {
			// 查询第二级
			String[] whereColumnArray = new String[] { Menu.parent_id, is_del };
			String orderBy = Menu.sort_num;
			List<Map<String, Object>> list = queryPage(null, null, null, false, selectColumnArray,
					null, whereColumnArray, null, null, orderBy,
					new Object[] { parentId, ConstantUtil.FLAG_NO });
			return list;
		} else {
			// 查询第一级
			StringBuilder table = new StringBuilder();
			table.append(T_MENU)
					.append(" where parent_id IS NULL AND is_del = '" + ConstantUtil.FLAG_NO + "'");
			String orderBy = Menu.menu_comment + "," + Menu.sort_num;
			List<Map<String, Object>> list = queryPage(page, null, table.toString(), true,
					selectColumnArray, null, null, null, null, orderBy, null);
			return list;
		}
	}

	@Override
	public void delModuleMenu(String moduleId) {

		StringBuffer sqlBuf = new StringBuffer();
		sqlBuf.append(" DELETE from ").append(T_ROLE_MENU)
				.append(" where menu_id in ( select id from ").append(T_MENU)
				.append("  where module_id = ? ) ");
		update(getJdbcTemplate(), sqlBuf.toString(), moduleId);
		delete(null, new String[] { Menu.module_id }, new Object[] { moduleId });
	}

	@Override
	public Map<String, Object> getDetail(String menuId) {

		return getByProperties(new String[] { BaseEntity.idx }, new Object[] { menuId });
	}

	@Override
	public boolean isUniqueMenuNameOnSameLevel(String name, String id, String parentId) {

		if (name != null)
			name = name.trim();
		SQLHelper whereColumnJoin = SQLHelper.builder();
		Object[] parameterArray;
		// 编辑菜单
		if (id != null) {
			Map<String, Object> menu = get(id);
			parentId = (String) menu.get(Menu.parent_id);
		}

		// 一级菜单
		if (parentId == null) {
			// 编辑菜单
			if (id != null) {
				whereColumnJoin.append("menu_text = ? AND parent_id IS NULL AND id <> ? ");
				parameterArray = new String[] { name, id };
			}
			// 新建菜单
			else {
				whereColumnJoin.append("menu_text = ? AND parent_id IS NULL ");
				parameterArray = new String[] { name };
			}

		}
		// 非一级菜单
		else {
			if (id != null) {
				whereColumnJoin.append("menu_text = ? AND parent_id = ? AND id <> ? ");
				parameterArray = new String[] { name, parentId, id };
			} else {
				whereColumnJoin.append("menu_text = ? AND parent_id = ? ");
				parameterArray = new String[] { name, parentId };
			}
		}
		long count = count(null, null, null, whereColumnJoin.toSQL(), null, parameterArray);
		return count == 0L;
	}
}
