/*
 * Copyright 2013 The UTFoodPortalSE Project. Zhuhai Unitech Power Technology Co.,Ltd. All Rights Reserved.
 */
package cn.com.ut.biz.permission.service.impl;

import static cn.com.ut.biz.permission.entities.Menu.*;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.com.ut.biz.permission.dao.MenuDAO;
import cn.com.ut.biz.permission.dao.RoleAndMenuDAO;
import cn.com.ut.biz.permission.entities.Menu;
import cn.com.ut.biz.permission.service.MenuService;
import cn.com.ut.biz.user.dao.UserParentDAO;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 系统菜单管理
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Service
public class MenuServiceImpl implements MenuService {

	@Resource
	private MenuDAO menuDAO;
	@Resource
	private RoleAndMenuDAO roleAndMenuDAO;

	@Resource
	private UserParentDAO userParentDAO;

	@Override
	public List<Map<String, Object>> listMenuTree(String roleId) {

		List<Map<String, Object>> list = menuDAO.queryMenuList(roleId);
		return CommonUtil.createTree(list, Menu.parent_id, Menu.idx, "node");
	}

	@Override
	public List<Map<String, Object>> queryBackgroundMenu(String parentId, PageBean page) {

		return menuDAO.queryBackgroundMenu(parentId, page);
	}

	@Override
	public List<Map<String, Object>> listUserMenus(User user) {

		List<Map<String, Object>> menuVos = roleAndMenuDAO.getUserMenu(user.getUserId());
		if (CollectionUtil.isEmptyCollection(menuVos)) {
			return menuVos;
		}

		List<String> list = CollectionUtil.listManyToOne(menuVos, Menu.idx);

		List<String> menuIds = CommonUtil.withParentMenus(list);
		menuIds.addAll(list);

		if (CollectionUtil.isEmptyCollection(menuIds)) {
			return null;
		}

		List<Map<String, Object>> menus = roleAndMenuDAO.getUserMenuByIds(menuIds);

		CollectionUtil.replaceMapsKey(menus, false);
		return CollectionUtil.createTreeList(menus, "parent_id", BaseEntity.idx, "menu");
	}

	@Override
	public List<Map<String, Object>> queryAllBackgroundMenu(PageBean page) {

		return menuDAO.queryAllBackgroundMenu(page);
	}

	@Override
	public String create(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, menu_text);
		if ("".equals(vo.get(Menu.parent_id)))
			vo.put(Menu.parent_id, null);

		boolean b = isUniqueMenuNameOnSameLevel((String) vo.get(menu_text), null,
				(String) vo.get(Menu.parent_id), null);
		if (!b) {
			ExceptionUtil.throwValidateException("菜单名称已存在");
		}

		vo.put(Menu.sort_num, "".equals(vo.get(Menu.sort_num).toString()) ? null
				: Integer.parseInt((String) vo.get(Menu.sort_num)));

		vo.put(Menu.is_use, ConstantUtil.FLAG_YES);

		String id = menuDAO.getNextId((String) vo.get(Menu.parent_id), menuDAO.getTable(),
				Menu.parent_id, Menu.idx);
		vo.put(Menu.idx, id);
		menuDAO.add(vo);
		return id;
	}

	@Override
	public void update(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, idx, menu_text);
		boolean b = isUniqueMenuNameOnSameLevel((String) vo.get(menu_text), (String) vo.get(idx),
				null, null);
		if (!b) {
			ExceptionUtil.throwValidateException("菜单名称已存在");
		}
		vo.put(Menu.sort_num, "".equals(vo.get(Menu.sort_num).toString()) ? null
				: Integer.parseInt((String) vo.get(Menu.sort_num)));
		vo.put(Menu.is_use, ConstantUtil.FLAG_YES);
		menuDAO.update(vo);
	}

	@Override
	public Map<String, Object> getDetail(String menuId) {

		Map<String, Object> vo = menuDAO.getDetail(menuId);
		if (vo.get(Menu.parent_id) != null) {
			Map<String, Object> parent = menuDAO.getDetail((String) vo.get(Menu.parent_id));
			vo.put("parent_name", parent.get(menu_text));
		}
		return vo;
	}

	@Override
	public void delete(String id) {

		long count = menuDAO.count(null, Menu.idx, new String[] { Menu.parent_id },
				new Object[] { id });
		if (count > 0) {
			ExceptionUtil.throwValidateException("该菜单下面还有子菜单，不允许被删除！");
		}
		Map<String, Object> vo = menuDAO.getDetail(id);
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("记录不存在！");
		}
		if (ConstantUtil.FLAG_ZERO.equals(vo.get(Menu.menu_type))) {
			ExceptionUtil.throwValidateException("该数据是系统数据，不允许被删除！");
		}
		roleAndMenuDAO.deleteRoleAndMenuByMenuId(id);
		menuDAO.delete(id);
	}

	/**
	 * 验证同一级的菜单名称是否存在重复的情况
	 * 
	 * @param name
	 * @param id
	 * @param parentId
	 * @param platformId
	 * @return
	 */
	private boolean isUniqueMenuNameOnSameLevel(String name, String id, String parentId,
			String platformId) {

		return menuDAO.isUniqueMenuNameOnSameLevel(name, id, parentId);
	}

	@Override
	public void updateMenuSortDefault() {

		menuDAO.updateMenuSortDefault();
	}
}
