package cn.com.ut.biz.user.service;

import java.util.List;
import java.util.Map;

/**
 * 用户拓展信息服务类接口
 * 
 * @author ouyuexing
 *
 */
public interface UserExpandService {

	/**
	 * 更新用户基础信息
	 * 
	 * @param userId
	 * @param json
	 * @return
	 */
	int updateUserPersion(String userId, Map<String, Object> json);

	/**
	 * 更新用户头像
	 * 
	 * @param userId
	 * @param userPic
	 */
	int updateUserPic(String userId, String userPic);

	/**
	 * 查询用户教育信息
	 * 
	 * @param userId
	 * @return
	 */
	List<Map<String, Object>> findUserPEducation(String userId);

	/**
	 * 添加用户教育经历
	 * 
	 * @param json
	 * @return
	 */
	String addUserPEducation(Map<String, Object> parVo);

	/**
	 * 删除用户教育经历
	 * 
	 * @param id
	 * @param userId
	 * @return
	 */
	int delUserPEducation(String id, String userId);

	/**
	 * 查询用户工作信息
	 * 
	 * @param userId
	 * @return
	 */
	List<Map<String, Object>> findUserPVocation(String userId);

	/**
	 * 添加用户工作经历
	 * 
	 * @param parVo
	 * @return
	 */
	String addUserPVocation(Map<String, Object> parVo);

	/**
	 * 删除用户工作经历
	 * 
	 * @param id
	 * @param userId
	 */
	int delUserPVocation(String id, String userId);

	/**
	 * 更新用户的个人信息
	 * 
	 * @param json
	 * @return
	 */
	int updateUserPer(Map<String, Object> json);

}
