package cn.com.ut.config.thirdlogin;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "third.sina.weibo")
public class SinaLoginModule {

	private String pcSecret;

	private String pcKey;

	private String appSecret;

	private String appKey;

	private String callBackUrl;

	public String getPcSecret() {

		return pcSecret;
	}

	public void setPcSecret(String pcSecret) {

		this.pcSecret = pcSecret;
	}

	public String getPcKey() {

		return pcKey;
	}

	public void setPcKey(String pcKey) {

		this.pcKey = pcKey;
	}

	public String getAppSecret() {

		return appSecret;
	}

	public void setAppSecret(String appSecret) {

		this.appSecret = appSecret;
	}

	public String getAppKey() {

		return appKey;
	}

	public void setAppKey(String appKey) {

		this.appKey = appKey;
	}

	public String getCallBackUrl() {

		return callBackUrl;
	}

	public void setCallBackUrl(String callBackUrl) {

		this.callBackUrl = callBackUrl;
	}

}
