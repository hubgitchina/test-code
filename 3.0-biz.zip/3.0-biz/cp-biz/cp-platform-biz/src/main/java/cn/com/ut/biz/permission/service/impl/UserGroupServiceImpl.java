/*
 * Copyright 2013 The UTFoodPortalSE Project. Zhuhai Unitech Power Technology Co.,Ltd. All Rights Reserved.
 */
package cn.com.ut.biz.permission.service.impl;

import static cn.com.ut.biz.permission.entities.UserGroup.group_class;
import static cn.com.ut.biz.permission.entities.UserGroup.group_name;
import static cn.com.ut.biz.permission.entities.UserGroup.group_type;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.JdbcOperationsImpl.NAMES_ID_CT_CID;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.permission.dao.RoleAndUserGroupDAO;
import cn.com.ut.biz.permission.dao.UserGroupAndUserDAO;
import cn.com.ut.biz.permission.dao.UserGroupDAO;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.biz.permission.service.UserGroupService;
import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import lombok.NonNull;

/**
 * 用户组管理
 * 
 * @author ouyuexing
 * @since 2013-4-8
 */
@Service
public class UserGroupServiceImpl implements UserGroupService {

	@Resource
	private UserGroupDAO userGroupDAO;
	@Resource
	private RoleAndUserGroupDAO roleAndUserGroupDAO;
	@Resource
	private UserGroupAndUserDAO userGroupAndUserDAO;

	@Autowired
	private UserService userService;

	@Override
	public String create(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, create_id, group_name, group_type, group_class);
		String groupName = (String) vo.get(group_name);
		vo.put(group_class, ConstantUtil.FLAG_ZERO);
		boolean isUnique = userGroupDAO.checkUnique(new String[] { group_name, group_class },
				new Object[] { groupName, ConstantUtil.FLAG_ZERO }, null, null);
		if (!isUnique) {
			ExceptionUtil.throwValidateException("用户组或部门名称已存在");
		}
		return userGroupDAO.add(vo);
	}

	@Override
	public void update(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, idx, update_id, group_name);
		String groupName = (String) vo.get(group_name);
		String groupId = (String) vo.get(UserGroup.idx);
		boolean isExist = !userGroupDAO.checkUnique(new String[] { group_name, group_class },
				new Object[] { groupName, ConstantUtil.FLAG_ZERO }, new String[] { UserGroup.idx },
				new Object[] { groupId });

		if (isExist) {
			ExceptionUtil.throwValidateException("用户组或部门名称已存在");
		}
		userGroupDAO.update(vo);
	}

	@Override
	public void delete(String groupId) {

		Map<String, Object> vo = userGroupDAO.getDetail(groupId);
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("用户组记录不存在");
		}

		long countUsers = userGroupAndUserDAO.count(null, null,
				new String[] { UserGroupAndUser.group_id }, new Object[] { groupId });

		if (countUsers > 0) {
			ExceptionUtil.throwValidateException("请先删除用户组或部门中的用户");
		}

		long countRoles = roleAndUserGroupDAO.count(null, null,
				new String[] { RoleAndUserGroup.group_id }, new Object[] { groupId });
		if (countRoles > 0) {
			ExceptionUtil.throwValidateException("该用户组或部门已经被角色记录引用");
		}

		userGroupDAO.delete(groupId);
	}

	@Override
	public Map<String, Object> getDetail(String groupId) {

		return userGroupDAO.getDetail(groupId);
	}

	/**
	 * 查询用户组列表
	 */
	@Override
	public List<Map<String, Object>> find(PageBean pageBean) {

		return userGroupDAO.query(pageBean, null, null, null, null, new String[] { group_class },
				new Object[] { ConstantUtil.FLAG_ZERO });
	}

	@Override
	public List<Map<String, Object>> listRefUsers(PageBean pageBean, String groupId) {

		List<Map<String, Object>> resultList = userGroupDAO.listRefUsers(groupId, pageBean);
		if (CollectionUtil.isEmptyCollection(resultList)) {
			return resultList;
		}
		List<Object> userIds = CollectionUtil.findValue(resultList, UserManager.user_id);
		if (CollectionUtil.isEmptyCollection(userIds)) {
			return resultList;
		}

		List<Map<String, Object>> vos = userService.getUserName(userIds);

		JSONArray userNames = (JSONArray) JSON.toJSON(vos);
		if (CollectionUtil.isEmptyCollection(userNames)) {
			return resultList;
		}

		for (Map<String, Object> temap : resultList) {
			String userId = (String) temap.get(UserManager.user_id);
			for (Object ob : userNames) {
				JSONObject jbO = (JSONObject) ob;
				if (CommonUtil.isNotEmpty(userId) && userId.equals(jbO.getString("user_id"))) {
					temap.put("user_name", jbO.get("user_name"));
					temap.put("user_type", jbO.get("user_type"));
				}
			}
		}
		return resultList;
	}

	@Override
	public List<Map<String, Object>> listNoRefUsers(PageBean pageBean, String groupId) {

		List<Map<String, Object>> resultList = userGroupDAO.listNoRefUsers(groupId, pageBean);
		if (CollectionUtil.isEmptyCollection(resultList)) {
			return resultList;
		}
		List<Object> userIds = CollectionUtil.findValue(resultList, UserManager.user_id);
		if (CollectionUtil.isEmptyCollection(userIds)) {
			return resultList;
		}

		List<Map<String, Object>> vos = userService.getUserName(userIds);

		JSONArray userNames = (JSONArray) JSON.toJSON(vos);
		if (CollectionUtil.isEmptyCollection(userNames)) {
			return resultList;
		}

		for (Map<String, Object> temap : resultList) {
			String userId = (String) temap.get(UserManager.user_id);
			for (Object ob : userNames) {
				JSONObject jbO = (JSONObject) ob;
				if (CommonUtil.isNotEmpty(userId) && userId.equals(jbO.getString("user_id"))) {
					temap.put("user_name", jbO.get("user_name"));
					temap.put("user_type", jbO.get("user_type"));
				}
			}
		}
		return resultList;
	}

	@Override
	public List<Map<String, Object>> findGroupsByUserId(String userId, PageBean pageBean) {

		return userGroupDAO.findGroupsByUserId(userId, pageBean);
	}

	@Override
	public void addUsers(@NonNull String groupId, List<String> users, String operator) {

		if (CollectionUtil.isEmptyCollection(users)) {
			return;
		}
		Map<String, Object> vo = new HashMap<>();
		userGroupAndUserDAO.deleteUserGroupAndUser(groupId, users);
		users.remove(0);
		List<Map<String, Object>> args = new ArrayList<>();
		Timestamp now = DateTimeUtil.currentDateTime();
		for (String userId : users) {
			vo.clear();
			vo.put(UserGroupAndUser.idx, CommonUtil.getUUID());
			vo.put(UserGroupAndUser.user_id, userId);
			vo.put(UserGroupAndUser.group_id, groupId);
			vo.put(UserGroupAndUser.create_id, operator);
			vo.put(UserGroupAndUser.create_time, now);
			args.add(vo);
		}
		userGroupAndUserDAO.addVoBatch(null,
				new String[] { UserGroupAndUser.user_id, UserGroupAndUser.group_id },
				NAMES_ID_CT_CID, args);
	}

	@Override
	public void removeUsers(String groupId, List<String> users) {

		if (CollectionUtil.isEmptyCollection(users)) {
			return;
		}
		userGroupAndUserDAO.deleteUserGroupAndUser(groupId, users);
	}
}
