package cn.com.ut.biz.permission.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 角色与用户关系实体
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public class RoleAndUser extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6208614611398359596L;
	/**
	 * 用户id
	 */
	public static final String user_id = "user_id";
	/**
	 * 角色id
	 */
	public static final String role_id = "role_id";
}