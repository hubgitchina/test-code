package cn.com.ut.biz.user.dao;

import cn.com.ut.biz.user.entities.UserPeducation;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 用户教育
 * 
 */
public interface UserPeducationDAO extends JdbcOperation<UserPeducation> {

}
