package cn.com.ut.biz.user.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.user.dao.UserPVocationDAO;
import cn.com.ut.biz.user.dao.UserParentDAO;
import cn.com.ut.biz.user.dao.UserPeducationDAO;
import cn.com.ut.biz.user.dao.UserPersonDAO;
import cn.com.ut.biz.user.entities.UserPVocation;
import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.biz.user.entities.UserPeducation;
import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.biz.user.service.UserExpandService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 用户拓展信息接口实现
 * 
 * @author ouyuexing
 *
 */
@Service
public class UserExpandServiceImpl implements UserExpandService {

	@Resource
	private UserParentDAO userParentDAO;
	@Autowired
	private UserPersonDAO userPersonDAO;
	@Resource
	private UserPeducationDAO userPeducationDAO;
	@Resource
	private UserPVocationDAO userPVocationDAO;

	@Override
	public int updateUserPic(String userId, String userPic) {

		if (CommonUtil.isEmpty(userId, userPic)) {
			ExceptionUtil.throwValidateException("参数空");
		}
		return userPersonDAO.update(null, new String[] { UserPerson.user_pic }, null,
				new String[] { UserPerson.user_id }, new Object[] { userPic },
				new Object[] { userId });

	}

	@Override
	public int updateUserPersion(String userId, Map<String, Object> json) {

		// ValidatorUtil.validateMapContainsKey(json, UserPerson.user_birthday,
		// UserPerson.user_sex,
		// UserParent.email);
		Map<String, Object> userMap = userPersonDAO.getByKey(null, null, null, null,
				new String[] { UserPerson.user_id }, new Object[] { userId }, null);
		if (CollectionUtil.isEmptyMap(userMap)) {
			ExceptionUtil.throwServiceException("用户基础信息空");
		}
		String birthday = (String) json.get(UserPerson.user_birthday);
		if (!CommonUtil.isEmpty(birthday)) {
			userMap.put(UserPerson.user_birthday, DateTimeUtil.dateFormat(birthday,
					cn.com.ut.core.common.constant.ConstantUtil.DATE_FORMAT));
		}
		String sex = (String) json.get(UserPerson.user_sex);
		if (!CommonUtil.isEmpty(sex)) {
			userMap.put(UserPerson.user_sex, json.get(UserPerson.user_sex));
		}
		String email = (String) json.get(UserParent.email);
		if (CommonUtil.isNotEmpty(email)) {
			String[] updateColumnArray = new String[] { UserParent.email };
			Map<String, Object> upMap = new HashMap<>();
			upMap.put(UserParent.email, json.get(UserParent.email));
			upMap.put(UserParent.idx, userId);
			userParentDAO.update(updateColumnArray, upMap);
		}
		return userPersonDAO.update(userMap);
	}

	@Override
	public List<Map<String, Object>> findUserPEducation(String userId) {

		return userPeducationDAO.queryPage(null, null, null, false,
				new String[] { UserPeducation.education_type, UserPeducation.enrollment_year,
						UserPeducation.school_name },
				null, new String[] { UserPeducation.user_id }, null, null, " enrollment_year desc ",
				new Object[] { userId });
	}

	@Override
	public String addUserPEducation(Map<String, Object> parVo) {

		ValidatorUtil.validateMapContainsKey(parVo, UserPeducation.education_type,
				UserPeducation.enrollment_year, UserPeducation.school_name, UserPeducation.user_id);
		return userPeducationDAO.add(parVo);
	}

	@Override
	public int delUserPEducation(String id, String userId) {

		return userPeducationDAO.delete(null,
				new String[] { UserPeducation.idx, UserPeducation.user_id },
				new Object[] { id, userId });
	}

	@Override
	public List<Map<String, Object>> findUserPVocation(String userId) {

		return userPVocationDAO.queryPage(null, null, null, false,
				new String[] { UserPVocation.begin_year, UserPVocation.company_name,
						UserPVocation.end_year },
				null, new String[] { UserPVocation.user_id }, null, null, " begin_year desc ",
				new Object[] { userId });
	}

	@Override
	public String addUserPVocation(Map<String, Object> parVo) {

		ValidatorUtil.validateMapContainsKey(parVo, UserPVocation.begin_year,
				UserPVocation.company_name, UserPVocation.end_year, UserPVocation.user_id);
		return userPVocationDAO.add(parVo);
	}

	@Override
	public int delUserPVocation(String id, String userId) {

		return userPVocationDAO.delete(null,
				new String[] { UserPVocation.idx, UserPVocation.user_id },
				new Object[] { id, userId });

	}

	@Override
	public int updateUserPer(Map<String, Object> vo) {

		String[] updateColumnArray = new String[] { UserPerson.education_level,
				UserPerson.monthly_income, UserPerson.province, UserPerson.city, UserPerson.area,
				UserPerson.contact_addr, UserPerson.user_hobbies, UserPerson.linkman_name,
				UserPerson.fixed_phone, UserPerson.industry_nature, UserPerson.is_marital };
		return userPersonDAO.update(null, updateColumnArray, null,
				new String[] { UserPerson.user_id, UserPerson.is_del },
				ParameterBuilder.builder().append(vo, updateColumnArray).toArray(),
				new Object[] { vo.get(UserPerson.user_id), ConstantUtil.FLAG_NO });
	}
}
