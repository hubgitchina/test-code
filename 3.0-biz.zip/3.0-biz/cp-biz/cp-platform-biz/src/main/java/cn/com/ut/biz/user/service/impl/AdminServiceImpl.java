package cn.com.ut.biz.user.service.impl;

import static cn.com.ut.biz.user.entities.UserManager.user_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.permission.dao.RoleAndUserDAO;
import cn.com.ut.biz.permission.dao.UserGroupAndUserDAO;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.biz.user.dao.UserManagerDAO;
import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.biz.user.service.AdminService;
import cn.com.ut.biz.user.service.AdminUserService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 系统管理员用户管理业务层实现类
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Service
public class AdminServiceImpl implements AdminService {

	@Resource
	private UserManagerDAO userManagerDAO;
	@Resource
	private UserGroupAndUserDAO userGroupAndUserDAO;
	@Resource
	private RoleAndUserDAO roleAndUserDAO;
	@Resource
	private UserService userService;
	@Autowired
	private AdminUserService adminUserService;

	@Override
	public String create(Map<String, Object> vo) {

		String userId = adminUserService.createAdminUser(vo);
		// 使用户为管理员
		vo.put("user_id", userId);
		userManagerDAO.add(vo);
		return userId;
	}

	@Override
	public void update(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, idx, UserManager.update_id);
		userManagerDAO.update(vo);
	}

	@Override
	public void delete(String platformId, String userId) {

		ValidatorUtil.requiredFieldMiss(new String[] { userId });
		Map<String, Object> userManagerVo = userManagerDAO
				.getByProperties(new String[] { UserManager.user_id }, new Object[] { userId });
		if (CollectionUtil.isEmptyMap(userManagerVo)) {
			ExceptionUtil.throwServiceException("数据不存在");
		}
		boolean isUniqueSuperManager = userManagerDAO.isUniqueSuperManager(userId);
		if (isUniqueSuperManager) {
			ExceptionUtil.throwServiceException("不能删除全部的超级管理员用户");
		}

		userGroupAndUserDAO.delete(null, new String[] { UserGroupAndUser.user_id },
				new Object[] { userId });
		roleAndUserDAO.delete(null, new String[] { RoleAndUser.user_id }, new Object[] { userId });
		userManagerDAO.delete(null, new String[] { RoleAndUser.user_id }, new Object[] { userId });
		adminUserService.deleteAdminUser(userId);
	}

	@Override
	public List<Map<String, Object>> find(PageBean page, String platformId) {

		return userManagerDAO.queryPage(page, null, null, false,
				new String[] { user_id + " as id", UserManager.real_name, UserManager.work_number,
						UserManager.work_desc, UserManager.email, UserManager.mobile },
				null, null, null, null, idx, null);
	}

	@Override
	public Map<String, Object> getDetailByUserId(String platformId, String userId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { userId });
		Map<String, Object> resultMap = userManagerDAO.getByKey(null, null,
				new String[] { UserManager.real_name, UserManager.mobile, UserManager.email,
						UserManager.work_number, user_id, UserManager.work_desc, idx },
				null, new String[] { user_id }, new Object[] { userId }, null);
		if (CollectionUtil.isEmptyMap(resultMap)) {
			ExceptionUtil.throwServiceException("查不到用户信息");
		}

		Map<String, Object> userInfo = userService.getUserByUserId(userId);
		if (!CollectionUtil.isEmptyMap(userInfo)) {
			resultMap.put("user_name", userInfo.get("user_name"));
		}
		return resultMap;
	}

	@Override
	public Map<String, Object> getDetailByUserId(String userId) {

		if (CommonUtil.isEmpty(userId)) {
			ExceptionUtil.throwValidateException("用户ID不能为空");
		}
		Map<String, Object> resultMap = userManagerDAO.getByKey(null, null,
				new String[] { UserManager.real_name, UserManager.mobile, UserManager.email,
						UserManager.work_number, user_id, UserManager.work_desc, idx },
				null, new String[] { user_id }, new Object[] { userId }, null);
		if (CollectionUtil.isEmptyMap(resultMap)) {
			ExceptionUtil.throwServiceException("管理员用户信息不存在");
		}

		Map<String, Object> userInfo = userService.getUserByUserId(userId);
		if (!CollectionUtil.isEmptyMap(userInfo)) {
			resultMap.put("user_name", userInfo.get("user_name"));
		}
		return resultMap;
	}

	@Override
	public void modifyAdminPwd(String platformId, String adminUserId, String pwd) {

		ValidatorUtil.requiredFieldMiss(new Object[] { adminUserId, pwd });
		Map<String, Object> resultMap = userManagerDAO.getByProperties(new String[] { user_id },
				new Object[] { adminUserId });
		if (CollectionUtil.isEmptyMap(resultMap)) {
			ExceptionUtil.throwServiceException("用户不存在");
		}
		adminUserService.modifyAdminPwd(adminUserId, pwd);
	}

}
