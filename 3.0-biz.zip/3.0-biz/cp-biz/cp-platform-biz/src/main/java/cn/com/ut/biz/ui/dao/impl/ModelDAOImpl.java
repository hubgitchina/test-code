
//-----------------------------DAOImpl start---------------------------------//
package cn.com.ut.biz.ui.dao.impl;

import static cn.com.ut.biz.ui.entities.Model.app_id;
import static cn.com.ut.biz.ui.entities.Model.front_tech;
import static cn.com.ut.biz.ui.entities.Model.is_use;
import static cn.com.ut.biz.ui.entities.Model.model_name;
import static cn.com.ut.biz.ui.entities.Model.model_type;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.ui.dao.ModelDAO;
import cn.com.ut.biz.ui.entities.Model;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

@Repository
public class ModelDAOImpl extends JdbcOperationsImpl<Model> implements ModelDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, new String[] { front_tech, model_name, model_type, is_use, app_id },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { front_tech, model_name, model_type, is_use, app_id })
						.append(id, DateTimeUtil.currentDateTime(), vo.get(Model.create_id))
						.toArray());
		return id;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null, new String[] { front_tech, model_name, model_type, is_use, app_id },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { front_tech, model_name, model_type, is_use, app_id })
						.append(DateTimeUtil.currentDateTime(), vo.get(Model.update_id)).toArray(),
				(String) vo.get(Model.idx), null);
	}
}
// -----------------------------DAOImpl end---------------------------------//