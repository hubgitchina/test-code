package cn.com.ut.biz.permission.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 用户分组管理业务层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface UserGroupService {

	/**
	 * 创建用户组
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新用户组
	 * 
	 * @param vo
	 * @return
	 */
	void update(Map<String, Object> vo);

	/**
	 * 删除用户组
	 *
	 * @param platformId
	 * @param groupId
	 */
	void delete(String groupId);

	/**
	 * 获取用户组详情
	 * 
	 * @param groupId
	 * @return
	 */
	Map<String, Object> getDetail(String groupId);

	/**
	 * 查询用户组列表
	 * 
	 * @param platformId
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> find(PageBean pageBean);

	/**
	 * 列出用户组已关联的用户
	 * 
	 * @param pageBean
	 * @param groupId
	 * @return
	 */
	List<Map<String, Object>> listRefUsers(PageBean pageBean, String groupId);

	/**
	 * 列出用户组未关联的用户
	 * 
	 * @param platformId
	 * @param pageBean
	 * @param groupId
	 * @return
	 */
	List<Map<String, Object>> listNoRefUsers(PageBean pageBean, String groupId);

	/**
	 * 根据USER_ID查询该用户所属的用户组
	 * 
	 *
	 * @param dataPlatformId
	 * @param userId
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> findGroupsByUserId(String userId, PageBean pageBean);

	/**
	 * 对用户组添加用户
	 * 
	 * @param groupId
	 * @param users
	 * @param operator
	 */
	void addUsers(String groupId, List<String> users, String operator);

	/**
	 * 对用户组移除用户
	 * 
	 * @param groupId
	 * @param users
	 */
	void removeUsers(String groupId, List<String> users);
}
