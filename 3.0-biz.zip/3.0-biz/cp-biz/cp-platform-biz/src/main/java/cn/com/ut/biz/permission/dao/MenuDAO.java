package cn.com.ut.biz.permission.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.permission.entities.Menu;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 菜单管理数据层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface MenuDAO extends JdbcOperation<Menu> {

	/**
	 * 获取指定角色的菜单权限
	 * 
	 * @param roleId
	 * @return 指定角色的菜单集合
	 */
	List<Map<String, Object>> listMenus(String roleId);

	/**
	 * 获取指定角色的菜单权限
	 * 
	 * @param platformId
	 * @param roleId
	 * @return 指定角色的菜单集合
	 */
	List<Map<String, Object>> queryMenuList(String roleId);

	/**
	 * 设置同一级菜单的默认排序，适用PostgreSQL
	 */
	void updateMenuSortDefault();

	/**
	 * 菜单管理查询所有菜单（分页、不分级）
	 * 
	 * @param dataPlatformId
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> queryAllBackgroundMenu(PageBean page);

	/**
	 * 菜单管理查询所有菜单（分页、分级）
	 * 
	 * @param dataPlatformId
	 * @param parentId
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> queryBackgroundMenu(String parentId, PageBean page);

	/**
	 * 删除模块的菜单
	 * 
	 * @param platformId
	 * @param moduleId
	 */
	void delModuleMenu(String moduleId);

	/**
	 * 获取菜单详情
	 * 
	 * @param platformId
	 * @param menuId
	 * @return
	 */
	Map<String, Object> getDetail(String menuId);

	/**
	 * 验证同一级的菜单名称是否存在重复的情况
	 * 
	 * @param name
	 * @param id
	 * @param parentId
	 * @param platformId
	 * @return
	 */
	boolean isUniqueMenuNameOnSameLevel(String name, String id, String parentId);
}
