package cn.com.ut.biz.ui.dao;


import cn.com.ut.biz.ui.entities.Component;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/4/25.
 */
public interface ComponentDAO extends JdbcOperation<Component> {

    /**
     * 更新组件.
     */
    int update(Map<String, Object> vo);


}
