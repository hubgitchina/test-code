package cn.com.ut.biz.business.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.business.entities.BizTmpEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 业务模板与业务实体DAO
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface BizTmpEntityDAO extends JdbcOperation<BizTmpEntity> {

	/**
	 * 根据实例模板ID集合查询所有业务实体
	 * 
	 * @param templateIds
	 * @return
	 */
	List<Map<String, Object>> findEntityByTmpIds(List<String> templateIds);
}