package cn.com.ut.biz.system.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.system.entities.Config;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface ConfigDAO extends JdbcOperation<Config> {

	/**
	 * 检查平台是否存在重复的系统配置编码
	 * 
	 * @param platformId
	 * @param configCode
	 * @param pkFieldNames
	 * @param pkFieldValues
	 * @return 若重复返回true
	 */
	boolean isConfigCodeRepeat(String configCode, String[] pkFieldNames, Object[] pkFieldValues);

	/**
	 * 查询指定平台拥有的系统配置数据
	 * 
	 * @param platformId
	 *            数据所属平台ID
	 * @param page
	 *            分页
	 * @return
	 */
	List<Map<String, Object>> findByPlatformId(PageBean page);

	/**
	 * 获取平台的系统配置值
	 * 
	 * @param platformId
	 * @param configCodes
	 * @return
	 */
	List<Map<String, Object>> getConfigValueByCode(List<Object> configCodes);

}