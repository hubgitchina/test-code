package cn.com.ut.biz.business.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 业务API
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public class BizAPI extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6506873249816362873L;
	/**
	 * 业务实体ID
	 */
	public static final String entity_id = "entity_id";
	/**
	 * api名称
	 */
	public static final String api_name = "api_name";
	/**
	 * api描述
	 */
	public static final String api_desc = "api_desc";
	/**
	 * api版本
	 */
	public static final String api_ver = "api_ver";
	/**
	 * 说明文档
	 */
	public static final String api_doc = "api_doc";
	/**
	 * 接口url
	 */
	public static final String api_url = "api_url";
}
