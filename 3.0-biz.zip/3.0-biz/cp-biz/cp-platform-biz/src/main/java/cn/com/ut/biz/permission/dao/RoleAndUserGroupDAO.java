package cn.com.ut.biz.permission.dao;

import java.util.Map;

import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 角色与用户组关系管理数据层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface RoleAndUserGroupDAO extends JdbcOperation<RoleAndUserGroup> {

	/**
	 * 删除与角色与分组关系记录
	 * 
	 * @param roleId
	 * @return 影响的记录数
	 */
	int deleteByRoleId(String roleId);

	/**
	 * 获取指定角色关联的角色与用户分组关系记录
	 * 
	 * @param roleId
	 * @return 指定角色关联的角色与用户分组关系记录
	 */
	Map<String, Object> getByRoleId(String roleId);
}
