package cn.com.ut.biz.system.service;

/**
 * @version tuna
 * @author gaozhilong
 * 
 */

public interface DictTypeServiceRemote {

}
