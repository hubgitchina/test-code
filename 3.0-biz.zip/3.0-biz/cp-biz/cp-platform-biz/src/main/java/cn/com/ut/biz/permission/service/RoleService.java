package cn.com.ut.biz.permission.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;

/**
 * 角色管理业务层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface RoleService {

	/**
	 * 创建角色
	 * 
	 *
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新角色
	 * 
	 * @param vo
	 *
	 */
	void update(Map<String, Object> vo);

	/**
	 * 删除角色
	 *
	 * (不允许删除sys系统用户创建的角色，检查逻辑外键约束)
	 *
	 * @param platformId
	 * @param roleId
	 */
	void delete(String roleId);

	/**
	 * 查询角色信息列表
	 * 
	 * @param platformId
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> find(PageBean pageBean);

	/**
	 * 查询未使用(可选择)的系统角色
	 * 
	 *
	 * @param platformId
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> queryNotUsedRoles(PageBean pageBean);

	/**
	 * 获取指定角色的详细信息
	 * 
	 *
	 * @param platformId
	 * @param roleId
	 * @return
	 */
	Map<String, Object> getDetail(String roleId);

	/**
	 * 列出角色关联的用户集合
	 * 
	 *
	 * @param platformId
	 * @param roleId
	 * @param user
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> listRoleRefUsers(String roleId, User user, PageBean pageBean);

	/**
	 * 列出角色关联的用户组中未与该角色关联的用户集合
	 * 
	 *
	 * @param platformId
	 * @param roleId
	 * @param user
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> listRoleNoRefUsers(String roleId, User user, PageBean pageBean);

	/**
	 * 查询指定用户关联的角色
	 *
	 * @param userId
	 *            指定用户ID
	 * @param user
	 *            当前用户
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> listUserRefRoles(String userId, User user, PageBean pageBean);

	/**
	 * 查找指定用户没有关联的角色
	 *
	 * @param userId
	 *            指定用户ID
	 * @param user
	 *            登录用户
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> listUserNoRefRoles(String userId, User user, PageBean pageBean);

	/**
	 * 关联用户与用户（从角色关联的用户组中选择用户）
	 * 
	 * @param roleId
	 * @param users
	 * @param operator
	 * @param platformId
	 */
	void addRoleRefUsers(String roleId, List<String> users, String operator, String platformId);

	/**
	 * 给指定用户添加角色
	 * 
	 * @param userId
	 *            指定用户ID
	 * @param roles
	 *            角色ID集
	 * @param operator
	 */
	void addUserRefRoles(String userId, List<String> roles, String operator);

	/**
	 * 移除角色关联的用户
	 *
	 * @param roleId
	 * @param users
	 */
	void removeRoleRefUsers(String roleId, List<String> users);

	/**
	 * 删除指定用户相关的指定角色
	 * 
	 * @param userId
	 * @param roles
	 */
	void removeUserRefRoles(String userId, List<String> roles);

	/**
	 * 列出指定角色关联的系统菜单集合
	 * 
	 * @param roleId
	 *            指定角色
	 * @param parentId
	 *            不传查根节点，传递查其子节点
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> listMenusByRoleId(String roleId, String parentId, PageBean pageBean,
			String operator);

	/**
	 * 获取指定角色的菜单列表，并指拥有哪些菜单，可分配哪些菜单
	 * 
	 * @param roleId
	 * @param user
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> queryEntRoleMenuByName(String roleId, User user, PageBean pageBean);

	/**
	 * 更新指定角色关联的菜单
	 * 
	 * @param roleId
	 *            指定角色
	 * @param menuList
	 * @param operator
	 */
	void updateRoleRefMenus(String roleId, List<Map<String, Object>> menuList, String operator);

	/**
	 * 移除用户拥有的所有角色（一般在用户被删除时调用）
	 *
	 * @param userId
	 *            用户ID
	 * @param roleClasses
	 *            角色类别
	 */
	void removeUserRefRolesAll(String userId, String[] roleClasses);

}
