package cn.com.ut.biz.business.dao.impl;

import java.sql.Timestamp;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.business.dao.BizAPIDAO;
import cn.com.ut.biz.business.entities.BizAPI;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 业务APIDAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Repository
public class BizAPIDAOImpl extends JdbcOperationsImpl<BizAPI> implements BizAPIDAO {

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = { BizAPI.entity_id, BizAPI.api_name, BizAPI.api_desc, BizAPI.api_ver,
				BizAPI.api_doc, BizAPI.api_url };
		add(null, names, NAMES,
				ParameterBuilder.builder().append(vo, names)
						.append(id, time, time, vo.get(BizAPI.create_id), vo.get(BizAPI.create_id))
						.toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, BizAPI.entity_id, BizAPI.api_name, BizAPI.api_desc, BizAPI.api_ver,
				BizAPI.api_doc, BizAPI.api_url);
		String[] names = pb.toColumns();
		return updateById(null, names, NAMES_UT_UID,
				ParameterBuilder.builder().append(vo, names)
						.append(DateTimeUtil.currentDateTime(), vo.get(BizAPI.update_id)).toArray(),
				(String) vo.get(BizAPI.idx));
	}

	@Override
	public boolean isUseTemplate(String apiId) {

		String sql = "select count(*) from t_biz_tmp_entity te, t_biz_api a where te.entity_id = a.entity_id and a.id = ?";
		int tmpEntityNum = queryForInt(getJdbcTemplate(), sql, apiId);
		boolean isUse = false;
		if (tmpEntityNum > 0) {
			isUse = true;
		}
		return isUse;
	}
}
