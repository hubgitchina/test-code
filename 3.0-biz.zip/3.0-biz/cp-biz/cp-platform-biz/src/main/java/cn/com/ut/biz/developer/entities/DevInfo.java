package cn.com.ut.biz.developer.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 开发者信息
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public class DevInfo extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 828976938226370856L;
	/**
	 * 企业名称
	 */
	public static final String corp_name = "corp_name";
	/**
	 * 联系人
	 */
	public static final String link_man = "link_man";
	/**
	 * 联系邮箱
	 */
	public static final String link_email = "link_email";
	/**
	 * 状态(0待审核，1审核中，2审核成功，3审核失败)
	 */
	public static final String status = "status";
	/**
	 * 联系电话
	 */
	public static final String link_phone = "link_phone";
	/**
	 * 营业执照号
	 */
	public static final String license_code = "license_code";
	/**
	 * 营业执照扫描件
	 */
	public static final String license_append = "license_append";
	/**
	 * 组织机构代码
	 */
	public static final String organization_code = "organization_code";
	/**
	 * 组织机构扫描件
	 */
	public static final String organization_append = "organization_append";
	/**
	 * 税务登记号
	 */
	public static final String tax_code = "tax_code";
	/**
	 * 税务登记扫描件
	 */
	public static final String tax_append = "tax_append";
	/**
	 * 开发者ID
	 */
	public static final String dev_id = "dev_id";
	/**
	 * 审核时间
	 */
	public static final String audit_time = "audit_time";
	/**
	 * 审核人
	 */
	public static final String audit_operator = "audit_operator";
	/**
	 * 审核结果
	 */
	public static final String audit_result = "audit_result";
}
