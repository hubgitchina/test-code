package cn.com.ut.biz.app.service;

import java.util.List;
import java.util.Map;

/**
 * 应用与业务模板业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface AppTmpService {

	/**
	 * 自定义创建应用的实例
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 通过模板创建应用下的实例
	 * 
	 * @param vo
	 * @return
	 */
	String createAppTmp(Map<String, Object> vo);

	/**
	 * 更新应用关联业务模板
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询应用关联业务模板详情
	 */
	Map<String, Object> getDetail(String id);

	/**
	 * 删除应用关联业务模板
	 * 
	 * @param id
	 */
	void delete(String id);

	/**
	 * 查询应用关联所有业务模板
	 * 
	 * @return
	 */
	List<Map<String, Object>> findTmpByAppId(String appId);
}
