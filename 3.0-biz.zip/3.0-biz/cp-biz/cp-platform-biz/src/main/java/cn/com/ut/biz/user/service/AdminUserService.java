package cn.com.ut.biz.user.service;

import java.util.Map;
import java.util.Set;

import cn.com.ut.core.common.system.beans.User;

/**
 * 超级管理员用户业务层接口
 * 
 */
public interface AdminUserService {

	/**
	 * 创建一个超级管理员用户
	 * 
	 * @param vo
	 * @return
	 */
	String createAdminUser(Map<String, Object> vo);

	/**
	 * 超级管理员登录
	 * 
	 * @param user
	 * @param loginByPwd
	 * @param b
	 */
	void loginByPwd(User user, Map<String, Object> loginByPwd, boolean b);

	/**
	 * 修改管理员密码
	 * 
	 * @param adminUserId
	 * @param pwd
	 */
	void modifyAdminPwd(String adminUserId, String pwd);

	/**
	 * 删除一个超级管理员
	 * 
	 * @param userID
	 */
	void deleteAdminUser(String userID);

	/**
	 * 删除一个或者多个超级管理员
	 * 
	 * @param userID
	 */
	void deleteAdminUser(Set<Object> userIDs);

}
