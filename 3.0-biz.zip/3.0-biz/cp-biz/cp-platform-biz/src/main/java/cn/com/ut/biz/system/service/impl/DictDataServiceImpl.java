/*
 * Copyright 2013 The UTFoodPortalSE Project. Zhuhai Unitech Power Technology Co.,Ltd. All Rights Reserved.
 */
package cn.com.ut.biz.system.service.impl;

import static cn.com.ut.biz.system.entities.DictData.dict_code;
import static cn.com.ut.biz.system.entities.DictData.dict_text;
import static cn.com.ut.biz.system.entities.DictData.sort_num;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_use;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.com.ut.biz.system.dao.DictDataDAO;
import cn.com.ut.biz.system.dao.DictTypeDAO;
import cn.com.ut.biz.system.entities.DictData;
import cn.com.ut.biz.system.entities.DictType;
import cn.com.ut.biz.system.service.DictDataService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.DictBuilder;

/**
 * 字典项管理
 * 
 * @author ouyuexing
 * @since 2014-3-28
 */
@Service
public class DictDataServiceImpl implements DictDataService {

	@Resource
	private DictDataDAO dictDataDAO;
	@Resource
	private DictTypeDAO dictTypeDAO;

	@Override
	public String create(Map<String, Object> dictDataVo) {

		ValidatorUtil.validateMapContainsKey(dictDataVo, dict_code, dict_text, "dict_type_id",
				is_use, create_id);
		String sortNum = dictDataVo.get(sort_num).toString();
		if (NumberUtil.isInteger(sortNum, false, 10)) {
			dictDataVo.put(sort_num, Integer.parseInt(sortNum));
		} else {
			ExceptionUtil.throwValidateException("排序参数格式有误，不是整数");
		}
		String dictCode = (String) dictDataVo.get(dict_code);

		// 从DictType中查询出GROUP_CODE和DICTTYPE_CODE
		String dictTypeId = (String) dictDataVo.get("dict_type_id");
		Map<String, Object> dictTypeVo = dictTypeDAO.get(dictTypeId);
		if (CollectionUtil.isEmptyMap(dictTypeVo)) {
			ExceptionUtil.throwValidateException("字典类型不存在");
		}
		String groupCode = (String) dictTypeVo.get(DictType.group_code);
		String dictType = (String) dictTypeVo.get(DictType.dicttype_code);

		boolean isDictDataCodeRepeat = dictDataDAO.isDictDataCodeRepeat(dictType, dictCode, null,
				null);
		if (isDictDataCodeRepeat) {
			ExceptionUtil.throwValidateException("字典类型编码重复");
		}

		dictDataVo.put(DictData.group_code, groupCode);
		dictDataVo.put(DictData.dict_type, dictType);
		String dictDataId = dictDataDAO.add(dictDataVo);

		return dictDataId;
	}

	@Override
	public String update(Map<String, Object> dictDataVo) {

		ValidatorUtil.validateMapContainsKey(dictDataVo, idx, dict_code, dict_text, "dict_type_id",
				update_id);
		String sortNum = (String) dictDataVo.get(sort_num);
		String dictDataId = (String) dictDataVo.get(DictData.idx);
		if (NumberUtil.isInteger(sortNum, false, 10)) {
			dictDataVo.put(sort_num, Integer.parseInt(sortNum));
		} else {
			ExceptionUtil.throwValidateException("排序参数格式有误，不是整数");
		}
		String dictCode = (String) dictDataVo.get(dict_code);
		String dictTypeId = (String) dictDataVo.get("dict_type_id");
		Map<String, Object> dictTypeVo = dictTypeDAO.get(dictTypeId);
		if (CollectionUtil.isEmptyMap(dictTypeVo)) {
			ExceptionUtil.throwValidateException("字典类型不存在");
		}
		String dictType = (String) dictTypeVo.get(DictType.dicttype_code);

		boolean isDictDataCodeRepeat = dictDataDAO.isDictDataCodeRepeat(dictType, dictCode,
				new String[] { idx }, new Object[] { dictDataId });
		if (isDictDataCodeRepeat) {
			ExceptionUtil.throwValidateException("字典项编码重复");
		}

		String operator = (String) dictDataVo.get(DictType.update_id);

		dictDataDAO.update(dictDataVo);
		return dictDataId;

	}

	/**
	 * 获取某字典详细信息
	 * 
	 * @param platformId
	 * @param dictDataId
	 */
	public Map<String, Object> getDetail(String dictDataId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { dictDataId });
		return dictDataDAO.getDetail(dictDataId);
	}

	@Override
	public void delMark(String dictDataId, String operator) {

		ValidatorUtil.requiredFieldMiss(new Object[] { dictDataId });
		Map<String, Object> vo = dictDataDAO.getDetail(dictDataId);
		if (CollectionUtil.isEmptyMap(vo)) {
			return;
		}

		dictDataDAO.deleteMark(dictDataId, operator);

	}

	@Override
	public void delMark(String[] ids, String operator) {

		ValidatorUtil.requiredFieldMiss(new Object[] { ids });

		Collection<String> delDictDataIds = Arrays.asList(ids);
		if (!CollectionUtil.isEmptyCollection(delDictDataIds)) {
			dictDataDAO.delMarkByIds(delDictDataIds);
		}
	}

	@Override
	public List<Map<String, Object>> findDictDataByType(String dictTypeId, PageBean pageBean) {

		ValidatorUtil.requiredFieldMiss(new Object[] { dictTypeId });
		return dictDataDAO.findDictDataByType(dictTypeId, pageBean);
	}

	@Override
	public List<Map<String, Object>> findDictDataExt(String dictTypeCode) {

		ValidatorUtil.requiredFieldMiss(new Object[] { dictTypeCode });
		List<Object> dictTypeCodes = new ArrayList<>();
		dictTypeCodes.add(dictTypeCode);
		return dictDataDAO.findDictData(dictTypeCodes, null);
	}

	@Override
	public List<Map<String, Object>> findDictDataExt() {

		List<Map<String, Object>> dictDataList = dictDataDAO.findDictData(null);

		Map<String, Collection<Map<String, Object>>> res = CollectionUtil
				.listToMapList(dictDataList, "dict_type");
		List<Map<String, Object>> resultList = new ArrayList<>();
		for (String key : res.keySet()) {
			Map<String, Object> tem = new HashMap<>();
			tem.put("dict_type", key);
			tem.put("dict_data", res.get(key));
			resultList.add(tem);
		}
		return resultList;
	}

	@Override
	public List<Map<String, Object>> findDictDataExt(List<Object> dictTypeCodes) {

		ValidatorUtil.requiredFieldMiss(new Object[] { dictTypeCodes });
		List<Map<String, Object>> dictDataList = dictDataDAO.findDictData(dictTypeCodes, null);

		Map<String, Collection<Map<String, Object>>> res = CollectionUtil
				.listToMapList(dictDataList, "dict_type");
		List<Map<String, Object>> resultList = new ArrayList<>();
		for (String key : res.keySet()) {
			Map<String, Object> tem = new HashMap<>();
			tem.put("dict_type", key);
			tem.put("dict_data", res.get(key));
			resultList.add(tem);
		}
		return resultList;
	}

	@Override
	public List<Map<String, Object>> findDictData(String dictTypeCode, PageBean pageBean) {

		ValidatorUtil.requiredFieldMiss(new Object[] { dictTypeCode });
		List<Object> dictTypeCodes = new ArrayList<>();
		dictTypeCodes.add(dictTypeCode);
		return queryDictDataByPlatform(dictTypeCodes);
	}

	@Override
	public Map<String, Object> preDictHandle(Map<String, Object> row, DictBuilder dictBuilder) {

		if (CollectionUtil.isEmptyMap(row) || dictBuilder == null
				|| CollectionUtil.isEmptyMap(dictBuilder.getDict())) {
			return row;
		}
		List<Object> dictTypeCodes = new ArrayList<>(dictBuilder.getDict().values());
		List<Map<String, Object>> dictDataList = queryDictDataByPlatform(dictTypeCodes);

		// 处理字典项到结果集row
		Map<String, Collection<Map<String, Object>>> dictTypeDataList = CollectionUtil
				.listToMapList(dictDataList, "dict_type");
		appendDictText(dictBuilder.getDict(), dictTypeDataList, row);
		return row;
	}

	@Override
	public List<Map<String, Object>> preDictHandle(List<Map<String, Object>> rows,
			DictBuilder dictBuilder) {

		if (CollectionUtil.isEmptyCollection(rows) || dictBuilder == null
				|| CollectionUtil.isEmptyMap(dictBuilder.getDict())) {
			return rows;
		}

		List<Object> dictTypeCodes = new ArrayList<>(dictBuilder.getDict().values());
		List<Map<String, Object>> dictDataList = queryDictDataByPlatform(dictTypeCodes);

		// 处理字典项到结果集row
		Map<String, Collection<Map<String, Object>>> dictTypeDataList = CollectionUtil
				.listToMapList(dictDataList, "dict_type");
		for (Map<String, Object> row : rows) {
			appendDictText(dictBuilder.getDict(), dictTypeDataList, row);
		}
		return rows;
	}

	/**
	 * 查询字典项，如果平台自己使用了字典模块并覆盖了相关的字典项则采用平台自己的，否则用基础数据的
	 * 
	 * @param platformId
	 * @param dictTypeCodes
	 * @return
	 */
	private List<Map<String, Object>> queryDictDataByPlatform(List<Object> dictTypeCodes) {

		return dictDataDAO.findDictData(dictTypeCodes, null);

	}

	private void appendDictText(Map<String, String> dictSet,
			Map<String, Collection<Map<String, Object>>> dictTypeDataList,
			Map<String, Object> row) {

		for (String dict : dictSet.keySet()) {
			String dictTypeCode = dictSet.get(dict);
			Collection<Map<String, Object>> dictDataVos = dictTypeDataList.get(dictTypeCode);
			if (CollectionUtil.isEmptyCollection(dictDataVos)) {
				row.put(dict + ConstantUtil.dict_fix, ConstantUtil.STR_EMPTY);
				continue;
			}
			Map<String, Object> dictCodeTextMap = new HashMap<>();
			if (!CollectionUtil.isEmptyCollection(dictDataVos)) {
				for (Map<String, Object> rule : dictDataVos) {
					dictCodeTextMap.put((String) rule.get("dict_code"), rule.get("dict_text"));
				}
			}
			String dictDataCode = (String) row.get(dict);
			String dictDataValue = (String) dictCodeTextMap.get(dictDataCode);
			row.put(dict + ConstantUtil.dict_fix, dictDataValue);
		}
	}

}
