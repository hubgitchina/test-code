package cn.com.ut.biz.business.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.business.dao.BizTmpEntityDAO;
import cn.com.ut.biz.business.service.BizTmpEntityService;

/**
 * 业务模板关联业务实体业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Service
public class BizTmpEntityServiceImpl implements BizTmpEntityService {

	@Autowired
	private BizTmpEntityDAO bizTmpEntityDAO;

	@Override
	public String create(Map<String, Object> vo) {

		return null;
	}

	@Override
	public String update(Map<String, Object> vo) {

		return null;
	}

	@Override
	public Map<String, Object> getDetail(String tmpEntityId) {

		return null;

	}

	@Override
	public void delete(String tmpEntityId) {

		bizTmpEntityDAO.delete(tmpEntityId);
	}
}
