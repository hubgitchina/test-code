package cn.com.ut.biz.user.dao.impl;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.user.dao.UserPVocationDAO;
import cn.com.ut.biz.user.entities.UserPVocation;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 用户工作经历
 * 
 * @author ouyuexing
 *
 */
@Repository
public class UserPVocationDAOImpl extends JdbcOperationsImpl<UserPVocation>
		implements UserPVocationDAO {

	String[] COLUMNS = { UserPVocation.begin_year, UserPVocation.company_name,
			UserPVocation.end_year, UserPVocation.user_id };

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

}
