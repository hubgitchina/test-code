package cn.com.ut.biz.app.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.app.dao.AppInfoDAO;
import cn.com.ut.biz.app.entities.AppInfo;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 应用信息DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Repository
public class AppInfoDAOImpl extends JdbcOperationsImpl<AppInfo> implements AppInfoDAO {

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = { AppInfo.app_id, AppInfo.app_name };
		add(null, names, NAMES, ParameterBuilder.builder().append(vo, names)
				.append(id, time, time, vo.get(AppInfo.create_id), vo.get(AppInfo.create_id))
				.toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, AppInfo.app_name);
		String[] names = pb.toColumns();
		return updateById(null, names, NAMES_UT_UID, ParameterBuilder.builder().append(vo, names)
				.append(DateTimeUtil.currentDateTime(), vo.get(AppInfo.update_id)).toArray(),
				(String) vo.get(AppInfo.idx));
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		String[] selectCols = new String[] { AppInfo.idx, AppInfo.app_id, AppInfo.app_name,
				AppInfo.app_key, AppInfo.status };
		return queryPage(page, null, null, false, selectCols, null, new String[] { AppInfo.is_del },
				null, null, AppInfo.create_time, new Object[] { ConstantUtil.FLAG_NO });
	}

	@Override
	public int generateAccessKey(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, AppInfo.app_key);
		String[] names = pb.toColumns();
		return updateById(null, names, NAMES_UT_UID, ParameterBuilder.builder().append(vo, names)
				.append(DateTimeUtil.currentDateTime(), vo.get(AppInfo.update_id)).toArray(),
				(String) vo.get(AppInfo.idx));
	}

	@Override
	public int examineAppInfo(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, AppInfo.status, AppInfo.audit_time, AppInfo.audit_operator,
				AppInfo.audit_result);
		String[] names = pb.toColumns();
		vo.put(AppInfo.audit_time, DateTimeUtil.currentDateTime());
		return updateById(null, names, null, ParameterBuilder.builder().append(vo, names).toArray(),
				(String) vo.get(AppInfo.idx));
	}

	@Override
	public int submitExamine(Map<String, Object> vo) {

		return updateById(null, new String[] { AppInfo.status },
				NAMES_UT_UID, new Object[] { ConstantUtil.AuditStatus.AUDIT_BEGIN,
						DateTimeUtil.currentDateTime(), vo.get(AppInfo.update_id) },
				(String) vo.get(AppInfo.idx));
	}

	@Override
	public int confirmUpdate(String id) {

		// 修改审核状态为待审核状态
		return updateById(null, new String[] { AppInfo.status }, null,
				new Object[] { ConstantUtil.AuditStatus.AUDIT_READY }, id);

	}

	@Override
	public int onlineApp(Map<String, Object> vo) {

		return updateById(null, new String[] { AppInfo.publish_status }, NAMES_UT_UID,
				new Object[] {
						cn.com.ut.common.constant.platform.ConstantUtil.ApplicationStatus.APP_ONLINE,
						DateTimeUtil.currentDateTime(), vo.get(AppInfo.update_id) },
				(String) vo.get(AppInfo.idx));
	}

	@Override
	public int downlineApp(Map<String, Object> vo) {

		return updateById(null, new String[] { AppInfo.publish_status }, NAMES_UT_UID,
				new Object[] {
						cn.com.ut.common.constant.platform.ConstantUtil.ApplicationStatus.APP_DOWNLINE,
						DateTimeUtil.currentDateTime(), vo.get(AppInfo.update_id) },
				(String) vo.get(AppInfo.idx));
	}
}
