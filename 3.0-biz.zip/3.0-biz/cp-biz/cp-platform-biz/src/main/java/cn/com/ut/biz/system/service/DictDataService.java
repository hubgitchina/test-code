package cn.com.ut.biz.system.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.restful.DictBuilder;

/**
 * @version tuna
 * @author gaozhilong
 * 
 */

public interface DictDataService extends DictDataServiceRemote {

	/**
	 * 创建字典内容
	 */
	String create(Map<String, Object> dictDataVo);

	/**
	 * 修改字典内容，返回字典内容ID（有可能跟原来的不一样）
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查看字典内容详情
	 * 
	 * @param platformId
	 * @param dictDataId
	 */
	Map<String, Object> getDetail(String dictDataId);

	/**
	 * 删除字典内容
	 *
	 * @param platformId
	 * @param dictDataId
	 * @param operator
	 */
	void delMark(String dictDataId, String operator);

	/**
	 * 批量删除字典内容
	 * 
	 * @param platformId
	 * @param ids
	 * @param operator
	 */
	void delMark(String[] ids, String operator);

	/**
	 * 查询平台的指定单个字典类型下所有(包括启用和没有启用的)字典项
	 * 
	 *
	 * @param platformId
	 * @param dictTypeId
	 *            字典类型ID
	 * @param bean
	 * @return
	 */
	List<Map<String, Object>> findDictDataByType(String dictTypeId, PageBean bean);

	/**
	 * 查询平台的指定单个字典类型下所有(启用的)字典项 如果该平台没有记录，查默认平台(基础数据平台)的字典项记录
	 * 
	 * @param platformId
	 *            平台ID
	 * @param dictTypeCode
	 *            字典类型code
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> findDictData(String dictTypeCode, PageBean pageBean);

	/**
	 * 为接口添加字典项对应的值，相当于以前的appendDict
	 * 
	 * @param platformId
	 * @param row
	 * @param dictBuilder
	 * @return row
	 */
	Map<String, Object> preDictHandle(Map<String, Object> row, DictBuilder dictBuilder);

	/**
	 * 为接口添加字典项对应的值，相当于以前的appendDict
	 * 
	 * @param platformId
	 * @param rows
	 * @param dictBuilder
	 * @return rows
	 */
	List<Map<String, Object>> preDictHandle(List<Map<String, Object>> rows,
			DictBuilder dictBuilder);
}
