package cn.com.ut.util;

import cn.com.ut.core.common.util.ExceptionUtil;

public class PageUtil {

	/** 上次生成ID的时间截 */
	private static long lastPageCode = -1L;

	/**
	 * 产生新的PAGE_CODE (该方法是线程安全的)
	 * 
	 * @return PageCode
	 */
	public static synchronized String nextPageCode() {

		long pageCode = timeGen();

		// 如果当前时间小于上一次ID生成的时间戳，说明系统时钟回退过这个时候应当抛出异常
		if (pageCode < lastPageCode) {
			ExceptionUtil.throwServiceException(
					String.format("系统时钟回退异常，距离当前时间落后  %d 毫秒", lastPageCode - pageCode));
		}

		// 如果是同一时间生成的
		if (lastPageCode == pageCode) {
			// 阻塞到下一个毫秒,获得新的时间戳
			pageCode = tilNextMillis(lastPageCode);
		}

		// 上次生成ID的时间截
		lastPageCode = pageCode;

		return String.valueOf(pageCode);
	}

	/**
	 * 阻塞到下一个毫秒，直到获得新的时间戳
	 * 
	 * @param lastTimestamp
	 *            上次生成ID的时间截
	 * @return 当前时间戳
	 */
	protected static long tilNextMillis(long lastTimestamp) {

		long timestamp = timeGen();
		while (timestamp <= lastTimestamp) {
			timestamp = timeGen();
		}
		return timestamp;
	}

	/**
	 * 返回以毫秒为单位的当前时间
	 * 
	 * @return 当前时间(毫秒)
	 */
	protected static long timeGen() {

		return System.nanoTime();
	}

}