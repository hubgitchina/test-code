package cn.com.ut.biz.permission.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.core.common.annotation.Dialect;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 角色菜单关系管理数据层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface RoleAndMenuDAO extends JdbcOperation<RoleAndMenu> {

	/**
	 * 删除指定角色下的指定菜单关系记录
	 * 
	 * @param roleId
	 *            指定角色
	 * @param menus
	 *            指定菜单
	 * @return 影响的记录数
	 */
	int deleteRoleMenusIn(String roleId, List<String> menus);

	/**
	 * 获取指定角色与指定菜单的角色关系记录
	 * 
	 * @param roleId
	 * @param menus
	 * @return 指定角色与指定菜单的角色关系记录
	 */
	List<Map<String, Object>> listRoleMenusIn(String roleId, List<String> menus);

	void addBatch(String roleId, List<Map<String, Object>> voList);

	void updateBatch(String roleId, List<Map<String, Object>> voList);

	/**
	 * 根据菜单id删除相关的角色菜单关系记录
	 * 
	 * @param menuId
	 * @return 影响的记录数
	 */
	int deleteRoleAndMenuByMenuId(String menuId);

	/**
	 * 获取用户的菜单
	 * 
	 * @param userId
	 * @return
	 */
	List<Map<String, Object>> getUserMenu(String userId);

	void deleteRoleAndMenuNotExistByRoleId(String roleId);

	@Dialect(multiDialectSupport = true)
	void deleteRoleAndMenuWithoutNextLevelByRoleId(String roleId);

	List<Map<String, Object>> getUserMenuByIds(List<String> menuIds);
}
