package cn.com.ut.biz.verification.controller;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.google.code.kaptcha.impl.DefaultKaptcha;

import cn.com.ut.biz.sms.service.SmsService;
import cn.com.ut.biz.user.dao.UserParentDAO;
import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.cache.CacheHelper;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.IpUtil;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 验证码相关的控制器
 * 
 * @author ouyuexing
 *
 */
@RestController
@RequestMapping(value = "/verification")
public class VerificationController {

	@Autowired
	private DefaultKaptcha kaptcha;
	@Autowired
	private CacheHelper cacheHelper;
	@Autowired
	private SmsService smsService;
	@Resource
	private UserParentDAO userParentDAO;
	@Autowired
	private Environment env;

	@ServiceComponent(session = false)
	@GetMapping(value = "/picver")
	public void picver(HttpServletResponse response, @RequestAttribute("user") User user)
			throws IOException {

		String sessionId = user.getSessionId();
		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		response.setHeader("Pragma", "no-cache");
		response.setContentType("image/jpeg");

		String capText = kaptcha.createText();
		cacheHelper.delete(ConstantUtil.CACHE_PREFIX.PIC_DEFAULT + sessionId);
		cacheHelper.add(ConstantUtil.CACHE_PREFIX.PIC_DEFAULT + sessionId,
				ConstantUtil.VERIFICATION_TIME.PIC_DEFAULT, capText);
		BufferedImage bi = kaptcha.createImage(capText);
		ServletOutputStream out = response.getOutputStream();
		try {
			ImageIO.write(bi, "jpg", out);
			out.flush();
		} finally {
			out.close();
		}
	}

	@ServiceComponent(session = false)
	@GetMapping(value = "/getPicver")
	public void picver2(HttpServletResponse response, @RequestParam(name = "sid") String sid)
			throws IOException {

		response.setDateHeader("Expires", 0);
		response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		response.setHeader("Pragma", "no-cache");
		response.setContentType("image/jpeg");

		String capText = kaptcha.createText();
		cacheHelper.delete(ConstantUtil.CACHE_PREFIX.PIC_DEFAULT + sid);
		cacheHelper.add(ConstantUtil.CACHE_PREFIX.PIC_DEFAULT + sid,
				ConstantUtil.VERIFICATION_TIME.PIC_DEFAULT, capText);
		BufferedImage bi = kaptcha.createImage(capText);
		ServletOutputStream out = response.getOutputStream();
		try {
			ImageIO.write(bi, "jpg", out);
			out.flush();
		} finally {
			out.close();
		}
	}

	/**
	 * 获取手机验证码
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/mobilever")
	public ResponseWrap mobilever(@RequestBody ResponseWrap responseWrap,
			HttpServletRequest request,
			@RequestAttribute(value = "user", required = false) User user) {

		checkIpSend(request);
		JSONObject par = responseWrap.getJson();
		if (par == null) {
			ExceptionUtil.throwValidateException("参数不能为空");
		}
		String mobile = par.getString("mobile");
		String type = par.getString("type");
		if (CommonUtil.isEmpty(mobile, type)) {
			ExceptionUtil.throwValidateException("MOBILE TYPE参数不能为空");
		}
		if (!NumberUtil.checkMobileNumber(mobile)) {
			ExceptionUtil.throwServiceException("手机号码不正确");
		}

		int timeout = 0;
		String key = null;
		String capText = kaptcha.createText();
		switch (type) {
		case ConstantUtil.MOBILEVER_TYPE.MOBILE_REGISTER:
			key = ConstantUtil.CACHE_PREFIX.MOBILE_REGISTER + mobile;
			timeout = ConstantUtil.VERIFICATION_TIME.MOBILE_REGISTER;
			checkAndPutinCache(key, timeout, capText);
			// 可加逻辑 该手机已经注册就不发送验证码
			// boolean flag = userParentDAO.checkUnique(new String[] {
			// UserParent.MOBILE },
			// new Object[] { mobile }, null, null);
			// if (!flag) {
			// ExceptionUtil.throwServiceException("该手机已注册");
			// }
			smsService.sendRegisterSmsNotice(mobile, capText);
			break;

		case ConstantUtil.MOBILEVER_TYPE.MOBILE_LOGIN:
			key = ConstantUtil.CACHE_PREFIX.MOBILE_LOGIN + mobile;
			timeout = ConstantUtil.VERIFICATION_TIME.MOBILE_LOGIN;
			checkAndPutinCache(key, timeout, capText);
			// 可加入逻辑该手机不是我们用户则不发送
			// boolean flag2 = userParentDAO.checkUnique(new String[] {
			// UserParent.MOBILE },
			// new Object[] { mobile }, null, null);
			// if (flag2) {
			// ExceptionUtil.throwServiceException("该手机未注册");
			// }
			// 暂时先用注册模板
			smsService.sendRegisterSmsNotice(mobile, capText);
			break;
		// 绑定手机
		case ConstantUtil.MOBILEVER_TYPE.BIND_MOBILE:
			if (user == null || CommonUtil.isEmpty(user.getUserId())) {
				ExceptionUtil.throwServiceException("清先登录");
			}
			key = ConstantUtil.CACHE_PREFIX.BIND_MOBILE + mobile;
			timeout = ConstantUtil.VERIFICATION_TIME.BIND_MOBILE;
			checkAndPutinCache(key, timeout, capText);
			// 可加入逻辑该手机不是我们用户则不发送
			Map<String, Object> userMap = userParentDAO.getById(null, null,
					new String[] { UserParent.idx, UserParent.mobile }, null, user.getUserId());
			if (CollectionUtil.isEmptyMap(userMap) || userMap.get(UserParent.mobile) != null) {
				ExceptionUtil.throwServiceException("用户已经绑定手机");
			}
			boolean flag = userParentDAO.checkUnique(
					new String[] { UserParent.mobile, UserParent.is_del },
					new Object[] { mobile, ConstantUtil.FLAG_NO }, null, null);
			if (!flag) {
				ExceptionUtil.throwServiceException("手机号码已经注册不能绑定");
			}
			// 暂时先用注册模板
			smsService.sendRegisterSmsNotice(mobile, capText);
			break;
		// 更换手机
		case ConstantUtil.MOBILEVER_TYPE.MODIFY_MOBILE:
			key = ConstantUtil.CACHE_PREFIX.MODIFY_MOBILE + mobile;
			timeout = ConstantUtil.VERIFICATION_TIME.MODIFY_MOBILE;
			checkAndPutinCache(key, timeout, capText);
			// 可加入逻辑该手机不是我们用户则不发送
			Map<String, Object> userMap2 = userParentDAO.getById(null, null,
					new String[] { UserParent.idx, UserParent.mobile }, null, user.getUserId());
			if (CollectionUtil.isEmptyMap(userMap2) || userMap2.get(UserParent.mobile) == null) {
				ExceptionUtil.throwServiceException("用户还没绑定手机");
			}
			if (mobile.equals(userMap2.get(UserParent.mobile))) {
				ExceptionUtil.throwServiceException("手机号码不需要更换");
			}
			boolean flag2 = userParentDAO.checkUnique(
					new String[] { UserParent.mobile, UserParent.is_del },
					new Object[] { mobile, ConstantUtil.FLAG_NO }, null, null);
			if (!flag2) {
				ExceptionUtil.throwServiceException("手机号码已经注册不能绑定");
			}
			// 暂时先用注册模板
			smsService.sendModMobileSmsNotice(mobile, capText);
			break;

		case ConstantUtil.MOBILEVER_TYPE.FORGET_PWD:
			key = ConstantUtil.CACHE_PREFIX.MOBILE_FORGETPWD + mobile;
			timeout = ConstantUtil.VERIFICATION_TIME.MOBILE_FORGETPWD;
			checkAndPutinCache(key, timeout, capText);
			Map<String, Object> userMap3 = userParentDAO.getByKey(null, null, null, null,
					new String[] { UserParent.mobile }, new Object[] { mobile }, null);
			if (CollectionUtil.isEmptyMap(userMap3)) {
				ExceptionUtil.throwServiceException("手机没绑定");
			}
			// 暂时先用注册模板
			smsService.sendModMobileSmsNotice(mobile, capText);
		default:
			ExceptionUtil.throwServiceException("TYPE不支持该类型");
		}
		return responseWrap;

	}

	/**
	 * 检查IP发送是否超过系统设置
	 */
	private void checkIpSend(HttpServletRequest request) {

		if (!ConstantUtil.FLAG_YES.equals(env.getProperty("jsms.maxsend.ip.open"))) {
			return;
		}
		String ip = IpUtil.getIpAddress(request);
		Integer time = cacheHelper.get(ConstantUtil.CACHE_PREFIX.IP_SEND_MSG + ip);
		if (time == null) {
			time = 0;
		}
		int maxTime = env.getProperty("jsms.maxsend.ip.time", Integer.class, 5);
		if (maxTime <= time) {
			ExceptionUtil.throwServiceException("你发送太频繁了请稍后再试");
		}
		time = time + 1;
		cacheHelper.set(ConstantUtil.CACHE_PREFIX.IP_SEND_MSG + ip, 60, time);
	}

	private void checkAndPutinCache(String key, int timeout, String capText) {

		// if (cacheHelper.get(key) != null) {
		// ExceptionUtil.throwServiceException("发送太频繁了");
		// }
		cacheHelper.delete(key);
		cacheHelper.add(key, timeout, capText);
	}

	private void checkCode(String key, String code) {

		String cachCode = cacheHelper.get(key);
		if (CommonUtil.isEmpty(cachCode) || !cachCode.equals(code)) {
			ExceptionUtil.throwServiceException("验证码不正确");
		}
	}

	/**
	 * 获取手机验证码
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/checkMobileCode")
	public ResponseWrap checkMobileCode(@RequestBody ResponseWrap responseWrap) {

		JSONObject par = responseWrap.getJson();
		if (par == null) {
			ExceptionUtil.throwValidateException("参数不能为空");
		}
		String mobile = par.getString("mobile");
		String type = par.getString("type");
		String code = par.getString("code");
		if (CommonUtil.isEmpty(mobile, type, code)) {
			ExceptionUtil.throwValidateException("MOBILE TYPE code 参数不能为空");
		}
		if (!NumberUtil.checkMobileNumber(mobile)) {
			ExceptionUtil.throwServiceException("手机号码不正确");
		}

		String key = null;
		switch (type) {
		case ConstantUtil.MOBILEVER_TYPE.MOBILE_REGISTER:
			key = ConstantUtil.CACHE_PREFIX.MOBILE_REGISTER + mobile;
			checkCode(key, code);
			break;

		case ConstantUtil.MOBILEVER_TYPE.MOBILE_LOGIN:
			key = ConstantUtil.CACHE_PREFIX.MOBILE_LOGIN + mobile;
			checkCode(key, code);
			break;
		// 绑定手机
		case ConstantUtil.MOBILEVER_TYPE.BIND_MOBILE:
			key = ConstantUtil.CACHE_PREFIX.BIND_MOBILE + mobile;
			checkCode(key, code);
			break;
		// 更换手机
		case ConstantUtil.MOBILEVER_TYPE.MODIFY_MOBILE:
			key = ConstantUtil.CACHE_PREFIX.MODIFY_MOBILE + mobile;
			checkCode(key, code);
			break;
		case ConstantUtil.MOBILEVER_TYPE.FORGET_PWD:
			key = ConstantUtil.CACHE_PREFIX.MOBILE_FORGETPWD + mobile;
			String userName = par.getString("user_name");
			if (CommonUtil.isEmpty(userName)) {
				ExceptionUtil.throwValidateException("user_name 参数不能为空");
			}
			checkCode(key, code);
			boolean flag = userParentDAO.checkUnique(
					new String[] { UserParent.mobile, UserParent.user_name },
					new Object[] { mobile, userName }, null, null);
			if (flag) {
				ExceptionUtil.throwServiceException("用户名和手机不匹配");
			}
			break;

		default:
			ExceptionUtil.throwServiceException("TYPE不支持该类型");
		}

		return responseWrap;
	}

}
