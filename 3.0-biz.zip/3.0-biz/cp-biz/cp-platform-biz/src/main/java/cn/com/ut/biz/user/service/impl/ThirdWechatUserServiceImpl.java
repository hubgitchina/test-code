package cn.com.ut.biz.user.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.user.service.ThirdWechatUserService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.config.thirdlogin.WechatLoginModule;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.rpc.ThirdRestTemplate;

/**
 * 第三方QQ用户管理
 * 
 * @author ouyuexing
 *
 */
@Service
public class ThirdWechatUserServiceImpl implements ThirdWechatUserService {

	@Autowired
	private WechatLoginModule wechatLoginModule;

	@Autowired
	private UserService userService;

	@Autowired
	private ThirdRestTemplate thirdRestTemplate;

	@Override
	public String getWechatLoginUrl(String sessionid, String successurl) {

		Map<String, Object> reqMap = new HashMap<>();
		reqMap.put("response_type", "code");
		reqMap.put("appid", wechatLoginModule.getPcId());
		JSONObject jb = new JSONObject();
		jb.put("vf", sessionid);
		jb.put("successurl", successurl);
		reqMap.put("state", jb.toJSONString());
		reqMap.put("scope", "snsapi_login");
		reqMap.put("redirect_uri", getCallBackEncUrl(successurl));
		return thirdRestTemplate.getReqUrl(ConstantUtil.RPC_PROJRCT.WECHATLOGINCODE,
				ConstantUtil.API_WECHAT.GET_CODE, reqMap);
	}

	@Override
	public String wechatUserLogin(String code, User user) {

		// 获取token
		Map<String, Object> parMap = new HashMap<>();
		parMap.put("appid", wechatLoginModule.getPcId());
		parMap.put("secret", wechatLoginModule.getPcKey());
		parMap.put("code", code);
		parMap.put("grant_type", "authorization_code");
		JSONObject jb = thirdRestTemplate.exchangeGetForEntity(parMap,
				ConstantUtil.RPC_PROJRCT.WECHATLOGIN, ConstantUtil.API_WECHAT.GET_ACC_TOKEN);
		// 获取token
		String accToken = jb.getString("access_token");
		String openId = jb.getString("openid");
		if (CommonUtil.isEmpty(accToken, openId)) {
			ExceptionUtil.throwServiceException("获取微信用户失败");
		}
		userService.wechatLogin(user, ConstantUtil.THIRD_USER_FORM.WECHAT,
				ConstantUtil.LOGIN_TYPE.PC, openId, accToken,
				Long.valueOf(ConstantUtil.SESSION_TIME.DEFAULT));
		return null;
	}

	@Override
	public Map<String, Object> getWechatUserInfo(String openId, String accessToken) {

		Map<String, Object> parMap = new HashMap<>();
		parMap.put("access_token", accessToken);
		parMap.put("openid", openId);
		parMap.put("lang", "zh-CN");
		JSONObject jb = thirdRestTemplate.exchangeGetForEntity(parMap,
				ConstantUtil.RPC_PROJRCT.WECHATLOGIN, ConstantUtil.API_WECHAT.GET_USER_INFO);
		if (CollectionUtil.isEmptyMap(jb)) {
			ExceptionUtil.throwServiceException("获取微信用户信息发生错误");
		}
		return jb;
	}

	private String getCallBackEncUrl(String successUrl) {

		// StringBuffer urlBuf = new StringBuffer();
		// urlBuf.append(wechatLoginModule.getCallBackUrl()).append("?successurl=").append(successUrl);
		return encode(wechatLoginModule.getCallBackUrl());
	}

	private String encode(String par) {

		String ourUrlenc = null;
		try {
			ourUrlenc = URLEncoder.encode(par, "UTF-8");
		} catch (UnsupportedEncodingException e) {
		}
		return ourUrlenc;
	}

	@Override
	public Map<String, Object> getSystemAppInfo() {

		Map<String, Object> res = new HashMap<>();
		res.put("app_id", wechatLoginModule.getAppId());
		return res;
	}

	@Override
	public void appLogin(User user, String code) {

		// 获取token
		Map<String, Object> parMap = new HashMap<>();
		parMap.put("appid", wechatLoginModule.getAppId());
		parMap.put("secret", wechatLoginModule.getAppKey());
		parMap.put("code", code);
		parMap.put("grant_type", "authorization_code");
		JSONObject jb = thirdRestTemplate.exchangeGetForEntity(parMap,
				ConstantUtil.RPC_PROJRCT.WECHATLOGIN, ConstantUtil.API_WECHAT.GET_ACC_TOKEN);
		// 获取token
		String accToken = jb.getString("access_token");
		String openId = jb.getString("openid");
		if (CommonUtil.isEmpty(accToken, openId)) {
			ExceptionUtil.throwServiceException("获取微信用户失败");
		}
		userService.wechatLogin(user, ConstantUtil.THIRD_USER_FORM.WECHAT,
				ConstantUtil.LOGIN_TYPE.APP, openId, accToken,
				Long.valueOf(ConstantUtil.SESSION_TIME.DEFAULT));
	}

}
