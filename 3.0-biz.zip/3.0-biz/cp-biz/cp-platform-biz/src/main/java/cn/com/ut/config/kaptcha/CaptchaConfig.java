package cn.com.ut.config.kaptcha;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.google.code.kaptcha.util.Config;

/**
 * 图片验证码配置
 * 
 * @author ouyuexing
 *
 */
@Configuration
public class CaptchaConfig {

	@Bean(name = "captchaProducer")
	public DefaultKaptcha getKaptchaBean() {

		DefaultKaptcha defaultKaptcha = new DefaultKaptcha();
		Properties properties = new Properties();
		properties.setProperty("kaptcha.border", "no");
		properties.setProperty("kaptcha.border.color", "105,179,90");
		properties.setProperty("kaptcha.textproducer.font.color", "black");
		// 文本集合，验证码值从此集合中获取
		properties.setProperty("kaptcha.textproducer.char.string", "1234567890");
		// 干扰实现类
		properties.setProperty("kaptcha.noise.impl", "");
		// 干扰 颜色
		properties.setProperty("kaptcha.noise.color", "gray");
		// 图片样式
		properties.setProperty("kaptcha.obscurificator.impl",
				"com.google.code.kaptcha.impl.ShadowGimpy");
		properties.setProperty("kaptcha.image.width", "125");
		properties.setProperty("kaptcha.image.height", "45");
		// properties.setProperty("kaptcha.session.key", "code");

		// properties.setProperty("kaptcha.background.clear.from", "gray");
		// properties.setProperty("kaptcha.background.clear.to", "gray");

		properties.setProperty("kaptcha.textproducer.char.length", "4");
		properties.setProperty("kaptcha.textproducer.font.names", "宋体,楷体,微软雅黑");
		Config config = new Config(properties);
		defaultKaptcha.setConfig(config);
		return defaultKaptcha;
	}

}
