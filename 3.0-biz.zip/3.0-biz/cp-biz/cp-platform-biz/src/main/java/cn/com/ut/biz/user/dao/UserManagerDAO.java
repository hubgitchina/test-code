package cn.com.ut.biz.user.dao;

import java.util.Collection;

import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 用户信息管理数据层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface UserManagerDAO extends JdbcOperation<UserManager> {

	/**
	 * 管理员是否为平台唯一的超级管理员
	 * 
	 * @param userId
	 * @return false 有可能不是超级管理员，有可能是超管但不是唯一的
	 */
	boolean isUniqueSuperManager(String userId);

	/**
	 * 查询平台的管理员用户
	 * 
	 * @param platformId
	 * @return userId集合
	 */
	Collection<String> findPlatformManagers(String platformId);
}
