package cn.com.ut.biz.user.service;

import java.util.Map;

import cn.com.ut.core.common.system.beans.User;

/**
 * 第三方QQ用户
 * 
 * @author ouyuexing
 *
 */
public interface ThirdQQUserService {

	/**
	 * 获取QQ登录的URL
	 * 
	 * @param sessionid
	 * @return
	 */
	String getQQLoginUrl(String sessionid, String successurl);

	/**
	 * code获取QQ授权用户的信息并填写到缓存
	 * 
	 * @param sessionId
	 * @param code
	 */
	String qqUserLogin(String code, User user);

	/**
	 * 获取QQ用户信息
	 * 
	 * @param openId
	 * @param accessToken
	 * @return
	 */
	Map<String, Object> getQQUserInfo(String openId, String accessToken);

	/**
	 * 获取第三方登录等key信息
	 * 
	 * @return
	 */
	Map<String, Object> getSystemAppInfo();

}
