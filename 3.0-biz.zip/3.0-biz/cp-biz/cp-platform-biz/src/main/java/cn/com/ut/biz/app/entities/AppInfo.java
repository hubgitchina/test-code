package cn.com.ut.biz.app.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 应用信息
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public class AppInfo extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3755516482364025348L;
	/**
	 * 应用ID
	 */
	public static final String app_id = "app_id";
	/**
	 * 应用名称
	 */
	public static final String app_name = "app_name";
	/**
	 * 应用密钥
	 */
	public static final String app_key = "app_key";
	/**
	 * 应用状态
	 */
	public static final String status = "status";
	/**
	 * 审核时间
	 */
	public static final String audit_time = "audit_time";
	/**
	 * 审核人
	 */
	public static final String audit_operator = "audit_operator";
	/**
	 * 审核结果
	 */
	public static final String audit_result = "audit_result";
	/**
	 * 上线状态（0下线1上线）
	 */
	public static final String publish_status = "publish_status";
}
