package cn.com.ut.biz.user.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 第三方用户关联
 * 
 * @author ouyuexing
 *
 */
public class ThirdUser extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4009622383338111763L;
	/**
	 * 
	 */
	public static final String user_id = "user_id";

	/**
	 * 第三方用户id
	 */
	public static final String open_id = "open_id";

	/**
	 * 数据来源
	 */
	public static final String user_from = "user_from";
}