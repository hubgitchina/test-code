package cn.com.ut.biz.permission.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 角色管理数据层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface RoleDAO extends JdbcOperation<Role> {

	/**
	 * 获取角色关联的菜单列表
	 * 
	 * @param roleId
	 * @param parentId
	 * @param pageBean
	 * @param userId
	 * @return 指定角色关联的菜单列表
	 */
	List<Map<String, Object>> listMenusByRoleId(String roleId, String parentId, PageBean pageBean,
			String userId);

	/**
	 * 获取角色关联的用户列表
	 * 
	 *
	 * @param platformId
	 * @param roleId
	 * @param pageBean
	 * @return 角色关联的用户列表
	 */
	List<Map<String, Object>> listRoleRefUsers(String roleId, PageBean pageBean);

	/**
	 * 获取指定角色没有关联的用户列表
	 * 
	 * @param platformId
	 * @param roleId
	 * @param pageBean
	 * @return 指定角色没有关联的用户列表
	 */
	List<Map<String, Object>> listRoleNoRefUsers(String roleId, PageBean pageBean);

	/**
	 * 获取指定角色之外的角色列表
	 * 
	 * @param roleIds
	 * @param pageBean
	 * @return 指定角色之外的角色列表
	 */
	List<Map<String, Object>> listRolesExcept(List<Object> roleIds, PageBean pageBean);

	/**
	 * 获取指定角色可分配的菜单
	 * 
	 * @param roleIds
	 * @return 指定角色可分配的菜单
	 */
	List<String> queryUserRoleMenuAssign(List<String> roleIds);

	/**
	 * 获取用户某个角色下某个父类菜单下子菜单列表，并标识哪些菜单已拥有，哪些菜单可分配
	 * 
	 * @param roleId
	 * @param menuIds
	 * @param parentMenuId
	 * @param userId
	 * @return 角色菜单列表
	 */
	List<Map<String, Object>> queryUserRoleMenu(String roleId, List<String> menuIds,
			String parentMenuId, String userId);

	/**
	 * 获取用户角色菜单信息，并标识哪些菜单已拥有，哪些菜单可分配
	 * 
	 * @param page
	 * @param roleId
	 * @param menuIds
	 * @param userId
	 * @return 角色菜单列表
	 */
	List<Map<String, Object>> queryUserRoleMenuByName(PageBean page, String roleId,
			List<String> menuIds, String userId);

	/**
	 * 获取含有指定角色的角色与分组关系
	 * 
	 * @param roles
	 * @return 含有指定角色的角色与分组关系
	 */
	List<Map<String, Object>> listRoleInclude(List<String> roles);

	/**
	 * 获取有指定菜单的用户
	 * 
	 * @param userIds
	 * @param menuIds
	 * @return 有指定菜单的用户
	 */
	List<String> queryUsersByMenus(List<String> userIds, List<String> menuIds);

	/**
	 * 根据角色名字查询角色ID
	 * 
	 * @param roleIds
	 * @return
	 */
	List<Map<String, Object>> queryRoleNameByIds(List<String> roleIds);

	/**
	 * 获取角色详情
	 * 
	 * @param platformId
	 * @param roleId
	 * @return
	 */
	Map<String, Object> getDetail(String roleId);

}
