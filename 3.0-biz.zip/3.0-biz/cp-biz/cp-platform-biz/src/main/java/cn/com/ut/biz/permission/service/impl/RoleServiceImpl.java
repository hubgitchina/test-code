/*
 * Copyright 2013 The UTFoodPortalSE Project. Zhuhai Unitech Power Technology Co.,Ltd. All Rights Reserved.
 */
package cn.com.ut.biz.permission.service.impl;

import static cn.com.ut.core.common.util.CollectionUtil.isEmptyCollection;
import static cn.com.ut.core.common.util.CollectionUtil.isEmptyMap;
import static cn.com.ut.core.common.util.CommonUtil.getUUID;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.JdbcOperationsImpl.NAMES_ID_CT_CID;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.permission.dao.RoleAndMenuDAO;
import cn.com.ut.biz.permission.dao.RoleAndUserDAO;
import cn.com.ut.biz.permission.dao.RoleAndUserGroupDAO;
import cn.com.ut.biz.permission.dao.RoleDAO;
import cn.com.ut.biz.permission.dao.UserGroupDAO;
import cn.com.ut.biz.permission.entities.Menu;
import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.service.RoleService;
import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.exception.ServiceException;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import lombok.NonNull;

/**
 * 系统角色管理
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Service
public class RoleServiceImpl implements RoleService {

	@Resource
	private RoleDAO roleDAO;
	@Resource
	private RoleAndUserGroupDAO roleAndUserGroupDAO;
	@Resource
	private UserGroupDAO userGroupDAO;
	@Resource
	private RoleAndUserDAO roleAndUserDAO;
	@Resource
	private RoleAndMenuDAO roleAndMenuDAO;
	@Autowired
	private UserService userService;

	@Override
	public String create(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, create_id);
		String roleName = (String) vo.get(Role.role_name);
		vo.putIfAbsent(Role.role_class, ConstantUtil.FLAG_ZERO);
		vo.putIfAbsent(Role.role_type, ConstantUtil.FLAG_ZERO);
		vo.putIfAbsent(Role.is_use, ConstantUtil.FLAG_YES);
		boolean isExist = !roleDAO.checkUnique(new String[] { Role.role_name, Role.role_type },
				new Object[] { roleName, ConstantUtil.FLAG_ZERO }, null, null);
		if (isExist) {
			ExceptionUtil.throwValidateException("此角色名称已存在，不允许重复！");
		}

		String roleId = roleDAO.add(vo);
		vo.put(RoleAndUserGroup.role_id, roleId);
		roleAndUserGroupDAO.add(vo);
		return roleId;
	}

	@Override
	public void update(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, update_id);
		ValidatorUtil.validateMapContainsKey(vo, idx, Role.role_name);
		String roleName = (String) vo.get(Role.role_name);
		String roleId = (String) vo.get(Role.idx);
		vo.putIfAbsent(Role.role_class, ConstantUtil.FLAG_ZERO);
		vo.putIfAbsent(Role.role_type, ConstantUtil.FLAG_ZERO);
		vo.putIfAbsent(Role.is_use, ConstantUtil.FLAG_YES);
		boolean isExist = !roleDAO.checkUnique(new String[] { Role.role_name, Role.role_class },
				new Object[] { roleName, ConstantUtil.FLAG_ZERO }, new String[] { Role.idx },
				new Object[] { roleId });
		if (isExist) {
			ExceptionUtil.throwValidateException("此角色名称已存在，不允许重复！");
		}
		roleDAO.update(vo);
		vo.put(RoleAndUserGroup.role_id, roleId);

		roleAndUserGroupDAO.update(vo);

	}

	@Override
	public void delete(String roleId) {

		Map<String, Object> vo = roleDAO.getDetail(roleId);
		if (isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("记录不存在");
		}
		if (vo.get(Role.role_type).equals(ConstantUtil.FLAG_ZERO)) {
			ExceptionUtil.throwValidateException("该数据是系统数据，不允许被删除！");
		}

		boolean isSuper = ConstantUtil.FLAG_YES.equals(vo.get(Role.is_supermanager));
		if (isSuper) {
			ExceptionUtil.throwValidateException("超级管理员角色不能删除！");
		}

		long countUsers = roleDAO.count(roleDAO.getTable(RoleAndUser.class), RoleAndUser.user_id,
				new String[] { RoleAndUser.role_id }, new Object[] { roleId });
		if (countUsers > 0) {
			ExceptionUtil.throwValidateException("请先删除角色关联的所有用户！");
		}

		long countMenus = roleDAO.count(roleDAO.getTable(RoleAndMenu.class), RoleAndMenu.menu_id,
				new String[] { RoleAndMenu.role_id }, new Object[] { roleId });
		if (countMenus > 0) {
			ExceptionUtil.throwValidateException("请先取消角色关联的所有菜单！");
		}

		roleAndUserDAO.delete(null, new String[] { RoleAndUser.role_id }, new Object[] { roleId });
		roleAndUserGroupDAO.delete(null, new String[] { RoleAndUserGroup.role_id },
				new Object[] { roleId });
		roleDAO.delete(roleId);
	}

	@Override
	public List<Map<String, Object>> find(PageBean pageBean) {

		return roleDAO.query(pageBean, null, null, null, null, null, null);
	}

	@Override
	public List<Map<String, Object>> queryNotUsedRoles(PageBean pageBean) {

		return roleDAO.query(pageBean, null, null, new String[] { Role.idx, Role.role_name }, null,
				new String[] { Role.role_class, Role.is_use },
				new String[] { ConstantUtil.FLAG_ZERO, ConstantUtil.FLAG_YES });
	}

	@Override
	public Map<String, Object> getDetail(String roleId) {

		Map<String, Object> roleMap = roleDAO.getDetail(roleId);
		if (isEmptyMap(roleMap)) {
			return roleMap;
		}
		Map<String, Object> roleAndUserGroupMap = roleAndUserGroupDAO.getByRoleId(roleId);
		if (!isEmptyMap(roleAndUserGroupMap)) {
			String groupId = (String) roleAndUserGroupMap.get(RoleAndUserGroup.group_id);
			Map<String, Object> groupMap = userGroupDAO.get(groupId);
			if (!isEmptyMap(groupMap)) {
				roleMap.put(UserGroup.group_name, groupMap.get(UserGroup.group_name));
				roleMap.put(RoleAndUserGroup.group_id, groupId);
			}
		}
		long countUsers = roleDAO.count(roleDAO.getTable(RoleAndUser.class), RoleAndUser.user_id,
				new String[] { RoleAndUser.role_id }, new Object[] { roleId });
		roleMap.put("change_group_flag",
				countUsers == 0 ? ConstantUtil.FLAG_YES : ConstantUtil.FLAG_NO);
		return roleMap;
	}

	@Override
	public List<Map<String, Object>> listRoleRefUsers(String roleId, User user, PageBean pageBean) {

		if (CommonUtil.isEmpty(roleId)) {
			return null;
		}
		List<Map<String, Object>> resultList = roleDAO.listRoleRefUsers(roleId, pageBean);
		if (CollectionUtil.isEmptyCollection(resultList)) {
			return resultList;
		}
		List<Object> userIds = CollectionUtil.findValue(resultList, UserManager.user_id);
		if (CollectionUtil.isEmptyCollection(userIds)) {
			return resultList;
		}

		List<Map<String, Object>> vos = userService.getUserName(userIds);

		JSONArray userNames = (JSONArray) JSON.toJSON(vos);
		if (CollectionUtil.isEmptyCollection(userNames)) {
			return resultList;
		}
		for (Map<String, Object> temap : resultList) {
			String userId = (String) temap.get(UserManager.user_id);
			for (Object ob : userNames) {
				JSONObject jbO = (JSONObject) ob;
				if (CommonUtil.isNotEmpty(userId) && userId.equals(jbO.getString("user_id"))) {
					temap.put("user_name", jbO.get("user_name"));
					temap.put("user_type", jbO.get("user_type"));
				}
			}
		}
		return resultList;
	}

	@Override
	public List<Map<String, Object>> listRoleNoRefUsers(String roleId, User user,
			PageBean pageBean) {

		List<Map<String, Object>> resultList = roleDAO.listRoleNoRefUsers(roleId, pageBean);
		if (CollectionUtil.isEmptyCollection(resultList)) {
			return resultList;
		}

		List<Object> userIds = CollectionUtil.findValue(resultList, UserManager.user_id);
		if (CollectionUtil.isEmptyCollection(userIds)) {
			return resultList;
		}

		List<Map<String, Object>> vos = userService.getUserName(userIds);

		JSONArray userNames = (JSONArray) JSON.toJSON(vos);

		if (CollectionUtil.isEmptyCollection(userNames)) {
			return resultList;
		}

		for (Map<String, Object> temap : resultList) {
			String userId = (String) temap.get(UserManager.user_id);
			for (Object ob : userNames) {
				JSONObject jbO = (JSONObject) ob;
				if (CommonUtil.isNotEmpty(userId) && userId.equals(jbO.getString("user_id"))) {
					temap.put("user_name", jbO.get("user_name"));
					temap.put("user_type", jbO.get("user_type"));
				}
			}
		}
		return resultList;
	}

	@Override
	public List<Map<String, Object>> listUserRefRoles(String userId, User user, PageBean pageBean) {

		throw new ServiceException("接口未开发！");
	}

	@Override
	public List<Map<String, Object>> listUserNoRefRoles(String userId, User user,
			PageBean pageBean) {

		throw new ServiceException("接口未开发！");
	}

	@Override
	public void addRoleRefUsers(@NonNull String roleId, List<String> users, String operator,
			String platformId) {

		if (CollectionUtil.isEmptyCollection(users)) {
			return;
		}

		Map<String, Object> roleVo = roleDAO.get(roleId);
		if (isEmptyMap(roleVo)) {
			ExceptionUtil.throwValidateException("角色不存在");
		}

		List<Map<String, Object>> args = new ArrayList<>();
		Timestamp now = DateTimeUtil.currentDateTime();
		for (String userId : users) {
			boolean isExist = !roleAndUserDAO.checkUnique(
					new String[] { RoleAndUser.role_id, RoleAndUser.user_id },
					new Object[] { roleId, userId }, null, null);
			if (isExist) {
				continue;
			}
			Map<String, Object> vo = new HashMap<>();
			vo.put(RoleAndUser.idx, getUUID());
			vo.put(RoleAndUser.role_id, roleId);
			vo.put(RoleAndUser.user_id, userId);
			vo.put(RoleAndUser.create_id, operator);
			vo.put(RoleAndUser.create_time, now);
			args.add(vo);
		}
		roleAndUserDAO.addVoBatch(null, new String[] { RoleAndUser.user_id, RoleAndUser.role_id },
				NAMES_ID_CT_CID, args);
	}

	@Override
	public void addUserRefRoles(@NonNull String userId, List<String> roles, String operator) {

		if (operator.equals(userId)) {
			ExceptionUtil.throwValidateException("不能给自己添加角色！");
		}
		if (CollectionUtil.isEmptyCollection(roles)) {
			return;
		}
		List<Map<String, Object>> args = new ArrayList<>();
		Timestamp now = DateTimeUtil.currentDateTime();
		for (String role : roles) {
			Map<String, Object> vo = new HashMap<>();
			vo.put(RoleAndUser.idx, getUUID());
			vo.put(RoleAndUser.role_id, role);
			vo.put(RoleAndUser.user_id, userId);
			vo.put(RoleAndUser.create_id, operator);
			vo.put(RoleAndUser.create_time, now);
			args.add(vo);
		}
		roleAndUserDAO.addVoBatch(null, new String[] { RoleAndUser.user_id, RoleAndUser.role_id },
				NAMES_ID_CT_CID, args);
	}

	@Override
	public void removeRoleRefUsers(@NonNull String roleId, List<String> users) {

		if (CollectionUtil.isEmptyCollection(users)) {
			return;
		}
		roleAndUserDAO.deleteRoleRefUsers(roleId, users);
	}

	@Override
	public void removeUserRefRoles(@NonNull String userId, List<String> roles) {

		if (CollectionUtil.isEmptyCollection(roles)) {
			return;
		}
		roleAndUserDAO.deleteUserRefRoles(userId, roles);
	}

	@Override
	public void removeUserRefRolesAll(@NonNull String userId, String[] roleClasses) {

		if (roleClasses.length == 0) {
			return;
		}
		roleAndUserDAO.deleteUserRefRolesAll(userId, roleClasses);
	}

	@Override
	public List<Map<String, Object>> listMenusByRoleId(@NonNull String roleId, String parentId,
			PageBean pageBean, String operator) {

		List<Map<String, Object>> list = roleDAO.listMenusByRoleId(roleId, parentId, pageBean,
				operator);
		return CollectionUtil.createTreeList(list, Menu.parent_id, Menu.idx, "node");
	}

	@Override
	public List<Map<String, Object>> queryEntRoleMenuByName(String roleId, User user,
			PageBean pageBean) {

		List<String> menuIds = roleDAO.queryUserRoleMenuAssign(user.getRoles());
		return roleDAO.queryUserRoleMenuByName(pageBean, roleId, menuIds, user.getUserId());
	}

	@Override
	public void updateRoleRefMenus(String roleId, List<Map<String, Object>> menuList,
			String operator) {

		if (CollectionUtil.isEmptyCollection(menuList) || roleId == null) {
			ExceptionUtil.throwValidateException("参数空");
		}

		// 准备更新和删除的参数列表
		List<String> updateIds = new ArrayList<>();
		List<String> deleteIds = new ArrayList<>();
		List<Map<String, Object>> updateMenus = new ArrayList<>();
		List<Map<String, Object>> deleteMenus = new ArrayList<>();
		for (Map<String, Object> menuVo : menuList) {
			String menuId = (String) menuVo.get(RoleAndMenu.menu_id);
			if (ConstantUtil.FLAG_NO.equals((menuVo.get(RoleAndMenu.is_own)))
					&& ConstantUtil.FLAG_NO.equals(menuVo.get(RoleAndMenu.is_assign))) {
				deleteIds.add(menuId);
				deleteMenus.add(menuVo);
			} else {
				updateIds.add(menuId);
				updateMenus.add(menuVo);
			}
		}

		// 删除
		if (!deleteIds.isEmpty()) {
			roleAndMenuDAO.deleteRoleMenusIn(roleId, deleteIds);
		}

		List<Map<String, Object>> args = new ArrayList<>();
		Timestamp now = DateTimeUtil.currentDateTime();

		// 获取指定角色与指定菜单的角色关系记录
		if (!updateIds.isEmpty()) {
			List<Map<String, Object>> menuVoExisted = roleAndMenuDAO.listRoleMenusIn(roleId,
					updateIds);
			if (CollectionUtil.isEmptyCollection(menuVoExisted)) {
				// 不存在记录，添加
				for (Map<String, Object> e : updateMenus) {
					String menuId = (String) e.get(RoleAndMenu.menu_id);
					String isOwn = (String) e.get(RoleAndMenu.is_own);
					String isAssign = (String) e.get(RoleAndMenu.is_assign);

					Map<String, Object> vo = new HashMap<>();
					vo.put(RoleAndUser.create_id, operator);
					vo.put(RoleAndUser.create_time, now);
					vo.put(RoleAndMenu.role_id, roleId);
					vo.put(RoleAndMenu.menu_id, menuId);
					vo.put(RoleAndMenu.is_own, isOwn);
					vo.put(RoleAndMenu.is_assign, isAssign);
					vo.put(RoleAndUser.idx, getUUID());
					args.add(vo);
				}
				roleAndMenuDAO
						.addVoBatch(null,
								new String[] { RoleAndMenu.role_id, RoleAndMenu.menu_id,
										RoleAndMenu.is_own, RoleAndMenu.is_assign },
								NAMES_ID_CT_CID, args);

			} else {
				// 若参数包含的角色关系部分或全部已存在，则不需要更新已存在的部分
				List<String> menuIdsExisted = CollectionUtil.listManyToOne(menuVoExisted,
						"menu_id");
				updateIds.removeAll(menuIdsExisted);
				List<Map<String, Object>> addArgs = new ArrayList<>();
				List<Map<String, Object>> updateArgs = new ArrayList<>();
				for (Map<String, Object> e : updateMenus) {
					String menuId = (String) e.get("menu_id");
					String isOwn = (String) e.get("is_own");
					String isAssign = (String) e.get("is_assign");

					Map<String, Object> vo = new HashMap<>();
					vo.put(RoleAndMenu.role_id, roleId);
					vo.put(RoleAndMenu.menu_id, menuId);
					vo.put(RoleAndMenu.is_own, isOwn);
					vo.put(RoleAndMenu.is_assign, isAssign);

					if (updateIds.contains(menuId)) {
						vo.put(idx, CommonUtil.getUUID());
						vo.put(RoleAndUser.create_id, operator);
						vo.put(RoleAndUser.create_time, now);
						addArgs.add(vo);
					} else {
						vo.put(RoleAndUser.update_id, operator);
						vo.put(RoleAndUser.update_time, now);
						updateArgs.add(vo);
					}
				}
				if (!isEmptyCollection(addArgs)) {
					roleAndMenuDAO.addVoBatch(null,
							new String[] { RoleAndMenu.role_id, RoleAndMenu.menu_id,
									RoleAndMenu.is_own, RoleAndMenu.is_assign },
							NAMES_ID_CT_CID, addArgs);
				}
				if (!isEmptyCollection(updateArgs)) {
					roleAndMenuDAO.updateBatch(roleId, updateArgs);
				}
			}
		}
	}

}