package cn.com.ut.biz.ui.service.impl;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import cn.com.ut.biz.ui.dao.PageDAO;
import cn.com.ut.biz.ui.entities.Page;
import cn.com.ut.biz.ui.service.PageService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.util.PageUtil;

/**
 * 应用定制页面业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年5月15日
 */
@Service
public class PageServiceImpl implements PageService {

	@Autowired
	private PageDAO pageDAO;

	@Override
	public String add(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Page.page_name, Page.model_id, Page.is_dir);

		boolean isCanAdd = pageDAO.checkUnique(
				new String[] { Page.page_name, Page.model_id, Page.parent_id }, new Object[] {
						vo.get(Page.page_name), vo.get(Page.model_id), vo.get(Page.parent_id) },
				null, null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("该模型下已存在同名定制页面");
		}

		// PAGE_CODE使用线程安全的时间戳来生成
		vo.put(Page.page_code, PageUtil.nextPageCode());

		return pageDAO.add(vo);
	}

	@Override
	public void update(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Page.idx, Page.page_name, Page.model_id,
				Page.is_dir);

		String pageId = (String) vo.get(Page.idx);
		boolean isCanUpdate = pageDAO.checkUnique(
				new String[] { Page.page_name, Page.model_id, Page.parent_id },
				new Object[] { vo.get(Page.page_name), vo.get(Page.model_id),
						vo.get(Page.parent_id) },
				new String[] { Page.idx }, new Object[] { pageId });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("该模型下已存在同名定制页面");
		}
		pageDAO.update(vo);
	}

	@Override
	public List<Map<String, Object>> query(PageBean pageBean) {

		String[] names = { Page.idx, Page.model_id, Page.page_name, Page.page_code, Page.page_edit,
				Page.page_view, Page.parent_id, Page.is_dir };
		return pageDAO.queryPage(pageBean, null, null, false, names, null,
				new String[] { Page.is_del }, null, null, Page.create_time,
				new Object[] { ConstantUtil.FLAG_NO });
	}

	@Override
	public List<Map<String, Object>> queryByModel(String modelId) {

		String[] names = { Page.idx, Page.page_name, Page.page_view, Page.parent_id, Page.is_dir };
		return pageDAO.queryPage(null, null, null, false, names, null,
				new String[] { Page.model_id, Page.is_del }, null, null, Page.create_time,
				new Object[] { modelId, ConstantUtil.FLAG_NO });
	}

	@Override
	public Map<String, Object> getPageById(String pageId) {

		String[] selectColumnArray = { Page.idx, Page.page_name, Page.page_view, Page.is_dir };

		return pageDAO.getByKey(null, null, selectColumnArray, null,
				new String[] { Page.idx, Page.is_dir },
				new Object[] { pageId, ConstantUtil.FLAG_NO }, null);
	}

	@Override
	public Map<String, Object> queryTree(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Page.model_id);

		String modelId = (String) vo.get(Page.model_id);

		Map<String, Object> treeMap = Maps.newHashMap();

		String[] names = { Page.idx, Page.model_id, Page.page_name, Page.page_code, Page.page_edit,
				Page.page_view, Page.parent_id, Page.is_dir };

		List<Map<String, Object>> allPage = pageDAO.queryPage(null, null, null, false, names, null,
				new String[] { Page.model_id, Page.is_del }, null, null, Page.create_time,
				new Object[] { modelId, ConstantUtil.FLAG_NO });

		List<Map<String, Object>> dirList = Lists.newArrayList();
		List<Map<String, Object>> pageList = Lists.newArrayList();

		// 先将目录和文件分开存放不同集合
		Iterator<Map<String, Object>> itAll = allPage.iterator();
		while (itAll.hasNext()) {
			Map<String, Object> map = itAll.next();
			String isDir = (String) map.get(Page.is_dir);
			if (ConstantUtil.FLAG_YES.equals(isDir)) {
				dirList.add(map);
			} else {
				pageList.add(map);
			}
		}

		// 先获取根节点数据，同时从集合删除根节点数据，减少递归次数
		List<Map<String, Object>> rootPage = Lists.newArrayList();
		Iterator<Map<String, Object>> itDir = dirList.iterator();
		while (itDir.hasNext()) {
			Map<String, Object> map = itDir.next();
			if (CommonUtil.isEmpty(map, new String[] { Page.parent_id })) {
				rootPage.add(map);
				itDir.remove();
			}
		}

		List<Map<String, Object>> childPageList = Lists.newArrayList();

		Iterator<Map<String, Object>> itPage = pageList.iterator();
		while (itPage.hasNext()) {
			Map<String, Object> pageMap = itPage.next();
			if (CommonUtil.isEmpty(pageMap, new String[] { Page.parent_id })) {
				childPageList.add(pageMap);
				itPage.remove();
			}
		}

		if (!CollectionUtil.isEmptyCollection(childPageList)) {
			treeMap.put("root_files", childPageList);
		}

		for (int i = 0; i < rootPage.size(); i++) {
			Map<String, Object> map = rootPage.get(i);
			String id = (String) map.get(Page.idx);

			getChildPage(id, dirList, pageList, map);
		}

		treeMap.put("dir", rootPage);

		return treeMap;
	}

	/**
	 * 递归遍历构造树目录，以及每个目录下包含的文件，将子节点数据返回到parentMap
	 * 
	 * @param parentId
	 * @param dirList
	 * @param pageList
	 * @param parentMap
	 */
	private void getChildPage(String parentId, List<Map<String, Object>> dirList,
			List<Map<String, Object>> pageList, Map<String, Object> parentMap) {

		if (!CollectionUtil.isEmptyCollection(pageList)) {
			List<Map<String, Object>> childPageList = Lists.newArrayList();
			Iterator<Map<String, Object>> itPage = pageList.iterator();
			while (itPage.hasNext()) {
				Map<String, Object> pageMap = itPage.next();
				String pageParentId = (String) pageMap.get(Page.parent_id);
				if (parentId.equals(pageParentId)) {
					childPageList.add(pageMap);
					itPage.remove();
				}
			}

			if (!CollectionUtil.isEmptyCollection(childPageList)) {
				parentMap.put("files", childPageList);
			}
		}

		List<Map<String, Object>> childList = Lists.newArrayList();
		if (!CollectionUtil.isEmptyCollection(dirList)) {
			for (int i = 0; i < dirList.size(); i++) {
				Map<String, Object> map = dirList.get(i);
				String tempId = (String) map.get(Page.idx);
				String tempParentId = (String) map.get(Page.parent_id);
				if (parentId.equals(tempParentId)) {
					childList.add(map);

					dirList.remove(map);
					i--;

					if (!CollectionUtil.isEmptyCollection(pageList)) {
						List<Map<String, Object>> childPageList = Lists.newArrayList();
						Iterator<Map<String, Object>> itPage = pageList.iterator();
						while (itPage.hasNext()) {
							Map<String, Object> pageMap = itPage.next();
							String pageParentId = (String) pageMap.get(Page.parent_id);
							if (parentId.equals(pageParentId)) {
								childPageList.add(pageMap);
								itPage.remove();
							}
						}

						if (!CollectionUtil.isEmptyCollection(childPageList)) {
							map.put("files", childPageList);
						}
					}

					getChildPage(tempId, dirList, pageList, map);
				}
			}
		}

		if (!CollectionUtil.isEmptyCollection(childList)) {
			parentMap.put("nextDir", childList);
		}
	}

	@Override
	public void delete(String id) {

		Map<String, Object> map = pageDAO.getById(null, null, new String[] { Page.is_dir }, null,
				id);
		if (!CollectionUtil.isEmptyMap(map)) {
			String isDir = (String) map.get(Page.is_dir);
			if (ConstantUtil.FLAG_NO.equals(isDir)) {
				pageDAO.delete(id);
			} else {
				// List<Map<String, Object>> childList =
				// pageDAO.getAllChild(id);
				// if (!CollectionUtil.isEmptyCollection(childList)) {
				// List<String> deleteIds = new ArrayList<>(childList.size() +
				// 1);
				// deleteIds.add(id);
				// for (Map<String, Object> idMap : childList) {
				// String deleteId = (String) idMap.get(Page.idx);
				// deleteIds.add(deleteId);
				// }
				// pageDAO.deleteBatch(deleteIds);
				// } else {
				// pageDAO.delete(id);
				// }

				List<String> deleteIds = Lists.newArrayList();
				deleteIds.add(id);
				getChildId(id, deleteIds);
				pageDAO.deleteBatch(deleteIds);
			}
		}
	}

	/**
	 * 递归查找父节点下包含的目录和文件，将ID返回到deleteIds
	 * 
	 * @param parentId
	 * @param deleteIds
	 */
	private void getChildId(String parentId, List<String> deleteIds) {

		String[] names = { Page.idx, Page.is_dir };

		List<Map<String, Object>> childList = pageDAO.queryPage(null, null, null, false, names,
				null, new String[] { Page.parent_id, Page.is_del }, null, null, Page.create_time,
				new Object[] { parentId, ConstantUtil.FLAG_NO });

		if (!CollectionUtil.isEmptyCollection(childList)) {
			for (Map<String, Object> map : childList) {
				String id = (String) map.get(Page.idx);
				String isDir = (String) map.get(Page.is_dir);

				deleteIds.add(id);

				if (ConstantUtil.FLAG_YES.equals(isDir)) {
					getChildId(id, deleteIds);
				}
			}
		}
	}

	@Override
	public Map<String, Object> getDetail(String id) {

		return pageDAO
				.getById(null, null,
						new String[] { Page.idx, Page.model_id, Page.page_name, Page.page_code,
								Page.page_edit, Page.page_view, Page.parent_id, Page.is_dir },
						null, id);
	}

	/**
	 * 构建完整路径
	 * 
	 * @param pageVos
	 * @return
	 */
	@Override
	public List<Map<String, Object>> buildFileFullPath(List<Map<String, Object>> pageVos) {

		if (pageVos.isEmpty()) {

			Map<String, Object> rootPageVo = new HashMap<>();
			rootPageVo.put(Page.is_dir, ConstantUtil.FLAG_YES);
			rootPageVo.put(Page.page_name, "root");
			rootPageVo.put("full_path", "");
			pageVos.add(rootPageVo);
			return pageVos;
		}

		Map<String, Map<String, Object>> pageCache = CollectionUtil.listToMap(pageVos, Page.idx);
		for (Map<String, Object> pageVo : pageVos) {

			buildFileFullPath(pageVo, pageCache);
		}

		return pageVos;
	}

	/**
	 * 构建完整路径
	 * 
	 * @param parentId
	 * @param pageCache
	 * @return
	 */
	private void buildFileFullPath(Map<String, Object> pageVo,
			Map<String, Map<String, Object>> pageCache) {

		String fullPath = "";
		String parentId = (String) pageVo.get(Page.parent_id);
		while (!CommonUtil.isEmpty(parentId)) {

			fullPath = String.valueOf(pageCache.get(parentId).get(Page.page_name)) + File.separator
					+ fullPath;
			parentId = (String) pageCache.get(parentId).get(Page.parent_id);

		}

		pageVo.put("full_path", fullPath);

	}

}