package cn.com.ut.biz.permission.service.impl;

import org.springframework.stereotype.Service;

import cn.com.ut.biz.permission.service.UserRightService;

@Service
public class UserRightServiceImpl implements UserRightService {

	
}
