package cn.com.ut.biz.session.service;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.core.common.system.beans.User;

/**
 * 用户会话服务层
 */
public interface UserSessionService {

	/**
	 * 获取会话信息
	 * 
	 * @param user
	 *            用户
	 * @param moduleCode
	 *            模块代码
	 * @return
	 */
	Map<String, Object> getUserSession(User user, String moduleCode);

	/**
	 * 设置登录用户信息
	 * 
	 * @param user
	 */
	User setLoginUserInfo(User user);

	/**
	 * 登录
	 * 
	 * @param userName
	 * @param password
	 * @param loginType
	 * @param sessionId
	 * @param randomCode
	 * @param response
	 * @return
	 */
	JSONObject login(String userName, String password, String loginType, String sessionId,
			String randomCode, HttpServletResponse response);

}
