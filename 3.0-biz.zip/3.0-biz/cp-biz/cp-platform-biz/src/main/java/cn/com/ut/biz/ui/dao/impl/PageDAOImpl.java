package cn.com.ut.biz.ui.dao.impl;

import static cn.com.ut.biz.ui.entities.Page.is_dir;
import static cn.com.ut.biz.ui.entities.Page.model_id;
import static cn.com.ut.biz.ui.entities.Page.page_code;
import static cn.com.ut.biz.ui.entities.Page.page_edit;
import static cn.com.ut.biz.ui.entities.Page.page_name;
import static cn.com.ut.biz.ui.entities.Page.page_view;
import static cn.com.ut.biz.ui.entities.Page.parent_id;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.ui.dao.PageDAO;
import cn.com.ut.biz.ui.entities.Page;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 应用定制页面DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年5月15日
 */
@Repository
public class PageDAOImpl extends JdbcOperationsImpl<Page> implements PageDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null,
				new String[] { page_edit, page_name, page_code, page_view, model_id, parent_id,
						is_dir },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { page_edit, page_name, page_code, page_view, model_id,
										parent_id, is_dir })
						.append(id, DateTimeUtil.currentDateTime(), vo.get(Page.create_id))
						.toArray());
		return id;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null,
				new String[] { page_edit, page_name, page_view, model_id, parent_id, is_dir },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { page_edit, page_name, page_view, model_id, parent_id,
										is_dir })
						.append(DateTimeUtil.currentDateTime(), vo.get(Page.update_id)).toArray(),
				(String) vo.get(Page.idx), null);
	}

	@Override
	public List<Map<String, Object>> getAllChild(String dirId) {

		String sql = "SELECT T2.id FROM	(SELECT @r AS _id,(SELECT @r := id FROM t_ui_page WHERE parent_id = _id	LIMIT 1) AS id,	@l := @l + 1 AS lvl FROM (SELECT @r := ?, @l := 0) vars, t_ui_page h WHERE @r != '') T1 JOIN t_ui_page T2 ON T1._id = T2.parent_id ORDER BY T1.lvl";
		return queryForList(getJdbcTemplate(), sql, dirId);
	}
}