package cn.com.ut.biz.system.dao.impl;

import static cn.com.ut.biz.system.entities.Config.config_code;
import static cn.com.ut.biz.system.entities.Config.config_des;
import static cn.com.ut.biz.system.entities.Config.config_name;
import static cn.com.ut.biz.system.entities.Config.config_type;
import static cn.com.ut.biz.system.entities.Config.config_value;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.system.dao.ConfigDAO;
import cn.com.ut.biz.system.entities.Config;
import cn.com.ut.core.cache.CachedParameter;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ArrayUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

@Repository
public class ConfigDAOImpl extends JdbcOperationsImpl<Config> implements ConfigDAO {

	public static final String CONFIGS_KEY = "config";

	{
		cachedParameter = new CachedParameter(null, 0, true, new String[] { CONFIGS_KEY });
	}

	private String T_CONFIG;
	{
		T_CONFIG = getTable(Config.class);
	}
	private static final String[] COLUMNS = { config_code, config_des, config_name, config_type,
			config_value };

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, COLUMNS, NAMES_ID_CT_CID, ParameterBuilder.builder().append(vo, COLUMNS)
				.append(id, DateTimeUtil.currentDateTime(), vo.get(Config.create_id)).toArray());
		return id;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null, COLUMNS, NAMES_UT_UID, null,
				ParameterBuilder.builder().append(vo, COLUMNS)
						.append(DateTimeUtil.currentDateTime(), vo.get(Config.update_id)).toArray(),
				(String) vo.get(Config.idx), cachedParameter);
	}

	public Config get(String id, Class<Config> clazz) {

		return getById(clazz, null,
				new String[] { config_code, config_des, config_name, config_type, config_value },
				NAMES, id);
	}

	public int delete(String id) {

		return deleteById(null, id, cachedParameter);
	}

	public List<Config> query(PageBean page, Class<Config> clazz) {

		return query(page, clazz, null, null, null, null, null);
	}

	@Override
	public boolean isConfigCodeRepeat(String configCode, String[] pkFieldNames,
			Object[] pkFieldValues) {

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT 1 from ").append(T_CONFIG).append(" c WHERE c.config_code = ? ");
		List<Object> args = new ArrayList<>();
		args.add(configCode);
		if (pkFieldNames != null && pkFieldNames.length > 0 && pkFieldValues != null) {
			sql.append(" AND (");
			sql.append(ArrayUtil.joinArrayElement(pkFieldNames, " OR ", "c.", " <> ? "));
			sql.append(")");
			CollectionUtil.addArrayToCollection(pkFieldValues, args);
		}
		List<Map<String, Object>> list = query(getJdbcTemplate(), sql.toString(), null,
				args.toArray());
		return !CollectionUtil.isEmptyCollection(list);
	}

	@Override
	public List<Map<String, Object>> findByPlatformId(PageBean page) {

		StringBuilder table = new StringBuilder();
		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.appendColumns("biz", COLUMNS);
		parameterBuilder.appendColumns("biz", idx);
		table.append(T_CONFIG).append(" biz ");
		return queryPage(page, null, table.toString(), false, parameterBuilder.toColumns(), null,
				null, null, null, null, null);
	}

	@Override
	public List<Map<String, Object>> getConfigValueByCode(List<Object> configCodes) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_CONFIG).append(" c WHERE c.config_code {IN} AND c.is_del = 'N' ");
		String tableSql = replaceInCase(table.toSQL(), new int[] { configCodes.size() });
		ParameterBuilder param = ParameterBuilder.builder();
		param.appendColumns("c", COLUMNS);
		param.appendColumns("c", idx);
		List<Object> args = new ArrayList<>();
		args.addAll(configCodes);
		return queryPage(null, null, tableSql, true, param.toColumns(), null, null, null, null,
				null, args.toArray());
	}
}
