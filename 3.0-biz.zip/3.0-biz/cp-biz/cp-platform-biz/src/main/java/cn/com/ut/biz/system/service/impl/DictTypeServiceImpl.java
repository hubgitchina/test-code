/*
 * Copyright 2013 The UTFoodPortalSE Project. Zhuhai Unitech Power Technology Co.,Ltd. All Rights Reserved.
 */

package cn.com.ut.biz.system.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.com.ut.biz.system.dao.DictDataDAO;
import cn.com.ut.biz.system.dao.DictTypeDAO;
import cn.com.ut.biz.system.entities.Config;
import cn.com.ut.biz.system.entities.DictType;
import cn.com.ut.biz.system.service.DictTypeService;
import cn.com.ut.core.common.exception.ValidateException;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 字典类型管理
 * 
 * @author ouyuexing
 * @since 2014-3-28
 */
@Service
public class DictTypeServiceImpl implements DictTypeService {

	@Resource
	private DictTypeDAO dictTypeDAO;
	@Resource
	private DictDataDAO dictDataDAO;

	@Override
	public String create(Map<String, Object> dictTypeVo) {

		ValidatorUtil.validateMapContainsKey(dictTypeVo, DictType.dicttype_code,
				DictType.dicttype_text, DictType.create_id);
		String sortNum = dictTypeVo.get(DictType.sort_num).toString();
		if (NumberUtil.isInteger(sortNum, false, 10)) {
			dictTypeVo.put(DictType.sort_num, Integer.parseInt(sortNum));
		} else {
			ExceptionUtil.throwValidateException("排序参数格式有误，不是整数");
		}
		String dictTypeCode = (String) dictTypeVo.get(DictType.dicttype_code);
		boolean isExist = dictTypeDAO.isDictTypeCodeRepeat(dictTypeCode, null, null);
		if (isExist) {
			ExceptionUtil.throwValidateException("字典类型编码重复");
		}
		String dictTypeId = dictTypeDAO.add(dictTypeVo);

		return dictTypeId;
	}

	@Override
	public String update(Map<String, Object> dictTypeVo) {

		ValidatorUtil.validateMapContainsKey(dictTypeVo, DictType.idx, DictType.dicttype_code,
				DictType.dicttype_text, DictType.update_id);
		String sortNum = (String) dictTypeVo.get(DictType.sort_num);
		String dictTypeCode = (String) dictTypeVo.get(DictType.dicttype_code);
		String dictTypeId = (String) dictTypeVo.get(DictType.idx);
		String operator = (String) dictTypeVo.get(DictType.update_id);

		if (NumberUtil.isInteger(sortNum, false, 10)) {
			dictTypeVo.put(DictType.sort_num, Integer.parseInt(sortNum));
		} else {
			ExceptionUtil.throwValidateException("排序参数格式有误，不是整数");
		}

		Map<String, Object> vo = getDetail(dictTypeId);
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("字典类型记录不存在");
		}
		// 存在字典项时不允许修改编码
		String oldCode = (String) vo.get(DictType.dicttype_code);
		if (!oldCode.equals(dictTypeCode)) {
			List<Map<String, Object>> dictDataList = dictDataDAO.findDictDataByType(dictTypeId,
					null);
			if (!CollectionUtil.isEmptyCollection(dictDataList)) {
				throw new ValidateException("该字典类型下存在字典项，不允许修改编码！");
			}

			boolean isConfigCodeRepeat = dictTypeDAO.isDictTypeCodeRepeat(dictTypeCode,
					new String[] { Config.idx }, new Object[] { dictTypeId });
			if (isConfigCodeRepeat) {
				ExceptionUtil.throwValidateException("字典类型编码重复");
			}
		}

		dictTypeDAO.update(dictTypeVo);
		return dictTypeId;
	}

	@Override
	public List<Map<String, Object>> find(PageBean page) {

		return dictTypeDAO.findByPlatformId(page);
	}

	@Override
	public Map<String, Object> getDetail(String dictTypeId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { dictTypeId });
		return dictTypeDAO.getDetail(dictTypeId);
	}

	@Override
	public void delMark(String dictTypeId, String operator) {

		ValidatorUtil.requiredFieldMiss(new Object[] { dictTypeId });
		Map<String, Object> vo = dictTypeDAO.getDetail(dictTypeId);
		if (CollectionUtil.isEmptyMap(vo)) {
			return;
		}

		Map<String, Object> oldRecord = getDetail(dictTypeId);
		if (CollectionUtil.isEmptyMap(oldRecord)) {
			// ExceptionUtil.throwValidateException("字典类型记录不存在");
			return;
		}
		List<Map<String, Object>> dictDataList = dictDataDAO.findDictDataByType(dictTypeId, null);
		if (!CollectionUtil.isEmptyCollection(dictDataList)) {
			throw new ValidateException("该字典类型下存在字典项，不允许修改编码！");
		}

		dictTypeDAO.deleteMark(dictTypeId, operator);

	}

}
