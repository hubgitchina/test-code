package cn.com.ut.biz.user.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 用户感兴趣的分类
 * 
 * @author zhanghaili
 * @since 2014-06-12
 */
public class UserPInterested extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -47446139685772982L;
	/**
	 * 普通用户表id
	 */
	public static final String user_id = "user_id";
	/**
	 * 商品分类id
	 */
	public static final String goods_category_id = "goods_category_id";
}