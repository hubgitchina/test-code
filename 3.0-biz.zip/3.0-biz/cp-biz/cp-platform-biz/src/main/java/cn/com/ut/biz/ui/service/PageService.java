package cn.com.ut.biz.ui.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 应用定制页面业务层接口
 * 
 * @author wangpeng1
 * @since 2018年5月15日
 */
public interface PageService {

	/**
	 * 添加应用定制页面信息
	 * 
	 * @param vo
	 * @return
	 */
	String add(Map<String, Object> vo);

	/**
	 * 修改应用定制页面信息
	 * 
	 * @param vo
	 */
	void update(Map<String, Object> vo);

	/**
	 * 查询应用定制页面信息（带分页）
	 * 
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> query(PageBean pageBean);

	/**
	 * 查询所有应用定制页面信息（树形结构）
	 * 
	 * @return
	 */
	Map<String, Object> queryTree(Map<String, Object> vo);

	/**
	 * 删除应用定制页面信息
	 * 
	 * @param id
	 */
	void delete(String id);

	/**
	 * 获取应用定制页面详情
	 * 
	 * @param id
	 * @return
	 */
	Map<String, Object> getDetail(String id);

	List<Map<String, Object>> buildFileFullPath(List<Map<String, Object>> pageVos);

	List<Map<String, Object>> queryByModel(String modelId);

	Map<String, Object> getPageById(String pageId);
}