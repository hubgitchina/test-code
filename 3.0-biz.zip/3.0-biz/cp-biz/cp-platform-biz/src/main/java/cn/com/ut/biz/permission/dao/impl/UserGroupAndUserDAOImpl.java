package cn.com.ut.biz.permission.dao.impl;

import static cn.com.ut.biz.permission.entities.UserGroupAndUser.group_id;
import static cn.com.ut.biz.permission.entities.UserGroupAndUser.user_id;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.permission.dao.UserGroupAndUserDAO;
import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 用户分组与用户关系管理数据层实现类
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Repository
public class UserGroupAndUserDAOImpl extends JdbcOperationsImpl<UserGroupAndUser>
		implements UserGroupAndUserDAO {

	private String T_ROLE;
	private String T_ROLE_MENU;
	private String T_ROLE_USER;
	private String T_ROLE_USERGROUP;
	private String T_USERGROUP;
	private String T_USERGROUP_USER;
	{
		T_ROLE = getTable(Role.class);
		T_ROLE_MENU = getTable(RoleAndMenu.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
		T_ROLE_USERGROUP = getTable(RoleAndUserGroup.class);
		T_USERGROUP = getTable(UserGroup.class);
		T_USERGROUP_USER = getTable(UserGroupAndUser.class);
	}
	private static final String[] COLUMNS = { group_id, user_id };

	@Override
	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, COLUMNS, NAMES_ID_CT_CID,
				ParameterBuilder.builder().append(vo, COLUMNS).append(id,
						DateTimeUtil.currentDateTime(), vo.get(UserGroupAndUser.create_id))
						.toArray());
		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		return updateById(null, COLUMNS, NAMES_UT_UID, null,
				ParameterBuilder.builder().append(vo, COLUMNS)
						.append(DateTimeUtil.currentDateTime(), vo.get(UserGroupAndUser.update_id))
						.toArray(),
				(String) vo.get(UserGroupAndUser.idx), null);
	}

	@Override
	public int deleteUserGroupAndUser(String groupId, List<String> users) {

		int size = users.size();
		users.add(0, groupId);

		return delete(null, null, group_id + " = ? AND " + user_id + " {IN} ", new int[] { size },
				users.toArray(), null);
	}

	@Override
	public void deleteEntAccountRepeat(String id, String userId) {

		SQLHelper sql = SQLHelper.builder();
		sql.append("delete from").append(T_USERGROUP_USER).append("where id = ? and")
				.append("(select count(1) from").append(T_USERGROUP_USER).append("aa INNER JOIN")
				.append(T_USERGROUP)
				.append("bb on aa.group_id = bb.id where aa.user_id = ? and bb.group_class = ?) > 1");
		Object[] array = new Object[] { id, userId, ConstantUtil.FLAG_ONE };
		update(getJdbcTemplate(), sql.toSQL(), array);
	}

	@Override
	public void deleteUserGroupAndUserRepeat(String id, String userId, String groupId) {

		SQLHelper sql = SQLHelper.builder();
		sql.append("delete from").append(T_USERGROUP_USER).append("where id = ? and")
				.append("(select count(1) from").append(T_USERGROUP_USER).append("aa INNER JOIN")
				.append(T_USERGROUP)
				.append("bb on aa.group_id = bb.id where aa.group_id = ? and aa.user_id = ? and bb.group_class = ?) > 1");
		Object[] array = new Object[] { id, groupId, userId, ConstantUtil.FLAG_ZERO };
		update(getJdbcTemplate(), sql.toSQL(), array);
	}

	@Override
	public List<Map<String, Object>> listUserRefGroups(PageBean pageBean, String userId) {

		StringBuilder listUserRefGroupsTable = new StringBuilder();
		listUserRefGroupsTable.append(T_USERGROUP).append(" WHERE ID IN ( ")
				.append(" SELECT group_id FROM ").append(T_USERGROUP_USER)
				.append(" WHERE user_id = ? ").append(" ) ");

		return queryPage(pageBean, null, listUserRefGroupsTable.toString(), true, null, null, null,
				null, null, null, new Object[] { userId });
	}
}
