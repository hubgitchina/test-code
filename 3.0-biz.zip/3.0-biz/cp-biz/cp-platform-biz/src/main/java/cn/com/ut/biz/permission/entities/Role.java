package cn.com.ut.biz.permission.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 角色实体
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public class Role extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * 角色名
	 */
	public static final String role_name = "role_name";
	/**
	 * 系统角色类型，用于区分是系统初始化角色（不能修改）还是普通角色，字典ROLE_TYPE（0系统角色，1普通用户角色）
	 */
	public static final String role_type = "role_type";
	/**
	 * 角色描述
	 */
	public static final String role_note = "role_note";
	/**
	 * 角色分类，字典ROLE_CLASS（0系统角色，1企业角色）
	 */
	public static final String role_class = "role_class";

	/**
	 * 是否为平台超级管理员
	 */
	public static final String is_supermanager = "is_supermanager";
}
