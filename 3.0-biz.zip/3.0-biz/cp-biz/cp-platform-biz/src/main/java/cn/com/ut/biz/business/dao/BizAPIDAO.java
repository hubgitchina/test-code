package cn.com.ut.biz.business.dao;

import cn.com.ut.biz.business.entities.BizAPI;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 业务APIDAO
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface BizAPIDAO extends JdbcOperation<BizAPI> {

	/**
	 * api所属业务实体是否被业务实例使用
	 * 
	 * @param apiId
	 * @return
	 */
	boolean isUseTemplate(String apiId);
}