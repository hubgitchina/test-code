package cn.com.ut.biz.business.service;

import java.util.List;
import java.util.Map;

/**
 * 业务实体业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface BizEntityService {

	/**
	 * 创建业务实体
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新业务实体
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询业务实体详情
	 */
	Map<String, Object> getDetail(String entityId);

	/**
	 * 删除业务实体
	 * 
	 * @param apiId
	 */
	void delete(String entityId);

	/**
	 * 查询所有业务实体
	 * 
	 * @return
	 */
	List<Map<String, Object>> findAll();

	/**
	 * 查询所有业务实体及关联接口
	 * 
	 * @return
	 */
	List<Map<String, Object>> findAllEntityAndAPI();

	/**
	 * 是否已存在同名业务实体
	 * 
	 * @param vo
	 * @return
	 */
	int existEntity(Map<String, Object> vo);
}
