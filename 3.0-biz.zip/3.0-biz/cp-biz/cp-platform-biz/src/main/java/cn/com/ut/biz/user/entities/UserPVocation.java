package cn.com.ut.biz.user.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 用户职业信息
 * 
 * @author zhanghaili
 * @since 2014-06-12
 */
public class UserPVocation extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9081759271480520408L;
	/**
	 * 个人(普通)用户表id
	 */
	public static final String user_id = "user_id";
	/**
	 * 单位名称
	 */
	public static final String company_name = "company_name";
	/**
	 * 工作开始年份
	 */
	public static final String begin_year = "begin_year";
	/**
	 * 结束工作年份
	 */
	public static final String end_year = "end_year";
}