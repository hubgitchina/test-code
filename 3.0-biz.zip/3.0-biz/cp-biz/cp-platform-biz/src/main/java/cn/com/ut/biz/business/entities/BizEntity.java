package cn.com.ut.biz.business.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 业务实体
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public class BizEntity extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8323182295945270488L;

	/**
	 * 业务实体名称
	 */
	public static final String entity_name = "entity_name";
	/**
	 * 业务实体描述
	 */
	public static final String entity_desc = "entity_desc";
}
