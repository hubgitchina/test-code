package cn.com.ut.biz.developer.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.developer.dao.DevInfoDAO;
import cn.com.ut.biz.developer.entities.DevInfo;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 开发者信息DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Repository
public class DevInfoDAOImpl extends JdbcOperationsImpl<DevInfo> implements DevInfoDAO {

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = { DevInfo.corp_name, DevInfo.link_man, DevInfo.link_email,
				DevInfo.link_phone, DevInfo.license_code, DevInfo.organization_code,
				DevInfo.tax_code, DevInfo.dev_id, DevInfo.license_append,
				DevInfo.organization_append, DevInfo.tax_append };
		add(null, names, NAMES, ParameterBuilder.builder().append(vo, names)
				.append(id, time, time, vo.get(DevInfo.create_id), vo.get(DevInfo.create_id))
				.toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, DevInfo.corp_name, DevInfo.link_man, DevInfo.link_email,
				DevInfo.link_phone, DevInfo.license_code, DevInfo.organization_code,
				DevInfo.tax_code, DevInfo.license_append, DevInfo.organization_append,
				DevInfo.tax_append);
		String[] names = pb.toColumns();
		return updateById(null, names, NAMES_UT_UID, ParameterBuilder.builder().append(vo, names)
				.append(DateTimeUtil.currentDateTime(), vo.get(DevInfo.update_id)).toArray(),
				(String) vo.get(DevInfo.idx));
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		String[] selectCols = new String[] { DevInfo.idx, DevInfo.corp_name, DevInfo.link_man,
				DevInfo.link_email, DevInfo.link_phone, DevInfo.license_code,
				DevInfo.organization_code, DevInfo.tax_code, DevInfo.dev_id, DevInfo.status };
		return queryPage(page, null, null, false, selectCols, null, new String[] { DevInfo.is_del },
				null, null, DevInfo.create_time, new Object[] { ConstantUtil.FLAG_NO });
	}

	@Override
	public int submitExamine(Map<String, Object> vo) {

		return updateById(null, new String[] { DevInfo.status },
				NAMES_UT_UID, new Object[] { ConstantUtil.AuditStatus.AUDIT_BEGIN,
						DateTimeUtil.currentDateTime(), vo.get(DevInfo.update_id) },
				(String) vo.get(DevInfo.idx));
	}

	@Override
	public int examineDevInfo(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, DevInfo.status, DevInfo.audit_time, DevInfo.audit_operator,
				DevInfo.audit_result);
		String[] names = pb.toColumns();
		vo.put(DevInfo.audit_time, DateTimeUtil.currentDateTime());
		return updateById(null, names, null, ParameterBuilder.builder().append(vo, names).toArray(),
				(String) vo.get(DevInfo.idx));
	}

	@Override
	public Map<String, Object> getDevInfoByUser(User user) {

		return getByKey(null, null,
				new String[] { DevInfo.idx, DevInfo.corp_name, DevInfo.link_man, DevInfo.link_email,
						DevInfo.link_phone, DevInfo.license_code, DevInfo.organization_code,
						DevInfo.tax_code, DevInfo.tax_append, DevInfo.dev_id, DevInfo.status,
						DevInfo.license_append, DevInfo.organization_append, DevInfo.tax_append,
						DevInfo.audit_result },
				null, new String[] { DevInfo.create_id }, new Object[] { user.getUserId() }, null);
	}

	@Override
	public int confirmUpdate(String id) {

		// 修改审核状态为待审核状态
		return updateById(null, new String[] { DevInfo.status }, null,
				new Object[] { ConstantUtil.AuditStatus.AUDIT_READY }, id);

		// return getById(null, null,
		// new String[] { DevInfo.idx, DevInfo.corp_name, DevInfo.link_man,
		// DevInfo.link_email,
		// DevInfo.link_phone, DevInfo.license_code, DevInfo.organization_code,
		// DevInfo.tax_code, DevInfo.tax_append, DevInfo.dev_id, DevInfo.status,
		// DevInfo.license_append, DevInfo.organization_append,
		// DevInfo.tax_append },
		// null, id);
	}
}
