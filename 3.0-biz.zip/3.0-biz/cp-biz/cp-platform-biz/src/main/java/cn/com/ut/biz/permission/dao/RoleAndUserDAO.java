package cn.com.ut.biz.permission.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 角色与用户关系管理数据层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface RoleAndUserDAO extends JdbcOperation<RoleAndUser> {

	/**
	 * 删除指定角色与指定用户之间的关系
	 * 
	 * @param roleId
	 * @param userIds
	 * @return 影响的记录数
	 */
	int deleteRoleRefUsers(String roleId, List<String> userIds);

	/**
	 * 获取指定用户的角色id集合
	 * 
	 * @param userId
	 * @return 指定用户的角色id集合
	 */
	List<String> listRolesByUserId(String userId);

	/**
	 * 分页获取指定用户关联的角色信息列表
	 * 
	 * @param pageBean
	 * @param userId
	 * @return 指定用户关联的角色信息列表
	 */
	List<Map<String, Object>> listUserRefRoles(PageBean pageBean, String userId);

	/**
	 * 删除指定用户与指定角色关系
	 * 
	 * @param userId
	 * @param roles
	 * @return 影响的记录数
	 */
	int deleteUserRefRoles(String userId, List<String> roles);

	/**
	 * 删除指定用户与指定角色之间的关系
	 * 
	 * @param roleId
	 * @param userId
	 * @return 影响的记录数
	 */
	int deleteByRoleAndUser(String roleId, String userId);

	/**
	 * 删除指定用户与指定的角色类型关联的记录
	 * 
	 * @param userId
	 * @param roleClasses
	 * @return 影响的记录数
	 */
	int deleteUserRefRolesAll(String userId, String[] roleClasses);
}
