package cn.com.ut.util;

import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;

public class APPUtil {

	/** 上次生成ID的时间截 */
	private static long lastAppId = -1L;

	/**
	 * 产生新的APP_ID (该方法是线程安全的)
	 * 
	 * @return AppId
	 */
	public static synchronized String nextAppId() {

		long appId = timeGen();

		// 如果当前时间小于上一次ID生成的时间戳，说明系统时钟回退过这个时候应当抛出异常
		if (appId < lastAppId) {
			ExceptionUtil.throwServiceException(
					String.format("系统时钟回退异常，距离当前时间落后  %d 毫秒", lastAppId - appId));
		}

		// 如果是同一时间生成的
		if (lastAppId == appId) {
			// 阻塞到下一个毫秒,获得新的时间戳
			appId = tilNextMillis(lastAppId);
		}

		// 上次生成ID的时间截
		lastAppId = appId;

		return String.valueOf(appId);
	}

	/**
	 * 阻塞到下一个毫秒，直到获得新的时间戳
	 * 
	 * @param lastTimestamp
	 *            上次生成ID的时间截
	 * @return 当前时间戳
	 */
	protected static long tilNextMillis(long lastTimestamp) {

		long timestamp = timeGen();
		while (timestamp <= lastTimestamp) {
			timestamp = timeGen();
		}
		return timestamp;
	}

	/**
	 * 返回以毫秒为单位的当前时间
	 * 
	 * @return 当前时间(毫秒)
	 */
	protected static long timeGen() {

		return System.currentTimeMillis();
	}

	/**
	 * 产生新的APP_KEY
	 * 
	 * @return
	 */
	public static String nextAppKey() {

		String appKey = CommonUtil.getUUID();
		return appKey;
	}

}