package cn.com.ut.biz.permission.dao.impl;

import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.permission.dao.RoleDAO;
import cn.com.ut.biz.permission.entities.Menu;
import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ArrayUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 角色管理数据层实现类
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Repository
public class RoleDAOImpl extends JdbcOperationsImpl<Role> implements RoleDAO {

	private String T_MENU;
	private String T_ROLE;
	private String T_ROLE_MENU;
	private String T_ROLE_USER;
	private String T_ROLE_USERGROUP;
	private String T_USERGROUP;
	private String T_USERGROUP_USER;
	private String T_USERMANAGER;
	private String tuser;
	{
		T_ROLE = getTable(Role.class);
		T_ROLE_MENU = getTable(RoleAndMenu.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
		T_ROLE_USERGROUP = getTable(RoleAndUserGroup.class);
		T_USERGROUP = getTable(UserGroup.class);
		T_USERGROUP_USER = getTable(UserGroupAndUser.class);
		T_MENU = getTable(Menu.class);
		T_USERMANAGER = getTable(UserManager.class);
		tuser = getTable(UserParent.class);
	}

	@Deprecated
	@Override
	public List<Map<String, Object>> queryRoleNameByIds(List<String> roleIds) {

		return queryPage(null, null, null, false, new String[] { BaseEntity.idx, Role.role_name },
				null, null, BaseEntity.idx + SQLHelper.IN_REPLACE, new int[] { roleIds.size() },
				null, roleIds.toArray());
	}

	@Override
	public Map<String, Object> getDetail(String roleId) {

		return getByProperties(new String[] { BaseEntity.idx }, new Object[] { roleId });
	}

	@Override
	public String add(Map<String, Object> vo) {

		Timestamp time = DateTimeUtil.currentDateTime();
		String id = CommonUtil.getUUID();

		add(null,
				new String[] { Role.role_name, Role.role_note, Role.role_type, BaseEntity.is_use,
						Role.role_class, Role.is_supermanager },
				NAMES,
				new Object[] { vo.get(Role.role_name), vo.get(Role.role_note),
						ConstantUtil.FLAG_ONE, vo.get(BaseEntity.is_use), vo.get(Role.role_class),
						vo.get(Role.is_supermanager), id, time, time, vo.get(create_id),
						vo.get(create_id) });
		return id;

	}

	/**
	 * 更新的字段只包括：role_name, role_note, is_use
	 */
	@Override
	public int update(Map<String, Object> vo) {

		Timestamp time = DateTimeUtil.currentDateTime();
		return updateById(null, new String[] { Role.role_name, Role.role_note, BaseEntity.is_use },
				NAMES_UT_UID,
				new Object[] { vo.get(Role.role_name), vo.get(Role.role_note),
						vo.get(BaseEntity.is_use), time, vo.get(create_id) },
				(String) vo.get(BaseEntity.idx));
	}

	@Override
	public List<Map<String, Object>> listMenusByRoleId(String roleId, String parentId,
			PageBean pageBean, String userId) {

		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.append(roleId);
		StringBuilder listMenusByRoleIdSQL = new StringBuilder();
		listMenusByRoleIdSQL.append(" SELECT ")
				.append(" A.ID,A.menu_text,A.menu_url,A.menu_comment,A.menu_img, ")
				.append(" (CASE WHEN ")
				.append(" A.parent_id IS NULL THEN '*' ELSE A.parent_id END) AS ")
				.append(" parent_id, ").append(" A.sort_num, ")
				.append(" (CASE WHEN B.menu_id IS NULL THEN '0' ELSE '1' END) AS IS_SEL, ")
				.append(" (CASE WHEN B.is_own IS NULL THEN 'N' ELSE B.is_own END) AS is_own, ")
				.append(" (CASE WHEN B.is_assign IS NULL THEN 'N' ELSE B.is_assign END) AS is_assign ")
				.append(" FROM ").append(T_MENU).append(" A LEFT JOIN ").append(T_ROLE_MENU)
				.append(" B ON A.ID = B.menu_id AND B.role_id = ? WHERE 1=1 ");
		if (CommonUtil.isEmpty(parentId)) {
			listMenusByRoleIdSQL.append(" AND A.parent_id IS NULL");
		} else {
			listMenusByRoleIdSQL.append(" AND A.parent_id = ?");
			parameterBuilder.append(parentId);
		}
		listMenusByRoleIdSQL.append(" AND  A.ID IN ").append(" ( ")
				.append(" SELECT mr.menu_id FROM ").append(T_ROLE_MENU).append(" mr WHERE ")
				.append(" mr.is_assign='Y' AND mr.role_id IN ").append(" (SELECT role_id FROM ")
				.append(T_ROLE_USER).append(" WHERE user_id=?) ").append(" UNION ALL ")
				.append(" SELECT m.id FROM ").append(T_MENU)
				.append(" m WHERE '5e4175d19df84bce93e84966dbe5bc95' IN ")
				.append(" (SELECT role_id FROM ").append(T_ROLE_USER).append(" WHERE user_id=?) ")
				.append(" ) ").append(" ORDER BY A.parent_id, A.sort_num ");

		parameterBuilder.append(userId);
		parameterBuilder.append(userId);
		return queryForList(getJdbcTemplate(), listMenusByRoleIdSQL.toString(),
				parameterBuilder.toArray());
	}

	@Override
	public List<Map<String, Object>> listRoleRefUsers(String roleId, PageBean pageBean) {

		StringBuffer table = new StringBuffer();
		table.append(getTable(UserParent.class)).append(" um INNER JOIN ")
				.append(getTable(RoleAndUser.class)).append(" ru on um.id = ru.user_id");
		String[] listRoleRefUsersColumns = new String[] { "um.id as user_id", "um.email" };
		return queryPage(pageBean, null, table.toString(), false, listRoleRefUsersColumns, null,
				new String[] { "ru.role_id", "ru.is_del" }, null, null, null,
				new Object[] { roleId, ConstantUtil.FLAG_NO });
	}

	@Override
	public List<Map<String, Object>> listRoleNoRefUsers(String roleId, PageBean pageBean) {

		StringBuilder listRoleNoRefUsersJoin = new StringBuilder();
		listRoleNoRefUsersJoin.append(tuser).append(" A WHERE A.id IN ")
				.append(" (SELECT user_id FROM ").append(T_USERGROUP_USER)
				.append(" WHERE group_id IN ").append(" (SELECT group_id from ")
				.append(T_ROLE_USERGROUP).append(" WHERE role_id=?) ").append(" ) ")
				.append(" AND A.id NOT IN ").append(" (SELECT user_id FROM ").append(T_ROLE_USER)
				.append(" WHERE role_id=? ) ");

		String[] listColumns = new String[] { "A.id AS user_id", "A.user_name", "A.user_type",
				"A.email" };
		return queryPage(pageBean, null, listRoleNoRefUsersJoin.toString(), true, listColumns, null,
				null, null, null, null, new Object[] { roleId, roleId });

	}

	@Override
	public List<Map<String, Object>> listRolesExcept(List<Object> roleIds, PageBean pageBean) {

		if (CollectionUtil.isEmptyCollection(roleIds)) {
			return query(pageBean);
		}

		return queryPage(pageBean, null, getTable(), false, null, null, null, "id not {IN}",
				new int[] { roleIds.size() }, null, roleIds.toArray());

	}

	@Override
	public List<Map<String, Object>> listRoleInclude(List<String> roles) {

		SQLHelper join = SQLHelper.builder();
		join.append(T_ROLE).append("aa LEFT JOIN").append(T_ROLE_USERGROUP)
				.append("bb on aa.id = bb.role_id");
		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns("aa", Role.idx + " AS " + RoleAndUserGroup.role_id, Role.role_name)
				.appendColumns("bb", RoleAndUserGroup.group_id);
		return queryPage(null, null, join.toSQL(), false, pb.toColumns(), null, null, "aa.ID {IN}",
				new int[] { roles.size() }, null, roles.toArray());
	}

	@Override
	public List<Map<String, Object>> queryUserRoleMenuByName(PageBean page, String roleId,
			List<String> menuIds, String userId) {

		if (menuIds == null) {
			menuIds = new ArrayList<String>();
			menuIds.add("");
		} else if (menuIds.isEmpty()) {
			menuIds.add("");
		}

		List<Object> array = new ArrayList<Object>();
		array.add(roleId);
		array.addAll(menuIds);
		array.add(userId);
		array.add(ConstantUtil.ROLE_ADMIN);

		SQLHelper join = SQLHelper.builder();
		join.append("(");
		join.append(" SELECT A.ID, A.menu_text, ").append(" (case when exists(select bb.id from ")
				.append(T_MENU)
				.append(" bb where bb.parent_id = a.id) then 'N' else 'Y' end) as leaf, ")
				.append(" ( CASE WHEN A.parent_id IS NULL THEN '*' ELSE A.parent_id END ) AS parent_id, ")
				.append(" ( CASE WHEN B.menu_id IS NULL THEN '0' ELSE '1' END ) AS IS_SEL, ")
				.append(" ( CASE WHEN B.is_own IS NULL THEN 'N' ELSE B.is_own END ) AS is_own, ")
				.append(" ( CASE WHEN B.is_assign IS NULL THEN 'N' ELSE B.is_assign END ) AS is_assign ")
				.append(" from ").append(T_MENU)
				.append(" A LEFT JOIN bdm_bas_role_menu B ON A.ID = B.menu_id AND B.role_id = ? ")
				.append(" WHERE ( ").append(" A.ID IN ( ")
				.append(ArrayUtil.joinSameElement("?", menuIds.size(), ",")).append(" ) ")
				.append(" or exists(SELECT role_id FROM bdm_bas_user_role WHERE user_id = ? and role_id = ?) ")
				.append(" ) ");
		join.append(") AS aa");

		// sql.append(" ORDER BY A.parent_id, A.sort_num ");
		String[] selectColumnArray = ParameterBuilder.builder()
				.appendColumns("aa", "ID", "menu_text", "LEAF", "IS_SEL", "is_own", "is_assign")
				.toColumns();
		return query(page, null, join.toSQL(), selectColumnArray, null, null, array.toArray());

	}

	@Override
	public List<Map<String, Object>> queryUserRoleMenu(String roleId, List<String> menuIds,
			String parentMenuId, String userId) {

		if (menuIds == null) {
			menuIds = new ArrayList<String>();
			menuIds.add("");
		} else if (menuIds.isEmpty()) {
			menuIds.add("");
		}

		List<String> parentIds = CommonUtil.withParentMenus(menuIds);
		menuIds.addAll(parentIds);

		List<Object> array = new ArrayList<Object>();
		array.add(roleId);
		array.addAll(menuIds);
		array.add(userId);
		array.add(ConstantUtil.ROLE_ADMIN);

		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT A.ID, A.menu_text, ").append(" (case when exists(select bb.id from ")
				.append(T_MENU)
				.append(" bb where bb.parent_id = a.id) then 'N' else 'Y' end) as leaf, ")
				.append(" ( CASE WHEN A.parent_id IS NULL THEN '*' ELSE A.parent_id END ) AS parent_id, ")
				.append(" ( CASE WHEN B.menu_id IS NULL THEN '0' ELSE '1' END ) AS IS_SEL, ")
				.append(" ( CASE WHEN B.is_own IS NULL THEN 'N' ELSE B.is_own END ) AS is_own, ")
				.append(" ( CASE WHEN B.is_assign IS NULL THEN 'N' ELSE B.is_assign END ) AS is_assign ")
				.append(" from ").append(T_MENU)
				.append(" A LEFT JOIN bdm_bas_role_menu B ON A.ID = B.menu_id AND B.role_id = ? ")
				.append(" WHERE ( ").append(" A.ID IN ( ")
				.append(ArrayUtil.joinSameElement("?", menuIds.size(), ",")).append(" ) ")
				.append(" or exists(SELECT role_id FROM bdm_bas_user_role WHERE user_id = ? and role_id = ?) ")
				.append(" ) ");
		if (CommonUtil.isEmpty(parentMenuId)) {
			sql.append(" AND a.parent_id is null ");
		} else {
			sql.append(" AND a.parent_id = ? ");
			array.add(parentMenuId);
		}
		sql.append(" ORDER BY A.parent_id, A.sort_num ");

		return queryForList(getJdbcTemplate(), sql.toString(), array.toArray());
	}

	@Override
	public List<String> queryUserRoleMenuAssign(List<String> roleIds) {

		if (CollectionUtil.isEmptyCollection(roleIds))
			return new ArrayList<>();

		List<String> array = new ArrayList<String>();
		array.add(0, ConstantUtil.FLAG_YES);
		array.addAll(roleIds);

		List<Map<String, Object>> listMany = queryPage(null, null, T_ROLE_MENU, false,
				new String[] { RoleAndMenu.menu_id }, null, new String[] { RoleAndMenu.is_assign },
				RoleAndMenu.role_id + " {IN}", new int[] { array.size() - 1 }, null,
				array.toArray());

		return CollectionUtil.listManyToOne(listMany, RoleAndMenu.menu_id);
	}

	@Override
	public List<String> queryUsersByMenus(List<String> userIds, List<String> menuIds) {

		SQLHelper sql = SQLHelper.builder();
		sql.append("select aa.user_id from").append(T_ROLE_USER).append("aa where aa.user_id in (");
		sql.append(ArrayUtil.joinSameElement("?", userIds.size(), ","))
				.append(") and EXISTS (select 1 from").append(T_ROLE_MENU)
				.append("bb where bb.menu_id in (");
		sql.append(ArrayUtil.joinSameElement("?", menuIds.size(), ","))
				.append(") and bb.role_id = aa.role_id)");
		userIds.addAll(menuIds);
		return queryForList(getJdbcTemplate(), sql.toSQL(), String.class, userIds.toArray());
	}

}
