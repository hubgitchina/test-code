package cn.com.ut.config.thirdlogin;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "third.tencent.qq")
public class QQLoginModule {

	private String callBackUrl;

	private String pcId;

	private String pcKey;

	private String appId;

	private String appKey;

	public String getAppId() {

		return appId;
	}

	public void setAppId(String appId) {

		this.appId = appId;
	}

	public String getAppKey() {

		return appKey;
	}

	public void setAppKey(String appKey) {

		this.appKey = appKey;
	}

	public String getPcId() {

		return pcId;
	}

	public void setPcId(String pcId) {

		this.pcId = pcId;
	}

	public String getPcKey() {

		return pcKey;
	}

	public void setPcKey(String pcKey) {

		this.pcKey = pcKey;
	}

	public String getCallBackUrl() {

		return callBackUrl;
	}

	public void setCallBackUrl(String callBackUrl) {

		this.callBackUrl = callBackUrl;
	}

}
