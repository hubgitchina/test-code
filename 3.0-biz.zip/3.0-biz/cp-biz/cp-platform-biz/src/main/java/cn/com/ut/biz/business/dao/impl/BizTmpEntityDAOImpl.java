package cn.com.ut.biz.business.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.business.dao.BizTmpEntityDAO;
import cn.com.ut.biz.business.entities.BizTmpEntity;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 业务模板与业务实体DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Repository
public class BizTmpEntityDAOImpl extends JdbcOperationsImpl<BizTmpEntity>
		implements BizTmpEntityDAO {

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = { BizTmpEntity.tmp_id, BizTmpEntity.entity_id };
		add(null, names, NAMES,
				ParameterBuilder
						.builder().append(vo, names).append(id, time, time,
								vo.get(BizTmpEntity.create_id), vo.get(BizTmpEntity.create_id))
						.toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, BizTmpEntity.tmp_id, BizTmpEntity.entity_id);
		String[] names = pb.toColumns();
		return updateById(null, names, NAMES_UT_UID, ParameterBuilder.builder().append(vo, names)
				.append(DateTimeUtil.currentDateTime(), vo.get(BizTmpEntity.update_id)).toArray(),
				(String) vo.get(BizTmpEntity.idx));
	}

	@Override
	public List<Map<String, Object>> findEntityByTmpIds(List<String> templateIds) {

		String sql = "select te.entity_id from t_biz_tmp_entity te where te.tmp_id {IN} group by te.entity_id";
		sql = replaceInCase(sql, new int[] { templateIds.size() });
		return queryForList(getJdbcTemplate(), sql, templateIds.toArray());
	}
}
