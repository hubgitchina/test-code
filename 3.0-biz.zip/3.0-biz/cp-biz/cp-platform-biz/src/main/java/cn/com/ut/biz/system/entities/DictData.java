package cn.com.ut.biz.system.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class DictData extends BaseEntity {

	private static final long serialVersionUID = 5441771982121209080L;

	public static final String dict_code = "dict_code";
	public static final String dict_text = "dict_text";
	public static final String dict_type = "dict_type";
	public static final String dict_des = "dict_des";
	public static final String group_code = "group_code";
	public static final String sort_num = "sort_num";

}
