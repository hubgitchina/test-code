package cn.com.ut.biz.business.service;

import java.util.List;
import java.util.Map;

/**
 * 业务实例业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface BizTemplateService {

	/**
	 * 创建业务实例
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 通过实例模板创建业务实例
	 * 
	 * @param vo
	 * @return
	 */
	String createByTemplate(Map<String, Object> vo);

	/**
	 * 更新业务实例
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询所有业务实例
	 * 
	 * @return
	 */
	List<Map<String, Object>> findAll(String tmpType);

	/**
	 * 根据用户信息查询所有业务实例及实例下所有实体
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> findTmpEntityByUser(Map<String, Object> vo);

	/**
	 * 查询业务实例详情
	 */
	List<Map<String, Object>> getDetail(String templateId);

	/**
	 * 删除业务实例
	 * 
	 * @param apiId
	 */
	void delete(String templateId);

	/**
	 * 是否已存在同名业务实例
	 * 
	 * @param vo
	 * @return
	 */
	int existTemplate(Map<String, Object> vo);

	/**
	 * 验证应用下是否已存在同名业务实例
	 * 
	 * @param vo
	 * @return
	 */
	int existAppTemplate(Map<String, Object> vo);
}
