package cn.com.ut.biz.ui.service;

import cn.com.ut.core.common.jdbc.PageBean;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/4/25.
 */
public interface ComponentService {


    /**
     * 创建组件
     *
     * @param component
     * @return
     */
    String add(Map<String, Object> component);

    /**
     * 更新组件
     *
     * @param id
     */
    void delete(String id);

    /**
     * 查询组件列表（支持分页）
     *
     * @param pageBean
     * @return
     */
    List<Map<String, Object>> query(PageBean pageBean);

    /**
     * 更新组件
     *
     * @param vo
     */
    void update(Map<String, Object> vo);

   Map<String,Object> getDetail(String configId) ;
}
