package cn.com.ut.util;

import java.util.HashMap;
import java.util.Map;

import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;

public class UserUtil {

	public static Map<String, Object> userToMap(User user) {

		Map<String, Object> userMap = new HashMap<>();
		if (user == null) {
			return userMap;
		}
		userMap.put(UserParent.user_name, user.getUserName());
		userMap.put(UserPerson.user_id, user.getUserId());
		userMap.put(UserParent.mobile, user.getMobile());
		userMap.put(UserParent.email, user.getEmail());
		userMap.put(UserPerson.user_pic, user.getImage());
		userMap.put(UserParent.nick_name, user.getNick());
		userMap.put(UserParent.user_type, user.getUserType());
		userMap.put("sid", user.getSessionId());
		Map<String, Object> selfMap = user.getSelf();
		if (!CollectionUtil.isEmptyMap(selfMap)) {
			userMap.put(UserPerson.user_birthday, selfMap.get(UserPerson.user_birthday));
			userMap.put(UserPerson.user_sex, selfMap.get(UserPerson.user_sex));
		}
		return userMap;
	}
}
