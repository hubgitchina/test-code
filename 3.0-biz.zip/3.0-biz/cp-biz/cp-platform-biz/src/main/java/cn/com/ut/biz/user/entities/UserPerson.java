package cn.com.ut.biz.user.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 普通用户信息
 */
public class UserPerson extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4919745943966854613L;
	/**
	 * 用户id
	 */
	public static final String user_id = "user_id";
	/**
	 * 用户性别
	 */
	public static final String user_sex = "user_sex";
	/**
	 * 用户生日
	 */
	public static final String user_birthday = "user_birthday";
	/**
	 * 用户头像资源id
	 */
	public static final String user_pic = "user_pic";
	/**
	 * 是否已婚
	 */
	public static final String is_marital = "is_marital";
	/**
	 * 从事的行业
	 */
	public static final String industry_nature = "industry_nature";

	/**
	 * 教育程度level of education，字典项存储EDUCATION_LEVEL
	 */
	public static final String education_level = "education_level";

	/**
	 * 个人用户的收入情况，字典项存储MonthlyIncome
	 */
	public static final String monthly_income = "monthly_income";

	/**
	 * 记录province的区域码，变长的8个字符
	 */
	public static final String province = "province";

	/**
	 * 记录city的区域码，变长的8个字符
	 */
	public static final String city = "city";

	/**
	 * 记录area的区域码，变长的8个字符
	 */
	public static final String area = "area";

	/**
	 * 详细地址
	 */
	public static final String contact_addr = "contact_addr";

	/**
	 * 兴趣爱好
	 */
	public static final String user_hobbies = "user_hobbies";

	/**
	 * 联系人
	 */
	public static final String linkman_name = "linkman_name";

	/**
	 * 固定电话
	 */
	public static final String fixed_phone = "fixed_phone";

}