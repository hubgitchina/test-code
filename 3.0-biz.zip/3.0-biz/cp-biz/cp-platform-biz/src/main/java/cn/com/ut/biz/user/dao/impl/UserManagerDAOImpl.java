package cn.com.ut.biz.user.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.user.dao.UserManagerDAO;
import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 管理员用户
 * 
 * @author ouyuexing
 *
 */
@Repository
public class UserManagerDAOImpl extends JdbcOperationsImpl<UserManager> implements UserManagerDAO {

	String[] COLUMNS = { UserManager.real_name, UserManager.user_id, UserManager.work_desc,
			UserManager.work_number, UserManager.email, UserManager.mobile };

	String[] UPDATECOLUMNS = { UserManager.real_name, UserManager.work_desc,
			UserManager.work_number, UserManager.email, UserManager.mobile };

	private String TABLE;
	private String T_ROLE;
	private String T_ROLE_USER;
	{
		TABLE = getTable(UserManager.class);
		T_ROLE = getTable(Role.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
	}

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(UPDATECOLUMNS, vo);
	}

	@Override
	public boolean isUniqueSuperManager(String userId) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_ROLE_USER).append("ur").append("INNER JOIN").append(T_ROLE)
				.append("r ON r.id = ur.role_id").append("WHERE r.is_supermanager = 'Y'");
		table.append("AND ur.user_id = ?");

		List<Object> args = new ArrayList<>();
		args.add(userId);

		List<Map<String, Object>> list = queryPage(null, null, table.toSQL(), true, null, null,
				null, null, null, null, args.toArray());
		if (!CollectionUtil.isEmptyCollection(list)) {
			if (list.size() == 1) {
				String uniqueUserId = (String) list.get(0).get("user_id");
				return userId.equals(uniqueUserId);
			}
		}

		return false;
	}

	@Override
	public Collection<String> findPlatformManagers(String platformId) {

		SQLHelper table = SQLHelper.builder();
		table.append(TABLE).append("m").append("WHERE EXISTS (SELECT 1 FROM").append(T_ROLE_USER)
				.append("ur").append("INNER JOIN").append(T_ROLE).append("r ON r.id = ur.role_id")
				.append("WHERE ur.user_id = m.user_id )");

		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.appendColumns("m", COLUMNS);

		List<Object> args = new ArrayList<>();

		List<Map<String, Object>> list = queryPage(null, null, table.toSQL(), true,
				parameterBuilder.toColumns(), null, null, null, null, null, args.toArray());
		return CollectionUtil.listManyToOne(list, "user_id");
	}
}
