package cn.com.ut.biz.developer.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.developer.entities.DevInfo;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 开发者信息DAO
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface DevInfoDAO extends JdbcOperation<DevInfo> {
	/**
	 * 查询所有的开发者信息（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);

	/**
	 * 提交审核
	 * 
	 * @param vo
	 * @return
	 */
	int submitExamine(Map<String, Object> vo);

	/**
	 * 审核开发者提交的企业认证信息
	 * 
	 * @param vo
	 * @return
	 */
	int examineDevInfo(Map<String, Object> vo);

	/**
	 * 根据用户查询当前用户提交的企业审核信息
	 * 
	 * @param user
	 * @return
	 */
	Map<String, Object> getDevInfoByUser(User user);

	/**
	 * 确认修改审核资料
	 * 
	 * @param id
	 * @return
	 */
	int confirmUpdate(String id);
}