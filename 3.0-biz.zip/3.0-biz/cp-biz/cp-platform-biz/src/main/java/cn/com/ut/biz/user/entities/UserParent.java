package cn.com.ut.biz.user.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 用户信息实体
 * 
 */
public class UserParent extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5912030064863125011L;
	/**
	 * 用户名
	 */
	public static final String user_name = "user_name";
	/**
	 * 用户类型
	 */
	public static final String user_type = "user_type";
	/**
	 * 用户密码
	 */
	public static final String user_pwd = "user_pwd";
	/**
	 * 用户邮箱
	 */
	public static final String email = "email";
	/**
	 * 手机号
	 */
	public static final String mobile = "mobile";
	/**
	 * 是否锁定
	 */
	public static final String is_locked = "is_locked";
	/**
	 * 昵称
	 */
	public static final String nick_name = "nick_name";

	/**
	 * 更新用户名次数
	 */
	public static final String update_user_name_time = "update_user_name_time";
}