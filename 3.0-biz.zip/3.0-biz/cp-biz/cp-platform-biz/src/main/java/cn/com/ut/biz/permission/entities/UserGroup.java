package cn.com.ut.biz.permission.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 用户分组实体
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public class UserGroup extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * 用户分组名
	 */
	public static final String group_name = "group_name";
	/**
	 * 用户分组类型
	 */
	public static final String group_type = "group_type";
	/**
	 * 父ID
	 */
	public static final String parent_id = "parent_id";
	/**
	 * 用户分组描述
	 */
	public static final String group_note = "group_note";
	/**
	 * 用户分组类别（系统的或者企业的）
	 */
	public static final String group_class = "group_class";

}