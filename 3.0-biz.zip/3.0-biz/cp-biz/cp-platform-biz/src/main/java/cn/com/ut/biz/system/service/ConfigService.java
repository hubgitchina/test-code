package cn.com.ut.biz.system.service;

import java.util.List;
import java.util.Map;

public interface ConfigService extends ConfigServiceRemote {

	/**
	 * 创建系统配置
	 * 
	 * @param platformId
	 * @param configVo
	 */
	String create(Map<String, Object> configVo);

	/**
	 * 更新系统配置
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询系统配置详情
	 */
	Map<String, Object> getDetail(String configId);

	/**
	 * 删除系统配置
	 */
	void delete(String configId);

	/**
	 * 获取系统配置
	 * 
	 * @param dataPlatformId
	 * @param configCodes
	 * @return
	 */
	List<Map<String, Object>> getConfigValueByCode(List<Object> configCodes);

}