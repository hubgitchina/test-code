package cn.com.ut.biz.permission.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 用户分组与角色关系实体
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public class RoleAndUserGroup extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8985551200825486196L;
	/**
	 * 分组id
	 */
	public static final String group_id = "group_id";
	/**
	 * 角色id
	 */
	public static final String role_id = "role_id";
}