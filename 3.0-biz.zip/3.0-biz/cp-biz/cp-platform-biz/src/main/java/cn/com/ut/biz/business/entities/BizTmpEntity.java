package cn.com.ut.biz.business.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 业务模板与业务实体
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public class BizTmpEntity extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7047954869082949774L;
	/**
	 * 业务模板ID
	 */
	public static final String tmp_id = "tmp_id";
	/**
	 * 业务实体ID
	 */
	public static final String entity_id = "entity_id";
}
