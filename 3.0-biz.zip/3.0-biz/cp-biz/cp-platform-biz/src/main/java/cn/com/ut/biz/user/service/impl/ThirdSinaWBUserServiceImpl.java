package cn.com.ut.biz.user.service.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.user.service.ThirdSinaWBUserService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.config.thirdlogin.SinaLoginModule;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.rpc.ThirdRestTemplate;

/**
 * 第三方QQ用户管理
 * 
 * @author ouyuexing
 *
 */
@Service
public class ThirdSinaWBUserServiceImpl implements ThirdSinaWBUserService {

	@Autowired
	private SinaLoginModule sinaLoginModule;

	@Autowired
	private UserService userService;

	@Autowired
	private ThirdRestTemplate thirdRestTemplate;

	@Override
	public String getSinaWBLoginUrl(String sessionid, String successurl) {

		Map<String, Object> reqMap = new HashMap<>();
		reqMap.put("client_id", sinaLoginModule.getPcKey());
		JSONObject jb = new JSONObject();
		jb.put("vf", sessionid);
		jb.put("successurl", successurl);
		reqMap.put("state", jb.toJSONString());
		reqMap.put("redirect_uri", getCallBackEncUrl());
		return thirdRestTemplate.getReqUrl(ConstantUtil.RPC_PROJRCT.SINAWEIBO,
				ConstantUtil.API_SINAWEIBO.GET_CODE, reqMap);
	}

	@Override
	public String sinaWBUserLogin(String code, User user) {

		// 获取token
		Map<String, Object> parMap = new HashMap<>();
		parMap.put("client_id", sinaLoginModule.getPcKey());
		parMap.put("client_secret", sinaLoginModule.getPcSecret());
		parMap.put("code", code);
		parMap.put("grant_type", "authorization_code");
		parMap.put("redirect_uri", getCallBackEncUrl());
		JSONObject jb = thirdRestTemplate.exchangePostParForEntity(parMap,
				ConstantUtil.RPC_PROJRCT.SINAWEIBO, ConstantUtil.API_SINAWEIBO.GET_ACC_TOKEN);
		// 获取token
		String accToken = jb.getString("access_token");
		String openId = jb.getString("uid");
		if (CommonUtil.isEmpty(accToken, openId)) {
			ExceptionUtil.throwServiceException("获取新浪微博用户失败");
		}
		userService.sinaWBLogin(user, ConstantUtil.THIRD_USER_FORM.SINA_WEIBO,
				ConstantUtil.LOGIN_TYPE.PC, openId, accToken,
				Long.valueOf(ConstantUtil.SESSION_TIME.DEFAULT));
		return null;
	}

	@Override
	public Map<String, Object> getSinaWBUserInfo(String openId, String accessToken) {

		Map<String, Object> parMap = new HashMap<>();
		parMap.put("access_token", accessToken);
		parMap.put("uid", openId);
		JSONObject jb = thirdRestTemplate.exchangeGetForEntity(parMap,
				ConstantUtil.RPC_PROJRCT.SINAWEIBO, ConstantUtil.API_SINAWEIBO.GET_USER_INFO);
		if (CollectionUtil.isEmptyMap(jb)) {
			ExceptionUtil.throwServiceException("获取新浪微博用户失败");
		}
		return jb;
	}

	private String getCallBackEncUrl() {

		return encode(sinaLoginModule.getCallBackUrl());
	}

	private String encode(String par) {

		String ourUrlenc = null;
		try {
			ourUrlenc = URLEncoder.encode(par, "UTF-8");
		} catch (UnsupportedEncodingException e) {
		}
		return ourUrlenc;
	}

	@Override
	public Map<String, Object> getSystemAppInfo() {

		Map<String, Object> resMap = new HashMap<>();
		resMap.put("app_id", sinaLoginModule.getAppKey());
		return resMap;
	}

}
