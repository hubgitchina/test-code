package cn.com.ut.biz.business.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 业务实例
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public class BizTemplate extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8341557733879186930L;
	/**
	 * 模板类型(0内置1自定义)
	 */
	public static final String tmp_type = "tmp_type";
	/**
	 * 模板名称
	 */
	public static final String temp_name = "temp_name";
	/**
	 * 模板描述
	 */
	public static final String tmp_desc = "tmp_desc";
	/**
	 * 拥有者，即创建此模板的应用
	 */
	public static final String own_id = "own_id";
}
