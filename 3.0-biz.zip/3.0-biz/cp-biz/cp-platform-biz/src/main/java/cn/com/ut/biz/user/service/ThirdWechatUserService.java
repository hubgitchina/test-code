package cn.com.ut.biz.user.service;

import java.util.Map;

import cn.com.ut.core.common.system.beans.User;

/**
 * 第三方微信用户
 * 
 * @author ouyuexing
 *
 */
public interface ThirdWechatUserService {

	/**
	 * 获取微信登录的URL
	 * 
	 * @param sessionid
	 * @return
	 */
	String getWechatLoginUrl(String sessionid, String successurl);

	/**
	 * 微信授权回调
	 * 
	 * @param code
	 * @param user
	 * @return
	 */
	String wechatUserLogin(String code, User user);

	/**
	 * 获取微信授权用户信息
	 * 
	 * @param openId
	 * @param accessToken
	 * @return
	 */
	Map<String, Object> getWechatUserInfo(String openId, String accessToken);

	/**
	 * 获取第三方APP登录系统信息
	 * 
	 * @return
	 */
	Map<String, Object> getSystemAppInfo();

	/**
	 * 微信QQ登录
	 * 
	 * @param user
	 * @param code
	 */
	void appLogin(User user, String code);

}
