
//-----------------------------ServiceImpl-start---------------------------------//
package cn.com.ut.biz.ui.service.impl;

import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.ui.dao.ModelDAO;
import cn.com.ut.biz.ui.entities.Model;
import cn.com.ut.biz.ui.service.ModelService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * ServiceImpl
 * 
 * @author
 * @since
 */
@Service
public class ModelServiceImpl implements ModelService {

	@Autowired
	private ModelDAO modelDAO;

	@Override
	public String add(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Model.app_id, Model.model_name, Model.model_type,
				Model.front_tech);

		long count = modelDAO.count(null, null, new String[] { Model.app_id, Model.model_name },
				new Object[] { vo.get(Model.app_id), vo.get(Model.model_name) });
		if (count > 0) {
			ExceptionUtil.throwValidateException("模型名称重复");
		}
		return modelDAO.add(vo);
	}

	@Override
	public void delete(String id) {

		modelDAO.delete(id);
	}

	@Override
	public List<Map<String, Object>> query(PageBean pageBean) {

		return modelDAO.query(pageBean);
	}

	@Override
	public List<Map<String, Object>> query(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Model.app_id);
		return modelDAO.queryPage(null, null, null, false,
				new String[] { Model.idx, Model.app_id, Model.model_name, Model.model_type,
						Model.front_tech, Model.is_use },
				null, new String[] { Model.app_id, Model.is_del }, null, null, Model.create_time,
				new Object[] { vo.get(Model.app_id), ConstantUtil.FLAG_NO });
	}

	@Override
	public void update(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, idx, Model.app_id, Model.model_name,
				Model.model_type, Model.front_tech);

		long count = modelDAO.count(null, null, new String[] { Model.app_id, Model.model_name },
				Model.idx + " <> ? ", null,
				new Object[] { vo.get(Model.app_id), vo.get(Model.model_name), vo.get(Model.idx) });
		if (count > 0) {
			ExceptionUtil.throwValidateException("模型名称重复");
		}
		modelDAO.update(vo);
	}

	@Override
	public Map<String, Object> getDetail(String id) {

		return modelDAO.get(id);
	}

}
// -----------------------------ServiceImpl-end---------------------------------//