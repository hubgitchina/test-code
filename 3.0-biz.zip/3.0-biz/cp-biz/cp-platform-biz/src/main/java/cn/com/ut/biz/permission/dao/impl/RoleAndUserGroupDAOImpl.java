package cn.com.ut.biz.permission.dao.impl;

import static cn.com.ut.biz.permission.entities.RoleAndUserGroup.group_id;
import static cn.com.ut.biz.permission.entities.RoleAndUserGroup.role_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_use;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.permission.dao.RoleAndUserGroupDAO;
import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 角色与用户分组关系管理数据层实现类
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Repository
public class RoleAndUserGroupDAOImpl extends JdbcOperationsImpl<RoleAndUserGroup>
		implements RoleAndUserGroupDAO {
	private String T_ROLE;
	private String T_ROLE_MENU;
	private String T_ROLE_USER;
	private String T_ROLE_USERGROUP;
	private String T_USERGROUP;
	private String T_USERGROUP_USER;
	{
		T_ROLE = getTable(Role.class);
		T_ROLE_MENU = getTable(RoleAndMenu.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
		T_ROLE_USERGROUP = getTable(RoleAndUserGroup.class);
		T_USERGROUP = getTable(UserGroup.class);
		T_USERGROUP_USER = getTable(UserGroupAndUser.class);
	}

	private static final String[] COLUMNS = { group_id, role_id, is_use };

	@Override
	public int update(Map<String, Object> vo) {

		return update(null, new String[] { RoleAndUserGroup.group_id, update_id, update_time },
				null, new String[] { RoleAndUserGroup.role_id },
				new Object[] { vo.get(RoleAndUserGroup.group_id), vo.get(update_id),
						DateTimeUtil.currentDateTime() },
				new Object[] { vo.get(RoleAndUserGroup.role_id) });
	}

	@Override
	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		vo.put(is_use, ConstantUtil.FLAG_YES);
		add(null, COLUMNS, NAMES_ID_CT_CID,
				ParameterBuilder.builder().append(vo, COLUMNS).append(id,
						DateTimeUtil.currentDateTime(), vo.get(RoleAndUserGroup.create_id))
						.toArray());
		return id;
	}

	@Override
	public int deleteByRoleId(String roleId) {

		return delete(null, new String[] { RoleAndUserGroup.role_id }, new Object[] { roleId });
	}

	@Override
	public Map<String, Object> getByRoleId(String roleId) {

		return get(null, null, false, null, null, new String[] { RoleAndUserGroup.role_id }, null,
				null, new Object[] { roleId });
	}
}
