package cn.com.ut.biz.app.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;

import cn.com.ut.biz.app.dao.AppTmpDAO;
import cn.com.ut.biz.app.entities.AppInfo;
import cn.com.ut.biz.app.entities.AppTmp;
import cn.com.ut.biz.app.service.AppTmpService;
import cn.com.ut.biz.business.service.BizTemplateService;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 应用与业务模板业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Service
public class AppTmpServiceImpl implements AppTmpService {

	@Autowired
	private AppTmpDAO appTmpDAO;

	@Autowired
	private BizTemplateService bizTemplateService;

	@Override
	public String create(Map<String, Object> vo) {

		String templateId = bizTemplateService.create(vo);
		ValidatorUtil.validateMapContainsKey(vo, AppTmp.app_id);

		Map<String, Object> appTmpVo = Maps.newHashMapWithExpectedSize(3);
		appTmpVo.put(AppTmp.app_id, vo.get(AppTmp.app_id));
		appTmpVo.put(AppTmp.tmp_id, templateId);
		appTmpVo.put(AppTmp.create_id, vo.get(AppTmp.create_id));
		String appTmpId = appTmpDAO.insert(appTmpVo);
		return appTmpId;
	}

	@Override
	public String createAppTmp(Map<String, Object> vo) {

		String templateId = bizTemplateService.createByTemplate(vo);
		ValidatorUtil.validateMapContainsKey(vo, AppTmp.app_id);

		Map<String, Object> appTmpVo = Maps.newHashMapWithExpectedSize(3);
		appTmpVo.put(AppTmp.app_id, vo.get(AppTmp.app_id));
		appTmpVo.put(AppTmp.tmp_id, templateId);
		appTmpVo.put(AppTmp.create_id, vo.get(AppTmp.create_id));
		String appTmpId = appTmpDAO.insert(appTmpVo);
		return appTmpId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, AppInfo.idx, AppInfo.app_name);
		String id = (String) vo.get(AppInfo.idx);
		boolean isCanUpdate = appTmpDAO.checkUnique(new String[] { AppInfo.app_name },
				new Object[] { vo.get(AppInfo.app_name) }, new String[] { AppInfo.idx },
				new Object[] { id });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("应用名称重复");
		}

		appTmpDAO.update(vo);
		return id;
	}

	@Override
	public Map<String, Object> getDetail(String id) {

		ValidatorUtil.requiredFieldMiss(new Object[] { id });

		return appTmpDAO.getById(null, null, new String[] { AppInfo.idx, AppInfo.app_id,
				AppInfo.app_name, AppInfo.app_key, AppInfo.status }, null, id);
	}

	@Override
	public void delete(String id) {

		// if(status.equals("")){
		// ExceptionUtil.throwValidateException("应用审核中，不能删除");
		// }else if(status.equals("")){
		// ExceptionUtil.throwValidateException("应用已上线，不能删除");
		// }

		appTmpDAO.delete(id);
	}

	@Override
	public List<Map<String, Object>> findTmpByAppId(String appId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { appId }, AppTmp.app_id);
		return appTmpDAO.findTmpByAppId(appId);
	}
}
