package cn.com.ut.biz.user.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 系统管理员用户管理业务层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface AdminService {

	/**
	 * 添加系统管理员用户,用户名和工号必须唯一
	 * 
	 * @param vo
	 *            user_name,create_id, real_name
	 * @return 用户表ID即User.ID
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新系统管理员
	 * 
	 * @param vo
	 *
	 */
	void update(Map<String, Object> vo);

	/**
	 * 获取管理员详细信息
	 * 
	 *
	 * @param platformId
	 * @param id
	 * @return
	 */
	Map<String, Object> getDetailByUserId(String platformId, String id);

	/**
	 * 删除平台管理员
	 * 
	 * @param platformId
	 * @param userId
	 */
	void delete(String platformId, String userId);

	/**
	 * 查询
	 * 
	 * @param page
	 * @param platformId
	 * @return
	 */
	List<Map<String, Object>> find(PageBean page, String platformId);

	/**
	 * 获取管理员详细信息
	 * 
	 * @param userId
	 * @return
	 */
	Map<String, Object> getDetailByUserId(String userId);

	/**
	 * 获取用户的详细信息
	 * 
	 * @param platformId
	 * @param adminUserId
	 * @param pwd
	 */
	void modifyAdminPwd(String platformId, String adminUserId, String pwd);
}
