package cn.com.ut.biz.business.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;

import cn.com.ut.biz.business.dao.BizAPIDAO;
import cn.com.ut.biz.business.dao.BizEntityDAO;
import cn.com.ut.biz.business.dao.BizTmpEntityDAO;
import cn.com.ut.biz.business.entities.BizAPI;
import cn.com.ut.biz.business.entities.BizEntity;
import cn.com.ut.biz.business.entities.BizTmpEntity;
import cn.com.ut.biz.business.service.BizEntityService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 业务实体业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Service
public class BizEntityServiceImpl implements BizEntityService {

	@Autowired
	private BizEntityDAO bizEntityDAO;

	@Autowired
	private BizTmpEntityDAO bizTmpEntityDAO;

	@Autowired
	private BizAPIDAO bizAPIDAO;

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, BizEntity.entity_name, BizEntity.create_id);

		boolean isCanAdd = bizEntityDAO.checkUnique(new String[] { BizEntity.entity_name },
				new Object[] { vo.get(BizEntity.entity_name) }, null, null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("业务实体名称重复");
		}
		String entityId = bizEntityDAO.insert(vo);

		return entityId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, BizEntity.idx, BizEntity.entity_name,
				BizEntity.update_id);
		String entityId = (String) vo.get(BizEntity.idx);
		boolean isCanUpdate = bizEntityDAO.checkUnique(new String[] { BizEntity.entity_name },
				new Object[] { vo.get(BizEntity.entity_name) }, new String[] { BizEntity.idx },
				new Object[] { entityId });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("业务实体名称重复");
		}

		bizEntityDAO.update(vo);
		return entityId;
	}

	@Override
	public Map<String, Object> getDetail(String entityId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { entityId });

		return bizEntityDAO.getById(null, null,
				new String[] { BizEntity.idx, BizEntity.entity_name, BizEntity.entity_desc }, null,
				entityId);
	}

	@Override
	public void delete(String entityId) {

		// 删除业务实体前，需要判断该实体是否被其它业务实例使用，被使用的不能删除
		boolean isCanDel = bizTmpEntityDAO.checkUnique(new String[] { BizTmpEntity.entity_id },
				new Object[] { entityId }, null, null);
		if (!isCanDel) {
			ExceptionUtil.throwValidateException("业务实体已被业务实例使用，不能删除");
		}
		// 未被使用的业务实体进行删除
		bizEntityDAO.delete(entityId);
		// 删除业务实体之后，进一步删除该实体下包含的接口
		bizAPIDAO.delete(null, new String[] { BizAPI.entity_id }, new Object[] { entityId });
	}

	@Override
	public List<Map<String, Object>> findAll() {

		String[] names = { BizEntity.idx, BizEntity.entity_name, BizEntity.entity_desc };
		return bizEntityDAO.queryPage(null, null, null, false, names, null,
				new String[] { BizEntity.is_del }, null, null, BizEntity.create_time,
				new Object[] { ConstantUtil.FLAG_NO });
	}

	@Override
	public List<Map<String, Object>> findAllEntityAndAPI() {

		List<Map<String, Object>> eaList = bizEntityDAO.findAllEntityAndAPI();
		if (CollectionUtil.isEmptyCollection(eaList)) {
			ExceptionUtil.throwValidateException("业务实体与业务接口为空");
		}

		List<Map<String, Object>> entityAPIList = new ArrayList<>();
		String entityId = "";
		String entityName = "";
		List<Map<String, Object>> apiList = new ArrayList<>();
		for (int i = 0; i < eaList.size(); i++) {
			Map<String, Object> map = eaList.get(i);
			String tmpApiId = (String) map.get("api_id");
			String tmpApiName = (String) map.get("api_name");
			String tmpEntityId = (String) map.get("entity_id");
			String tmpEntityName = (String) map.get("entity_name");
			Map<String, Object> tmpMap = Maps.newHashMapWithExpectedSize(2);
			tmpMap.put("api_id", tmpApiId);
			tmpMap.put("api_name", tmpApiName);
			if (CommonUtil.isEmpty(entityName)) {
				entityId = tmpEntityId;
				entityName = tmpEntityName;
				apiList.add(tmpMap);
			} else if (entityName.equals(tmpEntityName)) {
				apiList.add(tmpMap);
			}

			// 当前实体名称tmpEntityName不等于上一个已记录的实体名称entityName时，证明以循环到下一个实体所包含的接口，添加之前的数据到map中
			if (!entityName.equals(tmpEntityName)) {
				List<Map<String, Object>> tmpList = new ArrayList<>(apiList.size());
				tmpList.addAll(apiList);

				Map<String, Object> eaMap = Maps.newLinkedHashMapWithExpectedSize(3);
				eaMap.put("entity_id", entityId);
				eaMap.put("entity_name", entityName);
				eaMap.put("api_list", tmpList);
				entityAPIList.add(eaMap);

				entityId = tmpEntityId;
				entityName = tmpEntityName;
				apiList.clear();
				apiList.add(tmpMap);
			}

			// 循环到最后一个元素，即完成最后一个实体锁包含接口的遍历，将该实体接口集合加入map
			if (i == (eaList.size() - 1)) {
				Map<String, Object> eaMap = Maps.newLinkedHashMapWithExpectedSize(3);
				eaMap.put("entity_id", entityId);
				eaMap.put("entity_name", entityName);
				eaMap.put("api_list", apiList);
				entityAPIList.add(eaMap);
			}
		}
		return entityAPIList;
	}

	@Override
	public int existEntity(Map<String, Object> vo) {

		boolean isCanAdd = false;
		if (CommonUtil.isEmpty(vo, new String[] { BizEntity.idx })) {
			isCanAdd = bizEntityDAO.checkUnique(new String[] { BizEntity.entity_name },
					new Object[] { vo.get(BizEntity.entity_name) }, null, null);
		} else {
			isCanAdd = bizEntityDAO.checkUnique(new String[] { BizEntity.entity_name },
					new Object[] { vo.get(BizEntity.entity_name) }, new String[] { BizEntity.idx },
					new Object[] { vo.get(BizEntity.idx) });
		}
		if (isCanAdd) {
			return 0;
		} else {
			return 1;
		}
	}
}
