package cn.com.ut.biz.app.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.app.dao.AppInfoDAO;
import cn.com.ut.biz.app.dao.AppTmpDAO;
import cn.com.ut.biz.app.entities.AppInfo;
import cn.com.ut.biz.app.entities.AppTmp;
import cn.com.ut.biz.app.service.AppInfoService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.util.APPUtil;

/**
 * 应用信息业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Service
public class AppInfoServiceImpl implements AppInfoService {

	@Autowired
	private AppInfoDAO appInfoDAO;

	@Autowired
	private AppTmpDAO appTmpDAO;

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, AppInfo.app_name);

		boolean isCanAdd = appInfoDAO.checkUnique(new String[] { AppInfo.app_name },
				new Object[] { vo.get(AppInfo.app_name) }, null, null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("应用名称重复");
		}

		// APP_ID使用线程安全的时间戳来生成
		vo.put(AppInfo.app_id, APPUtil.nextAppId());

		String entityId = appInfoDAO.insert(vo);

		return entityId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, AppInfo.idx, AppInfo.app_name);
		String id = (String) vo.get(AppInfo.idx);
		boolean isCanUpdate = appInfoDAO.checkUnique(new String[] { AppInfo.app_name },
				new Object[] { vo.get(AppInfo.app_name) }, new String[] { AppInfo.idx },
				new Object[] { id });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("应用名称重复");
		}

		appInfoDAO.update(vo);
		return id;
	}

	@Override
	public Map<String, Object> getAccessKey(String id) {

		ValidatorUtil.requiredFieldMiss(new Object[] { id });

		return appInfoDAO.getById(null, null, new String[] { AppInfo.idx, AppInfo.app_id,
				AppInfo.app_name, AppInfo.app_key, AppInfo.status, AppInfo.create_time }, null, id);
	}

	@Override
	public Map<String, Object> getDetail(String id) {

		ValidatorUtil.requiredFieldMiss(new Object[] { id });

		return appInfoDAO.getById(null, null, new String[] { AppInfo.idx, AppInfo.app_id,
				AppInfo.app_name, AppInfo.app_key, AppInfo.status }, null, id);
	}

	@Override
	public void delete(String id, String appId) {

		// if (status.equals("")) {
		// ExceptionUtil.throwValidateException("应用审核中，不能删除");
		// } else if (status.equals("")) {
		// ExceptionUtil.throwValidateException("应用已上线，不能删除");
		// }

		appInfoDAO.delete(id);

		appTmpDAO.delete(null, new String[] { AppTmp.app_id }, new Object[] { appId });

		// appInfoDAO.deleteUpdateById(null, new String[] { AppInfo.update_time
		// },
		// new Object[] { ConstantUtil.FLAG_YES, DateTimeUtil.currentDateTime()
		// }, id);
	}

	@Override
	public List<Map<String, Object>> findByUser(User user) {

		// String[] names = { AppInfo.idx, AppInfo.app_id, AppInfo.app_name,
		// AppInfo.status,
		// AppInfo.publish_status };
		// return appInfoDAO.queryPage(null, null, null, false, names, null,
		// new String[] { AppInfo.create_id, AppInfo.is_del }, null, null,
		// AppInfo.create_time,
		// new Object[] { user.getUserId(), ConstantUtil.FLAG_NO });

		StringBuffer table = new StringBuffer();
		String[] selectColumnArray = new String[] { "i.id", "i.app_id", "i.app_name", "i.status",
				"i.publish_status", "t.tmp_id" };
		table.append("t_app_info i ").append("LEFT JOIN t_app_tmp t ON i.app_id = t.app_id");

		List<Map<String, Object>> appTmpList = appInfoDAO.queryPage(null, null, table.toString(),
				false, selectColumnArray, null, new String[] { "i.create_id", "i.is_del" }, null,
				null, "i.create_time", new Object[] { user.getUserId(), ConstantUtil.FLAG_NO });

		List<Map<String, Object>> appList = new ArrayList<>(appTmpList.size());
		String appId = "";
		int tmpNum = 0;
		Map<String, Object> appMap = null;
		for (int i = 0; i < appTmpList.size(); i++) {
			Map<String, Object> map = appTmpList.get(i);
			String tempAppId = (String) map.get(AppInfo.app_id);
			String tmpId = (String) map.get(AppTmp.tmp_id);
			// 当appId为空，即循环第一个元素，设置用于存放应用信息的变量appId，appMap
			if (CommonUtil.isEmpty(appId)) {
				appId = tempAppId;
				appMap = map;
				// 如果tmpId不为空，则表明该应用下存在实例模板，设置模板数加1
				if (CommonUtil.isNotEmpty(tmpId)) {
					tmpNum++;
				}
			} else if (tempAppId.equals(appId)) {
				// 当前tempAppId与上一个集合元素的appId相等，则表明二者为同一应用信息下的不同实例模板，模板数加1，删除当前元素，避免重复遍历
				tmpNum++;
				appTmpList.remove(map);
				i--;
			} else if (!tempAppId.equals(appId)) {
				// 当前tempAppId与上一个集合元素的appId不相等，则表明当前元素为新的应用信息，添加上一个元素进返回集合appList
				appMap.remove("tmp_id");
				appMap.put("tmp_num", tmpNum);
				appList.add(appMap);

				appId = tempAppId;
				appMap = map;
				if (CommonUtil.isNotEmpty(tmpId)) {
					tmpNum = 1;
				} else {
					tmpNum = 0;
				}
			}

			// 循环到最后一个元素，则为最后一条应用信息，添加到返回集合appList
			if (i == (appTmpList.size() - 1)) {
				map.remove("tmp_id");
				map.put("tmp_num", tmpNum);
				appList.add(map);
			}
		}

		return appList;
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		return appInfoDAO.findAllPage(page);
	}

	@Override
	public String generateAccessKey(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, AppInfo.idx, AppInfo.app_id);
		// APP_KEY暂时先用UUID替代
		String appKey = APPUtil.nextAppKey();
		vo.put(AppInfo.app_key, appKey);
		appInfoDAO.generateAccessKey(vo);
		return appKey;
	}

	@Override
	public int examineAppInfo(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, AppInfo.idx, AppInfo.audit_operator,
				AppInfo.audit_result);
		return appInfoDAO.examineAppInfo(vo);
	}

	@Override
	public int submitExamine(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, AppInfo.idx);
		return appInfoDAO.submitExamine(vo);
	}

	@Override
	public int confirmUpdate(String id) {

		return appInfoDAO.confirmUpdate(id);
	}

	@Override
	public int onlineApp(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, AppInfo.idx);
		return appInfoDAO.onlineApp(vo);
	}

	@Override
	public int downlineApp(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, AppInfo.idx);
		return appInfoDAO.downlineApp(vo);
	}

	@Override
	public int existApp(Map<String, Object> vo) {

		boolean isCanAdd = false;
		if (CommonUtil.isEmpty(vo, new String[] { AppInfo.idx })) {
			isCanAdd = appInfoDAO.checkUnique(new String[] { AppInfo.app_name },
					new Object[] { vo.get(AppInfo.app_name) }, null, null);
		} else {
			isCanAdd = appInfoDAO.checkUnique(new String[] { AppInfo.app_name },
					new Object[] { vo.get(AppInfo.app_name) }, new String[] { AppInfo.idx },
					new Object[] { vo.get(AppInfo.idx) });
		}
		if (isCanAdd) {
			return 0;
		} else {
			return 1;
		}
	}
}
