package cn.com.ut.biz.permission.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 菜单实体
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public class Menu extends BaseEntity {

	private static final long serialVersionUID = -1680928473402562404L;
	/**
	 * 菜单文本
	 */
	public static final String menu_text = "menu_text";
	/**
	 * 菜单对应链接
	 */
	public static final String menu_url = "menu_url";
	/**
	 * 菜单类型
	 */
	public static final String menu_type = "menu_type";
	/**
	 * 菜单
	 */
	public static final String menu_comment = "menu_comment";
	/**
	 * 菜单对应图片
	 */
	public static final String menu_img = "menu_img";
	/**
	 * 菜单对应父类id
	 */
	public static final String parent_id = "parent_id";
	/**
	 * 排序字段
	 */
	public static final String sort_num = "sort_num";

	/**
	 * 模块ID模块初始化的时候拥有
	 */
	public static final String module_id = "module_id";
}