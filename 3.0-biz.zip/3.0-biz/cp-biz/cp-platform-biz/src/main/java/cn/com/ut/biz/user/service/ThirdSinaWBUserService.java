package cn.com.ut.biz.user.service;

import java.util.Map;

import cn.com.ut.core.common.system.beans.User;

/**
 * 第三方新浪微博用户
 * 
 * @author ouyuexing
 *
 */
public interface ThirdSinaWBUserService {

	/**
	 * 获取新浪微博登录的URL
	 * 
	 * @param sessionid
	 * @return
	 */
	String getSinaWBLoginUrl(String sessionid, String successurl);

	/**
	 * 新浪微博授权回调
	 * 
	 * @param code
	 * @param user
	 * @return
	 */
	String sinaWBUserLogin(String code, User user);

	/**
	 * 获取新浪微博授权用户信息
	 * 
	 * @param openId
	 * @param accessToken
	 * @return
	 */
	Map<String, Object> getSinaWBUserInfo(String openId, String accessToken);

	/**
	 * 获取第三方APP登录系统信息
	 * 
	 * @return
	 */
	Map<String, Object> getSystemAppInfo();

}
