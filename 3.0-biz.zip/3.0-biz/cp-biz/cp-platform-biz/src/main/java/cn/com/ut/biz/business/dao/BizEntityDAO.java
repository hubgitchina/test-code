package cn.com.ut.biz.business.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.business.entities.BizEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 业务实体DAO
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface BizEntityDAO extends JdbcOperation<BizEntity> {
	/**
	 * 查询所有业务实体及关联接口
	 * 
	 * @return
	 */
	List<Map<String, Object>> findAllEntityAndAPI();
}