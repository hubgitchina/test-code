package cn.com.ut.biz.user.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 管理员信息实体
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public class UserManager extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4009622383338111763L;
	/**
	 * 
	 */
	public static final String user_id = "user_id";
	/**
	 * 真实姓名
	 */
	public static final String real_name = "real_name";
	/**
	 * 工号
	 */
	public static final String work_number = "work_number";
	/**
	 * 对自己工作的职责描述
	 */
	public static final String work_desc = "work_desc";

	/**
	 * 联系电话
	 */
	public static final String mobile = "mobile";

	/**
	 * 电子邮箱
	 */
	public static final String email = "email";
}