package cn.com.ut.biz.system.dao.impl;

import static cn.com.ut.biz.system.entities.DictData.dict_code;
import static cn.com.ut.biz.system.entities.DictData.dict_des;
import static cn.com.ut.biz.system.entities.DictData.dict_text;
import static cn.com.ut.biz.system.entities.DictData.dict_type;
import static cn.com.ut.biz.system.entities.DictData.group_code;
import static cn.com.ut.biz.system.entities.DictData.sort_num;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_use;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.system.dao.DictDataDAO;
import cn.com.ut.biz.system.entities.DictData;
import cn.com.ut.biz.system.entities.DictType;
import cn.com.ut.core.cache.CachedParameter;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ArrayUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

@Repository
public class DictDataDAOImpl extends JdbcOperationsImpl<DictData> implements DictDataDAO {

	private static final String[] COLUMNS = { dict_code, dict_text, dict_type, group_code, is_use,
			sort_num, dict_des };

	public static final String DICTTYPE_KEY = "DictType";
	private String T_DICTDATA;
	private String T_DICTTYPE;
	{
		T_DICTDATA = getTable(DictData.class);
		T_DICTTYPE = getTable(DictType.class);
	}

	public String add(Map<String, Object> vo) {

		String dictType = (String) vo.get(dict_type);
		CachedParameter cachedParameter = new CachedParameter(true,
				new String[] { DICTTYPE_KEY + "/" + dictType });

		Timestamp time = DateTimeUtil.currentDateTime();
		String id = CommonUtil.getUUID();
		add(null, COLUMNS, NAMES,
				new Object[] { vo.get(dict_code), vo.get(dict_text), vo.get(dict_type),
						vo.get(group_code), vo.get(is_use), vo.get(sort_num), vo.get(dict_des), id,
						time, time, vo.get(create_id), vo.get(create_id) },
				cachedParameter);
		return id;
	}

	public int update(Map<String, Object> vo) {

		String id = (String) vo.get(BaseEntity.idx);
		Map<String, Object> oldVO = get(id);
		String dictType = (String) oldVO.get(dict_type);
		CachedParameter cachedParameter = new CachedParameter(true,
				new String[] { DICTTYPE_KEY + "/" + dictType });

		Timestamp time = DateTimeUtil.currentDateTime();
		return updateById(null,
				new String[] { dict_code, dict_text, group_code, is_use, sort_num, dict_des },
				NAMES_UT_UID, null,
				new Object[] { vo.get(dict_code), vo.get(dict_text), vo.get(group_code),
						vo.get(is_use), vo.get(sort_num), vo.get(dict_des), time,
						vo.get(create_id) },
				(String) vo.get(BaseEntity.idx), cachedParameter);
	}

	public Map<String, Object> get(String id) {

		return getById(null, null, COLUMNS, NAMES, id);
	}

	public int delete(String id) {

		Map<String, Object> oldVO = get(id);
		String dictType = (String) oldVO.get(dict_type);
		CachedParameter cachedParameter = new CachedParameter(true,
				new String[] { DICTTYPE_KEY + "/" + dictType });

		return deleteById(null, id, cachedParameter);
	}

	@Override
	public Map<String, Object> getDetail(String dictDataId) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_DICTDATA).append(" d INNER JOIN ").append(T_DICTTYPE)
				.append(" t ON t.dicttype_code = d.dict_type ")
				.append(" WHERE d.is_del = 'N' AND t.is_del = 'N' and d.id = ? ");
		Object[] args = new Object[] { dictDataId };
		ParameterBuilder paramBuilder = ParameterBuilder.builder();
		paramBuilder.appendColumns("d", COLUMNS);
		paramBuilder.appendColumns("d", idx);
		paramBuilder.appendColumns("t.id AS dict_type_id");
		List<Map<String, Object>> list = queryPage(null, null, table.toSQL(), true,
				paramBuilder.toColumns(), null, null, null, null, null, args);
		if (CollectionUtil.isEmptyCollection(list)) {
			return null;
		}
		return list.get(0);
	}

	@Override
	public List<Map<String, Object>> findDictData(List<Object> dictTypeCodes, PageBean pageBean) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_DICTDATA).append(" d ")
				.append(" WHERE d.is_del = 'N' AND d.dict_type {IN} AND d.is_use='Y'")
				.append(" AND EXISTS ( SELECT 1 FROM ").append(T_DICTTYPE).append(" t ")
				.append(" WHERE t.dicttype_code = d.dict_type AND t.is_del = 'N' ").append(" )");
		String tableSql = replaceInCase(table.toSQL(), new int[] { dictTypeCodes.size() });
		List<Object> args = new ArrayList<>();
		args.addAll(dictTypeCodes);
		ParameterBuilder paramBuilder = ParameterBuilder.builder();
		paramBuilder.appendColumns("d", COLUMNS);
		paramBuilder.appendColumns("d", idx);
		return queryPage(pageBean, null, tableSql, true, paramBuilder.toColumns(), null, null, null,
				null, "d.sort_num", args.toArray());
	}

	@Override
	public List<Map<String, Object>> findDictData(PageBean pageBean) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_DICTDATA).append(" d ").append(" WHERE d.is_del = 'N' AND d.is_use='Y'")

				.append(" AND EXISTS ( SELECT 1 FROM ").append(T_DICTTYPE).append(" t ")
				.append(" WHERE t.dicttype_code = d.dict_type AND t.is_del = 'N' AND t.is_use='Y'")
				.append(" )");
		ParameterBuilder paramBuilder = ParameterBuilder.builder();
		paramBuilder.appendColumns("d", COLUMNS);
		paramBuilder.appendColumns("d", idx);
		return queryPage(pageBean, null, table.toSQL(), true, paramBuilder.toColumns(), null, null,
				null, null, "d.sort_num", null);

	}

	public List<Map<String, Object>> findDictDataByType(String dictTypeId, PageBean pageBean) {

		SQLHelper table = SQLHelper.builder();
		table.append(T_DICTDATA).append(" d ").append(" WHERE d.is_del = 'N'")
				.append(" AND EXISTS ( SELECT 1 FROM ").append(T_DICTTYPE).append(" t ")
				.append(" WHERE t.dicttype_code = d.dict_type AND t.is_del = 'N' AND t.id = ?")
				.append(" )");
		Object[] args = new Object[] { dictTypeId, };
		ParameterBuilder paramBuilder = ParameterBuilder.builder();
		paramBuilder.appendColumns("d", COLUMNS);
		paramBuilder.appendColumns("d", idx);
		return queryPage(pageBean, null, table.toSQL(), true, paramBuilder.toColumns(), null, null,
				null, null, "d.sort_num", args);
	}

	@Override
	public boolean isDictDataCodeRepeat(String dictTypeCode, String dictDataCode,
			String[] pkFieldNames, Object[] pkFieldValues) {

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT 1 FROM ").append(T_DICTDATA).append(" biz ")
				.append(" WHERE biz.dict_type = ? AND biz.dict_code = ? ");
		List<Object> args = new ArrayList<>();
		args.add(dictTypeCode);
		args.add(dictDataCode);
		if (pkFieldNames != null && pkFieldNames.length > 0 && pkFieldValues != null) {
			sql.append(" AND (");
			sql.append(ArrayUtil.joinArrayElement(pkFieldNames, " OR ", "biz.", " <> ? "));
			sql.append(")");
			CollectionUtil.addArrayToCollection(pkFieldValues, args);
		}
		List<Map<String, Object>> list = query(getJdbcTemplate(), sql.toString(), null,
				args.toArray());
		return !CollectionUtil.isEmptyCollection(list);
	}

	@Override
	public void delMarkByIds(Collection<String> delDictDataIds) {

		SQLHelper sqlTemp = SQLHelper.builder();
		sqlTemp.append("update ").append(getTable()).append(" set is_del = 'Y' where id {IN} ");
		String sql = replaceInCase(sqlTemp.toSQL(), new int[] { delDictDataIds.size() });
		update(getJdbcTemplate(), sql, delDictDataIds.toArray());
	}
}
