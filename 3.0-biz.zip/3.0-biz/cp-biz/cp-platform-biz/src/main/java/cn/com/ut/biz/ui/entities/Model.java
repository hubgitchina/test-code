
//------------------------------entity start--------------------------------//
package cn.com.ut.biz.ui.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class Model extends BaseEntity {


	/**
     * 前端技术（vue、react native）
     */
    public static final String front_tech = "front_tech";
	/**
     * 模型名称
     */
    public static final String model_name = "model_name";
	/**
     * 模型类型(APP,PC)
     */
    public static final String model_type = "model_type";
	/**
     * 是否使用
     */
    public static final String is_use = "is_use";
	/**
     * 应用ID
     */
    public static final String app_id = "app_id";
}
//------------------------------entity end--------------------------------//
