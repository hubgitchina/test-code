package cn.com.ut.biz.user.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 用户教育信息
 */
public class UserPeducation extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5230970554180411887L;
	/**
	 * 普通用户表id
	 */
	public static final String user_id = "user_id";
	/**
	 * 学校类型
	 */
	public static final String education_type = "education_type";
	/**
	 * 学校名
	 */
	public static final String school_name = "school_name";
	/**
	 * 入学年份
	 */
	public static final String enrollment_year = "enrollment_year";
}