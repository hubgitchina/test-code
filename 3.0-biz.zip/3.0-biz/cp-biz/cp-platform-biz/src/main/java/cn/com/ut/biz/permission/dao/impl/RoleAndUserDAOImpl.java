package cn.com.ut.biz.permission.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.permission.dao.RoleAndUserDAO;
import cn.com.ut.biz.permission.entities.Role;
import cn.com.ut.biz.permission.entities.RoleAndMenu;
import cn.com.ut.biz.permission.entities.RoleAndUser;
import cn.com.ut.biz.permission.entities.RoleAndUserGroup;
import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ArrayUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 角色与用户关系管理数据层实现类
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
@Repository
public class RoleAndUserDAOImpl extends JdbcOperationsImpl<RoleAndUser> implements RoleAndUserDAO {

	private String T_ROLE;
	private String T_ROLE_MENU;
	private String T_ROLE_USER;
	private String T_ROLE_USERGROUP;
	private String T_USERGROUP;
	private String T_USERGROUP_USER;
	{
		T_ROLE = getTable(Role.class);
		T_ROLE_MENU = getTable(RoleAndMenu.class);
		T_ROLE_USER = getTable(RoleAndUser.class);
		T_ROLE_USERGROUP = getTable(RoleAndUserGroup.class);
		T_USERGROUP = getTable(UserGroup.class);
		T_USERGROUP_USER = getTable(UserGroupAndUser.class);
	}
	private static final String[] COLUMNS = { RoleAndUser.role_id, RoleAndUser.user_id };

	@Override
	public int deleteRoleRefUsers(String roleId, List<String> userIds) {

		int size = userIds.size();
		userIds.add(0, roleId);

		return delete(null, null, "role_id = ? AND user_id {IN}", new int[] { size },
				userIds.toArray(), null);
	}

	@Override
	public int deleteUserRefRoles(String userId, List<String> roles) {

		int size = roles.size();
		roles.add(0, userId);

		return delete(null, null, "user_id = ? AND role_id {IN}", new int[] { size },
				roles.toArray(), null);
	}

	@Override
	public int deleteUserRefRolesAll(String userId, String[] roleClasses) {

		SQLHelper sql = SQLHelper.builder();
		sql.append("delete from").append(T_ROLE_USER)
				.append("aa where aa.user_id = ? and exists (");
		sql.append("select 1 from").append(T_ROLE).append("where role_class in (")
				.append(ArrayUtil.joinSameElement("?", roleClasses.length, ","))
				.append(") and id = aa.role_id)");
		List<Object> array = new ArrayList<>();
		array.add(userId);
		for (String roleClass : roleClasses) {
			array.add(roleClass);
		}
		return update(getJdbcTemplate(), sql.toSQL(), array.toArray());
	}

	@Override
	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, COLUMNS, NAMES_ID_CT_CID,
				ParameterBuilder.builder().append(vo, COLUMNS)
						.append(id, DateTimeUtil.currentDateTime(), vo.get(RoleAndUser.create_id))
						.toArray());
		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		return updateById(null, COLUMNS, NAMES_UT_UID, null,
				ParameterBuilder.builder().append(vo, COLUMNS)
						.append(DateTimeUtil.currentDateTime(), vo.get(RoleAndUser.update_id))
						.toArray(),
				(String) vo.get(RoleAndUser.idx), null);
	}

	@Override
	public List<String> listRolesByUserId(String userId) {

		String sql = "SELECT role_id from " + T_ROLE_USER + " where user_id = ?";
		return queryForList(getJdbcTemplate(), sql, String.class, userId);
	}

	/**
	 * 查询用户拥有的全部角色信息
	 */
	@Override
	public List<Map<String, Object>> listUserRefRoles(PageBean pageBean, String userId) {

		StringBuilder listUserRefRolesTable = new StringBuilder();
		listUserRefRolesTable.append(T_ROLE).append(" WHERE ID IN ( ")
				.append(" SELECT role_id FROM " + T_ROLE_USER + " WHERE user_id=? ").append(" ) ");
		return queryPage(pageBean, null, listUserRefRolesTable.toString(), true, null, null, null,
				null, null, null, new Object[] { userId });
	}

	@Override
	public int deleteByRoleAndUser(String roleId, String userId) {

		return delete(null, new String[] { RoleAndUser.role_id, RoleAndUser.user_id },
				new Object[] { roleId, userId });
	}
}
