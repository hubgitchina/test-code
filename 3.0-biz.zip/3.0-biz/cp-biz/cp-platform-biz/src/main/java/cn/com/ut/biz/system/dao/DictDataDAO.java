package cn.com.ut.biz.system.dao;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import cn.com.ut.biz.system.entities.DictData;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 字典项
 * 
 * @author lanbin
 */
public interface DictDataDAO extends JdbcOperation<DictData> {

	/**
	 * 检查平台字典类型下是否存在重复的字典项编码
	 * 
	 * @param platformId
	 * @param dictTypeCode
	 * @param dictDataCode
	 * @param pkFieldNames
	 * @param pkFieldValues
	 * @return 若重复返回true
	 */
	boolean isDictDataCodeRepeat(String dictTypeCode, String dictDataCode, String[] pkFieldNames,
			Object[] pkFieldValues);

	/**
	 * 批量删除字典项
	 * 
	 * @param delDictDataIds
	 */
	void delMarkByIds(Collection<String> delDictDataIds);

	/**
	 * 获取字典项详情
	 * 
	 * @param platformId
	 * @param dictDataId
	 * @return
	 */
	Map<String, Object> getDetail(String dictDataId);

	/**
	 * 查询平台的指定字典类型下所有(包括启用和没有启用的)字典项 （因为id是唯一的所有不需要平台筛选）
	 * 
	 *
	 * @param platformId
	 * @param dictTypeId
	 *            字典类型ID
	 * @param bean
	 * @return
	 */
	List<Map<String, Object>> findDictDataByType(String dictTypeId, PageBean bean);

	/**
	 * 查询平台的指定字典项下的所有(已启用的)字典项
	 * 
	 * @param platformId
	 * @param dictTypeCodes
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> findDictData(List<Object> dictTypeCodes, PageBean pageBean);

	/**
	 * 查询平台的所有字典项下的所有(已启用的)字典项
	 * 
	 * @param platformId
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> findDictData(PageBean pageBean);

}
