package cn.com.ut.biz.business.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.business.entities.BizTemplate;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 业务实例DAO
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface BizTemplateDAO extends JdbcOperation<BizTemplate> {
	/**
	 * 根据用户信息查询所有业务实例及实例下所有实体
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> findTmpEntityByUser(Map<String, Object> vo);
}