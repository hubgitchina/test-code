package cn.com.ut.biz.business.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.business.dao.BizEntityDAO;
import cn.com.ut.biz.business.entities.BizEntity;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 业务实体DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Repository
public class BizEntityDAOImpl extends JdbcOperationsImpl<BizEntity> implements BizEntityDAO {

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = { BizEntity.entity_name, BizEntity.entity_desc };
		add(null, names, NAMES,
				ParameterBuilder
						.builder().append(vo, names).append(id, time, time,
								vo.get(BizEntity.create_id), vo.get(BizEntity.create_id))
						.toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, BizEntity.entity_name, BizEntity.entity_desc);
		String[] names = pb.toColumns();
		return updateById(null, names, NAMES_UT_UID, ParameterBuilder.builder().append(vo, names)
				.append(DateTimeUtil.currentDateTime(), vo.get(BizEntity.update_id)).toArray(),
				(String) vo.get(BizEntity.idx));
	}

	@Override
	public List<Map<String, Object>> findAllEntityAndAPI() {

		StringBuffer table = new StringBuffer();
		String[] selectColumnArray = new String[] { "e.id as entity_id", "e.entity_name",
				"a.id as api_id", "a.api_name" };
		table.append("t_biz_entity e ").append("left join t_biz_api a on e.id = a.entity_id");
		return queryPage(null, null, table.toString(), false, selectColumnArray, null,
				new String[] { "e.is_del", "a.is_del" }, null, null, "e.create_time",
				new Object[] { ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO });
	}
}
