package cn.com.ut.biz.business.service;

import java.util.List;
import java.util.Map;

/**
 * 业务API业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface BizAPIService {

	/**
	 * 创建业务API
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新业务API
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询业务实体下所有业务API
	 * 
	 * @return
	 */
	List<Map<String, Object>> findAllByEId(Map<String, Object> vo);

	/**
	 * 查询业务API详情
	 */
	Map<String, Object> getDetail(String apiId);

	/**
	 * 删除业务API
	 * 
	 * @param apiId
	 */
	void delete(String apiId);
}
