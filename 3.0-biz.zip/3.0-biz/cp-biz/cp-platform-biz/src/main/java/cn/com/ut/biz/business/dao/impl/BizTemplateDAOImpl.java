package cn.com.ut.biz.business.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.business.dao.BizTemplateDAO;
import cn.com.ut.biz.business.entities.BizTemplate;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 业务实例DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Repository
public class BizTemplateDAOImpl extends JdbcOperationsImpl<BizTemplate> implements BizTemplateDAO {

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = { BizTemplate.temp_name, BizTemplate.tmp_desc, BizTemplate.tmp_type,
				BizTemplate.own_id };
		add(null, names, NAMES,
				ParameterBuilder
						.builder().append(vo, names).append(id, time, time,
								vo.get(BizTemplate.create_id), vo.get(BizTemplate.create_id))
						.toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, BizTemplate.temp_name, BizTemplate.tmp_desc);
		String[] names = pb.toColumns();
		return updateById(null, names, NAMES_UT_UID, ParameterBuilder.builder().append(vo, names)
				.append(DateTimeUtil.currentDateTime(), vo.get(BizTemplate.update_id)).toArray(),
				(String) vo.get(BizTemplate.idx));
	}

	@Override
	public List<Map<String, Object>> findTmpEntityByUser(Map<String, Object> vo) {

		// String sql = "SELECT t.id as tmp_id, t.temp_name, e.id as entity_id,
		// e.entity_name FROM t_biz_template t LEFT JOIN t_biz_tmp_entity te on
		// t.id = te.tmp_id LEFT JOIN t_biz_entity e on te.entity_id = e.id
		// WHERE (t.create_id = ? OR t.tmp_type = ?) AND t.is_del = ? and
		// te.is_del = ? and e.is_del = ? ORDER BY t.create_time";
		String sql = "SELECT t.id as tmp_id, t.temp_name, e.id as entity_id, e.entity_name FROM t_biz_template t LEFT JOIN t_biz_tmp_entity te on t.id = te.tmp_id LEFT JOIN t_biz_entity e on te.entity_id = e.id WHERE t.tmp_type = ? AND t.is_del = ? and te.is_del = ? and e.is_del = ? ORDER BY t.create_time";
		return queryForList(getJdbcTemplate(), sql, vo.get(BizTemplate.tmp_type),
				ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO);
	}
}
