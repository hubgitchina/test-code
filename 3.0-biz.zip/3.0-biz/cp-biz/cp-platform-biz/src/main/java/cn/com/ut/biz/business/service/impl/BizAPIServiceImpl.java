package cn.com.ut.biz.business.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.business.dao.BizAPIDAO;
import cn.com.ut.biz.business.entities.BizAPI;
import cn.com.ut.biz.business.service.BizAPIService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 业务API业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Service
public class BizAPIServiceImpl implements BizAPIService {

	@Autowired
	private BizAPIDAO bizAPIDAO;

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, BizAPI.entity_id, BizAPI.api_name);

		boolean isCanAdd = bizAPIDAO.checkUnique(new String[] { BizAPI.entity_id, BizAPI.api_name },
				new Object[] { vo.get(BizAPI.entity_id), vo.get(BizAPI.api_name) }, null, null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("业务实体下接口名称重复");
		}
		String apiId = bizAPIDAO.insert(vo);

		return apiId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, BizAPI.idx, BizAPI.entity_id, BizAPI.api_name,
				BizAPI.update_id);
		String apiId = (String) vo.get(BizAPI.idx);
		boolean isCanUpdate = bizAPIDAO.checkUnique(
				new String[] { BizAPI.entity_id, BizAPI.api_name },
				new Object[] { vo.get(BizAPI.entity_id), vo.get(BizAPI.api_name) },
				new String[] { BizAPI.idx }, new Object[] { apiId });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("业务实体下接口名称重复");
		}

		bizAPIDAO.update(vo);
		return apiId;
	}

	@Override
	public List<Map<String, Object>> findAllByEId(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, BizAPI.entity_id);
		String[] names = { BizAPI.idx, BizAPI.api_name, BizAPI.api_desc };
		return bizAPIDAO.queryPage(null, null, null, false, names, null,
				new String[] { BizAPI.entity_id, BizAPI.is_del }, null, null, BizAPI.create_time,
				new Object[] { vo.get(BizAPI.entity_id), ConstantUtil.FLAG_NO });
	}

	@Override
	public Map<String, Object> getDetail(String apiId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { apiId });

		return bizAPIDAO.getById(null, null, new String[] { BizAPI.idx, BizAPI.api_name,
				BizAPI.api_desc, BizAPI.api_ver, BizAPI.api_doc, BizAPI.api_url }, null, apiId);
	}

	@Override
	public void delete(String apiId) {

		boolean isUse = bizAPIDAO.isUseTemplate(apiId);
		if (isUse) {
			ExceptionUtil.throwValidateException("API所属业务实体已被业务实例使用，不能删除");
		}
		bizAPIDAO.delete(apiId);
	}
}
