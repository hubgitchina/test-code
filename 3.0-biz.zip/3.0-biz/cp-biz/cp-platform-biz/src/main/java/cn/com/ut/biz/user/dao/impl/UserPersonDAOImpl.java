package cn.com.ut.biz.user.dao.impl;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.user.dao.UserPersonDAO;
import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 用户管理员
 * 
 * @author ouyuexing
 *
 */
@Repository
public class UserPersonDAOImpl extends JdbcOperationsImpl<UserPerson> implements UserPersonDAO {

	String[] COLUMNS = { UserPerson.user_id, UserPerson.industry_nature, UserPerson.is_marital,
			UserPerson.user_pic, UserPerson.user_birthday, UserPerson.user_sex,
			UserPerson.education_level, UserPerson.monthly_income, UserPerson.province,
			UserPerson.city, UserPerson.area, UserPerson.contact_addr, UserPerson.user_hobbies,
			UserPerson.linkman_name, UserPerson.fixed_phone };

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

}
