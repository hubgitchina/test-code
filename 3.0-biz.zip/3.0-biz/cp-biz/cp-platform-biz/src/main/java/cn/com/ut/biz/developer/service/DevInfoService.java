package cn.com.ut.biz.developer.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;

/**
 * 开发者信息业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface DevInfoService {

	/**
	 * 创建开发者信息
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新开发者信息
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询开发者信息详情
	 */
	Map<String, Object> getDetail(String id);

	/**
	 * 删除开发者信息
	 * 
	 * @param id
	 * @param appId
	 */
	void delete(String id);

	/**
	 * 查询所有的开发者信息（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);

	/**
	 * 提交审核
	 * 
	 * @param vo
	 * @return
	 */
	int submitExamine(Map<String, Object> vo);

	/**
	 * 审核开发者提交的企业认证信息
	 * 
	 * @param vo
	 * @return
	 */
	int examineDevInfo(Map<String, Object> vo);

	/**
	 * 根据用户查询当前用户提交的企业审核信息
	 * 
	 * @param user
	 * @return
	 */
	Map<String, Object> getDevInfoByUser(User user);

	/**
	 * 确认修改审核资料
	 * 
	 * @param id
	 * @return
	 */
	int confirmUpdate(String id);
}
