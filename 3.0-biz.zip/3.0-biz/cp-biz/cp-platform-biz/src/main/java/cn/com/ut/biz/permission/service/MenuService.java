package cn.com.ut.biz.permission.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;

/**
 * 菜单管理业务层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface MenuService {
	/**
	 * 树型展示全部系统菜单(标记与指定角色已建立关联的系统菜单)
	 * 
	 *
	 * @param platformId
	 * @param roleId
	 * @return
	 */
	List<Map<String, Object>> listMenuTree(String roleId);

	/**
	 * 创建系统菜单
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新指定的系统菜单
	 * 
	 * @param vo
	 *
	 */
	void update(Map<String, Object> vo);

	/**
	 * 获取指定的系统菜单的详细信息
	 *
	 * @param platformId
	 * @param id
	 * @return
	 */
	Map<String, Object> getDetail(String id);

	/**
	 * 删除指定的系统菜单 （有子菜单的或系统用户创建的菜单不允许被删除，级联删除与之关联的用户和角色信息）
	 *
	 * @param platformId
	 * @param id
	 */
	void delete(String id);

	/**
	 * 设置同一级菜单的默认排序
	 */
	void updateMenuSortDefault();

	/**
	 * 菜单管理查询所有菜单（分页、不分级）
	 * 
	 * @param dataPlatformId
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> queryAllBackgroundMenu(PageBean page);

	/**
	 * 菜单管理查询所有菜单（分页、分级）
	 * 
	 * @param parentId
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> queryBackgroundMenu(String parentId, PageBean page);

	/**
	 * 列出用户所有菜单
	 * 
	 * @param user
	 * @return
	 */
	List<Map<String, Object>> listUserMenus(User user);

}
