
//-----------------------------Service start---------------------------------//
package cn.com.ut.biz.ui.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * Service
 * 
 * @author
 * @since
 */
public interface ModelService {

	String add(Map<String, Object> component);

	void delete(String id);

	List<Map<String, Object>> query(PageBean pageBean);

	/**
	 * 根据应用ID查询所有模型列表（不分页）
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> query(Map<String, Object> vo);

	void update(Map<String, Object> vo);

	Map<String, Object> getDetail(String id);

}
// -----------------------------Service end---------------------------------//