package cn.com.ut.biz.ui.service.impl;

import cn.com.ut.biz.ui.dao.ComponentDAO;
import cn.com.ut.biz.ui.entities.Component;
import cn.com.ut.biz.ui.service.ComponentService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

/**
 * Created by zhouquanguo on 2018/4/25.
 */
@Service
public class ComponentServiceImpl implements ComponentService {

    @Autowired
    private ComponentDAO componentDAO;


    public String add(Map<String, Object> component) {
        ValidatorUtil.validateMapContainsKey(component, Component.comp_name);
        boolean notExist = componentDAO.checkUnique(new String[]{Component.comp_name},
                new Object[]{component.get(Component.comp_name)}, null,
                null);
        if (!notExist) {
            ExceptionUtil.throwValidateException("组件名称重复");
        }
        return componentDAO.add(component);
    }

    @Override
    public void delete(String id) {
        componentDAO.delete(id);
    }

    @Override
    public List<Map<String, Object>> query(PageBean pageBean) {
        return componentDAO.query(pageBean);
    }

    @Override
    public void update(Map<String, Object> vo) {
        ValidatorUtil.validateMapContainsKey(vo, Component.update_id);
        ValidatorUtil.validateMapContainsKey(vo, idx);
        boolean notExist = componentDAO.checkUnique(new String[]{Component.comp_name},
                new Object[]{vo.get(Component.comp_name)}, new String[]{Component.idx},
                new Object[]{vo.get(Component.idx)});
        if (!notExist) {
            ExceptionUtil.throwValidateException("组件名称重复");
        }
        componentDAO.update(vo);
    }

    @Override
    public Map<String, Object> getDetail(String componentId) {
        return componentDAO.get(componentId);
    }


}
