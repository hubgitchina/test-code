package cn.com.ut.common.constant.platform;

/**
 * 字典数据常量
 * 
 * @author ouyuexing
 * @since 2015-6-17
 * @update 2015-6-17
 */
public class DictionaryConstant {

	/**
	 * 平台模块数据维护方式
	 */

	public interface MAINTENANCE_MODE {
		/**
		 * 创建
		 */
		String CREATE = "CREATE";

		/**
		 * 共享
		 */
		String SHARE = "SHARE";
		/**
		 * 只读
		 */
		String READ = "READ";
		/**
		 * 扩展
		 */
		String EXTEND = "EXTEND";
	}

	public interface EXTERNAL_AUTH {
		/**
		 * 共享
		 */
		String SHARE = "SHARE";
		/**
		 * 只读
		 */
		String READ = "READ";
		/**
		 * 扩展
		 */
		String EXTEND = "EXTEND";
	}

	/**
	 * 平台模块code
	 */

	public interface MODULE_CODE {

		/**
		 * 系统配置模块
		 */
		String SYS_CONFIG = "SYS_CONFIG";

		/**
		 * 系统权限模块（角色、管理、用户组、菜单）
		 */
		String SYS_AUTH = "SYS_AUTH";

		/**
		 * 字典项模块
		 */
		String SYS_DICT = "SYS_DICT";

		/**
		 * 平台管理模块
		 */
		String PLATFORM_MANAGE = "PLATFORM_MANAGE";

		/**
		 * 用户中心模块
		 */
		String USER_CENTRE_USERS = "USER_CENTRE_USERS";
	}
	
	/**
	 * token包含的信息
	 */
	public interface token_info {
		/**
		 * SESSIONKEY
		 */
		String SESSIONKEY = "sessionkey";
		/**
		 * 用户id
		 */
		String USERID = "user_id";

		String TOKEN = "token";

		String EXPIRESIN = "expiresin";

		String EXPIRESTIME = "expirestime";

		String TYPE = "type";

		String ACCESSTOKEN = "accesstoken";

		String REFRESHTOKEN = "refreshtoken";
	}
}
