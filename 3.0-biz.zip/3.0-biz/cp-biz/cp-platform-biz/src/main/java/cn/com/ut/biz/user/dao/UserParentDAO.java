package cn.com.ut.biz.user.dao;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 用户信息管理数据层接口
 * 
 */
public interface UserParentDAO extends JdbcOperation<UserParent> {

	/**
	 * 根据电话号码获取用户信息
	 * 
	 * @param mobile
	 * @param passwordMd5
	 * @return
	 */
	Map<String, Object> getUserInfoByMobile(String mobile, String passwordMd5);

	/**
	 * 根据用户名获取用户信息
	 * 
	 * @param userName
	 * @param passwordMd5
	 * @return
	 */
	Map<String, Object> getUserInfoByUserName(String userName, String passwordMd5);

	/**
	 * 根据电话号码获取用户
	 * 
	 * @param mobile
	 * @return
	 */
	Map<String, Object> getUserInfoByMobile(String mobile);

	/**
	 * 获取登录用户需要的信息
	 * 
	 * @param userId
	 * @return
	 */
	Map<String, Object> getUserInfoByUserId(String userId);

	/**
	 * 获取用户名
	 * 
	 * @param userIds
	 * @return
	 */
	List<Map<String, Object>> getUserName(Collection<Object> userIds);

}
