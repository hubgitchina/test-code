package cn.com.ut.biz.system.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.com.ut.biz.system.dao.ConfigDAO;
import cn.com.ut.biz.system.entities.Config;
import cn.com.ut.biz.system.service.ConfigService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 系统配置管理
 * 
 * @author ouyuexing
 * @since 2014-3-28
 */
@Service
public class ConfigServiceImpl implements ConfigService {

	@Resource
	private ConfigDAO configDAO;

	@Override
	public List<Map<String, Object>> find(PageBean page) {

		return configDAO.findByPlatformId(page);
	}

	@Override
	public String create(Map<String, Object> configVo) {

		ValidatorUtil.validateMapContainsKey(configVo, Config.config_code, Config.config_type,
				Config.config_name, Config.config_value, Config.create_id);
		String configCode = (String) configVo.get(Config.config_code);
		boolean isExist = configDAO.isConfigCodeRepeat(configCode, null, null);
		if (isExist) {
			ExceptionUtil.throwValidateException("系统配置编码重复");
		}
		String configId = configDAO.add(configVo);

		return configId;
	}

	@Override
	public String update(Map<String, Object> configVo) {

		ValidatorUtil.validateMapContainsKey(configVo, Config.idx, Config.config_code,
				Config.config_type, Config.config_name, Config.config_value, Config.update_id);
		String configCode = (String) configVo.get(Config.config_code);
		String configId = (String) configVo.get(Config.idx);
		String operator = (String) configVo.get(Config.update_id);
		boolean isConfigCodeRepeat = configDAO.isConfigCodeRepeat(configCode,
				new String[] { Config.idx }, new Object[] { configId });
		if (isConfigCodeRepeat) {
			ExceptionUtil.throwValidateException("系统配置编码重复");
		}

		configDAO.update(configVo);
		return configId;

	}

	@Override
	public Map<String, Object> getDetail(String configId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { configId });

		return configDAO.get(configId);
	}

	@Override
	public void delete(String configId) {

		configDAO.delete(configId);

	}

	@Override
	public String getConfigValueByCode(String configCode) {

		ValidatorUtil.requiredFieldMiss(new Object[] { configCode });
		// 对外接口和对内接口通用
		List<Object> configCodes = new ArrayList<>();
		configCodes.add(configCode);
		List<Map<String, Object>> configList = configDAO.getConfigValueByCode(configCodes);
		if (!CollectionUtil.isEmptyCollection(configList)) {
			Map<String, Object> map = configList.get(0);
			return (String) map.get(Config.config_code);
		}
		return ConstantUtil.STR_EMPTY;
	}

	@Override
	public List<Map<String, Object>> getConfigValueByCode(List<Object> configCodes) {

		ValidatorUtil.requiredFieldMiss(new Object[] { configCodes });
		List<Map<String, Object>> list = configDAO.getConfigValueByCode(configCodes);
		Map<String, Collection<Map<String, Object>>> res = CollectionUtil.listToMapList(list,
				"config_code");
		List<Map<String, Object>> resultList = new ArrayList<>();
		for (String key : res.keySet()) {
			Map<String, Object> tem = new HashMap<>();
			tem.put("dict_type", key);
			tem.put("dict_data", res.get(key));
			resultList.add(tem);
		}
		return resultList;
	}
}
