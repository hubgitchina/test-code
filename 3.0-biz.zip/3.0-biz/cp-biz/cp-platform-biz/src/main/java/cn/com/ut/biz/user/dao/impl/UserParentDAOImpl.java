package cn.com.ut.biz.user.dao.impl;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.user.dao.UserParentDAO;
import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 用户信息管理数据层实现类
 * 
 * @author wuxiaohua
 * @since 2015-05-12
 */
@Repository
public class UserParentDAOImpl extends JdbcOperationsImpl<UserParent> implements UserParentDAO {

	String[] COLUMNS = { UserParent.email, UserParent.mobile, UserParent.user_name,
			UserParent.user_pwd, UserParent.user_type, UserParent.nick_name, UserParent.is_locked };

	String[] selectUserPerColumnArray = new String[] { "u.id as user_id", "u.user_name",
			"u.user_type", "u.nick_name", "u.mobile", "u.update_user_name_time", "u.email",
			"u.is_locked", "up.user_sex", "up.user_birthday", "up.user_pic", "up.is_marital",
			"up.industry_nature", "up.education_level", "up.monthly_income", "up.province",
			"up.city", "up.area", "up.contact_addr", "up.user_hobbies", "up.linkman_name",
			"up.fixed_phone", "(CASE WHEN user_pwd is null THEN 'N'  ELSE 'Y' end) as haspwd " };

	String usperTable = getTable(UserParent.class) + " u Left join " + getTable(UserPerson.class)
			+ " up on up.user_id = u.id";

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

	@Override
	public Map<String, Object> getUserInfoByMobile(String mobile, String passwordMd5) {

		return getByKey(null, usperTable, selectUserPerColumnArray, null,
				new String[] { "u.mobile", "u.user_pwd", "u.is_del" },
				new Object[] { mobile, passwordMd5, ConstantUtil.FLAG_NO }, cachedParameter);
	}

	@Override
	public Map<String, Object> getUserInfoByMobile(String mobile) {

		return getByKey(null, usperTable, selectUserPerColumnArray, null,
				new String[] { "u.mobile", "u.is_del" },
				new Object[] { mobile, ConstantUtil.FLAG_NO }, cachedParameter);
	}

	@Override
	public Map<String, Object> getUserInfoByUserName(String userName, String passwordMd5) {

		return getByKey(null, usperTable, selectUserPerColumnArray, null,
				new String[] { "u.user_name", "u.user_pwd", "u.is_del" },
				new Object[] { userName, passwordMd5, ConstantUtil.FLAG_NO }, cachedParameter);
	}

	@Override
	public Map<String, Object> getUserInfoByUserId(String userId) {

		return getByKey(null, usperTable, selectUserPerColumnArray, null,
				new String[] { "u.id", "u.is_del" }, new Object[] { userId, ConstantUtil.FLAG_NO },
				cachedParameter);
	}

	@Override
	public List<Map<String, Object>> getUserName(Collection<Object> userIds) {

		return queryPage(null, null, null, false,
				new String[] { UserParent.user_name, UserParent.user_type, UserParent.email,
						UserParent.idx + " as user_id" },
				null, null, " id {IN}", new int[] { userIds.size() }, null, userIds.toArray());
	}

}
