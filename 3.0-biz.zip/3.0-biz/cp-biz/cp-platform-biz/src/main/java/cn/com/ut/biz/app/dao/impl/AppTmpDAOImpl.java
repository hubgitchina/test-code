package cn.com.ut.biz.app.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.app.dao.AppTmpDAO;
import cn.com.ut.biz.app.entities.AppTmp;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 应用与业务模板DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@Repository
public class AppTmpDAOImpl extends JdbcOperationsImpl<AppTmp> implements AppTmpDAO {

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = { AppTmp.app_id, AppTmp.tmp_id };
		add(null, names, NAMES,
				ParameterBuilder.builder().append(vo, names)
						.append(id, time, time, vo.get(AppTmp.create_id), vo.get(AppTmp.create_id))
						.toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		ParameterBuilder pb = ParameterBuilder.builder();
		pb.appendColumns(null, AppTmp.app_id, AppTmp.tmp_id);
		String[] names = pb.toColumns();
		return updateById(null, names, NAMES_UT_UID,
				ParameterBuilder.builder().append(vo, names)
						.append(DateTimeUtil.currentDateTime(), vo.get(AppTmp.update_id)).toArray(),
				(String) vo.get(AppTmp.idx));
	}

	@Override
	public List<Map<String, Object>> findTmpByAppId(String appId) {

		StringBuffer table = new StringBuffer();
		String[] selectColumnArray = new String[] { "t.id", "t.app_id", "t.tmp_id", "bt.temp_name",
				"bt.tmp_desc", "bt.tmp_type" };
		table.append("t_app_tmp t ").append("LEFT JOIN t_biz_template bt ON t.tmp_id = bt.id");
		return queryPage(null, null, table.toString(), false, selectColumnArray, null,
				new String[] { "t.app_id", "t.is_del", "bt.is_del" }, null, null, "bt.create_time",
				new Object[] { appId, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO });
	}
}
