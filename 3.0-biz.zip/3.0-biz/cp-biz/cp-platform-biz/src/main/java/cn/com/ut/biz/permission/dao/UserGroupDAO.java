package cn.com.ut.biz.permission.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 用户分组管理数据层接口
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public interface UserGroupDAO extends JdbcOperation<UserGroup> {

	/**
	 * 获取指定分组下的用户
	 * 
	 * @param groupId
	 * @param pageBean
	 * @return 指定分组下的用户
	 */
	List<Map<String, Object>> listRefUsers(String groupId, PageBean pageBean);

	/**
	 * 获取指定分组未关联的用户
	 * 
	 * @param groupId
	 * @param pageBean
	 * @return 指定分组未关联的用户
	 */
	List<Map<String, Object>> listNoRefUsers(String groupId, PageBean pageBean);

	/**
	 * 获取指定用户关联的分组列表
	 * 
	 *
	 * @param dataPlatformId
	 * @param userId
	 * @param pageBean
	 * @return 指定用户关联的分组列表
	 */
	List<Map<String, Object>> findGroupsByUserId(String userId, PageBean pageBean);

	Map<String, Object> getDetail(String groupId);

}
