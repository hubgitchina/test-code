package cn.com.ut.biz.user.dao.impl;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.user.dao.ThirdUserDAO;
import cn.com.ut.biz.user.entities.ThirdUser;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 第三方用户关联
 * 
 * @author ouyuexing
 *
 */
@Repository
public class ThirdUserDAOImpl extends JdbcOperationsImpl<ThirdUser> implements ThirdUserDAO {

	String[] COLUMNS = { ThirdUser.user_id, ThirdUser.user_from, ThirdUser.open_id };

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

}
