package cn.com.ut.biz.ui.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * Created by zhouquanguo on 2018/4/25.
 */
public class Component extends BaseEntity {


    private static final long serialVersionUID = 828976938226370846L;

    /**
     * 组件名称.
     */
    public static final String comp_name = "comp_name";
    /**
     * 组件描述.
     */
    public static final String comp_desc = "comp_desc";
    /**
     * 预览图.
     */
    public static final String comp_preview = "comp_preview";
    /**
     * 组件元数据.
     */
    public static final String comp_meta = "comp_meta";

}
