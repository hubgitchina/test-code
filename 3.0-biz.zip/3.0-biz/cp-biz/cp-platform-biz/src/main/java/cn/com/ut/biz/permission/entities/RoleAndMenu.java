package cn.com.ut.biz.permission.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 角色和菜单关系实体
 * 
 * @author ouyuexing
 * @since 2017-11-21
 */
public class RoleAndMenu extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7123884417600080548L;
	/**
	 * 角色id
	 */
	public static final String role_id = "role_id";
	/**
	 * 菜单id
	 */
	public static final String menu_id = "menu_id";
	/**
	 * 角色是否拥有该菜单
	 */
	public static final String is_own = "is_own";
	/**
	 * 角色是否可分配该菜单给其他人
	 */
	public static final String is_assign = "is_assign";
}