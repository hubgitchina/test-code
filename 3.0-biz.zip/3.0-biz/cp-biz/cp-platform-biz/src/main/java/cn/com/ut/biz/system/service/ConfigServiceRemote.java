package cn.com.ut.biz.system.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

public interface ConfigServiceRemote {

	/**
	 * 根据系统配置的code和平台id查询值
	 * 
	 * @param configCode
	 * @param dataPlatformId
	 * @return
	 */
	String getConfigValueByCode(String configCode);

	/**
	 * 查询系统配置
	 * 
	 * @param platformId
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> find(PageBean page);
}