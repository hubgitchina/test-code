package cn.com.ut.biz.business.service;

import java.util.Map;

/**
 * 业务模板关联业务实体业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
public interface BizTmpEntityService {

	/**
	 * 创建业务模板关联业务实体
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 更新业务模板关联业务实体
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询业务模板关联业务实体详情
	 */
	Map<String, Object> getDetail(String tmpEntityId);

	/**
	 * 删除业务模板关联业务实体
	 * 
	 * @param apiId
	 */
	void delete(String tmpEntityId);
}
