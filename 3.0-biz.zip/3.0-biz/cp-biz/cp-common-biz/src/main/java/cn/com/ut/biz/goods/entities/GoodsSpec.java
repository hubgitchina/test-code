package cn.com.ut.biz.goods.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品规格信息表 ds_goodsspec
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public class GoodsSpec extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -828643998431897041L;
	/**
	 * 商品公共表id
	 */
	public static final String goods_id = "goods_id";
	/**
	 * 商品价格
	 */
	public static final String goods_price = "goods_price";
	/**
	 * 商家编号
	 */
	public static final String goods_serial = "goods_serial";
	/**
	 * 商品库存报警值
	 */
	public static final String goods_storage_alarm = "goods_storage_alarm";
	/**
	 * 商品点击数量
	 */
	public static final String goods_click = "goods_click";
	/**
	 * 商品销售数量
	 */
	public static final String goods_salenum = "goods_salenum";
	/**
	 * 商品收藏数量
	 */
	public static final String goods_collect = "goods_collect";
	/**
	 * 商品库存
	 */
	public static final String goods_storage = "goods_storage";
	/**
	 * 商品主图
	 */
	public static final String goods_image = "goods_image";
	/**
	 * 颜色规格id
	 */
	public static final String color_id = "color_id";
	/**
	 * 好评星级
	 */
	public static final String evaluation_good_star = "evaluation_good_star";
	/**
	 * 评价数
	 */
	public static final String evaluation_count = "evaluation_count";
	/**
	 * 规格参数名称
	 */
	public static final String specparam_name = "specparam_name";
	/**
	 * 规格参数ID
	 */
	public static final String specparam_id = "specparam_id";
	/**
	 *
	 */
	public static final String goods_name = "goods_name";
}
