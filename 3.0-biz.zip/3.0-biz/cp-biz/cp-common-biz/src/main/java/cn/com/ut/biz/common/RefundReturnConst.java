package cn.com.ut.biz.common;

/**
 * @author zhouquanguo
 * @since on 2018/6/5.
 */
public class RefundReturnConst {
	public static final int DELAY_TIME = 15;
	public static final String INVALID_ORDER_GOODS_ID = "0";
	public static final String ALL_GOODS = "全部商品";

	/**
	 * 物流状态的枚举类
	 */
	public enum GoodsStateEnum {
		PENDING_DELIVERY(1, "待发货"), WAIT_RECEIVE(2, "待收货"), NOT_RECEIVED(3, "未收到"), RECEIVED(4,
				"已收货"),;
		GoodsStateEnum(int code, String message) {
			this.code = code;
			this.message = message;

		}

		public int getCode() {

			return code;
		}

		public void setCode(int code) {

			this.code = code;
		}

		public String getMessage() {

			return message;
		}

		public void setMessage(String message) {

			this.message = message;
		}

		private int code;
		private String message;

		public static GoodsStateEnum codeof(int code) {

			for (GoodsStateEnum goodsStateEnum : GoodsStateEnum.values()) {
				if (goodsStateEnum.getCode() == code) {
					return goodsStateEnum;
				}
			}
			throw new RuntimeException("未找到对应的枚举");

		}

	}

	/**
	 * 订单表退款状态的枚举
	 */
	public enum RefundStatusEnum {
		NON_REFUNDABLE(0, "无退款"), PARTIAL_REFUND(1, "部分退款"), FULL_REFUND(2, "全部退款");
		private int code;

		public int getCode() {

			return code;
		}

		public String getMessage() {

			return message;
		}

		private String message;

		RefundStatusEnum(int code, String message) {
			this.code = code;
			this.message = message;
		}

	}

	/**
	 * 退货退款卖家处理状态的枚举类
	 */
	public enum SellerStateEnum {

		WAIT_FOR_AUDIT(1, "待审核"), AGREE(2, "同意"), DISAGREE(3, "不同意");
		private int code;

		public int getCode() {

			return code;
		}

		public String getMessage() {

			return message;
		}

		private String message;

		SellerStateEnum(int code, String message) {
			this.code = code;
			this.message = message;
		}

	}

	/**
	 * 退货退款申请状态的枚举类
	 */
	public enum RefundStateEnum {

		PROCESSING(1, "处理中"), TO_BE_HANDLED_ADMINISTRATOR(2, "待管理员处理"), FINISH(3, "已完成"),;
		private int code;

		public int getCode() {

			return code;
		}

		public String getMessage() {

			return message;
		}

		private String message;

		RefundStateEnum(int code, String message) {
			this.code = code;
			this.message = message;
		}

	}

	/**
	 * 订单商品类型
	 */
	public interface OrderGoodsType {
		/**
		 * 默认
		 */
		int DEFULT = 1;
		/**
		 * 抢购商品
		 */
		int SNAP_UP_GOODS = 2;
		/**
		 * 限时折扣商品
		 */
		int TIME_LIMIT_DISCOUNT = 3;
		/**
		 * 组合套装
		 */
		int COMBINATION_SUIT = 4;

	}

	/**
	 * 退款申请类型
	 *
	 */
	public interface RefundType {
		/**
		 * 退款
		 */
		int REFUND = 1;
		/**
		 * 退货
		 */
		int RETURN_GOODS = 2;

	}

	/**
	 * 订单锁定类型
	 */
	public interface LockState {
		/**
		 * 不用锁定
		 */
		int NO_LOCKING = 1;
		/**
		 * 需要锁定
		 */
		int NEED_TO_LOCK = 2;
	}

	/**
	 * 退货退款申请类型
	 */
	public enum RefundTypeEnum {
		refund(1, "退款"), Return_goods(2, "退货"),;
		private int code;

		public int getCode() {

			return code;
		}

		public String getMessage() {

			return message;
		}

		private String message;

		RefundTypeEnum(int code, String message) {
			this.code = code;
			this.message = message;
		}

	}

	/**
	 * 订单处理天数
	 */
	public enum OrderLimitDayEnum {

		ORDER_REFUND(15, "收货完成后可以申请退款退货"), REFUND_CONFIRM(7, "卖家不处理退款退货申请时按同意处理"), RETURN_CONFIRM(7,
				"卖家不处理收货时按弃货处理"), RETURN_DELAY(5, "退货的商品发货多少天以后才可以选择没收到");

		public int getLimitDays() {

			return limitDays;
		}

		public String getMessage() {

			return message;
		}

		private int limitDays;
		private String message;

		OrderLimitDayEnum(int limitDays, String message) {
			this.limitDays = limitDays;
			this.message = message;

		}

	}

}
