package cn.com.ut.biz.goodsspec.util;

import org.apache.commons.lang3.builder.CompareToBuilder;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
@EqualsAndHashCode(of = { "specvalue_id" })
public class SpecValueVo implements Comparable<SpecValueVo> {

	private String specvalue_id;
	private String specvalue_name;

	@Override
	public int compareTo(SpecValueVo specValueVo) {

		return new CompareToBuilder().append(this.specvalue_id, specValueVo.getSpecvalue_id())
				.toComparison();
	}
}
