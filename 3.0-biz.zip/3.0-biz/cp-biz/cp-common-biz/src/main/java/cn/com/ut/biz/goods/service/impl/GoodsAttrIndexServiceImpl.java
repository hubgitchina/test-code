package cn.com.ut.biz.goods.service.impl;

import static cn.com.ut.biz.goods.entities.GoodsAttrIndex.attr_id;
import static cn.com.ut.biz.goods.entities.GoodsAttrIndex.attrvalue_id;
import static cn.com.ut.biz.goods.entities.GoodsAttrIndex.goods_id;
import static cn.com.ut.biz.goodsattribute.entities.Attribute.attr_name;
import static cn.com.ut.biz.goodsattribute.entities.AttributeValue.attrvalue_name;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.user_id;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;

import cn.com.ut.biz.goods.dao.GoodsAttrIndexDAO;
import cn.com.ut.biz.goods.service.GoodsAttrIndexService;
import cn.com.ut.biz.goods.util.ConstGoodsUtil;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 商品关联属性业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Service
public class GoodsAttrIndexServiceImpl implements GoodsAttrIndexService {

	@Autowired
	private GoodsAttrIndexDAO goodsAttrIndexDAO;

	@Override
	public void updateGoodsAttr(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, goods_id);

		// 获取规格json集合
		String strAttr = TypeConvert.getStringValue(vo.get(ConstGoodsUtil.ATTR));
		if (CommonUtil.isEmpty(strAttr)) {
			ExceptionUtil.throwValidateException("未设置商品关联属性参数");
		}

		JSONArray goodsAttrArray = JSONObject.parseArray(strAttr);
		if (CollectionUtil.isEmptyCollection(goodsAttrArray)) {
			ExceptionUtil.throwValidateException("未设置商品关联属性参数");
		}

		String userId = (String) vo.get(user_id);
		String goodsId = (String) vo.get(goods_id);

		List<Map<String, Object>> attrVos = new ArrayList<>(goodsAttrArray.size());
		Timestamp now = DateTimeUtil.currentDateTime();
		for (int i = 0; i < goodsAttrArray.size(); i++) {
			JSONObject attrIndex = goodsAttrArray.getJSONObject(i);

			ValidatorUtil.validateMapContainsKey(attrIndex, attr_id, attrvalue_id);

			String attrId = attrIndex.getString(attr_id);
			JSONArray valueIdArray = attrIndex.getJSONArray(attrvalue_id);

			if (CollectionUtil.isEmptyCollection(valueIdArray)) {
				ExceptionUtil.throwValidateException("attrvalue_id参数为空");
			}

			for (int j = 0; j < valueIdArray.size(); j++) {
				String valueId = valueIdArray.getString(j);
				Map<String, Object> attrMap = Maps.newHashMapWithExpectedSize(8);
				attrMap.put(idx, CommonUtil.getUUID());
				attrMap.put(create_id, userId);
				attrMap.put(create_time, now);
				attrMap.put(update_id, userId);
				attrMap.put(update_time, now);
				attrMap.put(goods_id, goodsId);
				attrMap.put(attr_id, attrId);
				attrMap.put(attrvalue_id, valueId);
				attrVos.add(attrMap);
			}
		}

		// 先删除原有商品关联的属性（一对多）
		goodsAttrIndexDAO.delete(null, new String[] { goods_id }, new Object[] { goodsId });

		String[] names = new String[] { idx, create_id, create_time, update_id, update_time,
				goods_id, attr_id, attrvalue_id };
		goodsAttrIndexDAO.addVoBatch(null, names, null, attrVos);
	}

	@Override
	public List<Map<String, Object>> queryGoodsAttr(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, goods_id);

		String goodsId = (String) vo.get(goods_id);

		List<Map<String, Object>> attrList = goodsAttrIndexDAO.queryGoodsAttr(goodsId);

		if (!CollectionUtil.isEmptyCollection(attrList)) {
			List<Map<String, Object>> attrValueIds = goodsAttrIndexDAO.queryPage(null, null, null,
					false, new String[] { attrvalue_id }, null, new String[] { goods_id, is_del },
					null, null, null, new Object[] { goodsId, ConstantUtil.FLAG_NO });

			List<Map<String, Object>> goodsAttrValue = new ArrayList<>();

			String attrId = "";
			String attrName = "";
			List<Map<String, Object>> attrValueList = new ArrayList<>();
			for (int i = 0; i < attrList.size(); i++) {
				Map<String, Object> tempAttrMap = attrList.get(i);
				String tempAttrId = (String) tempAttrMap.get(attr_id);
				String tempAttrName = (String) tempAttrMap.get(attr_name);

				String tempAttrValueId = (String) tempAttrMap.get(attrvalue_id);
				String tempAttrValueName = (String) tempAttrMap.get(attrvalue_name);

				String is_checked = ConstantUtil.FLAG_NO;
				for (Map<String, Object> attrValueId : attrValueIds) {
					String valueId = (String) attrValueId.get(attrvalue_id);
					if (valueId.equals(tempAttrValueId)) {
						is_checked = ConstantUtil.FLAG_YES;
						break;
					}
				}

				Map<String, Object> attrValueMap = Maps.newLinkedHashMapWithExpectedSize(3);
				attrValueMap.put(attrvalue_id, tempAttrValueId);
				attrValueMap.put(attrvalue_name, tempAttrValueName);
				attrValueMap.put(ConstGoodsUtil.IS_CHECKED, is_checked);

				if (CommonUtil.isEmpty(attrId)) {
					attrId = tempAttrId;
					attrName = tempAttrName;

					attrValueList.add(attrValueMap);
				} else if (attrId.equals(tempAttrId)) {
					attrValueList.add(attrValueMap);
				} else {
					List<Map<String, Object>> tempValueList = new ArrayList<>();
					tempValueList.addAll(attrValueList);

					Map<String, Object> tempMap = Maps.newLinkedHashMapWithExpectedSize(3);
					tempMap.put(attr_id, attrId);
					tempMap.put(attr_name, attrName);
					tempMap.put(ConstGoodsUtil.ATTRVALUE, tempValueList);
					goodsAttrValue.add(tempMap);

					attrId = tempAttrId;
					attrName = tempAttrName;
					attrValueList.clear();
					attrValueList.add(attrValueMap);
				}

				// 循环到最后一个元素，即完成最后一个属性锁包含属性值的遍历，将该属性集合加入map
				if (i == (attrList.size() - 1)) {
					Map<String, Object> tempMap = Maps.newLinkedHashMapWithExpectedSize(3);
					tempMap.put(attr_id, attrId);
					tempMap.put(attr_name, attrName);
					tempMap.put(ConstGoodsUtil.ATTRVALUE, attrValueList);
					goodsAttrValue.add(tempMap);
				}
			}
			return goodsAttrValue;
		} else {
			return Collections.emptyList();
		}
	}

}
