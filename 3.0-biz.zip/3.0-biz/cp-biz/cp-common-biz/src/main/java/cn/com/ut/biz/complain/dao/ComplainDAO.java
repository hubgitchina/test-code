
//-----------------------------DAO-start---------------------------------//
package cn.com.ut.biz.complain.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.complain.entities.Complain;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface ComplainDAO extends JdbcOperation<Complain> {

	Map<String, Object> getComplain(String complainId);

	List<Map<String, Object>> queryByAdmin(PageBean page);

	List<Map<String, Object>> queryByStore(PageBean page, String accusedId);

	List<Map<String, Object>> queryByCustomer(PageBean page, String accuserId);

}
// -----------------------------DAO-end---------------------------------//