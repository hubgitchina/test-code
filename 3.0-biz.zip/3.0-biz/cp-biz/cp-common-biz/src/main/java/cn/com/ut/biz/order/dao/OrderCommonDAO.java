
package cn.com.ut.biz.order.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.order.entities.OrderCommon;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 订单公共表DAO层
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
public interface OrderCommonDAO extends JdbcOperation<OrderCommon> {
	/**
	 * 新增订单公共表
	 * 
	 * @param vo
	 * @return
	 */
	String add(Map<String, Object> vo);

	/**
	 * 根据订单ID列表查询订单公共信息
	 * 
	 * @param orderIdList
	 * @return
	 */
	List<Map<String, Object>> queryOrderByOrderIdList(List<String> orderIdList);

	/**
	 *
	 * @param vo
	 */
	void updateOrderCommonInfo(Map<String, Object> vo);

	/**
	 * 更新订单公共表
	 */
	int update(Map<String, Object> vo);
}
