package cn.com.ut.biz.brand.dao;

import cn.com.ut.biz.brand.entities.Brand;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/4/27.
 */
public interface BrandDAO extends JdbcOperation<Brand> {
    /**
     * 查询品牌列表
     *
     * @param condition -查询条件，当传入brand_name查询条件时返回对品牌的模糊查询列表
     * @return
     */
    List<Map<String, Object>> findAll(Map<String, Object> condition, PageBean pageBean);
}
