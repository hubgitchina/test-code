package cn.com.ut.biz.order.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class OrderLog extends BaseEntity {

}
