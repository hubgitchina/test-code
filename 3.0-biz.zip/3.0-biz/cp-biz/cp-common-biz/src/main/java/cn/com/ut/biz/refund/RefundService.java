package cn.com.ut.biz.refund;

/**
 * @author zhouquanguo
 * @since on 2018/6/6.
 */
public interface RefundService {
	// 处理退款
	void processRefund();

}
