package cn.com.ut.biz.goods.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品与属性对应表 ds_goodsattrindex
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public class GoodsAttrIndex extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -361736006640758228L;
	/**
	 * 商品ID
	 */
	public static final String goods_id = "goods_id";
	/**
	 * 属性ID
	 */
	public static final String attr_id = "attr_id";
	/**
	 * 属性值ID
	 */
	public static final String attrvalue_id = "attrvalue_id";
}
