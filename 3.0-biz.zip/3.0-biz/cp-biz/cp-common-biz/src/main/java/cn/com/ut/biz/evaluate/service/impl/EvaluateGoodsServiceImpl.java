package cn.com.ut.biz.evaluate.service.impl;

import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_addtime;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_content;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_explain;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_goodsid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_goodsimage;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_goodsname;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_goodsprice;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_image;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_isanonymous;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_memberid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_membername;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_ordergoodsid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_orderid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_orderno;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_scores;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_storeid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_storename;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_addtime;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_deliverycredit;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_desccredit;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_memberid;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_membername;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_orderid;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_orderno;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_servicecredit;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_storeid;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_storename;
import static cn.com.ut.biz.order.entities.Order.buyer_id;
import static cn.com.ut.biz.order.entities.Order.buyer_name;
import static cn.com.ut.biz.order.entities.Order.order_sn;
import static cn.com.ut.biz.order.entities.Order.store_id;
import static cn.com.ut.biz.order.entities.Order.store_name;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_id;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_image;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_name;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_price;
import static cn.com.ut.biz.order.entities.OrderGoods.order_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;

import cn.com.ut.biz.evaluate.dao.EvaluateGoodsDAO;
import cn.com.ut.biz.evaluate.dao.EvaluateStoreDAO;
import cn.com.ut.biz.evaluate.service.EvaluateGoodsService;
import cn.com.ut.biz.evaluate.util.ConstEvaluateUtil;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 信誉评价业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
@Service
public class EvaluateGoodsServiceImpl implements EvaluateGoodsService {

	@Autowired
	private EvaluateGoodsDAO evaluateGoodsDAO;

	@Autowired
	private EvaluateStoreDAO evaluateStoreDAO;

	@Override
	public Map<String, Object> submit(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, geval_ordergoodsid, geval_scores, geval_content,
				geval_isanonymous, seval_desccredit, seval_servicecredit, seval_deliverycredit);

		String orderGoodsId = (String) vo.get(geval_ordergoodsid);
		Map<String, Object> orderGoodsInfo = evaluateGoodsDAO.getOrderGoodsStoreBuyer(orderGoodsId);
		if (CollectionUtil.isEmptyMap(orderGoodsInfo)) {
			ExceptionUtil.throwValidateException("订单商品不存在");
		}

		boolean isCanAdd = evaluateGoodsDAO.checkUnique(
				new String[] { geval_orderid, geval_ordergoodsid, geval_memberid, is_del },
				new Object[] { orderGoodsInfo.get(order_id), orderGoodsId,
						orderGoodsInfo.get(buyer_id), ConstantUtil.FLAG_NO },
				null, null);

		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("您已评价该商品和店铺");
		}

		String evaGoodsId = CommonUtil.getUUID();
		String evaStoreId = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		Map<String, Object> evaluateGoods = Maps.newHashMapWithExpectedSize(20);
		evaluateGoods.put(geval_orderid, orderGoodsInfo.get(order_id));
		evaluateGoods.put(geval_orderno, orderGoodsInfo.get(order_sn));
		evaluateGoods.put(geval_ordergoodsid, orderGoodsId);
		evaluateGoods.put(geval_goodsid, orderGoodsInfo.get(goods_id));
		evaluateGoods.put(geval_goodsname, orderGoodsInfo.get(goods_name));
		evaluateGoods.put(geval_goodsprice, orderGoodsInfo.get(goods_price));
		evaluateGoods.put(geval_goodsimage, orderGoodsInfo.get(goods_image));
		evaluateGoods.put(geval_scores, vo.get(geval_scores));
		evaluateGoods.put(geval_content, vo.get(geval_content));
		evaluateGoods.put(geval_isanonymous, vo.get(geval_isanonymous));
		evaluateGoods.put(geval_addtime, time);
		evaluateGoods.put(geval_storeid, orderGoodsInfo.get(store_id));
		evaluateGoods.put(geval_storename, orderGoodsInfo.get(store_name));
		evaluateGoods.put(geval_memberid, orderGoodsInfo.get(buyer_id));
		evaluateGoods.put(geval_membername, orderGoodsInfo.get(buyer_name));

		evaluateGoods.put(idx, evaGoodsId);
		evaluateGoods.put(create_id, orderGoodsInfo.get(buyer_id));
		evaluateGoods.put(create_time, time);
		evaluateGoods.put(update_id, orderGoodsInfo.get(buyer_id));
		evaluateGoods.put(update_time, time);

		evaluateGoodsDAO.insert(evaluateGoods);

		Map<String, Object> evaluateStore = Maps.newHashMapWithExpectedSize(15);
		evaluateStore.put(seval_orderid, orderGoodsInfo.get(order_id));
		evaluateStore.put(seval_orderno, orderGoodsInfo.get(order_sn));
		evaluateStore.put(seval_addtime, time);
		evaluateStore.put(seval_storeid, orderGoodsInfo.get(store_id));
		evaluateStore.put(seval_storename, orderGoodsInfo.get(store_name));
		evaluateStore.put(seval_memberid, orderGoodsInfo.get(buyer_id));
		evaluateStore.put(seval_membername, orderGoodsInfo.get(buyer_name));
		evaluateStore.put(seval_desccredit, vo.get(seval_desccredit));
		evaluateStore.put(seval_servicecredit, vo.get(seval_servicecredit));
		evaluateStore.put(seval_deliverycredit, vo.get(seval_deliverycredit));

		evaluateStore.put(idx, evaStoreId);
		evaluateStore.put(create_id, orderGoodsInfo.get(buyer_id));
		evaluateStore.put(create_time, time);
		evaluateStore.put(update_id, orderGoodsInfo.get(buyer_id));
		evaluateStore.put(update_time, time);

		evaluateStoreDAO.insert(evaluateStore);

		Map<String, Object> idMap = Maps.newHashMapWithExpectedSize(2);
		idMap.put(ConstEvaluateUtil.EVALUATEGOODS_ID, evaGoodsId);
		idMap.put(ConstEvaluateUtil.EVALUATESTORE_ID, evaStoreId);
		return idMap;
	}

	@Override
	public void uploadImages(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstEvaluateUtil.GEVAL_ID, geval_image);

		// 获取规格json集合
		String gevalImage = TypeConvert.getStringValue(vo.get(geval_image));
		if (CommonUtil.isEmpty(gevalImage)) {
			ExceptionUtil.throwValidateException("未设置晒单图片");
		}
		JSONArray gevalImageArray = JSONObject.parseArray(gevalImage);
		if (CollectionUtil.isEmptyCollection(gevalImageArray)) {
			ExceptionUtil.throwValidateException("未设置晒单图片");
		}
		if (gevalImageArray.size() > ConstEvaluateUtil.GEVAL_IMAGE_NUM) {
			StringBuilder maxImageNum = new StringBuilder();
			maxImageNum.append("晒单图片最多设置").append("【").append(ConstEvaluateUtil.GEVAL_IMAGE_NUM)
					.append("】").append("张");
			ExceptionUtil.throwValidateException(maxImageNum.toString());
		}
		for (int i = 0; i < gevalImageArray.size(); i++) {
			String imagePath = gevalImageArray.getString(i);
			if (CommonUtil.isEmpty(imagePath)) {
				ExceptionUtil.throwValidateException("晒单图片存在空值");
			}
		}

		String gevalId = (String) vo.get(ConstEvaluateUtil.GEVAL_ID);
		Map<String, Object> evaluateGoods = evaluateGoodsDAO.existEvaluateGoods(gevalId);
		if (CollectionUtil.isEmptyMap(evaluateGoods)) {
			ExceptionUtil.throwValidateException("评论信息不存在");
		}

		evaluateGoodsDAO.updateById(null, new String[] { geval_image }, null,
				new Object[] { gevalImage }, gevalId);
	}

	@Override
	public void explain(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstEvaluateUtil.GEVAL_ID, geval_explain);

		String gevalId = (String) vo.get(ConstEvaluateUtil.GEVAL_ID);
		Map<String, Object> evaluateGoods = evaluateGoodsDAO.existEvaluateGoods(gevalId);
		if (CollectionUtil.isEmptyMap(evaluateGoods)) {
			ExceptionUtil.throwValidateException("评论信息不存在");
		}

		String gevalExplain = (String) vo.get(geval_explain);
		evaluateGoodsDAO.updateById(null, new String[] { geval_explain }, null,
				new Object[] { gevalExplain }, gevalId);
	}

	@Override
	public ResponseWrap queryByBuyer(Map<String, Object> vo, ResponseWrap responseWrap) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstEvaluateUtil.BUYER_ID, ConstantUtil.PAGE_NO,
				ConstantUtil.PAGE_SIZE);

		PageBuilder pb = PageBuilder.build();
		// pb.appendWhereCondition("g", Goods.goods_name,
		// EnumConstant.WhereCase.LIKE,
		// EnumConstant.SqlType.STRING);
		pb.appendSortCondition(create_time);
		PageBean page = pb.buildSQL(vo);

		List<Map<String, Object>> listEvaluate = evaluateGoodsDAO.queryByBuyer(page, vo);
		responseWrap.appendPage(page);
		responseWrap.appendData(listEvaluate);
		return responseWrap;
	}

	@Override
	public ResponseWrap queryBySeller(Map<String, Object> vo, ResponseWrap responseWrap) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstEvaluateUtil.SELLER_ID, ConstantUtil.PAGE_NO,
				ConstantUtil.PAGE_SIZE);

		PageBuilder pb = PageBuilder.build();
		PageBean page = pb.buildSQL(vo);

		List<Map<String, Object>> listEvaluate = evaluateGoodsDAO.queryBySeller(page, vo);
		responseWrap.appendPage(page);
		responseWrap.appendData(listEvaluate);
		return responseWrap;
	}
}
