package cn.com.ut.biz.goodsspec.service.impl;

import static cn.com.ut.biz.goodsspec.entities.SpecValue.sort;
import static cn.com.ut.biz.goodsspec.entities.SpecValue.sp_id;
import static cn.com.ut.biz.goodsspec.entities.SpecValue.spvalue_name;
import static cn.com.ut.biz.goodsspec.entities.SpecValue.store_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.user_id;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;

import cn.com.ut.biz.goods.util.ConstGoodsUtil;
import cn.com.ut.biz.goodsspec.dao.SpecValueDAO;
import cn.com.ut.biz.goodsspec.entities.SpecValue;
import cn.com.ut.biz.goodsspec.service.SpecValueService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 商品规格值业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Service
public class SpecValueServiceImpl implements SpecValueService {

	@Autowired
	private SpecValueDAO goodsSpecValueDAO;

	private static String[] checkCols = { spvalue_name, sp_id, store_id, is_del };

	private static String[] selectCols = { idx, spvalue_name, sp_id, store_id, sort };

	@Override
	public void updateSpecValue(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, sp_id, store_id);

		// 获取规格json集合
		String specValues = TypeConvert.getStringValue(vo.get(ConstGoodsUtil.SPEC_VALUES));
		if (CommonUtil.isEmpty(specValues)) {
			ExceptionUtil.throwValidateException("未设置规格值参数");
		}

		JSONArray specValueArray = JSONObject.parseArray(specValues);
		if (CollectionUtil.isEmptyCollection(specValueArray)) {
			ExceptionUtil.throwValidateException("未设置规格值参数");
		}

		String userId = (String) vo.get(user_id);
		String spId = (String) vo.get(sp_id);
		String storeId = (String) vo.get(store_id);

		List<Map<String, Object>> addSpecValueVos = new ArrayList<>(specValueArray.size());
		Timestamp now = DateTimeUtil.currentDateTime();
		List<String> specValueNames = new ArrayList<>(specValueArray.size());
		for (int i = 0; i < specValueArray.size(); i++) {
			JSONObject specValue = specValueArray.getJSONObject(i);

			ValidatorUtil.validateMapContainsKey(specValue, spvalue_name, sort);

			String valueName = specValue.getString(spvalue_name);
			String sort = specValue.getString(SpecValue.sort);

			// 判断添加的规格值集合中是否存在重名的情况
			if (specValueNames.contains(valueName)) {
				ExceptionUtil.throwValidateException("添加规格值名称重复");
			}
			specValueNames.add(valueName);

			Map<String, Object> specValueVo = Maps.newHashMapWithExpectedSize(9);
			specValueVo.put(idx, CommonUtil.getUUID());
			specValueVo.put(create_id, userId);
			specValueVo.put(create_time, now);
			specValueVo.put(update_id, userId);
			specValueVo.put(update_time, now);
			specValueVo.put(sp_id, spId);
			specValueVo.put(store_id, storeId);
			specValueVo.put(spvalue_name, valueName);
			specValueVo.put(SpecValue.sort, sort);

			addSpecValueVos.add(specValueVo);
		}

		// 先删除原有规格关联的规格值（一对多）
		goodsSpecValueDAO.delete(null, new String[] { sp_id }, new Object[] { spId });

		String[] names = new String[] { create_id, create_time, update_id, update_time };
		goodsSpecValueDAO.addVoBatch(null, names, selectCols, addSpecValueVos);
	}

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, spvalue_name, sp_id, store_id, sort);

		String userId = (String) vo.get(user_id);
		vo.put(create_id, userId);

		boolean isCanAdd = goodsSpecValueDAO.checkUnique(checkCols, new Object[] {
				vo.get(spvalue_name), vo.get(sp_id), vo.get(store_id), ConstantUtil.FLAG_NO }, null,
				null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("该店铺当前商品规格下规格值名称重复");
		}

		String valueId = goodsSpecValueDAO.insert(vo);

		return valueId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, idx, spvalue_name, sp_id, store_id, sort);

		String userId = (String) vo.get(user_id);
		vo.put(update_id, userId);

		String valueId = (String) vo.get(idx);
		boolean isCanUpdate = goodsSpecValueDAO
				.checkUnique(checkCols,
						new Object[] { vo.get(spvalue_name), vo.get(sp_id), vo.get(store_id),
								ConstantUtil.FLAG_NO },
						new String[] { idx }, new Object[] { valueId });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("该店铺当前商品规格下规格值名称重复");
		}

		goodsSpecValueDAO.update(vo);
		return valueId;
	}

	@Override
	public Map<String, Object> getDetail(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstGoodsUtil.SPVALUE_ID);

		String valueId = (String) vo.get(ConstGoodsUtil.SPVALUE_ID);

		return goodsSpecValueDAO.getById(null, null, selectCols, null, valueId);
	}

	@Override
	public void delete(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, ConstGoodsUtil.SPVALUE_ID);

		String userId = (String) vo.get(user_id);
		String valueId = (String) vo.get(ConstGoodsUtil.SPVALUE_ID);

		goodsSpecValueDAO.deleteUpdateById(null, new String[] { update_id, update_time },
				new Object[] { ConstantUtil.FLAG_YES, userId, DateTimeUtil.currentDateTime() },
				valueId);
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		return goodsSpecValueDAO.findAllPage(page);
	}

}
