package cn.com.ut.biz.store.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.goods.service.GoodsService;
import cn.com.ut.biz.goodsclass.entity.GoodsClass;
import cn.com.ut.biz.goodsclass.service.GoodsClassService;
import cn.com.ut.biz.store.dao.StoreDAO;
import cn.com.ut.biz.store.entities.Store;
import cn.com.ut.biz.store.entities.StoreBindClass;
import cn.com.ut.biz.store.service.StoreBindClassService;
import cn.com.ut.biz.store.service.StoreService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * Created by zhouquanguo on 2018/5/9.
 */
@Service
public class StoreServiceImpl implements StoreService {

	private static final int store_show_num = 10;
	@Autowired
	private StoreDAO storeDAO;

	@Autowired
	private GoodsClassService goodsClassService;

	@Autowired
	private StoreBindClassService storeBindClassService;

	@Autowired
	private GoodsService goodsService;

	// 店铺的关键字段
	private static final String[] COLUMNS = new String[] { Store.store_name, Store.area_id,
			Store.area_info, Store.store_address, Store.store_company_name,
			Store.store_mainbusiness, Store.store_phone, Store.store_workingtime,
			Store.store_free_price, Store.is_platform_store, Store.store_huodaofk,
			Store.member_name, Store.store_keywords, Store.member_id };

	@Override
	public String create(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Arrays.copyOf(COLUMNS, COLUMNS.length - 1));
		String userId = (String) vo.get(Const.USER_ID);
		vo.put(Store.create_id, userId);
		vo.put(Store.member_id, userId);
		boolean isStoreNameUnique = storeDAO.checkUnique(
				new String[] { Store.store_name, Store.store_phone },
				new Object[] { vo.get(Store.store_name), vo.get(Store.store_phone) }, null, null);
		if (!isStoreNameUnique) {
			ExceptionUtil.throwValidateException("店铺名称重复");
		}
		long storeNum = storeDAO.countByUserId(userId);
		if (storeNum > 1) {
			ExceptionUtil.throwValidateException("当前用户名下已有店铺，请勿重复创建");
		}

		return storeDAO.add(COLUMNS, vo);

	}

	@Override
	public String update(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Store.idx, Const.USER_ID);
		Map<String, Object> before = getOne(vo);
		if (before == null || before.size() == 0) {
			ExceptionUtil.throwValidateException("待更新的店铺不存在");
		}

		boolean isUnique = storeDAO.checkUnique(new String[] { Store.store_name },
				new Object[] { vo.get(Store.store_name) }, new String[] { Store.idx },
				new Object[] { vo.get(Store.idx) });
		if (!isUnique) {
			ExceptionUtil.throwValidateException("店铺名称重复");
		}
		vo.put(Store.update_id, vo.get(Const.USER_ID));
		vo.put(Store.member_id, vo.get(Const.USER_ID));
		storeDAO.update(COLUMNS, vo);

		return (String) vo.get(Store.idx);

	}

	@Override
	public Map<String, Object> getOne(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Store.idx, Const.USER_ID);
		return storeDAO.getById(null, null, COLUMNS, new String[] { Store.idx },
				(String) vo.get(Store.idx));
	}

	@Override
	public void delete(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Store.idx);
		vo.put(Store.update_id, vo.get(Const.USER_ID));
		vo.put(Store.is_del, "Y");
		storeDAO.update(new String[] { Store.is_del, Store.update_id }, vo);
	}

	@Override
	public ResponseWrap query(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.Page.PAGE_NO, Const.Page.PAGE_SIZE,
				Const.USER_ID);
		PageBuilder pb = PageBuilder.build();
		PageBean pageBean = pb.buildSQL(vo);
		ResponseWrap responseWrap = ResponseWrap.builder();
		return responseWrap.appendPage(pageBean).appendData(storeDAO.findAll(pageBean));

	}

	@Override
	public List<Map<String, Object>> getBindCategories(String storeId) {

		// 查询当前店铺下的分类ID
		List<Map<String, Object>> categoryIdObj = storeBindClassService
				.getBindCategoryByStoreId(storeId);
		if (CollectionUtil.isEmptyCollection(categoryIdObj)) {
			return Lists.newArrayList();
		}
		List<String> categoryIds = categoryIdObj.stream()
				.map(e -> (String) e.get(StoreBindClass.gc_id)).collect(Collectors.toList());
		// 根据分类ID查询分类详情
		List<Map<String, Object>> goodsClassList = goodsClassService
				.getCategoryByCategoryId(categoryIds);
		return goodsClassList;
	}

	@Override
	public String addStoreCategory(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, StoreBindClass.store_id, Const.USER_ID,
				StoreBindClass.gc_id);
		String storeId = (String) vo.get(StoreBindClass.store_id);

		Map<String, Object> goodClass = goodsClassService
				.getCategoryByCategoryId(Arrays.asList((String) vo.get(StoreBindClass.gc_id)))
				.get(0);
		if (CollectionUtil.isEmptyMap(goodClass)
				|| (Integer) goodClass.get(GoodsClass.level) != Const.Level.LEVEL_TWO) {
			ExceptionUtil.throwValidateException("选择的商品分类不正确或分类信息不存在");

		}
		Map<String, Object> storeClass = storeBindClassService.selectByStoreIdAndGcId(storeId,
				(String) vo.get(StoreBindClass.gc_id));
		if (!CollectionUtil.isEmptyMap(storeClass)) {
			ExceptionUtil.throwValidateException("当前店铺已经绑定该分类");
		}
		// 新增当前店铺分类关联
		Map<String, Object> storeBindClass = Maps.newHashMap();
		storeBindClass.put(StoreBindClass.gc_id, goodClass.get(GoodsClass.idx));
		storeBindClass.put(StoreBindClass.store_id, storeId);
		storeBindClass.put(StoreBindClass.storebindclass_state, Const.Level.LEVEL_ZERO);
		storeBindClass.put(StoreBindClass.create_id, vo.get(Const.USER_ID));
		return storeBindClassService.create(storeBindClass);
	}

	@Override
	public ResponseWrap searchByStoreName(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Store.store_name, Const.USER_ID,
				Const.Page.PAGE_NO, Const.Page.PAGE_SIZE);

		// 查询当前店铺的信息
		String storeName = (String) vo.get(Store.store_name);
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition(null, Store.store_name, EnumConstant.WhereCase.LIKE,
				EnumConstant.SqlType.STRING);
		PageBean page = pb.buildSQL(vo);
		List<Map<String, Object>> stores = storeDAO.selectByStoreName(storeName, page);
		if (CollectionUtil.isEmptyCollection(stores)) {
			ExceptionUtil.throwRuntimeException("无相关的店铺信息");
		}
		List<String> storeIdList = stores.stream().map(e -> (String) e.get(Store.idx))
				.collect(Collectors.toList());

		// 查询当前店铺绑定的商品分类
		List<Map<String, Object>> goodsClassIdList = storeBindClassService
				.getClassByStoreIds(storeIdList);
		// 查询父（二级）分类列表
		List<Map<String, Object>> goodsParentList = goodsClassService.getCategoryByCategoryId(
				goodsClassIdList.stream().map(e -> (String) e.get(StoreBindClass.gc_id))
						.collect(Collectors.toList()));
		// 查找二级分类下的所有子分类
		Set<Map<String, Object>> allGoodsClassSet = Sets.newHashSet();
		for (Map<String, Object> goodsParent : goodsParentList) {
			List<Map<String, Object>> childrenCategory = goodsClassService
					.queryChildrenParallel((String) goodsParent.get(GoodsClass.gc_parent_id));
			allGoodsClassSet.addAll(childrenCategory);

		}

		List<Map<String, Object>> storeInfoList = Lists.newArrayList();
		// 查询当前店铺展示的商品信息
		for (String storeId : storeIdList) {
			Map<String, Object> storeResult = Maps.newHashMap();
			Map<String, Object> storeIdMap = Maps.newHashMap();
			storeIdMap.put("store_id", storeId);
			List<Map<String, Object>> storeGoodsInfo = goodsService.queryStoreGoods(null,
					storeIdMap);
			// 组装店铺与商品信息
			for (Map<String, Object> store : stores) {
				if (store.get(Store.idx).equals(storeId)) {
					storeResult.put(StoreBindClass.store_id, store.get(Store.idx));
					storeResult.put(Store.store_name, store.get(Store.store_name));
					storeResult.put(Store.store_deliverycredit,
							store.get(Store.store_deliverycredit));
					storeResult.put(Store.store_servicecredit,
							store.get(Store.store_servicecredit));
					storeResult.put("store_goods_amount", storeGoodsInfo.size());
					// 默认限定展示10个商品
					storeResult.put("store_goods_list", storeGoodsInfo.stream()
							.limit(store_show_num).collect(Collectors.toList()));
					storeInfoList.add(storeResult);
				}
			}

		}
		Map<String, Object> goodsMap = Maps.newHashMap();
		goodsMap.put("recommendGoodsClassList", allGoodsClassSet);
		// 限制展示的商品数量
		goodsMap.put("queryStoreInfoList",
				storeInfoList.stream().limit(store_show_num).collect(Collectors.toList()));

		return ResponseWrap.builder().appendData(goodsMap).appendPage(page);

	}

}
