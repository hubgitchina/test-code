package cn.com.ut.biz.goods.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.goods.entities.GoodsAttrIndex;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 商品关联属性信息DAO
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface GoodsAttrIndexDAO extends JdbcOperation<GoodsAttrIndex> {

	/**
	 * 获取商品关联属性和属性下包含所有属性值
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryGoodsAttr(String goodsId);
}
