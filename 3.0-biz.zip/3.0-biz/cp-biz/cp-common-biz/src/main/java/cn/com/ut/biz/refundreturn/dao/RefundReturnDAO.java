package cn.com.ut.biz.refundreturn.dao;

/**
* 退货退款DAO层
* 
 * @author zhouquanguo
 * @since on 2018/6/4.
 */

import cn.com.ut.biz.refundreturn.entities.RefundReturn;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

import java.util.List;
import java.util.Map;

public interface RefundReturnDAO extends JdbcOperation<RefundReturn> {
	/**
	 * 创建用户退款退货记录
	 * 
	 * @param vo
	 * @return
	 */
	String add(Map<String, Object> vo);

	/**
	 * 查询退货退款记录
	 * 
	 * @param refundId
	 * @return
	 */
	Map<String, Object> getByRefundId(String refundId);

	/**
	 * 根据店铺ID查询退款申请列表
	 * 
	 * @param storeId
	 * @param pageBean
	 * @return
	 */
	List<Map<String, Object>> listRefundByStoreId(String storeId, PageBean pageBean);

	/**
	 * 买家查询退款申请列表
	 * 
	 * @param buyerId
	 * @return
	 */
	List<Map<String, Object>> listRefundByBuyerId(String buyerId,PageBean pageBean);

	/**
	 * 查询退款处理详情
	 * @param buyerId
	 * @param refundId
	 * @return
	 */
	Map<String,Object> getByBuyerAndRefundId(String buyerId, String refundId);

	/**
	 * 根据订单ID和订单商品ID查询退款是否已存在
	 * @param orderId
	 * @param orderGoodsId
	 * @return
	 */
	Map<String,Object> getByOrderIdAndGoodId(String orderId, String orderGoodsId);
}