package cn.com.ut.biz.evaluate.dao.impl;

import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_addtime;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_deliverycredit;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_desccredit;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_memberid;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_membername;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_orderid;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_orderno;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_servicecredit;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_storeid;
import static cn.com.ut.biz.evaluate.entities.EvaluateStore.seval_storename;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.evaluate.dao.EvaluateStoreDAO;
import cn.com.ut.biz.evaluate.entities.EvaluateStore;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 店铺评分DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
@Repository
public class EvaluateStoreDAOImpl extends JdbcOperationsImpl<EvaluateStore>
		implements EvaluateStoreDAO {

	private static String[] columns = { idx, seval_orderid, seval_orderno, seval_addtime,
			seval_storeid, seval_storename, seval_memberid, seval_membername, seval_desccredit,
			seval_servicecredit, seval_deliverycredit, create_id, create_time, update_id,
			update_time };

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		add(null, columns, null, ParameterBuilder.builder().append(vo, columns).toArray());

		return (String) vo.get(idx);
	}
}