package cn.com.ut.biz.evaluate.util;

public class ConstEvaluateUtil {

	public static final String BUYER_ID = "buyer_id";

	public static final String SELLER_ID = "seller_id";

	public static final String EVALUATEGOODS_ID = "evaluategoods_id";

	public static final String EVALUATESTORE_ID = "evaluatestore_id";

	public static final String GEVAL_ID = "geval_id";

	public static final int GEVAL_IMAGE_NUM = 9;

	/**
	 * 评价状态
	 */
	public interface Evaluate_STATE {
		/**
		 * 正常
		 */
		public static final int display = 0;
		/**
		 * 禁止显示
		 */
		public static final int hide = 1;
	}
}
