package cn.com.ut.biz.goodsspec.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.goodsspec.entities.SpecValue;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 商品规格值DAO
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface SpecValueDAO extends JdbcOperation<SpecValue> {

	/**
	 * 查询商品规格值列表（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);
}
