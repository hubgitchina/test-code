
//------------------------------entity-start--------------------------------//
package cn.com.ut.biz.inform.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class Inform extends BaseEntity {


	/**
     * 举报处理时间
     */
    public static final String inform_handle_datetime = "inform_handle_datetime";
	/**
     * 举报主题ID
     */
    public static final String informsubject_id = "informsubject_id";
	/**
     * 举报时间
     */
    public static final String inform_datetime = "inform_datetime";
	/**
     * 店铺名
     */
    public static final String inform_store_name = "inform_store_name";
	/**
     * 举报主题
     */
    public static final String informsubject_content = "informsubject_content";
	/**
     * 举报处理结果(1无效举报/2恶意举报/3有效举报)
     */
    public static final String inform_handle_type = "inform_handle_type";
	/**
     * 被举报的商品名称
     */
    public static final String inform_goods_name = "inform_goods_name";
	/**
     * 被举报的商品ID
     */
    public static final String inform_goods_id = "inform_goods_id";
	/**
     * 举报人ID
     */
    public static final String inform_member_id = "inform_member_id";
	/**
     * 被举报商品的店铺ID
     */
    public static final String inform_store_id = "inform_store_id";
	/**
     * 举报人会员名
     */
    public static final String inform_member_name = "inform_member_name";
	/**
     * 图片，最多上传三张
     */
    public static final String inform_image = "inform_image";
	/**
     * 举报处理信息
     */
    public static final String inform_handle_message = "inform_handle_message";
	/**
     * 商品图
     */
    public static final String inform_goods_image = "inform_goods_image";
	/**
     * 举报信息
     */
    public static final String inform_content = "inform_content";
	/**
     * 举报状态(1未处理/2已处理)
     */
    public static final String inform_state = "inform_state";
	/**
     * 管理员ID
     */
    public static final String inform_handle_member_id = "inform_handle_member_id";
}
//------------------------------entity-end--------------------------------//
