package cn.com.ut.biz.goodsattribute.service.impl;

import static cn.com.ut.biz.goodsattribute.entities.Attribute.attr_name;
import static cn.com.ut.biz.goodsattribute.entities.Attribute.attr_show;
import static cn.com.ut.biz.goodsattribute.entities.Attribute.sort;
import static cn.com.ut.biz.goodsattribute.entities.Attribute.type_id;
import static cn.com.ut.biz.goodsattribute.entities.AttributeValue.attr_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.user_id;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.goodsattribute.dao.AttributeDAO;
import cn.com.ut.biz.goodsattribute.service.AttributeService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 商品属性业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Service
public class AttributeServiceImpl implements AttributeService {

	@Autowired
	private AttributeDAO attributeDAO;

	private static String[] checkCols = { attr_name, type_id, is_del };

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, attr_name, type_id, attr_show, sort);

		String userId = (String) vo.get(user_id);
		vo.put(create_id, userId);

		boolean isCanAdd = attributeDAO.checkUnique(checkCols,
				new Object[] { vo.get(attr_name), vo.get(type_id), ConstantUtil.FLAG_NO }, null,
				null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("商品类型下属性名称重复");
		}
		return attributeDAO.insert(vo);
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, idx, attr_name, type_id, attr_show, sort);

		String userId = (String) vo.get(user_id);
		vo.put(update_id, userId);

		String id = (String) vo.get(idx);
		boolean isCanUpdate = attributeDAO.checkUnique(checkCols,
				new Object[] { vo.get(attr_name), vo.get(type_id), ConstantUtil.FLAG_NO },
				new String[] { idx }, new Object[] { id });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("商品类型下属性名称重复");
		}

		attributeDAO.update(vo);
		return id;
	}

	@Override
	public Map<String, Object> getDetail(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, attr_id);

		String id = (String) vo.get(attr_id);

		return attributeDAO.getById(null, null,
				new String[] { idx, attr_name, type_id, attr_show, sort }, null, id);
	}

	@Override
	public void delete(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, attr_id);

		String userId = (String) vo.get(user_id);
		String id = (String) vo.get(attr_id);

		attributeDAO.deleteUpdateById(null, new String[] { update_id, update_time },
				new Object[] { ConstantUtil.FLAG_YES, userId, DateTimeUtil.currentDateTime() }, id);
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		return attributeDAO.findAllPage(page);
	}

}
