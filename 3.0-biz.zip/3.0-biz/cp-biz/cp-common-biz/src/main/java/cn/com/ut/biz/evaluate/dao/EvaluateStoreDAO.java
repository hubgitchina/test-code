package cn.com.ut.biz.evaluate.dao;

import cn.com.ut.biz.evaluate.entities.EvaluateStore;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 店铺评分DAO
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
public interface EvaluateStoreDAO extends JdbcOperation<EvaluateStore> {
}
