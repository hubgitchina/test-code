
//-----------------------------ServiceImpl-start---------------------------------//
package cn.com.ut.biz.complain.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.common.ConfigConstant;
import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.complain.dao.ComplainDAO;
import cn.com.ut.biz.complain.dao.ComplainTalkDAO;
import cn.com.ut.biz.complain.entities.Complain;
import cn.com.ut.biz.complain.entities.ComplainTalk;
import cn.com.ut.biz.complain.service.ComplainService;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.biz.order.service.OrderGoodsService;
import cn.com.ut.biz.order.service.OrderService;
import cn.com.ut.core.common.constant.EnumConstant.OrderBy;
import cn.com.ut.core.common.constant.EnumConstant.SqlType;
import cn.com.ut.core.common.constant.EnumConstant.WhereCase;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * ServiceImpl
 * 
 * @author wuxiaohua
 * @since 2018年6月8日
 */
@Service
public class ComplainServiceImpl implements ComplainService {

	@Autowired
	private ComplainDAO complainDAO;
	@Autowired
	private ComplainTalkDAO complainTalkDAO;
	@Autowired
	private OrderGoodsService orderGoodsService;
	@Autowired
	private OrderService orderService;

	public Map<String, Object> getComplainState(String complainId) {

		return complainDAO.getById(null, null,
				new String[] { Complain.complain_state, Complain.complain_active }, null,
				complainId);
	}

	@Override
	public String apply(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo,
				new String[] { Complain.complain_subject_id, Complain.accused_id,
						Complain.accuser_id, Complain.complain_content, Complain.order_goods_id });

		String orderGoodsId = (String) vo.get(Complain.order_goods_id);
		// 验证是否已经存在该订单商品的投诉记录
		Map<String, Object> complainVo = complainDAO.getByKey(null, null,
				new String[] { Complain.order_id }, null, new String[] { Complain.order_goods_id },
				new Object[] {}, null);
		if (complainVo != null) {

			ExceptionUtil.throwServiceException("已存在该订单商品的投诉记录");
		}

		// 判断订单商品是否存在
		Map<String, Object> orderGoodsVo = orderGoodsService.getByOrderGoodsId(orderGoodsId);
		if (orderGoodsVo == null) {
			ExceptionUtil.throwServiceException("订单商品不存在");
		}

		// 判断订单状态，已支付、已发货、已确认可以发起投诉
		String orderId = (String) orderGoodsVo.get(OrderGoods.order_id);
		Map<String, Object> orderVo = orderService.getByOrderId(orderId);
		int orderState = (int) orderVo.get(Order.order_state);
		if (orderState == Const.OrderStatusEnum.CANCELED.getCode()
				|| orderState == Const.OrderStatusEnum.NO_PAY.getCode()) {
			ExceptionUtil.throwServiceException("不能发起投诉");
		}

		// 验证是否超出投诉最后期限，交易成功后30天内
		Date finishedTime = (Date) orderVo.get(Order.finnshed_time);
		if (finishedTime != null) {
			if (DateTimeUtil.addDays(finishedTime, ConfigConstant.ComplainTimeLimit.COMPLAIN_DAYS)
					.before(new Date())) {
				ExceptionUtil.throwServiceException("超出投诉最后期限");
			}
		}

		// 填充冗余字段，商品名称、商品图片等
		vo.put(Complain.order_id, orderId);
		vo.put(Complain.complain_datetime, new Date());
		vo.put(Complain.complain_goodsid, orderGoodsVo.get(OrderGoods.goods_id));
		vo.put(Complain.complain_goodsname, orderGoodsVo.get(OrderGoods.goods_name));
		vo.put(Complain.complain_goodsimage, orderGoodsVo.get(OrderGoods.goods_image));
		vo.put(Complain.accuser_name, orderVo.get(Order.buyer_name));
		vo.put(Complain.accused_name, orderVo.get(Order.store_name));

		// 插入操作，初始化投诉状态，投诉时间
		return complainDAO.add(vo);
	}

	@Override
	public ResponseWrap queryByAdmin(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo, new String[] { Complain.user_id });

		PageBuilder pb = PageBuilder.build();

		// 动态where条件：投诉人，被投诉人，投诉状态，投诉时间起始
		String accuserName = (String) vo.get(Complain.accuser_name);
		String accusedName = (String) vo.get(Complain.accused_name);
		String complainState = (String) vo.get(Complain.complain_state);
		String complainDateTime = (String) vo.get(Complain.complain_datetime);

		if (!CommonUtil.isEmpty(accuserName))
			pb.appendWhereCondition(null, Complain.accuser_name, WhereCase.LIKE, SqlType.STRING);

		if (!CommonUtil.isEmpty(accusedName))
			pb.appendWhereCondition(null, Complain.accused_name, WhereCase.LIKE, SqlType.STRING);

		if (!CommonUtil.isEmpty(complainState))
			pb.appendWhereCondition(null, Complain.complain_state, WhereCase.EQ, SqlType.INT);

		if (!CommonUtil.isEmpty(complainDateTime))
			pb.appendWhereCondition(null, Complain.complain_datetime, WhereCase.BETWEEN,
					SqlType.DATETIME);

		// 排序字段：投诉时间降序
		pb.appendSortCondition(null, Complain.complain_datetime, OrderBy.DESC);

		PageBean page = pb.buildSQL(vo);

		List<Map<String, Object>> complainVos = complainDAO.queryByAdmin(page);

		Map<String, Object> data = new HashMap<>();
		data.put("complain", complainVos);
		return ResponseWrap.builder().appendData(data).appendPage(page);
	}

	@Override
	public ResponseWrap queryByStore(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo, new String[] { Complain.user_id });

		PageBuilder pb = PageBuilder.build();

		// 动态where条件：投诉人，被投诉人，投诉状态，投诉时间起始
		String userId = (String) vo.get(Complain.user_id);
		String accuserName = (String) vo.get(Complain.accuser_name);
		String complainState = (String) vo.get(Complain.complain_state);
		String complainDateTime = (String) vo.get(Complain.complain_datetime);

		if (!CommonUtil.isEmpty(accuserName))
			pb.appendWhereCondition(null, Complain.accuser_name, WhereCase.LIKE, SqlType.STRING);

		if (!CommonUtil.isEmpty(complainState))
			pb.appendWhereCondition(null, Complain.complain_state, WhereCase.EQ, SqlType.INT);

		if (!CommonUtil.isEmpty(complainDateTime))
			pb.appendWhereCondition(null, Complain.complain_datetime, WhereCase.BETWEEN,
					SqlType.DATETIME);

		// 排序字段：投诉时间降序
		pb.appendSortCondition(null, Complain.complain_datetime, OrderBy.DESC);

		PageBean page = pb.buildSQL(vo);

		List<Map<String, Object>> complainVos = complainDAO.queryByStore(page, userId);

		Map<String, Object> data = new HashMap<>();
		data.put("complain", complainVos);
		return ResponseWrap.builder().appendData(data).appendPage(page);
	}

	@Override
	public ResponseWrap queryByCustomer(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo, new String[] { Complain.user_id });

		PageBuilder pb = PageBuilder.build();

		// 动态where条件：投诉人，被投诉人，投诉状态，投诉时间起始
		String userId = (String) vo.get(Complain.user_id);
		String accusedName = (String) vo.get(Complain.accused_name);
		String complainState = (String) vo.get(Complain.complain_state);
		String complainDateTime = (String) vo.get(Complain.complain_datetime);

		if (!CommonUtil.isEmpty(accusedName))
			pb.appendWhereCondition(null, Complain.accused_name, WhereCase.LIKE, SqlType.STRING);

		if (!CommonUtil.isEmpty(complainState))
			pb.appendWhereCondition(null, Complain.complain_state, WhereCase.EQ, SqlType.INT);

		if (!CommonUtil.isEmpty(complainDateTime))
			pb.appendWhereCondition(null, Complain.complain_datetime, WhereCase.BETWEEN,
					SqlType.DATETIME);

		// 排序字段：投诉时间降序
		pb.appendSortCondition(null, Complain.complain_datetime, OrderBy.DESC);

		PageBean page = pb.buildSQL(vo);

		List<Map<String, Object>> complainVos = complainDAO.queryByCustomer(page, userId);

		Map<String, Object> data = new HashMap<>();
		data.put("complain", complainVos);
		return ResponseWrap.builder().appendData(data).appendPage(page);
	}

	@Override
	public Map<String, Object> getDetail(Map<String, Object> vo) {

		// 验证必填内容
		ValidatorUtil.validateMapContainsKey(vo, new String[] { Complain.complain_id });

		String complainId = (String) vo.get(Complain.complain_id);
		// 查找投诉记录
		Map<String, Object> complainVo = complainDAO.getComplain(complainId);
		if (complainVo == null) {
			ExceptionUtil.throwServiceException("投诉记录不存在");
		}

		Map<String, Object> data = new HashMap<>();

		// 追加对话记录
		List<Map<String, Object>> talkVos = complainTalkDAO.queryTalk(complainId);

		data.put("complain", complainVo);
		data.put("talk", talkVos);

		return data;
	}

	@Override
	public int cancelByCustomer(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo,
				new String[] { Complain.user_id, Complain.complain_id });

		String complainId = (String) vo.get(Complain.complain_id);
		// 判断投诉记录是否存在
		Map<String, Object> complainVo = getComplainState(complainId);
		if (complainVo == null) {
			ExceptionUtil.throwServiceException("投诉记录不存在");
		}

		// 判断投诉状态，新投诉状态可取消
		if (ConfigConstant.ComplainState.NEW != (int) complainVo.get(Complain.complain_state)) {
			ExceptionUtil.throwServiceException("投诉非新建状态不能进行取消操作");
		}

		// 更新投诉记录
		int count = complainDAO.updateById(null,
				new String[] { Complain.complain_state, Complain.update_time }, null,
				new Object[] { ConfigConstant.ComplainState.FINISH, new Date() }, complainId);
		return count;
	}

	@Override
	public int closeByAdmin(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo, new String[] { Complain.user_id,
				Complain.complain_id, Complain.final_handle_message });

		String complainId = (String) vo.get(Complain.complain_id);
		// 判断投诉记录是否存在
		Map<String, Object> complainVo = getComplainState(complainId);
		if (complainVo == null) {
			ExceptionUtil.throwServiceException("投诉记录不存在");
		}

		// 判断投诉状态，非关闭状态可进行关闭处理
		if (ConfigConstant.ComplainState.FINISH == (int) complainVo.get(Complain.complain_state)) {
			ExceptionUtil.throwServiceException("投诉记录已经关闭不能进行关闭操作");
		}

		// TODO 进行退款

		// 更新投诉记录
		Date date = new Date();
		int count = complainDAO.updateById(null,
				new String[] { Complain.complain_state, Complain.update_time,
						Complain.final_handle_datetime, Complain.final_handle_member_id,
						Complain.final_handle_message },
				null,
				new Object[] { ConfigConstant.ComplainState.FINISH, date, date,
						vo.get(Complain.user_id), vo.get(Complain.final_handle_message) },
				complainId);
		return count;
	}

	@Override
	public int auditByAdmin(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo,
				new String[] { Complain.user_id, Complain.complain_id });

		String complainId = (String) vo.get(Complain.complain_id);
		// 判断投诉记录是否存在
		Map<String, Object> complainVo = getComplainState(complainId);
		if (complainVo == null) {
			ExceptionUtil.throwServiceException("投诉记录不存在");
		}

		// 判断投诉状态，新建状态才可以进行审核
		if (ConfigConstant.ComplainState.NEW != (int) complainVo.get(Complain.complain_state)) {
			ExceptionUtil.throwServiceException("投诉记录非新建状态不能进行审核操作");
		}

		// 更新投诉记录
		Date date = new Date();
		int count = complainDAO
				.updateById(null,
						new String[] { Complain.complain_state, Complain.update_time,
								Complain.complain_handle_datetime,
								Complain.complain_handle_member_id, Complain.complain_active },
						null,
						new Object[] { ConfigConstant.ComplainState.WAIT_APPEAL, date, date,
								vo.get(Complain.user_id), ConfigConstant.ComplainState.AUDIT },
						complainId);
		return count;
	}

	@Override
	public int appeal(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo,
				new String[] { Complain.user_id, Complain.complain_id });

		String complainId = (String) vo.get(Complain.complain_id);
		// 判断投诉记录是否存在
		Map<String, Object> complainVo = getComplainState(complainId);
		if (complainVo == null) {
			ExceptionUtil.throwServiceException("投诉记录不存在");
		}

		// 判断投诉状态，待申诉状态可以进行申诉
		if (ConfigConstant.ComplainState.WAIT_APPEAL != (int) complainVo
				.get(Complain.complain_state)) {
			ExceptionUtil.throwServiceException("投诉记录非待申诉状态不能进行申诉操作");
		}

		// 更新投诉记录
		Date date = new Date();
		int count = complainDAO.updateById(null,
				new String[] { Complain.complain_state, Complain.update_time }, null,
				new Object[] { ConfigConstant.ComplainState.APPEAL, date }, complainId);
		return count;
	}

	@Override
	public int talk(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo, new String[] { Complain.user_id,
				Complain.complain_id, ComplainTalk.talk_member_type, ComplainTalk.talk_content });

		String complainId = (String) vo.get(Complain.complain_id);
		// 判断投诉记录是否存在
		Map<String, Object> complainVo = getComplainState(complainId);
		if (complainVo == null) {
			ExceptionUtil.throwServiceException("投诉记录不存在");
		}

		// 判断投诉状态，已申诉状态可发表对话
		if (ConfigConstant.ComplainState.APPEAL != (int) complainVo.get(Complain.complain_state)) {
			ExceptionUtil.throwServiceException("投诉记录非申诉状态不能进行对话操作");
		}

		// 插入对话
		vo.put(ComplainTalk.talk_member_id, vo.get(Complain.user_id));
		vo.put(ComplainTalk.talk_datetime, new Date());
		complainTalkDAO.add(vo);
		return 1;

	}

	@Override
	public int toJudge(Map<String, Object> vo) {

		// 验证必填字段
		ValidatorUtil.validateMapContainsKey(vo,
				new String[] { Complain.user_id, Complain.complain_id });

		String complainId = (String) vo.get(Complain.complain_id);
		// 判断投诉记录是否存在
		Map<String, Object> complainVo = getComplainState(complainId);
		if (complainVo == null) {
			ExceptionUtil.throwServiceException("投诉记录不存在");
		}

		// 判断投诉状态，已申诉状态可以进行仲裁
		if (ConfigConstant.ComplainState.APPEAL != (int) complainVo.get(Complain.complain_state)) {
			ExceptionUtil.throwServiceException("投诉记录非已申诉状态不能进行仲裁操作");
		}

		// 更新投诉记录
		Date date = new Date();
		int count = complainDAO.updateById(null,
				new String[] { Complain.complain_state, Complain.update_time }, null,
				new Object[] { ConfigConstant.ComplainState.ARBITRATE, date }, complainId);
		return count;
	}

}
// -----------------------------ServiceImpl-end---------------------------------//