package cn.com.ut.biz.goods.util;

public class ConstGoodsUtil {

	public static final String SPECVALUES = "specvalues";

	public static final String GOODS_IMAGE = "goods_image";

	public static final String GOODS_SPEC = "goods_spec";

	public static final String GOODS_ATTR = "goods_attr";

	public static final String ATTR = "attr";

	public static final String ATTRVALUE = "attrvalue";

	public static final String IS_CHECKED = "is_checked";

	public static final String LEFT_STORAGE = "left_storage";

	public static final String ATTR_VALUES = "attr_values";

	public static final String ATTRVALUE_ID = "attrvalue_id";

	public static final String IMAGE_DETAILS = "image_details";

	public static final String IMAGE_ID = "image_id";

	public static final String IMAGE_IDS = "image_ids";

	public static final String SPEC_ID = "spec_id";

	public static final String SPEC_VALUES = "spec_values";

	public static final String SPVALUE_ID = "spvalue_id";

}
