package cn.com.ut.biz.evaluate.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.evaluate.entities.EvaluateGoods;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 信誉评价DAO
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
public interface EvaluateGoodsDAO extends JdbcOperation<EvaluateGoods> {

	/**
	 * 根据主键ID获取评论信息，判断是否存在相应记录（效率最快）
	 * 
	 * @param vo
	 * @return
	 */
	Map<String, Object> existEvaluateGoods(String id);

	/**
	 * 根据订单商品ID获取相关订单、商品、店铺和买家信息
	 * 
	 * @param vo
	 * @return
	 */
	Map<String, Object> getOrderGoodsStoreBuyer(String orderGoodsId);

	/**
	 * 买家查询商品评价列表（带分页）
	 * 
	 * @param page
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryByBuyer(PageBean page, Map<String, Object> vo);

	/**
	 * 商家查询商品评价列表（带分页）
	 * 
	 * @param page
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryBySeller(PageBean page, Map<String, Object> vo);
}
