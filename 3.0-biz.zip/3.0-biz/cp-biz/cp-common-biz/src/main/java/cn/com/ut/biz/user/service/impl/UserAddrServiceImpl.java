/*
 * Copyright 2013 The UTFoodPortalSE Project. Zhuhai Unitech Power Technology Co.,Ltd. All Rights Reserved.
 */

package cn.com.ut.biz.user.service.impl;

import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.com.ut.biz.user.dao.UserAddressDAO;
import cn.com.ut.biz.user.entities.UserAddress;
import cn.com.ut.biz.user.service.UserAddrService;
import cn.com.ut.core.cache.CachedParameter;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.exception.ValidateException;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 收货地址管理
 */
@Service
public class UserAddrServiceImpl implements UserAddrService {

	@Resource
	private UserAddressDAO userAddressDAO;

	/**
	 * 每个用户最多只能由这么多个收货地址
	 */
	private static final int MAX_ADDR_NUM = 20;

	@Override
	public String create(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, UserAddress.contact_man, UserAddress.province,
				UserAddress.city, UserAddress.area, UserAddress.contact_addr, UserAddress.user_id,
				UserAddress.is_default, UserAddress.contact_phone);
		String userId = (String) vo.get(UserAddress.user_id);
		if (validIsTooManyAddr(userId)) {
			throw new ValidateException("你已经拥有" + MAX_ADDR_NUM + "了，不能再添加");
		}

		String isDefault = (String) vo.get(UserAddress.is_default);

		if (ConstantUtil.FLAG_YES.equals(isDefault)) {
			resetDefaultAddr(userId);
		} else {
			// 如果没有默认收货地址，将其设为默认
			Map<String, Object> addr = userAddressDAO.getDefaultAddr(userId);
			if (CollectionUtil.isEmptyMap(addr)) {
				isDefault = ConstantUtil.FLAG_YES;
			}
		}

		vo.put(UserAddress.user_id, userId);

		vo.put(UserAddress.create_id, userId);
		String id = userAddressDAO.add(vo);

		return id;
	}

	@Override
	public void update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, idx, UserAddress.contact_man, UserAddress.province,
				UserAddress.city, UserAddress.area, UserAddress.contact_addr, UserAddress.user_id,
				UserAddress.is_default, UserAddress.contact_phone);

		String userId = (String) vo.get(UserAddress.user_id);
		if (validIsTooManyAddr(userId)) {
			throw new ValidateException("你已经拥有" + MAX_ADDR_NUM + "了，不能再添加");
		}

		String isDefault = (String) vo.get(UserAddress.is_default);

		if (ConstantUtil.FLAG_YES.equals(isDefault)) {
			resetDefaultAddr(userId);
		} else {
			// 如果没有默认收货地址，将其设为默认
			Map<String, Object> addr = userAddressDAO.getDefaultAddr(userId);
			if (CollectionUtil.isEmptyMap(addr)) {
				isDefault = ConstantUtil.FLAG_YES;
			}
		}

		vo.put(UserAddress.update_id, userId);
		userAddressDAO.update(vo);

	}

	@Override
	public List<Map<String, Object>> find(String userId, PageBean page) {

		ValidatorUtil.requiredFieldMiss(new Object[] { userId }, new String[] { "用户ID" });
		List<Map<String, Object>> itemList = userAddressDAO.queryUserAddress(userId, page);

		return itemList;
	}

	@Override
	public Map<String, Object> getDetail(String id) {

		ValidatorUtil.requiredFieldMiss(new Object[] { id }, new String[] { "地址ID" });
		Map<String, Object> userAddrVO = userAddressDAO.getById(null, null,
				new String[] { idx, UserAddress.contact_man, UserAddress.province, UserAddress.city,
						UserAddress.area, UserAddress.contact_addr, UserAddress.is_default,
						UserAddress.position, UserAddress.contact_phone },
				null, id);

		return userAddrVO;
	}

	@Override
	public void delete(String userId, String id) {

		ValidatorUtil.requiredFieldMiss(new Object[] { userId, id },
				new String[] { "用户ID", "地址ID" });
		userAddressDAO.deleteById(null, id, new CachedParameter());
	}

	@Override
	public void setDefault(String userId, String id) {

		ValidatorUtil.requiredFieldMiss(new Object[] { userId, id },
				new String[] { "用户ID", "地址ID" });
		resetDefaultAddr(userId);
		userAddressDAO.updateAddressAsDefault(id, ConstantUtil.FLAG_YES);
	}

	protected void resetDefaultAddr(String userId) {

		userAddressDAO.updateUserAddressAsNotDefault(userId, ConstantUtil.FLAG_NO);
	}

	protected boolean validIsTooManyAddr(String userId) {

		long num = userAddressDAO.count(null, null, new String[] { UserAddress.user_id },
				new Object[] { userId });
		if (num >= MAX_ADDR_NUM) {
			return true;
		}
		return false;
	}

}
