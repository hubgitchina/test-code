
//-----------------------------Service-start---------------------------------//
package cn.com.ut.biz.complain.service;

import java.util.Map;

import cn.com.ut.core.restful.ResponseWrap;

/**
 * Service
 * 
 * @author 
 * @since 
 */
public interface ComplainService {

	String apply(Map<String, Object> vo);

	int toJudge(Map<String, Object> vo);

	int talk(Map<String, Object> vo);

	int appeal(Map<String, Object> vo);

	int auditByAdmin(Map<String, Object> vo);

	int closeByAdmin(Map<String, Object> vo);

	int cancelByCustomer(Map<String, Object> vo);

	Map<String, Object> getDetail(Map<String, Object> vo);

	ResponseWrap queryByAdmin(Map<String, Object> vo);

	ResponseWrap queryByStore(Map<String, Object> vo);

	ResponseWrap queryByCustomer(Map<String, Object> vo);
	
	
}
//-----------------------------Service-end---------------------------------//