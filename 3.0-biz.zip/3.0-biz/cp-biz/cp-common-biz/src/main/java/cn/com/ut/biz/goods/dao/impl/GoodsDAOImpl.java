package cn.com.ut.biz.goods.dao.impl;

import static cn.com.ut.biz.goods.entities.Goods.brand_id;
import static cn.com.ut.biz.goods.entities.Goods.gc_id;
import static cn.com.ut.biz.goods.entities.Goods.goods_addtime;
import static cn.com.ut.biz.goods.entities.Goods.goods_advword;
import static cn.com.ut.biz.goods.entities.Goods.goods_attr;
import static cn.com.ut.biz.goods.entities.Goods.goods_body;
import static cn.com.ut.biz.goods.entities.Goods.goods_commend;
import static cn.com.ut.biz.goods.entities.Goods.goods_costprice;
import static cn.com.ut.biz.goods.entities.Goods.goods_freight;
import static cn.com.ut.biz.goods.entities.Goods.goods_marketprice;
import static cn.com.ut.biz.goods.entities.Goods.goods_name;
import static cn.com.ut.biz.goods.entities.Goods.goods_price;
import static cn.com.ut.biz.goods.entities.Goods.goods_serial;
import static cn.com.ut.biz.goods.entities.Goods.goods_storage;
import static cn.com.ut.biz.goods.entities.Goods.goods_storage_alarm;
import static cn.com.ut.biz.goods.entities.Goods.is_virtual;
import static cn.com.ut.biz.goods.entities.Goods.price_max;
import static cn.com.ut.biz.goods.entities.Goods.price_min;
import static cn.com.ut.biz.goods.entities.Goods.spec_value;
import static cn.com.ut.biz.goods.entities.Goods.store_id;
import static cn.com.ut.biz.goods.entities.Goods.type_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;

import cn.com.ut.biz.goods.dao.GoodsDAO;
import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.biz.goods.entities.GoodsAttrIndex;
import cn.com.ut.biz.goodsclass.dao.GoodsClassDAO;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 商品信息DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Repository
public class GoodsDAOImpl extends JdbcOperationsImpl<Goods> implements GoodsDAO {

	private static String[] columns = { goods_name, goods_advword, gc_id, store_id, brand_id,
			type_id, goods_attr, goods_body, goods_addtime, goods_price, price_min, price_max,
			goods_marketprice, goods_costprice, goods_serial, goods_storage_alarm, goods_commend,
			goods_freight, is_virtual, goods_storage, spec_value };

	private static String[] query_columns = { "g.id", "g.goods_name", "g.store_id", "s.store_name",
			"g.image_path AS goods_image", "g.price_min AS goods_price_min",
			"g.price_max AS goods_price_max", "g.goods_marketprice", "g.goods_commend" };

	private static String[] select_columns = new String[] { "g.goods_name", "g.gc_id", "gc.gc_name",
			"g.store_id", "s.store_name", "g.brand_id", "b.brand_name", "g.type_id", "t.type_name",
			"g.goods_price", "g.goods_marketprice", "g.goods_costprice", "g.goods_serial",
			"g.goods_storage_alarm", "g.goods_commend", "g.goods_freight", "g.is_virtual",
			"g.goods_storage" };

	private static String[] key_columns = new String[] { "g.id", "gc.is_del", "s.is_del",
			"b.is_del", "t.is_del" };

	private static String[] selectCols = new String[] { "g.id", "g.goods_name", "g.store_id",
			"s.store_name", "g.image_path AS goods_image", "g.goods_price", "g.goods_commend",
			"g.goods_salenum" };

	private static SQLHelper sqlHelper = SQLHelper.builder().append("ds_goods g")
			.append("LEFT JOIN ds_goodsclass gc ON g.gc_id = gc.id")
			.append("LEFT JOIN ds_store s ON g.store_id = s.id")
			.append("LEFT JOIN ds_brand b ON g.brand_id = b.id")
			.append("LEFT JOIN ds_type t ON g.type_id = t.id");

	@Autowired
	private GoodsClassDAO goodsClassDAO;

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();

		add(null, columns, NAMES, ParameterBuilder.builder().append(vo, columns)
				.append(id, time, time, vo.get(create_id), vo.get(create_id)).toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		return updateById(null, columns, NAMES_UT_UID,
				ParameterBuilder.builder().append(vo, columns)
						.append(DateTimeUtil.currentDateTime(), vo.get(update_id)).toArray(),
				(String) vo.get(idx));
	}

	@Override
	public Map<String, Object> existGoods(String id) {

		SQLHelper sqlHelper = SQLHelper.builder();
		sqlHelper.append(SQLHelper.SELECT).append(idx).append(SQLHelper.FROM).append(getTable())
				.append(SQLHelper.WHERE).append(idx).append(SQLHelper.EQ).append("?")
				.append(SQLHelper.LIMIT).append(ConstantUtil.FLAG_ONE);
		return queryForMap(getJdbcTemplate(), sqlHelper.toSQL(), id);
	}

	@Override
	public List<Map<String, Object>> queryStoreGoods(PageBean page, Map<String, Object> vo) {

		String storeId = (String) vo.get(store_id);

		List<String> params = Lists.newArrayList();

		params.add(storeId);
		params.add(ConstantUtil.FLAG_NO);
		params.add(ConstantUtil.FLAG_NO);

		List<String> allGcIds = Lists.newArrayList();
		if (vo.get(gc_id) != null && CommonUtil.isNotEmpty((String) vo.get(gc_id))) {
			String gcId = (String) vo.get(gc_id);
			allGcIds.add(gcId);
			goodsClassDAO.getAllChildById(gcId, allGcIds);
			params.addAll(allGcIds);
		}

		SQLHelper sqlHelper = SQLHelper.builder();
		sqlHelper.append("ds_goods g").append("LEFT JOIN ds_store s ON g.store_id = s.id");

		String[] whereCols = { "g.store_id", "g.is_del", "s.is_del" };
		if (allGcIds.size() > 0) {
			return queryPage(page, null, sqlHelper.toSQL(), false, query_columns, null, whereCols,
					"g.gc_id" + SQLHelper.IN_REPLACE, new int[] { allGcIds.size() }, null,
					params.toArray());
		} else {
			return queryPage(page, null, sqlHelper.toSQL(), false, query_columns, null, whereCols,
					null, null, null, params.toArray());
		}
	}

	@Override
	public List<Map<String, Object>> queryMallGoods(PageBean page) {

		SQLHelper sqlHelper = SQLHelper.builder();
		sqlHelper.append("ds_goods g").append("LEFT JOIN ds_store s ON g.store_id = s.id");

		return queryPage(page, null, sqlHelper.toSQL(), false, query_columns, null,
				new String[] { "g.is_del", "s.is_del" }, null, null, null,
				new Object[] { ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO });
	}

	@Override
	public Map<String, Object> getGoods(String goodsId) {

		return getByKey(null, sqlHelper.toSQL(), select_columns, null, key_columns,
				new Object[] { goodsId, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO,
						ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO },
				null);
	}

	@Override
	public Map<String, Object> getGoodsDetail(String goodsId) {

		String[] appendColumnArray = new String[] { "g.goods_vat", "g.gc_fullpath",
				"g.goods_salenum", "g.goods_body" };
		return getByKey(null, sqlHelper.toSQL(), select_columns, appendColumnArray, key_columns,
				new Object[] { goodsId, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO,
						ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO },
				null);
	}

	@Override
	public void batchUpdateGoodsStorage(List<Map<String, Object>> goodsDoNotHaveSpecList) {

		List<Object[]> args = goodsDoNotHaveSpecList.stream()
				.map(e -> new Object[] { e.get(goods_storage), e.get(idx) })
				.collect(Collectors.toList());
		batchUpdate(getJdbcTemplate(), "UPDATE ds_goods SET goods_storage=? WHERE id=?", args);
	}

	@Override
	public List<Map<String, Object>> queryAllGoodsSpec(String goodsId) {

		String[] selectColumnArray = new String[] { "s.id spec_id", "s.sp_name spec_name",
				"sv.id specvalue_id", "sv.spvalue_name specvalue_name" };
		String[] whereColumnArray = new String[] { "g.id", "g.is_del", "s.is_del", "sv.is_del" };
		SQLHelper sqlHelper = SQLHelper.builder();
		sqlHelper.append("ds_goods g").append("LEFT JOIN ds_spec s ON g.type_id = s.type_id")
				.append("LEFT JOIN ds_specvalue sv ON s.id = sv.sp_id");
		return queryPage(null, null, sqlHelper.toSQL(), false, selectColumnArray, null,
				whereColumnArray, null, null, "s.sort, sv.sort", new Object[] { goodsId,
						ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO });
	}

	@Override
	public List<Map<String, Object>> queryIndex(PageBean page, Map<String, Object> vo) {

		SQLHelper selectSql = SQLHelper.builder();
		selectSql.append("ds_goods g").append("LEFT JOIN ds_store s ON g.store_id = s.id");

		SQLHelper whereSql = SQLHelper.builder();

		// SQL查询参数集合
		List<String> params = Lists.newArrayList();

		// 设置商品名称和关键字查询条件
		setGoodsNameParam(vo, params, whereSql);

		// 设置商品价格区间查询条件
		setGoodsPriceParam(vo, params, whereSql);

		// 设置商品所属类型查询条件
		setGoodsTypeParam(vo, params, whereSql);

		// 设置商品所属品牌查询条件
		setGoodsBrandParam(vo, params, whereSql);

		// 设置商品所属分类查询条件
		setGoodsClassParam(vo, params, whereSql);

		// 设置商品关联属性值查询条件
		SQLHelper groupBySql = SQLHelper.builder();
		setGoodsAttrParam(vo, params, selectSql, whereSql, groupBySql);

		SQLHelper orderBySql = SQLHelper.builder();

		// 商品销量排序参数，只按降序
		setOrderBySaleNum(vo, orderBySql);

		// 商品上架时间排序参数，只按降序
		setOrderByShelfTime(vo, orderBySql);

		// 商品价格排序参数，按商品最大价格price_max，可进行升序或降序
		setOrderByPrice(vo, orderBySql);

		if (!"".equals(whereSql.toSQL())) {
			selectSql.append(SQLHelper.WHERE).append(whereSql.toSQL());
		}

		return queryPage(page, null, selectSql.toSQL(), true, selectCols, null, null, null, null,
				orderBySql.toSQL(), groupBySql.toSQL(), null, orderBySql.toSQL(), params.toArray());
	}

	@Override
	public List<Map<String, Object>> queryGoodsInStore(PageBean page, Map<String, Object> vo) {

		SQLHelper selectSql = SQLHelper.builder();
		selectSql.append("ds_goods g").append("LEFT JOIN ds_store s ON g.store_id = s.id");

		SQLHelper whereSql = SQLHelper.builder();

		// SQL查询参数集合
		List<String> params = Lists.newArrayList();

		// 设置商品名称和关键字查询条件
		setGoodsNameParam(vo, params, whereSql);

		// 设置商品价格区间查询条件
		setGoodsPriceParam(vo, params, whereSql);

		SQLHelper orderBySql = SQLHelper.builder();

		// 商品销量排序参数，只按降序
		setOrderBySaleNum(vo, orderBySql);

		// 商品上架时间排序参数，只按降序
		setOrderByShelfTime(vo, orderBySql);

		// 商品价格排序参数，按商品最大价格price_max，可进行升序或降序
		setOrderByPrice(vo, orderBySql);

		if (!"".equals(whereSql.toSQL())) {
			selectSql.append(SQLHelper.WHERE).append(whereSql.toSQL());
		}

		String storeId = (String) vo.get(store_id);
		params.add(storeId);

		return queryPage(page, null, selectSql.toSQL(), true, selectCols, null,
				new String[] { "g.store_id" }, null, null, orderBySql.toSQL(), params.toArray());
	}

	/**
	 * 设置SQL查询商品名称和关键字参数和查询where条件
	 * 
	 * @param vo
	 * @param params
	 * @param whereSql
	 */
	private void setGoodsNameParam(Map<String, Object> vo, List<String> params,
			SQLHelper whereSql) {

		if (vo.get(goods_name) != null && CommonUtil.isNotEmpty((String) vo.get(goods_name))) {
			String goodsName = (String) vo.get(goods_name);
			if (!"".equals(whereSql.toSQL())) {
				whereSql.append(SQLHelper.AND);
			}
			whereSql.append("(").append(SQLHelper.like("g.goods_name")).append(SQLHelper.OR)
					.append(SQLHelper.like("g.goods_advword")).append(")");
			params.add(goodsName);
			params.add(goodsName);
		}
	}

	/**
	 * 设置SQL查询价格区间参数和查询where条件
	 * 
	 * @param vo
	 * @param params
	 * @param whereSql
	 */
	private void setGoodsPriceParam(Map<String, Object> vo, List<String> params,
			SQLHelper whereSql) {

		BigDecimal priceMin = BigDecimal.ZERO;
		if (vo.get(price_min) != null && CommonUtil.isNotEmpty((String) vo.get(price_min))) {
			priceMin = new BigDecimal((String) vo.get(price_min));
		}
		BigDecimal priceMax = BigDecimal.ZERO;
		if (vo.get(price_max) != null && CommonUtil.isNotEmpty((String) vo.get(price_max))) {
			priceMax = new BigDecimal((String) vo.get(price_max));
		}
		if ((priceMin != BigDecimal.ZERO) || (priceMax != BigDecimal.ZERO)) {
			if ((priceMin.compareTo(priceMax) == -1) || (priceMin.compareTo(priceMax) == 0)) {
				if (!"".equals(whereSql.toSQL())) {
					whereSql.append(SQLHelper.AND);
				}
				whereSql.append("(").append("g.price_min").append(SQLHelper.BETWEEN).append("?")
						.append(SQLHelper.AND).append("?").append(SQLHelper.OR)
						.append("g.price_max").append(SQLHelper.BETWEEN).append("?")
						.append(SQLHelper.AND).append("?").append(")");
				params.add(priceMin.toString());
				params.add(priceMax.toString());
				params.add(priceMin.toString());
				params.add(priceMax.toString());
			}
		}
	}

	/**
	 * 设置SQL查询商品类型参数和查询where条件
	 * 
	 * @param vo
	 * @param params
	 * @param whereSql
	 */
	private void setGoodsTypeParam(Map<String, Object> vo, List<String> params,
			SQLHelper whereSql) {

		if (vo.get(type_id) != null && CommonUtil.isNotEmpty((String) vo.get(type_id))) {
			String typeId = (String) vo.get(type_id);
			if (!"".equals(whereSql.toSQL())) {
				whereSql.append(SQLHelper.AND);
			}
			whereSql.append("(").append("g.type_id").append(SQLHelper.EQ).append("?").append(")");
			params.add(typeId);
		}
	}

	/**
	 * 设置SQL查询品牌参数和查询where条件
	 * 
	 * @param vo
	 * @param params
	 * @param whereSql
	 */
	private void setGoodsBrandParam(Map<String, Object> vo, List<String> params,
			SQLHelper whereSql) {

		if (vo.get(brand_id) != null && CommonUtil.isNotEmpty((String) vo.get(brand_id))) {
			String brandId = (String) vo.get(brand_id);
			if (!"".equals(whereSql.toSQL())) {
				whereSql.append(SQLHelper.AND);
			}
			whereSql.append("(").append("g.brand_id").append(SQLHelper.EQ).append("?").append(")");
			params.add(brandId);
		}
	}

	/**
	 * 设置SQL查询商品分类参数和查询where条件
	 * 
	 * @param vo
	 * @param params
	 * @param whereSql
	 */
	private void setGoodsClassParam(Map<String, Object> vo, List<String> params,
			SQLHelper whereSql) {

		if (vo.get(gc_id) != null && CommonUtil.isNotEmpty((String) vo.get(gc_id))) {
			String gcId = (String) vo.get(gc_id);
			List<String> allGcIds = Lists.newArrayList();
			allGcIds.add(gcId);
			goodsClassDAO.getAllChildById(gcId, allGcIds);

			StringBuilder sbGcId = new StringBuilder();
			sbGcId.append("g.gc_id").append(SQLHelper.IN_REPLACE);
			String gcIdSql = replaceInCase(sbGcId.toString(), new int[] { allGcIds.size() });

			if (!"".equals(whereSql.toSQL())) {
				whereSql.append(SQLHelper.AND);
			}
			whereSql.append("(").append(gcIdSql).append(")");

			params.addAll(allGcIds);
		}
	}

	/**
	 * 设置SQL查询商品属性值参数和查询where条件
	 * 
	 * @param vo
	 * @param params
	 * @param whereSql
	 */
	private void setGoodsAttrParam(Map<String, Object> vo, List<String> params, SQLHelper selectSql,
			SQLHelper whereSql, SQLHelper groupBySql) {

		if (vo.get("attrs") != null
				&& CommonUtil.isNotEmpty(TypeConvert.getStringValue(vo.get("attrs")))) {
			String attrs = TypeConvert.getStringValue(vo.get("attrs"));
			JSONArray attrArray = JSONObject.parseArray(attrs);
			if (!CollectionUtil.isEmptyCollection(attrArray)) {
				List<String> valueIds = Lists.newArrayList();
				for (int i = 0; i < attrArray.size(); i++) {
					JSONObject attrJsonObj = attrArray.getJSONObject(i);

					ValidatorUtil.validateMapContainsKey(attrJsonObj, GoodsAttrIndex.attr_id,
							"attrvalues");

					// String attrId = attrJsonObj.getString("attr_id");
					JSONArray valueIdArray = attrJsonObj.getJSONArray("attrvalues");

					if (!CollectionUtil.isEmptyCollection(valueIdArray)) {
						for (int j = 0; j < valueIdArray.size(); j++) {
							String valueId = valueIdArray.getString(j);
							valueIds.add(valueId);
						}
					}
				}

				if (!CollectionUtil.isEmptyCollection(valueIds)) {
					selectSql.append("LEFT JOIN ds_goodsattrindex ga ON g.id = ga.goods_id");
					groupBySql.append("g.id");

					StringBuilder sbValueId = new StringBuilder();
					sbValueId.append("ga.attrvalue_id").append(SQLHelper.IN_REPLACE);
					String valueIdSql = replaceInCase(sbValueId.toString(),
							new int[] { valueIds.size() });

					if (!"".equals(whereSql.toSQL())) {
						whereSql.append(SQLHelper.AND);
					}
					whereSql.append("(").append(valueIdSql).append(")");

					params.addAll(valueIds);
				}
			}
		}
	}

	/**
	 * 设置查询OrderBy条件，根据销量排序（目前只按降序）
	 * 
	 * @param vo
	 * @param orderBySql
	 */
	private void setOrderBySaleNum(Map<String, Object> vo, SQLHelper orderBySql) {

		// 商品销量排序参数，只按降序
		if (vo.get("desc_salenum") != null
				&& CommonUtil.isNotEmpty((String) vo.get("desc_salenum"))) {
			String descSaleNum = (String) vo.get("desc_salenum");
			if (ConstantUtil.FLAG_ONE.equals(descSaleNum)) {
				orderBySql.append("g.goods_salenum").append(SQLHelper.DESC);
			}
		}
	}

	/**
	 * 设置查询OrderBy条件，根据上架时间排序（目前只按降序）
	 * 
	 * @param vo
	 * @param orderBySql
	 */
	private void setOrderByShelfTime(Map<String, Object> vo, SQLHelper orderBySql) {

		// 商品上架时间排序参数，只按降序
		if (vo.get("desc_shelftime") != null
				&& CommonUtil.isNotEmpty((String) vo.get("desc_shelftime"))) {
			String descShelfTime = (String) vo.get("desc_shelftime");
			if (ConstantUtil.FLAG_ONE.equals(descShelfTime)) {
				if (!"".equals(orderBySql.toSQL())) {
					orderBySql.append(",");
				}
				orderBySql.append("g.goods_shelftime").append(SQLHelper.DESC);
			}
		}
	}

	/**
	 * 设置查询OrderBy条件，根据最大价格排序
	 * 
	 * @param vo
	 * @param orderBySql
	 */
	private void setOrderByPrice(Map<String, Object> vo, SQLHelper orderBySql) {

		// 商品价格排序参数，按商品最大价格price_max，可进行升序或降序
		if (vo.get("sort_price") != null && CommonUtil.isNotEmpty((String) vo.get("sort_price"))) {
			String sortPrice = (String) vo.get("sort_price");
			if (ConstantUtil.FLAG_ONE.equals(sortPrice)) {
				if (!"".equals(orderBySql.toSQL())) {
					orderBySql.append(",");
				}
				orderBySql.append("g.price_max").append(SQLHelper.DESC);
			} else {
				if (!"".equals(orderBySql.toSQL())) {
					orderBySql.append(",");
				}
				orderBySql.append("g.price_max").append(SQLHelper.ASC);
			}
		}
	}

}