package cn.com.ut.biz.goods.service;

import java.util.List;
import java.util.Map;

/**
 * 商品规格信息业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface GoodsSpecService {

	/**
	 * 更新商品关联规格信息
	 * 
	 * @param vo
	 */
	void updateGoodsSpec(Map<String, Object> vo);

	/**
	 * 查询当前规格商品的信息
	 * 
	 * @param specParamId
	 * @return
	 */
	Map<String, Object> getGoodsPriceBySpecId(String specParamId);

	/**
	 * 批量更新商品的库存
	 * 
	 * @param orderItemList
	 */
	void batchUpdateGoodsStorge(List<Map<String, Object>> orderItemList, String user_id);

	/**
	 * 通过specparam_id查询商品信息
	 * 
	 * @param specparam_id
	 * @return
	 */
	Map<String, Object> getBySpecparmId(String specparam_id);
}
