package cn.com.ut.biz.evaluate.service;

import java.util.Map;

import cn.com.ut.core.restful.ResponseWrap;

/**
 * 信誉评价业务层接口
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
public interface EvaluateGoodsService {

	/**
	 * 提交商品评价和店铺评价
	 * 
	 * @param vo
	 * @return
	 */
	Map<String, Object> submit(Map<String, Object> vo);

	/**
	 * 上传晒单图片
	 * 
	 * @param vo
	 */
	void uploadImages(Map<String, Object> vo);

	/**
	 * 商家解释商品评价
	 * 
	 * @param vo
	 */
	void explain(Map<String, Object> vo);

	/**
	 * 买家查询商品评价列表（带分页）
	 * 
	 * @param vo
	 * @param responseWrap
	 * @return
	 */
	ResponseWrap queryByBuyer(Map<String, Object> vo, ResponseWrap responseWrap);

	/**
	 * 商家查询商品评价列表（带分页）
	 * 
	 * @param vo
	 * @param responseWrap
	 * @return
	 */
	ResponseWrap queryBySeller(Map<String, Object> vo, ResponseWrap responseWrap);
}
