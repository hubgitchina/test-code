
package cn.com.ut.biz.cart.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.cart.entities.Cart;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface CartDAO extends JdbcOperation<Cart> {
	/** 查询当前买家的购物车列表 */
	List<Map<String, Object>> queryCartList(String buyer_id);

	/** 添加购物车 */
	String add(Map<String, Object> vo);

	/** 查询当前用户的购物车是否有该产品 **/
	Map<String, Object> getByProductIdAndUserId(String buyerId, String goodsId, String storeId);

	/** 更新当前购物车的商品 **/
	int update(Map<String, Object> vo);

	/**
	 * 查询当前用户购物车中商品的总数量
	 * 
	 * @param buyerId
	 * @return
	 */
	int getTotalCartCount(String buyerId);

	/**
	 * 批量删除购物车记录
	 * 
	 * @param orderItemList
	 */
	void batchCleanCart(List<Map<String, Object>> orderItemList);

	/**
	 *
	 * @param buyerId
	 * @param goodsId
	 * @param storeId
	 * @param specId
	 * @return
	 */
	Map<String, Object> getBySpecIdAndUserId(String buyerId, String goodsId, String storeId,
			String specId);
}
