
//-----------------------------DAOImpl-start---------------------------------//
package cn.com.ut.biz.complain.dao.impl;

import static cn.com.ut.biz.complain.entities.ComplainTalk.complain_id;
import static cn.com.ut.biz.complain.entities.ComplainTalk.talk_admin;
import static cn.com.ut.biz.complain.entities.ComplainTalk.talk_content;
import static cn.com.ut.biz.complain.entities.ComplainTalk.talk_datetime;
import static cn.com.ut.biz.complain.entities.ComplainTalk.talk_member_id;
import static cn.com.ut.biz.complain.entities.ComplainTalk.talk_member_name;
import static cn.com.ut.biz.complain.entities.ComplainTalk.talk_member_type;
import static cn.com.ut.biz.complain.entities.ComplainTalk.talk_state;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.complain.dao.ComplainTalkDAO;
import cn.com.ut.biz.complain.entities.ComplainTalk;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

@Repository
public class ComplainTalkDAOImpl extends JdbcOperationsImpl<ComplainTalk>
		implements ComplainTalkDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null,
				new String[] { talk_member_type, complain_id, talk_member_id, talk_member_name,
						talk_content, talk_datetime },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { talk_member_type, complain_id, talk_member_id,
										talk_member_name, talk_content, talk_datetime })
						.append(id, DateTimeUtil.currentDateTime(), vo.get(ComplainTalk.user_id))
						.toArray());
		return id;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null,
				new String[] { talk_member_type, complain_id, talk_member_id, talk_member_name,
						talk_content, talk_datetime, talk_state, talk_admin },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { talk_member_type, complain_id, talk_member_id,
										talk_member_name, talk_content, talk_datetime, talk_state,
										talk_admin })
						.append(DateTimeUtil.currentDateTime(), vo.get(ComplainTalk.update_id))
						.toArray(),
				(String) vo.get(ComplainTalk.idx), null);
	}

	@Override
	public List<Map<String, Object>> queryTalk(String complainId) {

		return queryPage(null, null, null, false,
				new String[] { ComplainTalk.idx, talk_member_type, talk_member_id, talk_member_name,
						talk_content, talk_datetime },
				null, new String[] { complain_id }, null, null, talk_datetime + " desc",
				new Object[] { complainId });
	}
}
// -----------------------------DAOImpl-end---------------------------------//