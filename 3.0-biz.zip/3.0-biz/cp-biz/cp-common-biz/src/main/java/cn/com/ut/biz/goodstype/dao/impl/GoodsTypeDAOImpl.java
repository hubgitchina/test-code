package cn.com.ut.biz.goodstype.dao.impl;

import cn.com.ut.biz.goodstype.dao.GoodsTypeDAO;
import cn.com.ut.biz.goodstype.entities.GoodsType;
import cn.com.ut.constant.api.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * 商品类型DAO层接口
 *
 * Created by zhouquanguo on 2018/5/9.
 */
@Repository
public class GoodsTypeDAOImpl extends JdbcOperationsImpl<GoodsType> implements GoodsTypeDAO {
    @Override
    public List<Map<String, Object>> findAll(Map<String,Object> vo,PageBean pageBean) {
        return queryPage(pageBean, null, null, false, new String[]{GoodsType.type_name, GoodsType.idx}, null,
                new String[]{GoodsType.is_del}, null, null, GoodsType.sort, new Object[]{ConstantUtil.FLAG_NO});

    }
}
