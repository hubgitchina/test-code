package cn.com.ut.biz.evaluate.dao.impl;

import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_addtime;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_content;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_explain;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_goodsid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_goodsimage;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_goodsname;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_goodsprice;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_image;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_isanonymous;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_memberid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_membername;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_ordergoodsid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_orderid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_orderno;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_scores;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_state;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_storeid;
import static cn.com.ut.biz.evaluate.entities.EvaluateGoods.geval_storename;
import static cn.com.ut.biz.order.entities.Order.buyer_id;
import static cn.com.ut.biz.order.entities.Order.buyer_name;
import static cn.com.ut.biz.order.entities.Order.order_sn;
import static cn.com.ut.biz.order.entities.Order.store_id;
import static cn.com.ut.biz.order.entities.Order.store_name;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_id;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_image;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_name;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_price;
import static cn.com.ut.biz.order.entities.OrderGoods.order_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import cn.com.ut.biz.evaluate.dao.EvaluateGoodsDAO;
import cn.com.ut.biz.evaluate.entities.EvaluateGoods;
import cn.com.ut.biz.evaluate.util.ConstEvaluateUtil;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.biz.store.dao.StoreDAO;
import cn.com.ut.biz.store.entities.Store;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 信誉评价DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
@Repository
public class EvaluateGoodsDAOImpl extends JdbcOperationsImpl<EvaluateGoods>
		implements EvaluateGoodsDAO {

	@Autowired
	private StoreDAO storeDAO;

	private static String[] columns = { geval_orderid, geval_orderno, geval_ordergoodsid,
			geval_goodsid, geval_goodsname, geval_goodsimage, geval_scores, geval_content,
			geval_addtime, geval_storeid, geval_storename, geval_memberid, geval_membername };

	private static String[] query_columns = { geval_explain, geval_image };

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String[] names = { idx, geval_goodsprice, geval_isanonymous, create_id, create_time,
				update_id, update_time };
		add(null, columns, names,
				ParameterBuilder.builder().append(vo, columns).append(vo, names).toArray());

		return (String) vo.get(idx);
	}

	@Override
	public Map<String, Object> existEvaluateGoods(String id) {

		SQLHelper sqlHelper = SQLHelper.builder();
		sqlHelper.append(SQLHelper.SELECT).append(idx).append(SQLHelper.FROM).append(getTable())
				.append(SQLHelper.WHERE).append(idx).append(SQLHelper.EQ).append("?")
				.append(SQLHelper.LIMIT).append(ConstantUtil.FLAG_ONE);
		return queryForMap(getJdbcTemplate(), sqlHelper.toSQL(), id);
	}

	@Override
	public Map<String, Object> getOrderGoodsStoreBuyer(String orderGoodsId) {

		SQLHelper selectSql = SQLHelper.builder();
		selectSql.append(getTable(OrderGoods.class)).append("og").append(SQLHelper.LEFT_JOIN)
				.append(getTable(Order.class)).append("o").append(SQLHelper.ON)
				.append("og.order_id = o.id");

		ParameterBuilder paramBuilder = ParameterBuilder.builder();
		paramBuilder.appendColumns("og", order_id, goods_id, goods_name, goods_price, goods_image);
		paramBuilder.appendColumns("o", order_sn, store_id, store_name, buyer_id, buyer_name);
		return getByKey(null, selectSql.toSQL(), paramBuilder.toColumns(), null,
				new String[] { "og.id" }, new Object[] { orderGoodsId }, null);
	}

	@Override
	public List<Map<String, Object>> queryByBuyer(PageBean page, Map<String, Object> vo) {

		String buyerId = (String) vo.get(ConstEvaluateUtil.BUYER_ID);
		return queryPage(page, null, null, false, columns, query_columns,
				new String[] { geval_memberid, geval_state, is_del }, null, null, null,
				new Object[] { buyerId, ConstEvaluateUtil.Evaluate_STATE.display,
						ConstantUtil.FLAG_NO });
	}

	@Override
	public List<Map<String, Object>> queryBySeller(PageBean page, Map<String, Object> vo) {

		String sellerId = (String) vo.get(ConstEvaluateUtil.SELLER_ID);
		Map<String, Object> store = storeDAO.getByKey(null, null, new String[] { Store.idx }, null,
				new String[] { Store.member_id }, new Object[] { sellerId }, null);
		if (CollectionUtil.isEmptyMap(store)) {
			ExceptionUtil.throwValidateException("没有该用户的店铺信息");
		}
		return queryPage(page, null, null, false, columns, query_columns,
				new String[] { geval_storeid, geval_state, is_del }, null, null, null,
				new Object[] { store.get(Store.idx), ConstEvaluateUtil.Evaluate_STATE.display,
						ConstantUtil.FLAG_NO });
	}
}