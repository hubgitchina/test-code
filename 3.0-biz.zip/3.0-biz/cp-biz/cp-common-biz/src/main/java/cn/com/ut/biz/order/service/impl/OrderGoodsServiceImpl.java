
package cn.com.ut.biz.order.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.order.dao.OrderGoodsDAO;

import cn.com.ut.biz.order.service.OrderGoodsService;

/**
 * 订单商品表Service层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
@Service
public class OrderGoodsServiceImpl implements OrderGoodsService {

	@Autowired
	private OrderGoodsDAO orderGoodsDAO;

	@Override
	public void batchInsert(List<Map<String, Object>> orderItemList) {

		orderGoodsDAO.addBatch(orderItemList);
	}

	@Override
	public List<Map<String, Object>> selectByOrderId(String orderId) {

		return orderGoodsDAO.selectByOrderId(orderId);
	}

	@Override
	public List<Map<String, Object>> selectByOrderIdList(List<String> orderIdList) {

		return orderGoodsDAO.selectByOrderIdList(orderIdList);
	}

	@Override public Map<String, Object> getByOrderGoodsId(String orderGoodsId) {

		return orderGoodsDAO.getById(null,null,null,null,orderGoodsId);
	}
}
