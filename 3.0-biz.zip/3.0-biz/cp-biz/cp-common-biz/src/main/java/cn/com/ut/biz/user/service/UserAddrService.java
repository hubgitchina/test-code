package cn.com.ut.biz.user.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * @author: lanbin
 * @since: 2017年3月27日
 */
public interface UserAddrService {

	public String create(Map<String, Object> vo);

	public void update(Map<String, Object> vo);

	public void delete(String userId, String id);

	public void setDefault(String userId, String id);

	public List<Map<String, Object>> find(String userId, PageBean page);

	public Map<String, Object> getDetail(String id);

}
