package cn.com.ut.biz.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;

/**
 * JSON工具类
 *
 * @author zhouquanguo
 * @since 2018年5月15日
 */
public class JsonUtils {
	private static ObjectMapper objectMapper = new ObjectMapper();

	public static <T> String obj2Strig(T object) {

		if (object == null) {
			return null;
		}
		try {
			return object instanceof String ? (String) object
					: objectMapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static <T> T str2obj(String str, Class<T> clazz) {

		if (StringUtils.isEmpty(str) || clazz == null) {
			return null;
		}
		try {
			return clazz == String.class ? (T) str : objectMapper.readValue(str, clazz);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

	}

}
