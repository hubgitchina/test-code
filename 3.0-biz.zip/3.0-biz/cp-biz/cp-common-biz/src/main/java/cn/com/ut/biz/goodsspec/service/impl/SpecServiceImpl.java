package cn.com.ut.biz.goodsspec.service.impl;

import static cn.com.ut.biz.goodsspec.entities.Spec.sort;
import static cn.com.ut.biz.goodsspec.entities.Spec.sp_name;
import static cn.com.ut.biz.goodsspec.entities.Spec.type_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.user_id;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.goods.util.ConstGoodsUtil;
import cn.com.ut.biz.goodsspec.dao.SpecDAO;
import cn.com.ut.biz.goodsspec.service.SpecService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 商品规格业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Service
public class SpecServiceImpl implements SpecService {

	@Autowired
	private SpecDAO goodsSpecDAO;

	private static String[] checkCols = { sp_name, type_id, is_del };

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, sp_name, type_id, sort);

		String userId = (String) vo.get(user_id);
		vo.put(create_id, userId);

		boolean isCanAdd = goodsSpecDAO.checkUnique(checkCols,
				new Object[] { vo.get(sp_name), vo.get(type_id), ConstantUtil.FLAG_NO }, null,
				null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("商品类型下规格名称重复");
		}
		String specId = goodsSpecDAO.insert(vo);

		return specId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, idx, sp_name, type_id, sort);

		String userId = (String) vo.get(user_id);
		vo.put(update_id, userId);

		String specId = (String) vo.get(idx);
		boolean isCanUpdate = goodsSpecDAO.checkUnique(checkCols,
				new Object[] { vo.get(sp_name), vo.get(type_id), ConstantUtil.FLAG_NO },
				new String[] { idx }, new Object[] { specId });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("商品类型下规格名称重复");
		}

		goodsSpecDAO.update(vo);
		return specId;
	}

	@Override
	public Map<String, Object> getDetail(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstGoodsUtil.SPEC_ID);

		String specId = (String) vo.get(ConstGoodsUtil.SPEC_ID);

		return goodsSpecDAO.getById(null, null, new String[] { idx, sp_name, type_id, sort }, null,
				specId);
	}

	@Override
	public void delete(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, ConstGoodsUtil.SPEC_ID);

		String userId = (String) vo.get(user_id);
		String specId = (String) vo.get(ConstGoodsUtil.SPEC_ID);

		goodsSpecDAO.deleteUpdateById(null, new String[] { update_id, update_time },
				new Object[] { ConstantUtil.FLAG_YES, userId, DateTimeUtil.currentDateTime() },
				specId);
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		return goodsSpecDAO.findAllPage(page);
	}

}
