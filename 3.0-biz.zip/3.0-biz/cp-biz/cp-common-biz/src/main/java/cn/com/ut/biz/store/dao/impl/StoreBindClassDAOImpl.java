package cn.com.ut.biz.store.dao.impl;

import static cn.com.ut.biz.store.entities.StoreBindClass.store_id;
import static cn.com.ut.biz.store.entities.StoreBindClass.gc_id;
import static cn.com.ut.biz.store.entities.StoreBindClass.storebindclass_state;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import cn.com.ut.core.dal.sql.SQLHelper;
import org.springframework.stereotype.Repository;

import cn.com.ut.biz.store.dao.StoreBindClassDAO;
import cn.com.ut.biz.store.entities.StoreBindClass;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

@Repository
public class StoreBindClassDAOImpl extends JdbcOperationsImpl<StoreBindClass>
		implements StoreBindClassDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, new String[] { store_id, gc_id, storebindclass_state }, NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo, new String[] { store_id, gc_id, storebindclass_state })
						.append(id, DateTimeUtil.currentDateTime(),
								vo.get(StoreBindClass.create_id))
						.toArray());
		return id;
	}

	@Override
	public List<Map<String, Object>> getClassByStoreIds(List<String> storeIdList) {

		SQLHelper table = SQLHelper.builder();
		table.append("ds_storebindclass").append(" s WHERE s.store_id {IN} AND s.is_del = 'N' ");
		String tableSql = replaceInCase(table.toSQL(), new int[] { storeIdList.size() });
		List<Object> args = new ArrayList<>();
		args.addAll(storeIdList);
		return queryPage(null, null, tableSql, true, new String[] { StoreBindClass.gc_id }, null,
				null, null, null, null, args.toArray());

	}

	public int update(Map<String, Object> vo) {

		return updateById(null, new String[] { store_id, gc_id, storebindclass_state },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo, new String[] { store_id, gc_id, storebindclass_state })
						.append(DateTimeUtil.currentDateTime(), vo.get(StoreBindClass.update_id))
						.toArray(),
				(String) vo.get(StoreBindClass.idx), null);
	}

	@Override
	public List<Map<String, Object>> getBindClassId(String storeId) {

		return query(null, null, null, new String[] { StoreBindClass.gc_id }, null,
				new String[] { StoreBindClass.store_id }, new Object[] { storeId });
	}
}
