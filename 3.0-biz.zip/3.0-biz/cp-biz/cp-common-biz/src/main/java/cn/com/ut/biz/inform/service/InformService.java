
//-----------------------------Service-start---------------------------------//
package cn.com.ut.biz.inform.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;

/**
 * Service
 * 
 * @author 
 * @since 
 */
public interface InformService {
	
	
}
//-----------------------------Service-end---------------------------------//