package cn.com.ut.biz.goodsattribute.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.goodsattribute.entities.Attribute;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 商品属性DAO
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface AttributeDAO extends JdbcOperation<Attribute> {

	/**
	 * 查询商品属性列表（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);
}
