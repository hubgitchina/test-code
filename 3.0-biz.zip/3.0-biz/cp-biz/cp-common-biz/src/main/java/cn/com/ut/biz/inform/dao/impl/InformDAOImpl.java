
//-----------------------------DAOImpl-start---------------------------------//
package cn.com.ut.biz.inform.dao.impl;

import static cn.com.ut.biz.inform.entities.Inform.inform_handle_datetime;
import static cn.com.ut.biz.inform.entities.Inform.informsubject_id;
import static cn.com.ut.biz.inform.entities.Inform.inform_datetime;
import static cn.com.ut.biz.inform.entities.Inform.inform_store_name;
import static cn.com.ut.biz.inform.entities.Inform.informsubject_content;
import static cn.com.ut.biz.inform.entities.Inform.inform_handle_type;
import static cn.com.ut.biz.inform.entities.Inform.inform_goods_name;
import static cn.com.ut.biz.inform.entities.Inform.inform_goods_id;
import static cn.com.ut.biz.inform.entities.Inform.inform_member_id;
import static cn.com.ut.biz.inform.entities.Inform.inform_store_id;
import static cn.com.ut.biz.inform.entities.Inform.inform_member_name;
import static cn.com.ut.biz.inform.entities.Inform.inform_image;
import static cn.com.ut.biz.inform.entities.Inform.inform_handle_message;
import static cn.com.ut.biz.inform.entities.Inform.inform_goods_image;
import static cn.com.ut.biz.inform.entities.Inform.inform_content;
import static cn.com.ut.biz.inform.entities.Inform.inform_state;
import static cn.com.ut.biz.inform.entities.Inform.inform_handle_member_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.inform.dao.InformDAO;
import cn.com.ut.biz.inform.entities.Inform;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ArrayUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

@Repository
public class InformDAOImpl extends JdbcOperationsImpl<Inform> implements InformDAO {
	
	
	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, new String[]{inform_handle_datetime, informsubject_id, inform_datetime, inform_store_name, informsubject_content, inform_handle_type, inform_goods_name, inform_goods_id, inform_member_id, inform_store_id, inform_member_name, inform_image, inform_handle_message, inform_goods_image, inform_content, inform_state, inform_handle_member_id}, NAMES_ID_CT_CID, ParameterBuilder.builder().append(vo, new String[]{inform_handle_datetime, informsubject_id, inform_datetime, inform_store_name, informsubject_content, inform_handle_type, inform_goods_name, inform_goods_id, inform_member_id, inform_store_id, inform_member_name, inform_image, inform_handle_message, inform_goods_image, inform_content, inform_state, inform_handle_member_id})
				.append(id, DateTimeUtil.currentDateTime(), vo.get(Inform.create_id)).toArray());
		return id;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null, new String[]{inform_handle_datetime, informsubject_id, inform_datetime, inform_store_name, informsubject_content, inform_handle_type, inform_goods_name, inform_goods_id, inform_member_id, inform_store_id, inform_member_name, inform_image, inform_handle_message, inform_goods_image, inform_content, inform_state, inform_handle_member_id}, NAMES_UT_UID, null,
				ParameterBuilder.builder().append(vo, new String[]{inform_handle_datetime, informsubject_id, inform_datetime, inform_store_name, informsubject_content, inform_handle_type, inform_goods_name, inform_goods_id, inform_member_id, inform_store_id, inform_member_name, inform_image, inform_handle_message, inform_goods_image, inform_content, inform_state, inform_handle_member_id})
						.append(DateTimeUtil.currentDateTime(), vo.get(Inform.update_id)).toArray(),
				(String) vo.get(Inform.idx), null);
	}
}
//-----------------------------DAOImpl-end---------------------------------//