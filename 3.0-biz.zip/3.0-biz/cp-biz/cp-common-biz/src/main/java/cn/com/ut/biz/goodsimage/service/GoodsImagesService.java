package cn.com.ut.biz.goodsimage.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 商品图片业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface GoodsImagesService {

	/**
	 * 添加商品图片
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 修改商品图片
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询商品图片详情
	 */
	Map<String, Object> getDetail(Map<String, Object> vo);

	/**
	 * 删除商品图片
	 * 
	 * @param id
	 * @param appId
	 */
	void delete(Map<String, Object> vo);

	/**
	 * 查询所有的商品图片（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);

	/**
	 * 根据商品ID查询所有的商品图片
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> findByGoodsId(Map<String, Object> vo);

	/**
	 * 设置商品默认图片
	 * 
	 * @param vo
	 * @return
	 */
	int setDefaultImage(Map<String, Object> vo);
}
