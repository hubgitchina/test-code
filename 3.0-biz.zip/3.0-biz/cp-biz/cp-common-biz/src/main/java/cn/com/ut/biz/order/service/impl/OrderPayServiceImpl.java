
package cn.com.ut.biz.order.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;

import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.order.dao.OrderDAO;
import cn.com.ut.biz.order.dao.OrderPayDAO;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.entities.OrderCommon;
import cn.com.ut.biz.order.entities.OrderPay;
import cn.com.ut.biz.order.service.OrderPayService;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 订单Service层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
@Service
public class OrderPayServiceImpl implements OrderPayService {

	@Autowired
	private OrderDAO orderDAO;

	@Autowired
	private OrderPayDAO orderPayDAO;

	@Override
	public void payOrder(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, OrderCommon.order_id, OrderPay.pay_sn,
				Order.payment_time, "pay_state");
		String orderId = (String) vo.get(OrderCommon.order_id);
		Map<String, Object> order = orderDAO.getById(null, null, new String[] { Order.buyer_id },
				null, orderId);
		if (CollectionUtil.isEmptyMap(order)) {
			ExceptionUtil.throwValidateException("订单不存在");
		}
		String payTime = (String) vo.get(Order.payment_time);
		orderDAO.updateById(null, new String[] { Order.order_state, Order.payment_time }, null,
				new Object[] { Const.OrderStatusEnum.PAID.getCode(), payTime }, orderId);

		String buyerId = (String) order.get(Order.buyer_id);
		String payState = (String) vo.get("pay_state");
		String paySn = (String) vo.get(OrderPay.pay_sn);
		Map<String, Object> orderPay = Maps.newHashMapWithExpectedSize(3);
		orderPay.put(OrderPay.pay_sn, paySn);
		orderPay.put(OrderPay.buyer_id, buyerId);
		orderPay.put(OrderPay.api_paystate, payState);
		orderPayDAO.add(orderPay);
	}
}
