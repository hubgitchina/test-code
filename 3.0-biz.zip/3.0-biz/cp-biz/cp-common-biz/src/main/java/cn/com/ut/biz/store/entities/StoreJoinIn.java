package cn.com.ut.biz.store.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class StoreJoinIn extends BaseEntity {

}
