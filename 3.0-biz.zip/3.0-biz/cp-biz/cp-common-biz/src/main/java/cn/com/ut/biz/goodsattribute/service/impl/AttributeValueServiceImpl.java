package cn.com.ut.biz.goodsattribute.service.impl;

import static cn.com.ut.biz.goodsattribute.entities.AttributeValue.attr_id;
import static cn.com.ut.biz.goodsattribute.entities.AttributeValue.attrvalue_name;
import static cn.com.ut.biz.goodsattribute.entities.AttributeValue.sort;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.user_id;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;

import cn.com.ut.biz.goods.util.ConstGoodsUtil;
import cn.com.ut.biz.goodsattribute.dao.AttributeValueDAO;
import cn.com.ut.biz.goodsattribute.entities.AttributeValue;
import cn.com.ut.biz.goodsattribute.service.AttributeValueService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 商品属性值业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Service
public class AttributeValueServiceImpl implements AttributeValueService {

	@Autowired
	private AttributeValueDAO attributeValueDAO;

	private static String[] checkCols = { attrvalue_name, attr_id, is_del };

	@Override
	public void updateAttrValue(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, attr_id);

		// 获取规格json集合
		String attrValues = TypeConvert.getStringValue(vo.get(ConstGoodsUtil.ATTR_VALUES));
		if (CommonUtil.isEmpty(attrValues)) {
			ExceptionUtil.throwValidateException("未设置属性值参数");
		}

		JSONArray attrValueArray = JSONObject.parseArray(attrValues);
		if (CollectionUtil.isEmptyCollection(attrValueArray)) {
			ExceptionUtil.throwValidateException("未设置属性值参数");
		}

		String userId = (String) vo.get(user_id);
		String attrId = (String) vo.get(attr_id);

		List<Map<String, Object>> addAttrValueVos = new ArrayList<>(attrValueArray.size());
		Timestamp now = DateTimeUtil.currentDateTime();
		List<String> attrValueNames = new ArrayList<>(attrValueArray.size());
		for (int i = 0; i < attrValueArray.size(); i++) {
			JSONObject attrValue = attrValueArray.getJSONObject(i);

			ValidatorUtil.validateMapContainsKey(attrValue, attrvalue_name, sort);

			String valueName = attrValue.getString(attrvalue_name);
			String sort = attrValue.getString(AttributeValue.sort);

			// 判断添加的属性值集合中是否存在重名的情况
			if (attrValueNames.contains(valueName)) {
				ExceptionUtil.throwValidateException("添加属性值名称重复");
			}
			attrValueNames.add(valueName);

			Map<String, Object> attrValueVo = Maps.newHashMapWithExpectedSize(8);
			attrValueVo.put(idx, CommonUtil.getUUID());
			attrValueVo.put(create_id, userId);
			attrValueVo.put(create_time, now);
			attrValueVo.put(update_id, userId);
			attrValueVo.put(update_time, now);
			attrValueVo.put(attr_id, attrId);
			attrValueVo.put(attrvalue_name, valueName);
			attrValueVo.put(AttributeValue.sort, sort);

			addAttrValueVos.add(attrValueVo);
		}

		// 先删除原有属性关联的属性值（一对多）
		attributeValueDAO.delete(null, new String[] { attr_id }, new Object[] { attrId });

		String[] names = new String[] { idx, create_id, create_time, update_id, update_time,
				attr_id, attrvalue_name, sort };
		attributeValueDAO.addVoBatch(null, names, null, addAttrValueVos);
	}

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, attr_id, attrvalue_name, sort);

		String userId = (String) vo.get(user_id);
		vo.put(create_id, userId);

		boolean isCanAdd = attributeValueDAO.checkUnique(checkCols,
				new Object[] { vo.get(attrvalue_name), vo.get(attr_id), ConstantUtil.FLAG_NO },
				null, null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("当前商品属性下属性值名称重复");
		}

		String valueId = attributeValueDAO.insert(vo);

		return valueId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, idx, attr_id, attrvalue_name, sort);

		String userId = (String) vo.get(user_id);
		vo.put(update_id, userId);

		String valueId = (String) vo.get(idx);
		boolean isCanUpdate = attributeValueDAO.checkUnique(checkCols,
				new Object[] { vo.get(attrvalue_name), vo.get(attr_id), ConstantUtil.FLAG_NO },
				new String[] { idx }, new Object[] { valueId });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("当前商品属性下属性值名称重复");
		}

		attributeValueDAO.update(vo);
		return valueId;
	}

	@Override
	public Map<String, Object> getDetail(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstGoodsUtil.ATTRVALUE_ID);

		String valueId = (String) vo.get(ConstGoodsUtil.ATTRVALUE_ID);

		return attributeValueDAO.getById(null, null,
				new String[] { idx, attr_id, attrvalue_name, sort }, null, valueId);
	}

	@Override
	public void delete(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, ConstGoodsUtil.ATTRVALUE_ID);

		String userId = (String) vo.get(user_id);
		String valueId = (String) vo.get(ConstGoodsUtil.ATTRVALUE_ID);

		attributeValueDAO.deleteUpdateById(null, new String[] { update_id, update_time },
				new Object[] { ConstantUtil.FLAG_YES, userId, DateTimeUtil.currentDateTime() },
				valueId);
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		return attributeValueDAO.findAllPage(page);
	}

}
