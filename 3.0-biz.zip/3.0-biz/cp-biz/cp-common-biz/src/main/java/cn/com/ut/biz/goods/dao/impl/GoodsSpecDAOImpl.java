package cn.com.ut.biz.goods.dao.impl;

import static cn.com.ut.biz.goods.entities.GoodsSpec.goods_storage;
import static cn.com.ut.biz.goods.entities.GoodsSpec.specparam_id;
import static cn.com.ut.biz.goodsspec.entities.Spec.sort;
import static cn.com.ut.biz.goodsspec.entities.Spec.sp_name;
import static cn.com.ut.biz.goodsspec.entities.Spec.type_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.goods.dao.GoodsSpecDAO;
import cn.com.ut.biz.goods.entities.GoodsSpec;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 商品规格信息DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Repository
public class GoodsSpecDAOImpl extends JdbcOperationsImpl<GoodsSpec> implements GoodsSpecDAO {

	private static String[] columns = { sp_name, type_id, sort };

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();

		add(null, columns, NAMES, ParameterBuilder.builder().append(vo, columns)
				.append(id, time, time, vo.get(create_id), vo.get(create_id)).toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		return updateById(null, columns, NAMES_UT_UID,
				ParameterBuilder.builder().append(vo, columns)
						.append(DateTimeUtil.currentDateTime(), vo.get(update_id)).toArray(),
				(String) vo.get(idx));
	}

	@Override
	public void batchUpdateGoodsStorage(List<Map<String, Object>> goodsSpecList) {

		List<Object[]> args = goodsSpecList.stream()
				.map(e -> new Object[] { e.get(goods_storage), e.get(specparam_id) })
				.collect(Collectors.toList());
		batchUpdate(getJdbcTemplate(),
				"UPDATE ds_goodsspec SET goods_storage=? WHERE specparam_id=?", args);

	}

	@Override
	public Map<String, Object> getBySpecParamId(String specParamId) {

		return getByProperties(new String[] { "specparam_id" }, new Object[] { specParamId });
	}

}
