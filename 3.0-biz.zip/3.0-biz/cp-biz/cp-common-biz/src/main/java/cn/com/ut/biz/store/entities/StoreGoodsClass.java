
//------------------------------entity-start--------------------------------//
package cn.com.ut.biz.store.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class StoreGoodsClass extends BaseEntity {


	/**
     * 店铺ID
     */
    public static final String store_id = "store_id";
	/**
     * 树型结构层级，使用数字表示
     */
    public static final String level = "level";
	/**
     * 分类完整路径，上级分类ID加下划线拼接分类ID
     */
    public static final String gc_full_path = "gc_full_path";
	/**
     * 店铺商品分类名称
     */
    public static final String storegc_name = "storegc_name";
	/**
     * 商品分类排序
     */
    public static final String sort = "sort";
	/**
     * 上级ID
     */
    public static final String storegc_parent_id = "storegc_parent_id";
	/**
     * 店铺商品分类状态
     */
    public static final String storegc_state = "storegc_state";
}
//------------------------------entity-end--------------------------------//
