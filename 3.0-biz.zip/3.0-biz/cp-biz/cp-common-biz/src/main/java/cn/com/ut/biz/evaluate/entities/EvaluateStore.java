package cn.com.ut.biz.evaluate.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 店铺评分表 ds_evaluatestore
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
public class EvaluateStore extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2559053151281364833L;
	/**
	 * 订单ID
	 */
	public static final String seval_orderid = "seval_orderid";
	/**
	 * 订单编号
	 */
	public static final String seval_orderno = "seval_orderno";
	/**
	 * 评价时间
	 */
	public static final String seval_addtime = "seval_addtime";
	/**
	 * 店铺ID
	 */
	public static final String seval_storeid = "seval_storeid";
	/**
	 * 店铺名称
	 */
	public static final String seval_storename = "seval_storename";
	/**
	 * 买家ID
	 */
	public static final String seval_memberid = "seval_memberid";
	/**
	 * 买家名称
	 */
	public static final String seval_membername = "seval_membername";
	/**
	 * 描述相符评分
	 */
	public static final String seval_desccredit = "seval_desccredit";
	/**
	 * 服务态度评分
	 */
	public static final String seval_servicecredit = "seval_servicecredit";
	/**
	 * 发货速度评分
	 */
	public static final String seval_deliverycredit = "seval_deliverycredit";
}
