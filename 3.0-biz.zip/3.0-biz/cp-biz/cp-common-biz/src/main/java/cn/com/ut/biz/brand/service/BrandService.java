package cn.com.ut.biz.brand.service;


import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.restful.ResponseWrap;


import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/4/26.
 */
public interface BrandService {

    /**
     * 创建品牌
     *
     * @param brandDto
     * @return
     */
    String add(Map<String, Object> brandDto);

    /**
     * 删除品牌
     *
     * @param brandId
     * @return
     */
    ResponseWrap deleteById(String brandId);

    /**
     * 根据id获取一条品牌记录
     *
     * @param id
     * @return
     */
    Map<String, Object> getOne(String id);

    /**
     * 查询品牌列表（支持根据品牌名称的模糊查询）
     *
     * @param condition
     * @return
     */
    List<Map<String, Object>> query(Map<String, Object> condition, PageBean pageBean);

    /**
     * 更新品牌
     *
     * @param brandDto
     * @return
     */
    ResponseWrap update(Map<String, Object> brandDto);
}
