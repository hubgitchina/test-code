package cn.com.ut.biz.goodsclass.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.goodsclass.dao.GoodsClassDAO;
import cn.com.ut.biz.goodsclass.entity.GoodsClass;
import cn.com.ut.biz.goodsclass.service.GoodsClassService;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * Created by zhouquanguo on 2018/4/28.
 */
@Service
public class GoodsClassServiceImpl implements GoodsClassService {

	@Autowired
	private GoodsClassDAO goodsClassDAO;

	private static final String[] COLUMNNS = { GoodsClass.gc_name, GoodsClass.type_id,
			GoodsClass.gc_parent_id, GoodsClass.gc_full_path, GoodsClass.gc_virtual,
			GoodsClass.level, GoodsClass.sort };

	@Override
	public String add(Map<String, Object> categoryDto) {

		ValidatorUtil.validateMapContainsKey(categoryDto, GoodsClass.gc_name, GoodsClass.type_id,
				GoodsClass.gc_virtual, GoodsClass.sort, Const.USER_ID);
		categoryDto.put(GoodsClass.create_id, categoryDto.get(Const.USER_ID));
		// 判断同一层级下是否有同名的分类名称（同一层级下不可以有同一名称的分类名称，不同层级下可以有同名的分类名称）
		List<Map<String, Object>> checkResultList = goodsClassDAO.checkExist(
				(String) categoryDto.get(GoodsClass.gc_name),
				(String) categoryDto.get(GoodsClass.gc_parent_id), null);
		if (!CollectionUtil.isEmptyCollection(checkResultList)) {
			ExceptionUtil.throwValidateException("分类名称重复");
		}
		String parentId = (String) categoryDto.get(GoodsClass.gc_parent_id);
		// 根据id来查询父类level,如果为空的话就是root节点
		int currentLevel = getParentLevel(parentId);
		categoryDto.put(GoodsClass.level, currentLevel);
		String currentId = goodsClassDAO.add(COLUMNNS, categoryDto);
		// 获得新增后的id后来拼接更新当前记录的gc_full_path，例如ee38369c4022446b8746a97abcf63a50_0a8c6496967b44ab99d293dbc100a4e5
		categoryDto.put(GoodsClass.idx, currentId);
		StringBuffer stringBuffer = new StringBuffer(
				(String) categoryDto.get(GoodsClass.gc_parent_id));
		String gc_full_path = currentId;
		if (currentLevel > 0) {
			gc_full_path = findFullPath((String) categoryDto.get(GoodsClass.gc_parent_id),
					currentLevel, stringBuffer) + "_" + currentId;
		}
		categoryDto.put(GoodsClass.gc_full_path, gc_full_path);
		goodsClassDAO.update(new String[] { GoodsClass.gc_full_path }, categoryDto);
		return currentId;

	}

	// 获取父类的level
	private int getParentLevel(String parentId) {

		if (StringUtils.isBlank(parentId)) {
			return 0;
		}
		Map<String, Object> goodsClass = goodsClassDAO.get(parentId);
		if (goodsClass == null) {
			return 0;
		}
		return (Integer) goodsClass.get(GoodsClass.level) + 1;
	}

	@Override
	public void delete(String id) {

		Map<String, Object> category = goodsClassDAO.get(id);
		if (category == null || category.size() < 1) {
			ExceptionUtil.throwValidateException("待删除的分类不存在");
		}

		List<Object> idList = new ArrayList<>();
		List<Map<String, Object>> categoryList = queryAllChildrenCategory(id);
		// 如果当前分类下有子分类的话，递归的对子分类进行逻辑删除
		if (CollectionUtils.isNotEmpty(categoryList)) {
			idList = categoryList.stream().map(e -> e.get(GoodsClass.idx))
					.collect(Collectors.toList());
		}
		idList.add(id);
		goodsClassDAO.batchUpdateDelStatus(idList.toArray());

	}

	@Override
	public List<Map<String, Object>> queryChildrenParallel(String categoryId) {

		return goodsClassDAO.queryChildrenParallel(categoryId);

	}

	@Override
	public List<Map<String, Object>> queryAllChildrenCategory(String categoryId) {

		List<Map<String, Object>> goodsCategoryList = new ArrayList<>();
		findAllChildrenCategory(goodsCategoryList, categoryId);
		// 查询当前节点的信息
		if (StringUtils.isNotEmpty(categoryId)) {
			List<Map<String, Object>> currentCategory = getCategoryByCategoryId(
					Arrays.asList(categoryId));
			goodsCategoryList.addAll(currentCategory);
		}
		return goodsCategoryList;
	}

	@Override
	public void update(Map<String, Object> categoryDto) {

		ValidatorUtil.validateMapContainsKey(categoryDto, GoodsClass.gc_name, GoodsClass.idx,
				GoodsClass.type_id);
		Map<String, Object> before = goodsClassDAO.get((String) categoryDto.get(GoodsClass.idx));
		if (before == null) {
			ExceptionUtil.throwValidateException("待更新的分类不存在");
		}
		String parentId = (String) categoryDto.get(GoodsClass.gc_parent_id);
		// 检查同一层级下更新时是否是同名的gc_name。不同层级下可以有同名的gc_name。
		List<Map<String, Object>> checkResultList = goodsClassDAO.checkExist(
				(String) categoryDto.get(GoodsClass.gc_name), parentId,
				(String) categoryDto.get(GoodsClass.idx));
		if (!CollectionUtil.isEmptyCollection(checkResultList)) {
			ExceptionUtil.throwValidateException("分类名称重复");
		}
		Map<String, Object> after = new HashedMap();
		after.putAll(categoryDto);
		// 如果未改变当前父类的id，则当前分类的层级与gc_full_path都不会改变
		if (!parentId.equals(before.get(GoodsClass.gc_parent_id))) {
			// 根据父类Id重新计算层级(level)
			int currentLevel = getParentLevel(parentId);
			after.put(GoodsClass.level, currentLevel);
			// 重新计算gc_full_path
			StringBuffer stringBuffer = new StringBuffer(parentId);
			String gc_full_path = (String) categoryDto.get(GoodsClass.idx);
			if (currentLevel > 0) {
				gc_full_path = findFullPath(parentId, currentLevel, stringBuffer) + "_"
						+ gc_full_path;
			}
			after.put(GoodsClass.gc_full_path, gc_full_path);
			after.put(GoodsClass.level, currentLevel);
			// 如果当前分类下没有子分类，则不用递归更新其子类的信息
			List<Map<String, Object>> nextLevelChildrenCategory = queryAllChildrenCategory(
					(String) before.get(GoodsClass.idx));
			if (CollectionUtils.isNotEmpty(nextLevelChildrenCategory)) {
				updateWithChild(before, after, nextLevelChildrenCategory);
			}
			goodsClassDAO.updateByPrimaryKey(after);

		} else {
			after.put(GoodsClass.level, before.get(GoodsClass.level));
			after.put(GoodsClass.gc_full_path, before.get(GoodsClass.gc_full_path));
			goodsClassDAO.updateByPrimaryKey(after);
		}

	}

	/**
	 * 递归更新子类的level与gc_full_path
	 * 
	 * @param before
	 * @param after
	 * @param nextLevelChildrenCategory
	 */
	@Transactional
	private void updateWithChild(Map<String, Object> before, Map<String, Object> after,
			List<Map<String, Object>> nextLevelChildrenCategory) {

		Integer levelChangeValue = (Integer) after.get(GoodsClass.level)
				- (Integer) before.get(GoodsClass.level);
		String afterGcFullPath = (String) after.get(GoodsClass.gc_full_path);
		for (Map<String, Object> dept : nextLevelChildrenCategory) {
			Integer level = (Integer) dept.get(GoodsClass.level);
			dept.put(GoodsClass.level, level + levelChangeValue);
			String tempFullPath = (String) dept.get(GoodsClass.gc_full_path);
			String path = tempFullPath
					.substring(tempFullPath.indexOf((String) after.get(GoodsClass.idx)) + 32);
			dept.put(GoodsClass.gc_full_path, StringUtils.join(afterGcFullPath, "_", path));

		}
		goodsClassDAO.batchUpdateLevel(nextLevelChildrenCategory);
	}

	@Override
	public Map<String, Object> queryOne(String categoryId) {

		return goodsClassDAO.getById(null, null, COLUMNNS, null, categoryId);
	}

	@Override
	public List<Map<String, Object>> getCategoryByCategoryId(List<String> categoryIds) {

		List<Map<String, Object>> goodsClassList = goodsClassDAO
				.queryCategoryByCategoryIdList(categoryIds);
		return goodsClassList;

	}

	// 递归查询当前分类的所有子分类
	private void findAllChildrenCategory(List<Map<String, Object>> goodsCategoryList,
			String categoryId) {

		List<Map<String, Object>> categoryList = queryChildrenParallel(categoryId);
		if (CollectionUtils.isNotEmpty(categoryList)) {
			goodsCategoryList.addAll(categoryList);
		}
		for (Map<String, Object> category : categoryList) {
			findAllChildrenCategory(goodsCategoryList, (String) category.get(GoodsClass.idx));
		}

	}

	/**
	 * 根据层级来确定当前分类的gc_full_path
	 */
	private String findFullPath(String gc_parent_id, int level, StringBuffer stringBuffer) {

		if (level == 1) {
			return stringBuffer.toString();
		} else {
			String parentId = (String) goodsClassDAO.get(gc_parent_id).get(GoodsClass.gc_parent_id);
			stringBuffer.insert(0, parentId + "_");
			return findFullPath(parentId, --level, stringBuffer);
		}
	}

	private int lookindex(String string, char s, int expectCount) {

		int count = 0;
		for (int i = 0; i < string.length(); i++) {
			if (string.charAt(i) == s) {
				count++;
				if (count == expectCount)
					return i;
			}
		}
		return -1;
	}

	@Override
	public void getAllChildById(String parentId, List<String> childIds) {

		goodsClassDAO.getAllChildById(parentId, childIds);
	}
}
