package cn.com.ut.biz.common;

import java.math.BigDecimal;

/**
 * BigDecimal工具类
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
public class BigDecimalUtil {
	public static BigDecimal add(double value1, double value2) {

		BigDecimal bigDecimal1 = new BigDecimal(Double.toString(value1));
		BigDecimal bigDecimal2 = new BigDecimal(Double.toString(value2));
		return bigDecimal1.add(bigDecimal2);

	}

	public static BigDecimal subtract(double value1, double value2) {

		BigDecimal bigDecimal1 = new BigDecimal(Double.toString(value1));
		BigDecimal bigDecimal2 = new BigDecimal(Double.toString(value2));
		return bigDecimal1.subtract(bigDecimal2);
	}

	public static BigDecimal multiply(double value1, double value2) {

		BigDecimal bigDecimal1 = new BigDecimal(Double.toString(value1));
		BigDecimal bigDecimal2 = new BigDecimal(Double.toString(value2));
		return bigDecimal1.multiply(bigDecimal2);

	}

	public static BigDecimal divide(double value1, double value2) {

		BigDecimal bigDecimal1 = new BigDecimal(Double.toString(value1));
		BigDecimal bigDecimal2 = new BigDecimal(Double.toString(value2));
		return bigDecimal1.divide(bigDecimal2, 2, BigDecimal.ROUND_HALF_DOWN);// 四舍五入，保留两位小数

	}

}
