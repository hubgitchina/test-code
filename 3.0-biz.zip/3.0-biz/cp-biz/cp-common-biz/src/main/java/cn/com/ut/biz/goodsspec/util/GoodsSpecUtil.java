package cn.com.ut.biz.goodsspec.util;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * 商品规格格式解析，关键字段提取
 * 
 * @author wuxiaohua
 * @since 2018年5月17日
 */
public class GoodsSpecUtil {

	public static final String SPEC_ID = "spec_id";
	public static final String SPEC_NAME = "spec_name";
	public static final String SPECVALUE_ID = "specvalue_id";
	public static final String SPECVALUE_NAME = "specvalue_name";
	public static final String SPEC_PARAM = "spec_param";
	public static final String GOODS_SPEC = "goods_spec";
	public static final String SPEC_CHECKED = "spec_checked";
	public static final String GOODS_PRICE = "goods_price";
	public static final String PRICE_MIN = "price_min";
	public static final String PRICE_MAX = "price_max";
	public static final String PRICE_RANGE = "price_range";

	/**
	 * 商品规格管理时，对规格参数进行解析处理，请求的格式，例如，
	 * 
	 * { "goods_id":"", "goods_spec":[ { "spec_param": [
	 * {"spec_id":"1","spec_name":"颜色","specvalue_id":"1-1","specvalue_name":"红"},
	 * {"spec_id":"2","spec_name":"码数","specvalue_id":"2-1","specvalue_name":"S"}
	 * ], "goods_price":"", "goods_storage":"" }, { "spec_param": [
	 * {"spec_id":"1","spec_name":"颜色","specvalue_id":"1-1","specvalue_name":"红"},
	 * {"spec_id":"2","spec_name":"码数","specvalue_id":"2-2","specvalue_name":"M"}
	 * ], "goods_price":"", "goods_storage":"" }, { "spec_param": [
	 * {"spec_id":"1","spec_name":"颜色","specvalue_id":"1-2","specvalue_name":"黑"},
	 * {"spec_id":"2","spec_name":"码数","specvalue_id":"2-1","specvalue_name":"S"}
	 * ], "goods_price":"", "goods_storage":"" }, { "spec_param": [
	 * {"spec_id":"1","spec_name":"颜色","specvalue_id":"1-2","specvalue_name":"黑"},
	 * {"spec_id":"2","spec_name":"码数","specvalue_id":"2-2","specvalue_name":"M"}
	 * ], "goods_price":"", "goods_storage":"" } ] }
	 * 
	 * 返回购物车可选规格格式，例如，
	 * 
	 * { "spec_checked": {"1":["1-1","1-2"],"2":["2-1","2-2"]}, "goods_spec": [
	 * {"spec_id":"1","spec_name":"颜色", "specvalues":
	 * [{"specvalue_id":"1-1","specvalue_name":"红"},{"specvalue_id":"1-2","specvalue_name":"黑"}]
	 * }, {"spec_id":"2","spec_name":"码数", "specvalues":
	 * [{"specvalue_id":"2-1","specvalue_name":"S"},{"specvalue_id":"2-2","specvalue_name":"M"}]
	 * } ] }
	 * 
	 * @param jaGoodsSpec
	 * @return 购物车可选规格格式
	 * 
	 */
	public static Map<String, Object> handleSpecParamBatch(JSONArray jaGoodsSpec) {

		Map<String, Object> data = new HashMap<>();

		Map<String, SpecVo> goodsSpecCache = new HashMap<>();
		Map<String, Object> specCheckedCache = new HashMap<>();
		TreeSet<BigDecimal> priceSet = new TreeSet<>();

		for (int i = 0; i < jaGoodsSpec.size(); i++) {
			JSONObject joSpec = jaGoodsSpec.getJSONObject(i);
			JSONArray jaSpecParam = joSpec.getJSONArray(SPEC_PARAM);
			priceSet.add(joSpec.getBigDecimal(GOODS_PRICE));
			for (int j = 0; j < jaSpecParam.size(); j++) {
				JSONObject joSpecParam = jaSpecParam.getJSONObject(j);
				String specId = joSpecParam.getString(SPEC_ID);
				String specName = joSpecParam.getString(SPEC_NAME);
				String specvalueId = joSpecParam.getString(SPECVALUE_ID);
				String specvalueName = joSpecParam.getString(SPECVALUE_NAME);
				SpecVo specVo = null;

				if ((specVo = goodsSpecCache.get(specId)) == null) {
					specVo = new SpecVo();
					specVo.setSpec_id(specId);
					specVo.setSpec_name(specName);
					goodsSpecCache.put(specId, specVo);
				}

				TreeSet<SpecValueVo> specvaluesCache = specVo.getSpecvalues();

				SpecValueVo specValueVo = new SpecValueVo();
				specValueVo.setSpecvalue_id(specvalueId);
				specValueVo.setSpecvalue_id(specvalueName);
				if (!specvaluesCache.contains(specValueVo)) {
					specvaluesCache.add(specValueVo);
				}

				Set<String> specValues = null;
				if (specCheckedCache.containsKey(specId)) {
					specValues = (Set<String>) specCheckedCache.get(specId);

				} else {
					specValues = new HashSet<>();
					specCheckedCache.put(specId, specValues);
				}

				specValues.add(specvalueId);

			}
		}

		Collection<SpecVo> goodsSpecVos = goodsSpecCache.values();
		data.put(GOODS_SPEC, goodsSpecVos);
		data.put(SPEC_CHECKED, specCheckedCache);

		// price range
		Map<String, BigDecimal> priceRange = new HashMap<>();
		priceRange.put(PRICE_MIN, priceSet.first());
		priceRange.put(PRICE_MAX, priceSet.last());
		data.put(PRICE_RANGE, priceRange);

		return data;

	}

	/**
	 * 商品规格管理时或添加购物车时，对规格参数进行解析处理，请求格式，例如，
	 * 
	 * { "spec_param": [
	 * {"spec_id":"1","spec_name":"颜色","specvalue_id":"1-1","specvalue_name":"红"},
	 * {"spec_id":"2","spec_name":"码数","specvalue_id":"2-2","specvalue_name":"M"}
	 * ], "goods_price":"", "goods_storage":"" }
	 * 
	 * 返回规格参数ID，按spec_id排序，拼接格式为spec_id:specvalue_id,spec_id:specvalue_id；
	 * 例如，"specparam_name":"颜色:黑,码数:M"
	 * 规格参数名称，按spec_id排序，拼接格式为spec_name:specvalue_name,spec_name:specvalue_name
	 * 例如， "specparam_id":"1:1-2,2:2-2"
	 * 
	 * @param joSpecParam
	 * @return
	 */
	public static SpecParamVo handleSpecParamSingle(JSONObject joSpecParam) {

		JSONArray jaSpecParam = joSpecParam.getJSONArray(SPEC_PARAM);
		TreeMap<String, Map<String, Object>> treeMap = new TreeMap<>();

		for (int i = 0; i < jaSpecParam.size(); i++) {
			JSONObject joSpec = jaSpecParam.getJSONObject(i);
			treeMap.put(joSpec.getString(SPEC_ID), joSpec);
		}

		StringBuilder specParamId = new StringBuilder();
		StringBuilder specParamName = new StringBuilder();
		for (Map<String, Object> specValue : treeMap.values()) {

			if (specParamId.length() > 0) {
				specParamId.append(",");
				specParamName.append(",");
			}
			specParamId.append(specValue.get(SPEC_ID)).append(":")
					.append(specValue.get(SPECVALUE_ID));
			specParamName.append(specValue.get(SPEC_NAME)).append(":")
					.append(specValue.get(SPECVALUE_NAME));
		}

		SpecParamVo specParamVo = new SpecParamVo();

		specParamVo.setSpecparam_id(specParamId.toString());
		specParamVo.setSpecparam_name(specParamName.toString());

		return specParamVo;
	}
}
