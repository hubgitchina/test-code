package cn.com.ut.biz.refundreturn.service;

import cn.com.ut.core.restful.ResponseWrap;
import java.util.Map;

/**
 * 退货退款业务层
 * 
 * @author zhouquanguo
 * @since on 2018/6/4.
 */
public interface RefundReturnService {

	/**
	 * 买家提交退款申请
	 * 
	 * @param vo
	 */
	String buyerSubmit(Map<String, Object> vo);

	/**
	 * 买家取消退款申请
	 * 
	 * @param vo
	 */
	void buyerCancel(Map<String, Object> vo);

	/**
	 * 卖家处理退款申请
	 * 
	 * @param vo
	 */
	void sellerDeal(Map<String, Object> vo);

	/**
	 * 买家发货
	 * 
	 * @param vo
	 */
	void buyerDelivery(Map<String, Object> vo);

	/**
	 * 商家收货
	 * 
	 * @param vo
	 */
	void sellerReceive(Map<String, Object> vo);

	/**
	 * 商家查询退款申请列表
	 * 
	 * @param vo
	 * @return
	 */
	ResponseWrap queryBySeller(Map<String, Object> vo);

	/**
	 * 买家查询退款申请列表
	 * 
	 * @param vo
	 * @return
	 */
	ResponseWrap queryByBuyer(Map<String, Object> vo);

	/**
	 * 查看退款处理详情
	 * 
	 * @param vo
	 * @return
	 */
	Map<String, Object> getRefund(Map<String, Object> vo);
}