package cn.com.ut.biz.goodstype.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * Created by zhouquanguo on 2018/5/9.
 */
public class GoodsType extends BaseEntity {

    private static final long serialVersionUID = 7621542851087659558L;
    /**
     * 类型名称
     */
    public static final String type_name = "type_name";
    /**
     * 类型排序
     */
    public static final String sort = "sort";


}
