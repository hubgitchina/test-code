package cn.com.ut.biz.goodsimage.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品图片表 ds_goodsimages
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public class GoodsImages extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7621542851087659557L;
	/**
	 * 商品公共ID
	 */
	public static final String goods_id = "goods_id";
	/**
	 * 店铺ID
	 */
	public static final String store_id = "store_id";
	/**
	 * 商品图片
	 */
	public static final String image_path = "image_path";
	/**
	 * 商品图片排序
	 */
	public static final String sort = "sort";
	/**
	 * 商品图片默认主图，1是，0否
	 */
	public static final String is_default = "is_default";
}
