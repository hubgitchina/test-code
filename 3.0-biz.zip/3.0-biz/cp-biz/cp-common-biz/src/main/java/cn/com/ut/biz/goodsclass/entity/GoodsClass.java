package cn.com.ut.biz.goodsclass.entity;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * Created by zhouquanguo on 2018/4/27.
 */
public class GoodsClass extends BaseEntity {

	/**
	 * 商品分类名称.
	 */
	public static final String gc_name = "gc_name";
	/**
	 * 类型id.
	 */
	public static final String type_id = "type_id";
	/**
	 * 商品分类上级ID.
	 */
	public static final String gc_parent_id = "gc_parent_id";
	/**
	 * 商品分类排序.
	 */
	public static final String sort = "sort";
	/**
	 * 是否允许发布虚拟商品 1:是 0:否.
	 */
	public static final String gc_virtual = "gc_virtual";
	/**
	 * 商品分类前台显示 0:否 1:是.
	 */
	public static final String gc_show = "gc_show";
	/**
	 * 分类完整路径，上级分类ID加下划线拼接分类ID.
	 */
	public static final String gc_full_path = "gc_full_path";
	/**
	 * 树型结构层级，使用数字表示.
	 */
	public static final String level = "level";
}
