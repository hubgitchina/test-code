package cn.com.ut.biz.goodsclass.dao.impl;

import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import cn.com.ut.biz.goodsclass.dao.GoodsClassDAO;
import cn.com.ut.biz.goodsclass.entity.GoodsClass;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * Created by zhouquanguo on 2018/4/28.
 */
@Repository
public class GoodsClassDAOImpl extends JdbcOperationsImpl<GoodsClass> implements GoodsClassDAO {

	private static final String[] COLUMNNS = { GoodsClass.gc_name, GoodsClass.type_id,
			GoodsClass.gc_parent_id, GoodsClass.gc_full_path, GoodsClass.gc_virtual,
			GoodsClass.level, GoodsClass.sort };

	@Override
	public List<Map<String, Object>> queryChildrenParallel(String id) {

		return query(null, null, null, COLUMNNS, new String[] { BaseEntity.idx },
				new String[] { GoodsClass.gc_parent_id }, new Object[] { id });
	}

	@Override
	public List<Map<String, Object>> checkExist(String gcName, String parentId, String currentId) {

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT 1 from ").append("ds_goodsclass").append(" g WHERE g.gc_name = ? ");
		List<Object> args = new ArrayList<>();
		args.add(gcName);
		if (StringUtils.isNotBlank(parentId)) {
			sql.append(" AND ");
			sql.append("g.gc_parent_id =?");
			args.add(parentId);
		}
		if (StringUtils.isNotBlank(currentId)) {
			sql.append(" AND ");
			sql.append("g.id <> ?");
			args.add(currentId);
		}

		List<Map<String, Object>> list = query(getJdbcTemplate(), sql.toString(), null,
				args.toArray());
		return list;
	}

	@Override
	@Transactional
	public void batchUpdateDelStatus(Object[] idArrray) {

		SQLHelper table = SQLHelper.builder();
		table.append("update ds_goodsclass g set is_del ='Y'").append(" WHERE g.id {IN}");
		String tableSql = replaceInCase(table.toSQL(), new int[] { idArrray.length });
		List list = new ArrayList();
		list.add(idArrray);
		batchUpdate(getJdbcTemplate(), tableSql.toString(), list);

	}

	@Override
	public void batchUpdateLevel(List<Map<String, Object>> nextLevelChildrenCategory) {

		SQLHelper table = SQLHelper.builder();
		table.append("UPDATE ds_goodsclass g SET g.level =?,g.gc_full_path=?")
				.append(" WHERE g.id=?");
		List<Object[]> args = nextLevelChildrenCategory
				.stream().map(e -> new Object[] { e.get(GoodsClass.level),
						e.get(GoodsClass.gc_full_path), e.get(GoodsClass.idx) })
				.collect(Collectors.toList());
		batchUpdate(getJdbcTemplate(), table.toSQL(), args);

	}

	@Override
	public void updateByPrimaryKey(Map<String, Object> after) {

		updateById(null, COLUMNNS, null,
				new Object[] { after.get(GoodsClass.gc_name), after.get(GoodsClass.type_id),
						after.get(GoodsClass.gc_parent_id), after.get(GoodsClass.gc_full_path),
						after.get(GoodsClass.gc_virtual), after.get(GoodsClass.level),
						after.get(GoodsClass.sort) },
				(String) after.get(GoodsClass.idx));

	}

	@Override
	public List<Map<String, Object>> queryCategoryByCategoryIdList(List<String> categoryIds) {

		SQLHelper table = SQLHelper.builder();
		table.append("ds_goodsclass c WHERE c.id {IN} AND c.is_del = 'N' ");
		String tableSql = replaceInCase(table.toSQL(), new int[] { categoryIds.size() });
		ParameterBuilder param = ParameterBuilder.builder();
		param.appendColumns("c", COLUMNNS);
		param.appendColumns("c", idx);
		List<Object> args = new ArrayList<>();
		args.addAll(categoryIds);
		return queryPage(null, null, tableSql, true, param.toColumns(), null, null, null, null,
				GoodsClass.sort, args.toArray());

	}

	@Override
	public void getAllChildById(String parentId, List<String> childIds) {

		String[] names = { GoodsClass.idx };

		List<Map<String, Object>> childList = queryPage(null, null, null, false, names, null,
				new String[] { GoodsClass.gc_parent_id, GoodsClass.gc_show, GoodsClass.is_del },
				null, null, GoodsClass.create_time,
				new Object[] { parentId, ConstantUtil.FLAG_ONE, ConstantUtil.FLAG_NO });

		if (!CollectionUtil.isEmptyCollection(childList)) {
			for (Map<String, Object> map : childList) {
				String id = (String) map.get(GoodsClass.idx);
				childIds.add(id);
				getAllChildById(id, childIds);
			}
		}
	}
}
