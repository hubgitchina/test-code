package cn.com.ut.biz.evaluate.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 信誉评价表 ds_evaluategoods
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
public class EvaluateGoods extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7825397399892066877L;
	/**
	 * 订单表ID
	 */
	public static final String geval_orderid = "geval_orderid";
	/**
	 * 订单编号
	 */
	public static final String geval_orderno = "geval_orderno";
	/**
	 * 订单商品表编号
	 */
	public static final String geval_ordergoodsid = "geval_ordergoodsid";
	/**
	 * 商品表编号
	 */
	public static final String geval_goodsid = "geval_goodsid";
	/**
	 * 商品名称
	 */
	public static final String geval_goodsname = "geval_goodsname";
	/**
	 * 商品价格
	 */
	public static final String geval_goodsprice = "geval_goodsprice";
	/**
	 * 商品图片
	 */
	public static final String geval_goodsimage = "geval_goodsimage";
	/**
	 * 1-5分
	 */
	public static final String geval_scores = "geval_scores";
	/**
	 * 信誉评价内容
	 */
	public static final String geval_content = "geval_content";
	/**
	 * 是否匿名评价，0不是，1匿名评价
	 */
	public static final String geval_isanonymous = "geval_isanonymous";
	/**
	 * 评价时间
	 */
	public static final String geval_addtime = "geval_addtime";
	/**
	 * 店铺编号
	 */
	public static final String geval_storeid = "geval_storeid";
	/**
	 * 店铺名称
	 */
	public static final String geval_storename = "geval_storename";
	/**
	 * 评价人编号
	 */
	public static final String geval_memberid = "geval_memberid";
	/**
	 * 评价人名称
	 */
	public static final String geval_membername = "geval_membername";
	/**
	 * 评价信息的状态 0为正常 1为禁止显示
	 */
	public static final String geval_state = "geval_state";
	/**
	 * 管理员对评价的处理备注
	 */
	public static final String geval_remark = "geval_remark";
	/**
	 * 解释内容
	 */
	public static final String geval_explain = "geval_explain";
	/**
	 * 晒单图片
	 */
	public static final String geval_image = "geval_image";
}
