package cn.com.ut.biz.user.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class UserAddress extends BaseEntity {

	private static final long serialVersionUID = 1L;

	public static final String user_id = "USER_ID";
	public static final String contact_man = "contact_man";
	public static final String province = "province";
	public static final String city = "city";
	public static final String area = "area";
	public static final String contact_addr = "contact_addr";
	public static final String contact_phone = "contact_phone";
	public static final String is_default = "is_default";
	public static final String position = "position";

}
