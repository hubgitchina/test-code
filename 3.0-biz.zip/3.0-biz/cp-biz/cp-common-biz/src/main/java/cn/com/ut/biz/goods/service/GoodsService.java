package cn.com.ut.biz.goods.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 商品信息业务层接口
 *
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface GoodsService {

	/**
	 * 添加商品信息
	 *
	 * @param vo
	 * @return
	 */
	String addGoods(Map<String, Object> vo);

	/**
	 * 修改商品信息
	 *
	 * @param vo
	 * @return
	 */
	String updateGoods(Map<String, Object> vo);

	/**
	 * 查询商品信息详情
	 */
	Map<String, Object> getGoods(Map<String, Object> vo);

	/**
	 * 删除商品信息
	 *
	 * @param id
	 * @param appId
	 */
	void delete(Map<String, Object> vo);

	/**
	 * 根据店铺ID查询商品信息列表（带分页）
	 *
	 * @param page
	 * @param storeId
	 * @return
	 */
	List<Map<String, Object>> queryStoreGoods(PageBean page, Map<String, Object> vo);

	/**
	 * 查询商城全部商品（带分页）
	 *
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> queryMallGoods(PageBean page);

	/**
	 * 更新商品上下架状态
	 *
	 * @param vo
	 */
	void updateGoodsState(Map<String, Object> vo);

	/**
	 * 更新商品详情页内容
	 *
	 * @param vo
	 */
	void updateGoodsContent(Map<String, Object> vo);

	/**
	 * 获取商品详情页内容
	 */
	Map<String, Object> getGoodsContent(Map<String, Object> vo);

	/**
	 * 根据商品主键查询商品信息
	 *
	 * @param goodsId
	 *            商品主键
	 * @return
	 */
	Map<String, Object> getByGoodsId(String goodsId);

	/**
	 * 批量更新商品的库存
	 * 
	 * @param goodsDoNotHaveSpecList
	 */
	void batchUpdateGoodsStorage(List<Map<String, Object>> goodsDoNotHaveSpecList);

	/**
	 * 查询商品所有规格和规格值
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryAllGoodsSpec(Map<String, Object> vo);

	/**
	 * 查询商品信息详情（消费者查看）
	 */
	Map<String, Object> getGoodsDetail(Map<String, Object> vo);

	/**
	 * 商品搜索（商城首页）
	 * 
	 * @param page
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryIndex(PageBean page, Map<String, Object> vo);

	/**
	 * 店铺商品查询（消费者在店铺搜索商品）
	 * 
	 * @param page
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryGoodsInStore(PageBean page, Map<String, Object> vo);
}
