package cn.com.ut.biz.goodsattribute.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品属性值表 ds_attributevalue
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public class AttributeValue extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1244107581365799010L;
	/**
	 * 属性值名称
	 */
	public static final String attrvalue_name = "attrvalue_name";
	/**
	 * 所属属性ID
	 */
	public static final String attr_id = "attr_id";
	/**
	 * 属性值排序
	 */
	public static final String sort = "sort";
}
