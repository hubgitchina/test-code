
package cn.com.ut.biz.order.service;

import java.util.Map;

/**
 * 订单支付Service层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
public interface OrderPayService {

	/**
	 * 订单支付
	 *
	 * @param vo
	 */
	void payOrder(Map<String, Object> vo);

}
