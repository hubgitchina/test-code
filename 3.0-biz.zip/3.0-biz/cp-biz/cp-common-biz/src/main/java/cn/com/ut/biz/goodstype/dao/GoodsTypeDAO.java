package cn.com.ut.biz.goodstype.dao;


import cn.com.ut.biz.goodstype.entities.GoodsType;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/9.
 */
public interface GoodsTypeDAO extends JdbcOperation<GoodsType> {


    List<Map<String,Object>> findAll( Map<String,Object> vo,PageBean pageBean);
}
