
package cn.com.ut.biz.order.dao.impl;

import static cn.com.ut.biz.order.entities.OrderCommon.*;
import static cn.com.ut.biz.order.entities.OrderCommon.order_id;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.order.dao.OrderCommonDAO;
import cn.com.ut.biz.order.entities.OrderCommon;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 订单公共表DAO层
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
@Repository
public class OrderCommonDAOImpl extends JdbcOperationsImpl<OrderCommon> implements OrderCommonDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null,
				new String[] { reciver_info, deliver_explain, evaluation_time, evalseller_time,
						reciver_name, reciver_city_id, order_message, shipping_express_id,
						evalseller_state, order_id, shipping_time, reciver_province_id },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { reciver_info, deliver_explain, evaluation_time,
										evalseller_time, reciver_name, reciver_city_id,
										order_message, shipping_express_id, evalseller_state,
										order_id, shipping_time, reciver_province_id })
						.append(id, DateTimeUtil.currentDateTime(), vo.get(OrderCommon.create_id))
						.toArray());
		return id;
	}

	@Override
	public List<Map<String, Object>> queryOrderByOrderIdList(List<String> orderIdList) {

		String[] COLUMNS = new String[] { idx, order_id, shipping_time, shipping_express_id,
				order_message, reciver_name, reciver_info, reciver_province_id, reciver_city_id };
		SQLHelper table = SQLHelper.builder();
		table.append("ds_ordercommon").append(" d WHERE d.order_id {IN} AND d.is_del = 'N' ");
		String tableSql = replaceInCase(table.toSQL(), new int[] { orderIdList.size() });
		ParameterBuilder param = ParameterBuilder.builder();
		param.appendColumns("d", COLUMNS);
		List<Object> args = new ArrayList<>();
		args.addAll(orderIdList);
		return queryPage(null, null, tableSql, true, param.toColumns(), null, null, null, null,
				null, args.toArray());

	}

	@Override
	public void updateOrderCommonInfo(Map<String, Object> vo) {

		update(null, new String[] { OrderCommon.order_message, OrderCommon.reciver_info }, null,
				new String[] { order_id }, new Object[] { vo.get(OrderCommon.order_message),
						vo.get(OrderCommon.reciver_info) },
				new Object[] { vo.get(order_id) });
	}

	public int update(Map<String, Object> vo) {

		return updateById(null, new String[] { reciver_info, deliver_explain, evaluation_time,
				evalseller_time, reciver_name, reciver_city_id, order_message, shipping_express_id,
				evalseller_state, order_id, shipping_time, reciver_province_id, shipping_code },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo, new String[] { reciver_info, deliver_explain, evaluation_time,
								evalseller_time, reciver_name, reciver_city_id, order_message,
								shipping_express_id, evalseller_state, order_id, shipping_time,
								reciver_province_id, shipping_code })
						.append(DateTimeUtil.currentDateTime(), vo.get(OrderCommon.update_id))
						.toArray(),
				(String) vo.get(OrderCommon.idx), null);
	}
}
