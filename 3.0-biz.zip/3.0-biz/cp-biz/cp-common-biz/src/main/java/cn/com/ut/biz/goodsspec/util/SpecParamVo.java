package cn.com.ut.biz.goodsspec.util;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
@EqualsAndHashCode(of = { "specparam_id" })
public class SpecParamVo {

	private String specparam_id;
	private String specparam_name;
}
