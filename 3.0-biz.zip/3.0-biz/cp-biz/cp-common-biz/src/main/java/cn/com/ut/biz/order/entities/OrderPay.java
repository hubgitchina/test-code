
package cn.com.ut.biz.order.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 订单支付实体类
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
public class OrderPay extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7348911526632628229L;
	/**
	 * 支付单号
	 */
	public static final String pay_sn = "pay_sn";
	/**
	 * 买家ID
	 */
	public static final String buyer_id = "buyer_id";
	/**
	 * 0默认未支付1已支付(只有第三方支付接口通知到时才会更改此状态)
	 */
	public static final String api_paystate = "api_paystate";
}
