package cn.com.ut.biz.goodsspec.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品规格值表 ds_specvalue
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public class SpecValue extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1441913196642032136L;
	/**
	 * 规格值名称
	 */
	public static final String spvalue_name = "spvalue_name";
	/**
	 * 所属规格ID
	 */
	public static final String sp_id = "sp_id";
	/**
	 * 店铺ID
	 */
	public static final String store_id = "store_id";
	/**
	 * 规格排序
	 */
	public static final String sort = "sort";
}
