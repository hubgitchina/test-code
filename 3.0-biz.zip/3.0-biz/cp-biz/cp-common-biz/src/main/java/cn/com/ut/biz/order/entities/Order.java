
package cn.com.ut.biz.order.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 订单实体类
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
public class Order extends BaseEntity {

	/**
	 * 卖家店铺ID
	 */
	public static final String store_id = "store_id";
	/**
	 * 删除状态 0:未删除 1:放入回收站 2:彻底删除
	 */
	public static final String delete_state = "delete_state";
	/**
	 * 锁定状态:0:正常,大于0:锁定
	 */
	public static final String lock_state = "lock_state";
	/**
	 * 商品总价格
	 */
	public static final String goods_amount = "goods_amount";
	/**
	 * 支付(付款)时间
	 */
	public static final String payment_time = "payment_time";
	/**
	 * 买家姓名
	 */
	public static final String buyer_name = "buyer_name";
	/**
	 * 评价状态 0：未评价 1：已评价 2:已过期未评价
	 */
	public static final String evaluation_state = "evaluation_state";
	/**
	 * 买家ID
	 */
	public static final String buyer_id = "buyer_id";
	/**
	 * 运费
	 */
	public static final String shipping_fee = "shipping_fee";
	/**
	 * 订单完成时间
	 */
	public static final String finnshed_time = "finnshed_time";
	/**
	 * 订单来源，1:PC 2:手机
	 */
	public static final String order_from = "order_from";
	/**
	 * 订单总价格
	 */
	public static final String order_amount = "order_amount";
	/**
	 * 卖家店铺名称
	 */
	public static final String store_name = "store_name";
	/**
	 * 退款金额
	 */
	public static final String refund_amount = "refund_amount";
	/**
	 * 支付单号
	 */
	public static final String pay_sn = "pay_sn";
	/**
	 * 订单生成时间
	 */
	public static final String add_time = "add_time";
	/**
	 * 订单状态：0:已取消 10:未付款 20:已付款 30:已发货 40:已收货
	 */
	public static final String order_state = "order_state";
	/**
	 * 退款状态 0:无退款 1:部分退款 2:全部退款
	 */
	public static final String refund_state = "refund_state";
	/**
	 * 订单类型
	 */
	public static final String order_type = "order_type";
	/**
	 * 订单编号
	 */
	public static final String order_sn = "order_sn";
	/**
	 * 支付方式名称代码
	 */
	public static final String payment_code = "payment_code";
	/**
	 * 延迟时间,默认为0
	 */
	public static final String delay_time = "delay_time";
	/**
	 * 订单商品冗余信息，JSON数组形式
	 */
	public static final String order_goods = "order_goods";
}
