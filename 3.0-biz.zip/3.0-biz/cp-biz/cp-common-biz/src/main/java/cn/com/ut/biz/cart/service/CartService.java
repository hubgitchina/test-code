
package cn.com.ut.biz.cart.service;

import com.alibaba.fastjson.JSONObject;

import java.util.List;
import java.util.Map;

/**
 * Service
 *
 * @author
 */
public interface CartService {

	/**
	 * 查询购物车列表
	 *
	 * @param vo
	 * @return
	 */
	Map<String, Object> list(Map<String, Object> vo);

	/**
	 * 添加购物车
	 *
	 * @param vo
	 * @return
	 */
	String add(JSONObject vo);

	/**
	 * 获得用户右上方的购物车商品数量
	 *
	 * @return
	 */
	Map<String, Object> getCartCount(Map<String, Object> vo);

	/**
	 * 删除购物车商品
	 *
	 * @param vo
	 * @return
	 */
	void delete(Map<String, Object> vo);

	/**
	 * 更新购物车中的商品数量
	 *
	 * @param vo
	 */
	void updateGoodsNumber(Map<String, Object> vo);

	/**
	 * 批量清除购物车列表
	 *
	 * @param orderItemList
	 */
	void batchCleanCart(List<Map<String, Object>> orderItemList);

	/**
	 * 查询当前买家的购物车信息
	 *
	 * @param buyerId
	 * @return
	 */
	Map<String, Object> getCartVoInfo(String buyerId, Object... cartIds);
}
