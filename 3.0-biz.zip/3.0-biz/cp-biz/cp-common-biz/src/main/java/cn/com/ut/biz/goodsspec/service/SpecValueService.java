package cn.com.ut.biz.goodsspec.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 商品规格值业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface SpecValueService {

	/**
	 * 更新商品规格下的规格值（多条规格值批量更新）
	 * 
	 * @param vo
	 */
	void updateSpecValue(Map<String, Object> vo);

	/**
	 * 添加商品规格值
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 修改商品规格值
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询商品规格值详情
	 */
	Map<String, Object> getDetail(Map<String, Object> vo);

	/**
	 * 删除商品规格值
	 * 
	 * @param id
	 * @param appId
	 */
	void delete(Map<String, Object> vo);

	/**
	 * 查询所有的商品规格值（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);
}
