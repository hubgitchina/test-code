
package cn.com.ut.biz.order.service;

import java.util.List;
import java.util.Map;

/**
 * 订单商品表Service层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
public interface OrderGoodsService {

	/**
	 * 批量插入订单详情
	 *
	 * @param orderItemList
	 */
	void batchInsert(List<Map<String, Object>> orderItemList);

	/**
	 * 根据订单ID查询订单商品明细
	 *
	 * @param orderId
	 * @return
	 */
	List<Map<String, Object>> selectByOrderId(String orderId);

	/**
	 * 根据订单ID列表查询订单商品明细
	 *
	 * @param orderIdList
	 * @return
	 */
	List<Map<String, Object>> selectByOrderIdList(List<String> orderIdList);

	/**
	 * 根据主键ID查询订单商品记录
	 * @param orderGoodsId
	 * @return
	 */
	Map<String,Object> getByOrderGoodsId(String orderGoodsId);
}
