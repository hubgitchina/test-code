
package cn.com.ut.biz.order.service;

import java.util.List;
import java.util.Map;

/**
 * 订单公共表Service层
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
public interface OrderCommonService {

	/**
	 * 新增订单公共表
	 *
	 * @param orderCommon
	 * @return
	 */
	String add(Map<String, Object> orderCommon);

	/**
	 * 根据订单ID列表查询订单公共信息
	 *
	 * @param orderIdList
	 * @return
	 */
	List<Map<String, Object>> queryOrderByOrderIdList(List<String> orderIdList);

	/**
	 * 付款前商家修改订单信息
	 */
	void updateOrderCommonInfo(Map<String, Object> vo);

	/**
	 * 更新订单公共表信息
	 */
	int update(Map<String, Object> vo);

	/**
	 * 根据订单ID查询订单公共信息
	 * @param orderId
	 * @return
	 */
	Map<String,Object> getByOrderId(String orderId);
}
