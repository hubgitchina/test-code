
package cn.com.ut.biz.order.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.restful.ResponseWrap;

/**
 * 订单Service层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
public interface OrderService {

	/**
	 * 提交订单
	 *
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> submitOrder(Map<String, Object> vo);

	/**
	 * 取消订单
	 *
	 * @param vo
	 */
	void cancel(Map<String, Object> vo);

	/**
	 * 订单预览
	 *
	 * @param vo
	 */
	Map<String, Object> previewOrder(Map<String, Object> vo);

	/**
	 * 买家订单确认收货
	 *
	 * @param vo
	 */
	void confirmOrder(Map<String, Object> vo);

	/**
	 * 删除订单
	 *
	 * @param vo
	 */
	void deleteOrder(Map<String, Object> vo);

	/**
	 * 付款前商家修改订单信息
	 *
	 * @param vo
	 */
	void modifyOrder(Map<String, Object> vo);

	/**
	 * 查询订单列表
	 *
	 * @param vo
	 */
	ResponseWrap queryOrders(Map<String, Object> vo);

	/**
	 * 查看订单详情
	 *
	 * @param vo
	 * @return
	 */
	ResponseWrap viewOrder(Map<String, Object> vo);

	/**
	 * 商家订单发货
	 *
	 * @param vo
	 * @return
	 */
	ResponseWrap deliver(Map<String, Object> vo);

	/**
	 * 买家订单查询
	 * 
	 * @param vo
	 */
	List<Map<String, Object>> buyerQuery(Map<String, Object> vo);

	/**
	 * 根据主键查询订单信息
	 * @param orderId
	 * @return
	 */
	Map<String,Object> getByOrderId(String  orderId);

	/**
	 * 更新订单信息
	 * @param order
	 */
	int updateOrder(Map<String, Object> order);
}
