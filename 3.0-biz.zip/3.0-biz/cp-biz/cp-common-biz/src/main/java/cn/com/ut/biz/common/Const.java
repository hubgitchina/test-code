package cn.com.ut.biz.common;

/**
 * 常量枚举类
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
public class Const {
	public static final String USER_ID = "user_id";
	public static final String NODE_NAME = "children_list";
	public static final String flag = "flag";

	/**
	 * 订单状态对应的枚举
	 */
	public enum OrderStatusEnum {
		CANCELED(0, "已取消"), NO_PAY(10, "未支付"), PAID(20, "已付款"), SHIPPED(30, "已发货"), RECEIVED(40,
				"已收货"), ORDER_SUCCESS(50, "订单完成"), NO_DELETE(0,
						"订单未删除"), PUT_INTO_RECYCLE_BIN(1, "放入回收站"), THOROUGHLY_DELETING(2, "彻底删除"),;

		OrderStatusEnum(int code, String value) {
			this.code = code;
			this.value = value;
		}

		private String value;
		private int code;

		public String getValue() {

			return value;
		}

		public int getCode() {

			return code;
		}

		public static OrderStatusEnum codeOf(int code) {

			for (OrderStatusEnum orderStatusEnum : values()) {
				if (orderStatusEnum.getCode() == code) {
					return orderStatusEnum;
				}
			}
			throw new RuntimeException("没有找到对应的枚举");
		}
	}

	/**
	 * 分页信息常量参数
	 */
	public interface Page {
		String PAGE_NO = "pageno";
		String PAGE_SIZE = "pagesize";
	}

	/**
	 * 订单锁定状态
	 */
	public interface LockState {
		int UNLOCKED = 0;
		int LOCKING = 1000;
	}

	public interface Level {
		int LEVEL_ZERO = 0;
		int LEVEL_ONE = 1;
		int LEVEL_TWO = 2;
		int LEVEL_THREE = 3;
		int LEVEL_FOUR = 4;
	}

}
