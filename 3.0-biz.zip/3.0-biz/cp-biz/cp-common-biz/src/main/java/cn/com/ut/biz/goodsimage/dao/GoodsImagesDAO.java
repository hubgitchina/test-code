package cn.com.ut.biz.goodsimage.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.goodsimage.entities.GoodsImages;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 商品图片DAO
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface GoodsImagesDAO extends JdbcOperation<GoodsImages> {

	/**
	 * 查询商品图片列表（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);
}
