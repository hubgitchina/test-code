
package cn.com.ut.biz.order.dao.impl;

import java.sql.Timestamp;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.biz.order.dao.OrderPayDAO;
import cn.com.ut.biz.order.entities.OrderPay;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 订单DAO层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
@Repository
public class OrderPayDAOImpl extends JdbcOperationsImpl<OrderPay> implements OrderPayDAO {

	@Override
	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = { OrderPay.buyer_id, OrderPay.api_paystate, OrderPay.pay_sn };
		add(null, names, NAMES,
				ParameterBuilder.builder().append(vo, names)
						.append(id, time, time, vo.get(Goods.create_id), vo.get(Goods.create_id))
						.toArray());
		return id;
	}
}
