package cn.com.ut.biz.goods.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 商品信息DAO
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface GoodsDAO extends JdbcOperation<Goods> {

	/**
	 * 根据主键ID获取商品信息，判断是否存在相应记录（效率最快）
	 * 
	 * @param vo
	 * @return
	 */
	Map<String, Object> existGoods(String id);

	/**
	 * 根据店铺ID查询商品信息列表（带分页）
	 * 
	 * @param page
	 * @param storeId
	 * @return
	 */
	List<Map<String, Object>> queryStoreGoods(PageBean page, Map<String, Object> vo);

	/**
	 * 查询商城全部商品（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> queryMallGoods(PageBean page);

	/**
	 * 根据商品ID获取商品详情
	 * 
	 * @param goodsId
	 * @return
	 */
	Map<String, Object> getGoods(String goodsId);

	/**
	 * 批量更新商品的库存
	 * 
	 * @param goodsDoNotHaveSpecList
	 */
	void batchUpdateGoodsStorage(List<Map<String, Object>> goodsDoNotHaveSpecList);

	/**
	 * 查询商品所有规格和规格值
	 * 
	 * @param goodsId
	 * @return
	 */
	List<Map<String, Object>> queryAllGoodsSpec(String goodsId);

	/**
	 * 查询商品信息详情（消费者查看）
	 */
	Map<String, Object> getGoodsDetail(String goodsId);

	/**
	 * 商品搜索（商城首页）
	 * 
	 * @param page
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryIndex(PageBean page, Map<String, Object> vo);

	/**
	 * 店铺商品查询（消费者在店铺搜索商品）
	 * 
	 * @param page
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryGoodsInStore(PageBean page, Map<String, Object> vo);
}
