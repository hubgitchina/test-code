package cn.com.ut.biz.goods.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品信息表 ds_goods
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public class Goods extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4696067802243581022L;
	/**
	 * 商品名称
	 */
	public static final String goods_name = "goods_name";
	/**
	 * 商品广告词
	 */
	public static final String goods_advword = "goods_advword";
	/**
	 * 商品分类
	 */
	public static final String gc_id = "gc_id";
	/**
	 * 店铺id
	 */
	public static final String store_id = "store_id";
	/**
	 * 规格值
	 */
	public static final String spec_value = "spec_value";
	/**
	 * 品牌id
	 */
	public static final String brand_id = "brand_id";
	/**
	 * 类型id
	 */
	public static final String type_id = "type_id";
	/**
	 * 商品属性
	 */
	public static final String goods_attr = "goods_attr";
	/**
	 * 商品内容
	 */
	public static final String goods_body = "goods_body";
	/**
	 * 商品状态 0:下架 1:正常 10:违规（禁售）
	 */
	public static final String goods_state = "goods_state";
	/**
	 * 违规原因
	 */
	public static final String goods_stateremark = "goods_stateremark";
	/**
	 * 商品审核 1通过，0未通过，10审核中
	 */
	public static final String goods_verify = "goods_verify";
	/**
	 * 审核失败原因
	 */
	public static final String goods_verifyremark = "goods_verifyremark";
	/**
	 * 商品锁定 0未锁，1已锁
	 */
	public static final String goods_lock = "goods_lock";
	/**
	 * 商品添加时间
	 */
	public static final String goods_addtime = "goods_addtime";
	/**
	 * 上架时间
	 */
	public static final String goods_shelftime = "goods_shelftime";
	/**
	 * 商品价格
	 */
	public static final String goods_price = "goods_price";
	/**
	 * 商品市场价
	 */
	public static final String goods_marketprice = "goods_marketprice";
	/**
	 * 商品成本价
	 */
	public static final String goods_costprice = "goods_costprice";
	/**
	 * 商品折扣
	 */
	public static final String goods_discount = "goods_discount";
	/**
	 * 商家编号
	 */
	public static final String goods_serial = "goods_serial";
	/**
	 * 商品库存报警值
	 */
	public static final String goods_storage_alarm = "goods_storage_alarm";
	/**
	 * 商品推荐 1:是 0:否
	 */
	public static final String goods_commend = "goods_commend";
	/**
	 * 商品运费 0为免运费
	 */
	public static final String goods_freight = "goods_freight";
	/**
	 * 商品是否开具增值税发票 1:是 0:否
	 */
	public static final String goods_vat = "goods_vat";
	/**
	 * 店铺分类id 首尾用,隔开
	 */
	public static final String goods_stcids = "goods_stcids";
	/**
	 * 是否为虚拟商品 1:是 0:否
	 */
	public static final String is_virtual = "is_virtual";
	/**
	 * 总库存
	 */
	public static final String goods_storage = "goods_storage";
	/**
	 * 商品分类完整路径冗余，方便按分类或子分类查询商品
	 */
	public static final String gc_fullpath = "gc_fullpath";
	/**
	 * 最低价
	 */
	public static final String price_min = "price_min";
	/**
	 * 最高价
	 */
	public static final String price_max = "price_max";
	/**
	 * 销量
	 */
	public static final String goods_salenum = "goods_salenum";
	/**
	 * 商品默认图片
	 */
	public static final String image_path = "image_path";
}
