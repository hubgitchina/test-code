package cn.com.ut.biz.user.dao.impl;

import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.user.dao.UserAddressDAO;
import cn.com.ut.biz.user.entities.UserAddress;
import cn.com.ut.core.cache.CachedParameter;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

@Repository
public class UserAddressDAOImpl extends JdbcOperationsImpl<UserAddress> implements UserAddressDAO {

	public int updateUserAddressAsNotDefault(String userId, String isDefault) {

		return update(null, new String[] { UserAddress.is_default }, null, null,
				new String[] { UserAddress.user_id }, null, null, new Object[] { isDefault },
				new Object[] { userId }, new CachedParameter());
	}

	public int updateAddressAsDefault(String id, String isDefault) {

		return updateById(null, new String[] { UserAddress.is_default }, null, null,
				new String[] { isDefault }, id, new CachedParameter());
	}

	@Override
	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		String[] names = new String[] { UserAddress.user_id, UserAddress.contact_man,
				UserAddress.province, UserAddress.city, UserAddress.area, UserAddress.contact_addr,
				UserAddress.contact_phone, UserAddress.is_default, UserAddress.position };
		List<Object> array = mapValuesToList(vo, names);
		array.add(id);
		array.add(vo.get(UserAddress.create_id));
		array.add(time);
		add(null, names,
				new String[] { UserAddress.idx, UserAddress.create_id, UserAddress.create_time },
				array.toArray());
		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		String[] names = new String[] { UserAddress.contact_man, UserAddress.province,
				UserAddress.city, UserAddress.area, UserAddress.contact_addr,
				UserAddress.contact_phone, UserAddress.is_default, UserAddress.position };
		List<Object> array = mapValuesToList(vo, names);
		array.add(DateTimeUtil.currentDateTime());
		return updateById(null, names, new String[] { UserAddress.update_time }, null,
				array.toArray(), (String) vo.get(UserAddress.idx), new CachedParameter());
	}

	public List<Map<String, Object>> queryUserAddress(String userId, PageBean page) {

		return query(page, null, null,
				new String[] { idx, UserAddress.contact_man, UserAddress.province, UserAddress.city,
						UserAddress.area, UserAddress.contact_addr, UserAddress.is_default,
						UserAddress.position, UserAddress.contact_phone },
				null, new String[] { UserAddress.user_id }, new Object[] { userId });
	}

	@Override
	public Map<String, Object> getDefaultAddr(String userId) {

		Map<String, Object> addr = getByKey(null, null,
				new String[] { UserAddress.idx, UserAddress.city }, null,
				new String[] { UserAddress.user_id, UserAddress.is_default },
				new Object[] { userId, ConstantUtil.FLAG_YES }, null);
		return addr;
	}

}
