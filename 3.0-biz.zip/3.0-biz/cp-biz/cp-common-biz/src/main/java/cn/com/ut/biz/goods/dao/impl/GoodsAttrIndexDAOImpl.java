package cn.com.ut.biz.goods.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.goods.dao.GoodsAttrIndexDAO;
import cn.com.ut.biz.goods.entities.GoodsAttrIndex;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 商品关联属性DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Repository
public class GoodsAttrIndexDAOImpl extends JdbcOperationsImpl<GoodsAttrIndex>
		implements GoodsAttrIndexDAO {

	@Override
	public List<Map<String, Object>> queryGoodsAttr(String goodsId) {

		StringBuffer table = new StringBuffer();
		String[] selectColumnArray = new String[] { "ga.attr_id", "a.attr_name",
				"av.id attrvalue_id", "av.attrvalue_name" };
		table.append("ds_goodsattrindex ga ")
				.append("LEFT JOIN ds_attribute a ON ga.attr_id = a.id ")
				.append("LEFT JOIN ds_attributevalue av ON ga.attr_id = av.attr_id");

		return queryPage(null, null, table.toString(), false, selectColumnArray, null,
				new String[] { "ga.goods_id", "ga.is_del", "a.is_del", "av.is_del" }, null, null,
				null, "av.id", null, "av.sort", new Object[] { goodsId, ConstantUtil.FLAG_NO,
						ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO });
	}

}
