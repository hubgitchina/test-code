package cn.com.ut.biz.goodsattribute.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品属性表 ds_attribute
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public class Attribute extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6881093947454892818L;
	/**
	 * 属性名称
	 */
	public static final String attr_name = "attr_name";
	/**
	 * 所属类型ID
	 */
	public static final String type_id = "type_id";
	/**
	 * 属性是否显示。0不显示、1显示
	 */
	public static final String attr_show = "attr_show";
	/**
	 * 属性排序
	 */
	public static final String sort = "sort";
}
