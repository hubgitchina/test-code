
//-----------------------------DAO-start---------------------------------//
package cn.com.ut.biz.inform.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.inform.entities.Inform;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface InformDAO extends JdbcOperation<Inform> {

}
//-----------------------------DAO-end---------------------------------//