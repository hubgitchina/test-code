
package cn.com.ut.biz.cart.service.impl;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import cn.com.ut.biz.common.BigDecimalUtil;
import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.common.JsonUtils;
import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.biz.goods.service.GoodsService;
import cn.com.ut.biz.goods.service.GoodsSpecService;
import cn.com.ut.biz.goodsspec.util.GoodsSpecUtil;
import cn.com.ut.biz.goodsspec.util.SpecParamVo;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.store.entities.Store;
import cn.com.ut.core.common.util.ExceptionUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.cart.dao.CartDAO;
import cn.com.ut.biz.cart.entities.Cart;
import cn.com.ut.biz.cart.service.CartService;
import cn.com.ut.biz.cart.vo.CartVo;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 购物车Service层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartDAO cartDAO;

	@Autowired
	private GoodsService goodsService;

	@Autowired
	private GoodsSpecService goodsSpecService;

	@Override
	public Map<String, Object> list(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Cart.buyer_id);
		return getCartVoInfo((String) vo.get(Cart.buyer_id));

	}

	@Override
	public String add(JSONObject vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Cart.buyer_id, Cart.goods_id,
				Cart.goods_name, Cart.goods_num, Cart.store_id, Cart.store_name,
				GoodsSpecUtil.SPEC_PARAM);

		// 查询当前购物车商品的信息
		Map<String, Object> goods;
		Map<String, Object> cart;
		// 反序列化规格组合列表
		List specGroupList = JsonUtils.str2obj(vo.get(GoodsSpecUtil.SPEC_PARAM).toString(),
				List.class);
		if (!CollectionUtil.isEmptyCollection(specGroupList)) {
			// 假如有规格组合列表则通过specparam_id来查询商品信息
			String specparam_id = GoodsSpecUtil.handleSpecParamSingle(vo).getSpecparam_id();
			goods = goodsSpecService.getGoodsPriceBySpecId(specparam_id);
			cart = cartDAO.getBySpecIdAndUserId((String) vo.get(Cart.buyer_id),
					(String) vo.get(Cart.goods_id), (String) vo.get(Cart.store_id), specparam_id);
		} else {
			goods = goodsService.getByGoodsId((String) vo.get(Cart.goods_id));
			cart = cartDAO.getByProductIdAndUserId((String) vo.get(Cart.buyer_id),
					(String) vo.get(Cart.goods_id), (String) vo.get(Cart.store_id));
		}
		if (goods == null) {
			ExceptionUtil.throwRuntimeException("商品不存在或已下架");

		}
		// 添加该购物车
		if (CollectionUtil.isEmptyMap(cart)) {

			vo.put(Cart.create_id, vo.get(Const.USER_ID));
			vo.put(Cart.goods_name, vo.get(Goods.goods_name));
			vo.put(Cart.goods_price, goods.get(Goods.goods_price));
			vo.put(Cart.store_name, vo.get(Store.store_name));
			if (!CollectionUtil.isEmptyCollection(specGroupList)) {
				SpecParamVo specParamVo = GoodsSpecUtil.handleSpecParamSingle(vo);
				vo.put(Cart.specparam_id, specParamVo.getSpecparam_id());
				vo.put(Cart.specparam_name, specParamVo.getSpecparam_name());
			}

			return cartDAO.add(vo);

		} else {
			// 该买家已购买当前商品，更新当前购物车中的商品数量
			int count = (int) cart.get(Cart.goods_num);
			count += (Integer) vo.get(Cart.goods_num);
			cart.put(Cart.goods_num, count);
			cart.put(Cart.update_id, vo.get(Const.USER_ID));
			cartDAO.update(cart);
			return (String) cart.get(Cart.idx);
		}

	}

	@Override
	public Map<String, Object> getCartCount(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Cart.buyer_id);
		int totalCartCount = cartDAO.getTotalCartCount((String) vo.get(Cart.buyer_id));
		Map<String, Object> resultCount = Maps.newHashMap();
		resultCount.put("totalCartCount", totalCartCount);
		return resultCount;
	}

	@Override
	public void delete(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Cart.buyer_id, "productIds");
		Object[] productIdArray = ((JSONArray) vo.get("productIds")).toArray();
		List<Object> productIdList = Arrays.asList(productIdArray);
		if (CollectionUtil.isEmptyCollection(productIdList)) {
			ExceptionUtil.throwValidateException("必须传入要删除商品的Id列表");
		}
		cartDAO.deleteBatch(productIdList, Cart.goods_id);

	}

	@Override
	public void updateGoodsNumber(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Cart.buyer_id, Cart.goods_num,
				"cart_id");
		// 查询当前购物车商品的信息
		Map<String, Object> cart = cartDAO.getById(null, null, null, null,
				(String) vo.get("cart_id"));
		if (CollectionUtil.isEmptyMap(cart)) {
			ExceptionUtil.throwValidateException("当前买家不存在该订单");
		}
		if (cart.get(Cart.goods_num) == vo.get(Cart.goods_num)) {
			return;

		}
		cart.put(Cart.goods_num, vo.get(Cart.goods_num));
		cart.put(Cart.update_id, vo.get(Const.USER_ID));

		cartDAO.update(cart);

	}

	@Override
	public void batchCleanCart(List<Map<String, Object>> orderItemList) {

		cartDAO.batchCleanCart(orderItemList);
	}

	// 返回当前买家的购物车信息
	public Map<String, Object> getCartVoInfo(String buyerId, Object... cartIds) {

		List<Map<String, Object>> cartList = cartDAO.queryCartList(buyerId);
		if (CollectionUtil.isEmptyCollection(cartList)) {
			ExceptionUtil.throwRuntimeException("购物车为空");
		}
		// 假如有cartId限制则对cartList进行截断
		if (cartIds.length > 0) {
			cartList = cartList.stream()
					.filter(cart -> Arrays.asList(cartIds).contains(cart.get(Cart.idx)))
					.collect(Collectors.toList());
		}
		Set<String> cartStoreNames = cartList.stream().map(e -> (String) e.get(Cart.store_name))
				.collect(Collectors.toSet());
		List<CartVo> cartVoList = Lists.newArrayList();
		BigDecimal cartTotalPrice = new BigDecimal("0");
		if (!CollectionUtil.isEmptyCollection(cartList)) {
			for (String cartStoreName : cartStoreNames) {
				CartVo cartVo = new CartVo();
				cartVo.setStore_name(cartStoreName);
				BigDecimal currentCartTotalPrice = new BigDecimal("0");
				List<Map<String, Object>> carts = Lists.newArrayList();
				for (Map<String, Object> cart : cartList) {
					if (cart.get(Cart.store_name).equals(cartStoreName)) {
						// 计算当前商品的总价
						currentCartTotalPrice = currentCartTotalPrice.add(BigDecimalUtil.multiply(
								Double.valueOf(cart.get(Cart.goods_num).toString()),
								Double.valueOf(cart.get(Cart.goods_price).toString())));
						carts.add(cart);
					}
				}
				cartVo.setShop_total_price(currentCartTotalPrice);
				// 替换id为cart_id
				List<Map<String, Object>> cartsReuslt = CollectionUtil.replaceListMapKey(carts,
						new String[] { Cart.idx + "@cart_id" });

				cartVo.setStore_id((String) carts.get(0).get(Cart.store_id));
				CollectionUtil.removeKeysFromMaps(cartsReuslt,
						new Object[] { Order.store_id, Order.store_name });
				cartVo.setGoods(cartsReuslt);
				cartVoList.add(cartVo);
				cartTotalPrice = cartTotalPrice.add(currentCartTotalPrice);
			}

		}
		Map<String, Object> cartResultVoList = Maps.newHashMap();
		cartResultVoList.put("store", cartVoList);
		cartResultVoList.put("goods_amount", cartTotalPrice);

		return cartResultVoList;

	}

}
