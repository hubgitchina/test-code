
//-----------------------------DAOImpl-start---------------------------------//
package cn.com.ut.biz.complain.dao.impl;

import static cn.com.ut.biz.complain.entities.Complain.accused_id;
import static cn.com.ut.biz.complain.entities.Complain.accused_name;
import static cn.com.ut.biz.complain.entities.Complain.accuser_id;
import static cn.com.ut.biz.complain.entities.Complain.accuser_name;
import static cn.com.ut.biz.complain.entities.Complain.appeal_datetime;
import static cn.com.ut.biz.complain.entities.Complain.appeal_image;
import static cn.com.ut.biz.complain.entities.Complain.appeal_message;
import static cn.com.ut.biz.complain.entities.Complain.complain_active;
import static cn.com.ut.biz.complain.entities.Complain.complain_content;
import static cn.com.ut.biz.complain.entities.Complain.complain_datetime;
import static cn.com.ut.biz.complain.entities.Complain.complain_handle_datetime;
import static cn.com.ut.biz.complain.entities.Complain.complain_handle_member_id;
import static cn.com.ut.biz.complain.entities.Complain.complain_image;
import static cn.com.ut.biz.complain.entities.Complain.complain_state;
import static cn.com.ut.biz.complain.entities.Complain.complain_subject_content;
import static cn.com.ut.biz.complain.entities.Complain.complain_subject_id;
import static cn.com.ut.biz.complain.entities.Complain.final_handle_datetime;
import static cn.com.ut.biz.complain.entities.Complain.final_handle_member_id;
import static cn.com.ut.biz.complain.entities.Complain.final_handle_message;
import static cn.com.ut.biz.complain.entities.Complain.order_goods_id;
import static cn.com.ut.biz.complain.entities.Complain.order_id;
import static cn.com.ut.biz.complain.entities.Complain.complain_goodsid;
import static cn.com.ut.biz.complain.entities.Complain.complain_goodsimage;
import static cn.com.ut.biz.complain.entities.Complain.complain_goodsname;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.complain.dao.ComplainDAO;
import cn.com.ut.biz.complain.entities.Complain;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

@Repository
public class ComplainDAOImpl extends JdbcOperationsImpl<Complain> implements ComplainDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		String[] addNames = new String[] { complain_subject_content, complain_subject_id,
				accused_id, accused_name, accuser_id, complain_datetime, complain_image,
				complain_content, order_goods_id, order_id, accuser_name, complain_goodsid,
				complain_goodsname, complain_goodsimage };

		add(null, addNames, NAMES_ID_CT_CID, ParameterBuilder.builder().append(vo, addNames)
				.append(id, DateTimeUtil.currentDateTime(), vo.get(Complain.create_id)).toArray());
		return id;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null,
				new String[] { complain_subject_content, complain_handle_member_id, appeal_image,
						complain_subject_id, appeal_message, appeal_datetime, accused_id,
						accused_name, final_handle_member_id, accuser_id, complain_datetime,
						complain_active, complain_image, final_handle_datetime, complain_content,
						final_handle_message, complain_state, order_goods_id, order_id,
						accuser_name, complain_handle_datetime },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo, new String[] { complain_subject_content,
								complain_handle_member_id, appeal_image, complain_subject_id,
								appeal_message, appeal_datetime, accused_id, accused_name,
								final_handle_member_id, accuser_id, complain_datetime,
								complain_active, complain_image, final_handle_datetime,
								complain_content, final_handle_message, complain_state,
								order_goods_id, order_id, accuser_name, complain_handle_datetime })
						.append(DateTimeUtil.currentDateTime(), vo.get(Complain.update_id))
						.toArray(),
				(String) vo.get(Complain.idx), null);
	}

	@Override
	public Map<String, Object> getComplain(String complainId) {

		Map<String, Object> complainVo = getById(null, null, null, null, complainId);
		if (complainVo != null) {

			complainVo.remove(Complain.create_id);
			complainVo.remove(Complain.create_time);
			complainVo.remove(Complain.update_id);
			complainVo.remove(Complain.update_time);
			complainVo.remove(Complain.is_del);
		}

		return complainVo;

	}

	@Override
	public List<Map<String, Object>> queryByAdmin(PageBean page) {

		return query(page, null, null,
				new String[] { Complain.idx, Complain.complain_subject_content, accuser_name,
						accused_name, complain_state, complain_datetime, complain_goodsid,
						complain_goodsname, complain_goodsimage },
				null, null, null);
	}

	@Override
	public List<Map<String, Object>> queryByStore(PageBean page, String accusedId) {

		return query(page, null, null,
				new String[] { Complain.idx, Complain.complain_subject_content, accuser_name,
						accused_name, complain_state, complain_datetime, complain_goodsid,
						complain_goodsname, complain_goodsimage },
				null, new String[] { accused_id }, new Object[] { accusedId });
	}

	@Override
	public List<Map<String, Object>> queryByCustomer(PageBean page, String accuserId) {

		return query(page, null, null,
				new String[] { Complain.idx, Complain.complain_subject_content, accuser_name,
						accused_name, complain_state, complain_datetime, complain_goodsid,
						complain_goodsname, complain_goodsimage },
				null, new String[] { accuser_id }, new Object[] { accuserId });
	}

}
// -----------------------------DAOImpl-end---------------------------------//