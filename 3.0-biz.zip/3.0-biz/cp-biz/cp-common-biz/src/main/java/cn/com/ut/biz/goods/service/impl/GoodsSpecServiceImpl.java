package cn.com.ut.biz.goods.service.impl;

import static cn.com.ut.biz.goods.entities.Goods.goods_serial;
import static cn.com.ut.biz.goods.entities.Goods.goods_storage_alarm;
import static cn.com.ut.biz.goods.entities.Goods.price_max;
import static cn.com.ut.biz.goods.entities.Goods.price_min;
import static cn.com.ut.biz.goods.entities.Goods.spec_value;
import static cn.com.ut.biz.goods.entities.Goods.store_id;
import static cn.com.ut.biz.goods.entities.GoodsSpec.goods_id;
import static cn.com.ut.biz.goods.entities.GoodsSpec.goods_price;
import static cn.com.ut.biz.goods.entities.GoodsSpec.goods_storage;
import static cn.com.ut.biz.goods.entities.GoodsSpec.specparam_id;
import static cn.com.ut.biz.goods.entities.GoodsSpec.specparam_name;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_num;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.user_id;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.goods.dao.GoodsDAO;
import cn.com.ut.biz.goods.dao.GoodsSpecDAO;
import cn.com.ut.biz.goods.service.GoodsService;
import cn.com.ut.biz.goods.service.GoodsSpecService;
import cn.com.ut.biz.goods.util.ConstGoodsUtil;
import cn.com.ut.biz.goodsspec.util.GoodsSpecUtil;
import cn.com.ut.biz.goodsspec.util.SpecParamVo;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 商品规格信息业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Service
public class GoodsSpecServiceImpl implements GoodsSpecService {

	@Autowired
	private GoodsSpecDAO goodsSpecDAO;

	@Autowired
	private GoodsDAO goodsDAO;

	@Autowired
	private GoodsService goodsService;

	@Override
	public void updateGoodsSpec(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, goods_id);

		// 获取规格json集合
		String goodsSpec = TypeConvert.getStringValue(vo.get(GoodsSpecUtil.GOODS_SPEC));
		if (CommonUtil.isEmpty(goodsSpec)) {
			ExceptionUtil.throwValidateException("未设置商品关联规格信息参数");
		}

		JSONArray goodsSpecArray = JSONObject.parseArray(goodsSpec);
		if (CollectionUtil.isEmptyCollection(goodsSpecArray)) {
			ExceptionUtil.throwValidateException("未设置商品关联规格信息参数");
		}

		String userId = (String) vo.get(user_id);
		String goodsId = (String) vo.get(goods_id);

		Map<String, Object> goodsMap = goodsDAO.getByKey(null, null,
				new String[] { goods_serial, goods_storage_alarm }, null,
				new String[] { idx, is_del }, new Object[] { goodsId, ConstantUtil.FLAG_NO }, null);
		if (CollectionUtil.isEmptyMap(goodsMap)) {
			ExceptionUtil.throwValidateException("商品不存在");
		}
		String goodsSerial = (String) goodsMap.get(goods_serial);
		int storageAlarm = (int) goodsMap.get(goods_storage_alarm);

		List<Map<String, Object>> specVos = new ArrayList<>(goodsSpecArray.size());
		Timestamp now = DateTimeUtil.currentDateTime();
		for (int i = 0; i < goodsSpecArray.size(); i++) {
			JSONObject specValue = goodsSpecArray.getJSONObject(i);

			ValidatorUtil.validateMapContainsKey(specValue, GoodsSpecUtil.SPEC_PARAM, goods_price,
					goods_storage);

			JSONArray specParamArray = specValue.getJSONArray(GoodsSpecUtil.SPEC_PARAM);
			if (CollectionUtil.isEmptyCollection(specParamArray)) {
				ExceptionUtil.throwValidateException("未设置商品关联规格信息参数");
			}

			String goodsPrice = specValue.getString(goods_price);
			String goodsStorage = specValue.getString(goods_storage);

			SpecParamVo specParamVo = GoodsSpecUtil.handleSpecParamSingle(specValue);

			Map<String, Object> specMap = Maps.newHashMapWithExpectedSize(12);
			specMap.put(idx, CommonUtil.getUUID());
			specMap.put(create_id, userId);
			specMap.put(create_time, now);
			specMap.put(update_id, userId);
			specMap.put(update_time, now);
			specMap.put(goods_id, goodsId);
			specMap.put(goods_price, goodsPrice);
			specMap.put(goods_storage, goodsStorage);
			specMap.put(goods_serial, goodsSerial);
			specMap.put(goods_storage_alarm, storageAlarm);
			specMap.put(specparam_id, specParamVo.getSpecparam_id());
			specMap.put(specparam_name, specParamVo.getSpecparam_name());
			specVos.add(specMap);
		}

		// 先删除原有商品关联的规格信息（一对多，物理删除）
		goodsSpecDAO.delete(null, new String[] { goods_id }, new Object[] { goodsId });

		String[] names = new String[] { idx, create_id, create_time, update_id, update_time,
				goods_id, goods_price, goods_storage, goods_serial, goods_storage_alarm,
				specparam_id, specparam_name };
		goodsSpecDAO.addVoBatch(null, names, null, specVos);

		// 将选择商品规格后返回的json格式转为购物车选择规格格式
		Map<String, Object> specValueMap = GoodsSpecUtil.handleSpecParamBatch(goodsSpecArray);

		// 直接更新商品表规格值会报序列化的异常，先转为json字符串后再同步更新商品表规格值字段
		String specValueText = JSONObject.toJSONString(specValueMap);

		// 更新商品规格时，记录最小价格跟最大价格的值，同步更新到商品表对应字段price_min和price_max
		@SuppressWarnings("unchecked")
		Map<String, Object> priceRange = (Map<String, Object>) specValueMap
				.get(GoodsSpecUtil.PRICE_RANGE);
		BigDecimal priceMin = (BigDecimal) priceRange.get(GoodsSpecUtil.PRICE_MIN);
		BigDecimal priceMax = (BigDecimal) priceRange.get(GoodsSpecUtil.PRICE_MAX);

		goodsDAO.updateById(null, new String[] { spec_value, price_min, price_max }, null,
				new Object[] { specValueText, priceMin, priceMax }, goodsId);
	}

	@Override
	public Map<String, Object> getGoodsPriceBySpecId(String specParamId) {

		return goodsSpecDAO.getBySpecParamId(specParamId);
	}

	@Override
	public void batchUpdateGoodsStorge(List<Map<String, Object>> orderItemList, String user_id) {

		List<Map<String, Object>> goodsHavaSpecList = Lists.newArrayList();
		List<Map<String, Object>> goodsDoNotHaveSpecList = Lists.newArrayList();
		for (Map<String, Object> orderItem : orderItemList) {
			// 是否有规格，假如有规格则更新商品主表与规格表；否则只更新商品主表
			if ((boolean) orderItem.get(Const.flag)) {
				Map<String, Object> goodsSpec = Maps.newHashMap();
				goodsSpec.put(idx, orderItem.get(GoodsSpecUtil.SPEC_ID));
				// 订单详情表的库存数量
				goodsSpec.put(goods_storage, orderItem.get(ConstGoodsUtil.LEFT_STORAGE));
				goodsSpec.put(update_id, user_id);
				goodsSpec.put(goods_id, orderItem.get(goods_id));
				goodsSpec.put(specparam_id, orderItem.get(specparam_id));
				goodsHavaSpecList.add(goodsSpec);
				// 更新有规格的商品主表
				Map<String, Object> goods = goodsService
						.getByGoodsId((String) orderItem.get(goods_id));
				goods.put(goods_storage,
						(Integer) goods.get(goods_storage) - (Integer) orderItem.get(goods_num));
				goods.put(store_id, orderItem.get(store_id));
				goods.put(update_id, user_id);
				goodsDoNotHaveSpecList.add(goods);

			} else {
				Map<String, Object> goods = Maps.newHashMap();
				goods.put(idx, orderItem.get(goods_id));
				goods.put(goods_storage, orderItem.get(ConstGoodsUtil.LEFT_STORAGE));
				goods.put(update_id, user_id);
				goodsDoNotHaveSpecList.add(goods);
			}
			if (!CollectionUtil.isEmptyCollection(goodsHavaSpecList)) {
				// 批量更新商品规格表的商品库存
				goodsSpecDAO.batchUpdateGoodsStorage(goodsHavaSpecList);
			}
			if (!CollectionUtil.isEmptyCollection(goodsDoNotHaveSpecList)) {
				// 批量更新商品主表的商品库存
				goodsService.batchUpdateGoodsStorage(goodsDoNotHaveSpecList);
			}

		}

	}

	@Override
	public Map<String, Object> getBySpecparmId(String specparam_id) {

		return goodsSpecDAO.getByProperties(new String[] { specparam_id },
				new Object[] { specparam_id });
	}

}
