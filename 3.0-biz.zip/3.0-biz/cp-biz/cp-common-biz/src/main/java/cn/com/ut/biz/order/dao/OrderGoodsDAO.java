
package cn.com.ut.biz.order.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 订单商品表DAO层
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
public interface OrderGoodsDAO extends JdbcOperation<OrderGoods> {

	void addBatch(List<Map<String, Object>> orderItemList);

	/**
	 * 根据订单ID查询订单商品明细
	 * 
	 * @param orderId
	 * @return
	 */
	List<Map<String, Object>> selectByOrderId(String orderId);

	/**
	 * 根据订单ID列表查询订单商品详情
	 * 
	 * @param orderIdList
	 * @return
	 */
	List<Map<String, Object>> selectByOrderIdList(List<String> orderIdList);
}
