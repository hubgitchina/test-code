
//-----------------------------DAO-start---------------------------------//
package cn.com.ut.biz.complain.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.complain.entities.ComplainTalk;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface ComplainTalkDAO extends JdbcOperation<ComplainTalk> {

	List<Map<String, Object>> queryTalk(String complainId);

}
//-----------------------------DAO-end---------------------------------//