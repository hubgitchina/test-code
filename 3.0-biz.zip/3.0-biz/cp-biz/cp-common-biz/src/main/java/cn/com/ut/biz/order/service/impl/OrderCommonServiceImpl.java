
package cn.com.ut.biz.order.service.impl;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.order.entities.OrderCommon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.order.dao.OrderCommonDAO;
import cn.com.ut.biz.order.service.OrderCommonService;

/**
 * 订单公共表Service层
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
@Service
public class OrderCommonServiceImpl implements OrderCommonService {

	@Autowired
	private OrderCommonDAO orderCommonDAO;

	@Override
	public String add(Map<String, Object> orderCommon) {

		return orderCommonDAO.add(orderCommon);
	}

	@Override
	public List<Map<String, Object>> queryOrderByOrderIdList(List<String> orderIdList) {

		return orderCommonDAO.queryOrderByOrderIdList(orderIdList);
	}

	@Override
	public void updateOrderCommonInfo(Map<String, Object> vo) {

		orderCommonDAO.updateOrderCommonInfo(vo);

	}

	@Override
	public int update(Map<String, Object> vo) {

		return orderCommonDAO.update(vo);
	}

	@Override
	public Map<String, Object> getByOrderId(String orderId) {

		return orderCommonDAO.getByProperties(new String[] { OrderCommon.order_id },
				new Object[] { orderId });
	}
}
