package cn.com.ut.biz.goodstype.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.goodstype.dao.GoodsTypeDAO;
import cn.com.ut.biz.goodstype.entities.GoodsType;
import cn.com.ut.biz.goodstype.service.GoodsTypeService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * Created by zhouquanguo on 2018/5/9.
 */
@Service
public class GoodsTypeServiceImpl implements GoodsTypeService {

	@Resource
	private GoodsTypeDAO goodsTypeDAO;

	@Override
	public String create(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, GoodsType.type_name, GoodsType.sort,
				Const.USER_ID);
		String userId = (String) vo.get(GoodsType.user_id);
		vo.put(GoodsType.create_id, userId);
		boolean isUnique = goodsTypeDAO.checkUnique(new String[] { GoodsType.type_name },
				new Object[] { vo.get(GoodsType.type_name) }, null, null);
		if (!isUnique) {
			ExceptionUtil.throwValidateException("商品类型名称重复");
		}
		return goodsTypeDAO.add(new String[] { GoodsType.type_name, GoodsType.sort }, vo);

	}

	@Override
	public String update(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, GoodsType.idx, GoodsType.type_name, Const.USER_ID);
		Map<String, Object> before = getOne(vo);
		if (before == null || before.size() < 0) {
			ExceptionUtil.throwValidateException("待更新的商品类型不存在");
		}

		boolean isUnique = goodsTypeDAO.checkUnique(new String[] { GoodsType.type_name },
				new Object[] { vo.get(GoodsType.type_name) }, new String[] { GoodsType.idx },
				new Object[] { vo.get(GoodsType.idx) });
		if (!isUnique) {
			ExceptionUtil.throwValidateException("品牌名称重复");
		}
		vo.put(GoodsType.update_id, vo.get(Const.USER_ID));
		goodsTypeDAO.update(new String[] { GoodsType.type_name, GoodsType.sort,
				GoodsType.update_time, GoodsType.update_id }, vo);

		return (String) vo.get(GoodsType.idx);

	}

	@Override
	public Map<String, Object> getOne(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, GoodsType.idx, Const.USER_ID);
		return goodsTypeDAO.getById(null, null,
				new String[] { GoodsType.idx, GoodsType.type_name, GoodsType.sort }, null,
				(String) vo.get(GoodsType.idx));
	}

	@Override
	public void delete(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, GoodsType.idx);
		vo.put(GoodsType.update_id, vo.get(Const.USER_ID));
		vo.put(GoodsType.is_del, "Y");
		goodsTypeDAO.update(new String[] { GoodsType.is_del, GoodsType.update_id }, vo);

	}

	@Override
	public ResponseWrap query(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.Page.PAGE_NO, Const.Page.PAGE_SIZE,
				Const.USER_ID);
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition(null, GoodsType.type_name, EnumConstant.WhereCase.LIKE,
				EnumConstant.SqlType.STRING);
		PageBean pageBean = pb.buildSQL(vo);
		ResponseWrap responseWrap = ResponseWrap.builder();
		return responseWrap.appendPage(pageBean).appendData(goodsTypeDAO.findAll(vo, pageBean));

	}

}
