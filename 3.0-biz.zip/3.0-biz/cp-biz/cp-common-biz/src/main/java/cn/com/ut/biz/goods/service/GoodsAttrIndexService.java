package cn.com.ut.biz.goods.service;

import java.util.List;
import java.util.Map;

/**
 * 商品关联属性业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface GoodsAttrIndexService {

	/**
	 * 更新商品关联属性
	 * 
	 * @param vo
	 */
	void updateGoodsAttr(Map<String, Object> vo);

	/**
	 * 获取商品关联属性
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryGoodsAttr(Map<String, Object> vo);
}
