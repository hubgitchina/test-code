package cn.com.ut.biz.goodsimage.service.impl;

import static cn.com.ut.biz.goodsimage.entities.GoodsImages.goods_id;
import static cn.com.ut.biz.goodsimage.entities.GoodsImages.image_path;
import static cn.com.ut.biz.goodsimage.entities.GoodsImages.is_default;
import static cn.com.ut.biz.goodsimage.entities.GoodsImages.sort;
import static cn.com.ut.biz.goodsimage.entities.GoodsImages.store_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.user_id;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;

import cn.com.ut.biz.goods.dao.GoodsDAO;
import cn.com.ut.biz.goods.util.ConstGoodsUtil;
import cn.com.ut.biz.goodsimage.dao.GoodsImagesDAO;
import cn.com.ut.biz.goodsimage.entities.GoodsImages;
import cn.com.ut.biz.goodsimage.service.GoodsImagesService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 商品图片业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Service
public class GoodsImagesServiceImpl implements GoodsImagesService {

	@Autowired
	private GoodsImagesDAO goodsImagesDAO;

	@Autowired
	private GoodsDAO goodsDAO;

	private static String[] columns = { idx, create_id, create_time, update_id, update_time,
			goods_id, store_id, image_path, sort, is_default };

	private static String[] updateCols = { is_default, update_id, update_time };

	private static String[] selectCols = { idx, image_path, sort, is_default };

	private static String[] appendCols = { goods_id, store_id };

	@Override
	public String create(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, goods_id, store_id);

		// 获取规格json集合
		String imageDetails = TypeConvert.getStringValue(vo.get(ConstGoodsUtil.IMAGE_DETAILS));
		if (CommonUtil.isEmpty(imageDetails)) {
			ExceptionUtil.throwValidateException("未设置图片参数");
		}

		JSONArray imageDetailArray = JSONObject.parseArray(imageDetails);
		if (CollectionUtil.isEmptyCollection(imageDetailArray)) {
			ExceptionUtil.throwValidateException("未设置图片参数");
		}

		String userId = (String) vo.get(user_id);
		String goodsId = (String) vo.get(goods_id);
		String storeId = (String) vo.get(store_id);

		List<Map<String, Object>> imageDetailVos = new ArrayList<>(imageDetailArray.size());
		Timestamp now = DateTimeUtil.currentDateTime();
		for (int i = 0; i < imageDetailArray.size(); i++) {
			JSONObject imageDetail = imageDetailArray.getJSONObject(i);

			ValidatorUtil.validateMapContainsKey(imageDetail, image_path, sort, is_default);

			String imagePath = imageDetail.getString(image_path);
			String sort = imageDetail.getString(GoodsImages.sort);
			String isDefault = imageDetail.getString(is_default);
			Map<String, Object> imageDetailVo = Maps.newHashMapWithExpectedSize(10);
			imageDetailVo.put(idx, CommonUtil.getUUID());
			imageDetailVo.put(create_id, userId);
			imageDetailVo.put(create_time, now);
			imageDetailVo.put(update_id, userId);
			imageDetailVo.put(update_time, now);
			imageDetailVo.put(goods_id, goodsId);
			imageDetailVo.put(store_id, storeId);
			imageDetailVo.put(image_path, imagePath);
			imageDetailVo.put(GoodsImages.sort, sort);
			imageDetailVo.put(is_default, isDefault);
			imageDetailVos.add(imageDetailVo);
		}

		goodsImagesDAO.addVoBatch(null, columns, null, imageDetailVos);

		return goodsId;
	}

	@Override
	public String update(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, goods_id, store_id);

		// 获取规格json集合
		String imageDetails = TypeConvert.getStringValue(vo.get(ConstGoodsUtil.IMAGE_DETAILS));
		if (CommonUtil.isEmpty(imageDetails)) {
			ExceptionUtil.throwValidateException("未设置图片参数");
		}

		JSONArray imageDetailArray = JSONObject.parseArray(imageDetails);
		if (CollectionUtil.isEmptyCollection(imageDetailArray)) {
			ExceptionUtil.throwValidateException("未设置图片参数");
		}

		String userId = (String) vo.get(user_id);
		String goodsId = (String) vo.get(goods_id);
		String storeId = (String) vo.get(store_id);

		List<Map<String, Object>> imageDetailVos = new ArrayList<>(imageDetailArray.size());
		Timestamp now = DateTimeUtil.currentDateTime();
		for (int i = 0; i < imageDetailArray.size(); i++) {
			JSONObject imageDetail = imageDetailArray.getJSONObject(i);

			ValidatorUtil.validateMapContainsKey(imageDetail, image_path, sort, is_default);

			String imagePath = imageDetail.getString(image_path);
			String sort = imageDetail.getString(GoodsImages.sort);
			String isDefault = imageDetail.getString(is_default);
			Map<String, Object> imageDetailVo = Maps.newHashMapWithExpectedSize(7);
			imageDetailVo.put(idx, CommonUtil.getUUID());
			imageDetailVo.put(create_id, userId);
			imageDetailVo.put(create_time, now);
			imageDetailVo.put(update_id, userId);
			imageDetailVo.put(update_time, now);
			imageDetailVo.put(goods_id, goodsId);
			imageDetailVo.put(store_id, storeId);
			imageDetailVo.put(image_path, imagePath);
			imageDetailVo.put(GoodsImages.sort, sort);
			imageDetailVo.put(is_default, isDefault);
			imageDetailVos.add(imageDetailVo);
		}

		// 先删除该店铺该商品下原有的所有图片
		goodsImagesDAO.delete(null, appendCols, new Object[] { goodsId, storeId });

		goodsImagesDAO.addVoBatch(null, columns, null, imageDetailVos);

		return goodsId;
	}

	@Override
	public Map<String, Object> getDetail(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstGoodsUtil.IMAGE_ID);

		String imageId = (String) vo.get(ConstGoodsUtil.IMAGE_ID);

		return goodsImagesDAO.getById(null, null, selectCols, appendCols, imageId);
	}

	@Override
	public void delete(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, ConstGoodsUtil.IMAGE_IDS);

		// 获取规格json集合
		String imageIds = TypeConvert.getStringValue(vo.get(ConstGoodsUtil.IMAGE_IDS));
		JSONArray imageIdsArray = JSONObject.parseArray(imageIds);
		if (CollectionUtil.isEmptyCollection(imageIdsArray)) {
			ExceptionUtil.throwValidateException("未设置待删除图片ID");
		}

		goodsImagesDAO.deleteBatch(imageIdsArray);

		// goodsImagesDAO.deleteUpdateById(null,
		// new String[] { GoodsImages.update_id, GoodsImages.update_time },
		// new Object[] { ConstantUtil.FLAG_YES, userId,
		// DateTimeUtil.currentDateTime() },
		// imageId);
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		return goodsImagesDAO.findAllPage(page);
	}

	@Override
	public List<Map<String, Object>> findByGoodsId(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, goods_id);
		String goodsId = (String) vo.get(goods_id);
		return goodsImagesDAO.queryPage(null, null, null, false, selectCols, null,
				new String[] { goods_id }, null, null, sort, new Object[] { goodsId });
	}

	@Override
	public int setDefaultImage(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, ConstGoodsUtil.IMAGE_ID, goods_id,
				store_id);

		String userId = (String) vo.get(user_id);
		String imageId = (String) vo.get(ConstGoodsUtil.IMAGE_ID);
		String goodsId = (String) vo.get(goods_id);
		String storeId = (String) vo.get(store_id);

		Map<String, Object> imageMap = goodsImagesDAO.getById(null, null,
				new String[] { image_path }, null, imageId);

		if (CollectionUtil.isEmptyMap(imageMap)) {
			ExceptionUtil.throwValidateException("图片不存在");
		}

		// 设置商品默认图片时，同步设置商品表冗余字段image_path
		goodsDAO.updateById(null, new String[] { image_path }, null,
				new Object[] { imageMap.get(image_path) }, goodsId);

		// 先将该商品下原有的默认图片取消
		int flag = goodsImagesDAO.update(null, updateCols, null,
				new String[] { goods_id, store_id, is_default },
				new Object[] { ConstantUtil.FLAG_ZERO, userId, DateTimeUtil.currentDateTime() },
				new Object[] { goodsId, storeId, ConstantUtil.FLAG_ONE });

		// 设置刚刚选择的图片为商品默认图片
		flag += goodsImagesDAO.updateById(null, updateCols, null,
				new Object[] { ConstantUtil.FLAG_ONE, userId, DateTimeUtil.currentDateTime() },
				imageId);

		return flag;
	}
}
