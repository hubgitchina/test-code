package cn.com.ut.biz.brand.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * Created by zhouquanguo on 2018/4/26.
 */
public class Brand  extends BaseEntity{

    private static final long serialVersionUID = 2L;

    /**
     * 店铺ID.
     */
    public static final String store_id = "store_id";
    /**
     * 品牌名称.
     */
    public static final String brand_name = "brand_name";
    /**
     * 品牌首字母.
     */
    public static final String brand_initial = "brand_initial";

    /**
     * 品牌图片.
     */
    public static final String brand_pic = "brand_pic";
    /**
     * 品牌排序.
     */
    public static final String sort = "sort";
    /**
     * 品牌推荐，0为否，1为是.
     */
    public static final String brand_recommend = "brand_recommend";
    /**
     * 品牌申请，0为申请中，1为通过，默认为1，申请功能是会员使用.
     */
    public static final String brand_apply = "brand_apply";
    /**
     * 品牌展示类型 0表示图片 1表示文字.
     */
    public static final String brand_showtype = "brand_showtype";

}
