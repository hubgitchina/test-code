
package cn.com.ut.biz.order.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 订单DAO层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
public interface OrderDAO extends JdbcOperation<Order> {
	/**
	 * 新增订单
	 **/
	String add(Map<String, Object> vo, String orderId);

	/**
	 * 更新订单
	 *
	 * @param vo
	 * @return
	 */
	int update(Map<String, Object> vo);

	/**
	 * 根据订单主键集合查询订单信息
	 *
	 * @param collect
	 * @return
	 */
	List<Map<String, Object>> getOrderSnById(List<Object> collect);

	/**
	 * 查询当前用户下的订单列表
	 *
	 * @param
	 * @return
	 */
	List<Map<String, Object>> queryOrderByBuyerId(String buyer_id, PageBean pageBean);

	/**
	 * 根据当前订单ID和买家ID查询订单
	 *
	 * @param buyer_id
	 * @param order_id
	 * @return
	 */
	Map<String, Object> getByBuyerIdAndOrderId(String buyer_id, String order_id);

	/**
	 * 买家根据查询调价筛选订单
	 * 
	 * @param queryCondition
	 * @return
	 */
	List<Map<String, Object>> buyerQuery(Map<String, Object> queryCondition);

}
