
package cn.com.ut.biz.order.service.impl;

import java.math.BigDecimal;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import cn.com.ut.biz.cart.entities.Cart;
import cn.com.ut.biz.cart.service.CartService;
import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.common.JsonUtils;
import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.biz.goods.entities.GoodsSpec;
import cn.com.ut.biz.goods.service.GoodsService;
import cn.com.ut.biz.goods.service.GoodsSpecService;
import cn.com.ut.biz.goodsspec.util.GoodsSpecUtil;
import cn.com.ut.biz.order.entities.OrderCommon;
import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.biz.order.service.OrderCommonService;
import cn.com.ut.biz.order.service.OrderGoodsService;
import cn.com.ut.constant.api.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.*;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.restful.ResponseWrap;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.order.dao.OrderDAO;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.service.OrderService;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import org.springframework.transaction.annotation.Transactional;

import static cn.com.ut.biz.order.entities.OrderCommon.shipping_code;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;

/**
 * 订单Service层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderDAO orderDAO;

	@Autowired
	private OrderGoodsService orderGoodsService;

	@Autowired
	private GoodsSpecService goodsSpecService;

	@Autowired
	private CartService cartService;

	@Autowired
	private GoodsService goodsService;

	@Autowired
	private GIDGenerator gidGenerator;

	@Autowired
	private OrderCommonService orderCommonService;

	@Override
	public List<Map<String, Object>> submitOrder(Map<String, Object> vo) {

		// 参数校验
		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Order.buyer_id, Order.buyer_name,
				OrderCommon.reciver_info, Order.payment_code, Order.goods_amount, Order.order_from,
				Order.order_type, Order.payment_code, "store");
		// 获取当前购物车中的店铺商品信息
		List<Map<String, Object>> storeCartInfoList = (List<Map<String, Object>>) vo.get("store");
		if (CollectionUtil.isEmptyCollection(storeCartInfoList)) {
			ExceptionUtil.throwValidateException("必须传入店铺购物车商品信息");
		}

		// 生成订单详情。同时验证商品库存并且订单主表入库/订单公共表入库
		List<Map<String, Object>> orderItemList = getCartOrderItem(vo);
		if (CollectionUtil.isEmptyCollection(orderItemList)) {
			ExceptionUtil.throwRuntimeException("生成订单详情错误");
		}

		// 批量插入订单详情
		orderGoodsService.batchInsert(orderItemList);
		// 生成成功,减少产品的库存
		reduceProductStock(orderItemList, (String) vo.get(Const.USER_ID));
		// 清空购物车
		cleanCart(orderItemList);
		// 返回给前端数据
		List<Map<String, Object>> result = orderDAO.getOrderSnById(orderItemList.stream()
				.map(e -> e.get(OrderGoods.order_id)).collect(Collectors.toList()));
		// 替换字段名称id为order_id
		List<Map<String, Object>> finalResult = CollectionUtil.replaceListMapKey(result,
				new String[] { Order.idx + "@" + OrderGoods.order_id });
		return finalResult;
	}

	@Override
	public void cancel(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, OrderGoods.order_id, Order.buyer_id,
				Const.USER_ID);
		Map<String, Object> order = orderDAO.getByBuyerIdAndOrderId((String) vo.get(Order.buyer_id),
				(String) vo.get(OrderCommon.order_id));
		if (CollectionUtil.isEmptyMap(order)) {
			ExceptionUtil.throwRuntimeException("当前用户无此订单");

		}
		if ((Integer) order.get(Order.order_state) != Const.OrderStatusEnum.NO_PAY.getCode()) {
			ExceptionUtil.throwValidateException("已付款,无法取消订单");
		}
		// 更新主订单的状态为取消状态
		Map<String, Object> updateOrder = Maps.newHashMap();
		CollectionUtil.copyMap(order, updateOrder);
		updateOrder.put(Order.order_state, Const.OrderStatusEnum.CANCELED.getCode());
		updateOrder.put(Order.idx, vo.get(OrderGoods.order_id));
		updateOrder.put(Order.update_id, vo.get(Const.USER_ID));
		int effectedNum = orderDAO.update(updateOrder);
		if (effectedNum < 1) {
			ExceptionUtil.throwRuntimeException("订单取消失败");
		}
		// 更新完成后返还库存
		// 1、订单商品表查询订单商品明细
		List<Map<String, Object>> orderGoodsList = orderGoodsService
				.selectByOrderId((String) vo.get(OrderGoods.order_id));
		for (Map<String, Object> orderGoods : orderGoodsList) {
			String specparam_id = (String) orderGoods.get(OrderGoods.specparam_id);
			if (StringUtils.isEmpty(specparam_id)) {
				// 无规格直接更新ds_goods表，此时的left_storage是：ds_goods的商品数量
				Map<String, Object> goods = goodsService
						.getByGoodsId((String) orderGoods.get(OrderGoods.goods_id));
				orderGoods.put(Const.flag, false);
				orderGoods.put("left_storage", (Integer) goods.get(Goods.goods_storage)
						+ (Integer) orderGoods.get(OrderGoods.goods_num));
			} else {
				// 如果有规格ID则更新商品主表与规格表，此时的left_storage对应的是：ds_goodspec里的库存数量
				// goods_num对应的是ds_goods里要更新的商品数量
				Map<String, Object> goods = goodsSpecService.getBySpecparmId(specparam_id);
				orderGoods.put(Const.flag, true);
				orderGoods.put("left_storage", (Integer) goods.get(GoodsSpec.goods_storage)
						+ (Integer) (orderGoods.get(OrderGoods.goods_num)));
				orderGoods.put(OrderGoods.goods_num,
						-(Integer) (orderGoods.get(OrderGoods.goods_num)));

			}
		}
		reduceProductStock(orderGoodsList, (String) vo.get(Const.USER_ID));

	}

	@Override
	public Map<String, Object> previewOrder(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Order.buyer_id, Const.USER_ID, "cart_ids",
				Order.buyer_name);
		Object[] cart_ids = ((JSONArray) vo.get("cart_ids")).toArray();
		// 封装返回前端的数据
		Map<String, Object> cartVo = cartService.getCartVoInfo((String) vo.get(Order.buyer_id),
				cart_ids);
		cartVo.put(Order.buyer_id, vo.get(Order.buyer_id));
		cartVo.put(Order.buyer_name, vo.get(Order.buyer_name));

		return cartVo;

	}

	@Override
	public void confirmOrder(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Order.buyer_id, Const.USER_ID,
				OrderGoods.order_id);
		Map<String, Object> order = orderDAO.getByBuyerIdAndOrderId((String) vo.get(Order.buyer_id),
				(String) vo.get(OrderCommon.order_id));
		if (CollectionUtil.isEmptyMap(order)) {
			ExceptionUtil.throwRuntimeException("当前用户无此订单");
		}
		// 只有商品发货后才能确认订单
		if ((int) order.get(Order.order_state) == Const.OrderStatusEnum.SHIPPED.getCode()) {
			Map<String, Object> updateOrder = Maps.newHashMap();
			CollectionUtil.copyMap(order, updateOrder);
			updateOrder.put(Order.order_state, Const.OrderStatusEnum.RECEIVED.getCode());
			updateOrder.put(Order.idx, vo.get(OrderGoods.order_id));
			updateOrder.put(Order.update_id, vo.get(Const.USER_ID));
			Timestamp timestamp = DateTimeUtil.currentDateTime();
			updateOrder.put(Order.finnshed_time, timestamp);
			updateOrder.put(update_time, timestamp);
			int effectedNum = orderDAO.update(updateOrder);
			if (effectedNum < 1) {
				ExceptionUtil.throwRuntimeException("订单确认收货失败");
			}
		} else {
			ExceptionUtil.throwRuntimeException("当前订单未发货或已完成");
		}

	}

	@Override
	public void deleteOrder(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, OrderGoods.order_id, Order.buyer_id,
				Const.USER_ID);
		Map<String, Object> order = orderDAO.getByBuyerIdAndOrderId((String) vo.get(Order.buyer_id),
				(String) vo.get(OrderCommon.order_id));
		if (CollectionUtil.isEmptyMap(order)) {
			ExceptionUtil.throwRuntimeException("当前用户无此订单");

		}
		// 只有已完成或者已取消的订单才能删除
		if ((Integer) order.get(Order.order_state) == Const.OrderStatusEnum.CANCELED.getCode()
				|| (Integer) order.get(Order.order_state) == Const.OrderStatusEnum.ORDER_SUCCESS
						.getCode()) {
			Map<String, Object> updateOrder = Maps.newHashMap();
			CollectionUtil.copyMap(order, updateOrder);
			updateOrder.put(Order.idx, vo.get(OrderGoods.order_id));
			updateOrder.put(Order.update_id, vo.get(Const.USER_ID));
			updateOrder.put(Order.is_del, ConstantUtil.FLAG_YES);
			updateOrder.put(Order.delete_state,
					Const.OrderStatusEnum.THOROUGHLY_DELETING.getCode());
			updateOrder.put(Order.order_state, Const.OrderStatusEnum.CANCELED.getCode());
			int effectedNum = orderDAO.update(updateOrder);
			if (effectedNum < 1) {
				ExceptionUtil.throwRuntimeException("订单删除失败");
			}

		} else {
			ExceptionUtil.throwValidateException("当前订单正在进行中，无法删除当前订单");
		}

	}

	@Override
	public void modifyOrder(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, OrderGoods.order_id, Const.USER_ID,
				Order.order_amount, OrderCommon.order_message, OrderCommon.reciver_info);
		Map<String, Object> order = orderDAO.getByBuyerIdAndOrderId((String) vo.get(Order.buyer_id),
				(String) vo.get(OrderCommon.order_id));
		if (CollectionUtil.isEmptyMap(order)) {
			ExceptionUtil.throwRuntimeException("当前用户无此订单");
		}
		// 如果当前订单的订单金额无变化，则不用进行更新主订单信息
		if (((BigDecimal) order.get(Order.order_amount))
				.compareTo((BigDecimal) vo.get(Order.order_amount)) != 0) {
			order.put(Order.order_amount, vo.get(Order.order_amount));
			CollectionUtil.replaceMapKey(order,
					new String[] { OrderGoods.order_id + "@" + Order.idx });
			orderDAO.update(order);
		}
		orderCommonService.updateOrderCommonInfo(vo);

	}

	@Override
	public ResponseWrap queryOrders(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.Page.PAGE_NO, Const.Page.PAGE_SIZE,
				Const.USER_ID, Order.buyer_id);
		PageBuilder pb = PageBuilder.build();
		PageBean pageBean = pb.buildSQL(vo);
		// 根据buyer_id查询当前用户的订单列表
		List<Map<String, Object>> orderList = orderDAO
				.queryOrderByBuyerId((String) vo.get(Order.buyer_id), pageBean);

		if (CollectionUtil.isEmptyCollection(orderList)) {
			ExceptionUtil.throwRuntimeException("当前用户无订单");

		}
		// 提取订单ID列表
		List<String> orderIdList = orderList.stream().map(e -> (String) e.get(OrderGoods.order_id))
				.collect(Collectors.toList());
		// 根据订单ID列表查询订单公共信息
		List<Map<String, Object>> orderCommonList = orderCommonService
				.queryOrderByOrderIdList(orderIdList);
		// 反序列化order_goods为列表
		for (Map<String, Object> order : orderList) {
			String orderGoods = (String) order.get(Order.order_goods);
			order.put(Order.order_goods, JsonUtils.str2obj(orderGoods, List.class));
			// 设置订单留言等信息
			Map<String, Object> orderCommonInfo = orderCommonList.stream().filter(
					e -> (e.get(OrderCommon.order_id)).equals(order.get(OrderCommon.order_id)))
					.collect(Collectors.toList()).get(0);
			order.put(OrderCommon.order_message, orderCommonInfo.get(OrderCommon.order_message));

		}

		Map<String, Object> result = Maps.newHashMap();
		result.put("order", orderList);

		return ResponseWrap.builder().appendPage(pageBean).appendData(result);

	}

	@Override
	public ResponseWrap viewOrder(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Order.buyer_id,
				OrderCommon.order_id);
		Map<String, Object> order = orderDAO.getByBuyerIdAndOrderId((String) vo.get(Order.buyer_id),
				(String) vo.get(OrderCommon.order_id));
		// 根据订单ID列表查询订单公共信息
		Map<String, Object> orderCommon = orderCommonService
				.queryOrderByOrderIdList(Arrays.asList((String) vo.get(OrderCommon.order_id)))
				.get(0);
		if (CollectionUtil.isEmptyMap(order) || CollectionUtil.isEmptyMap(orderCommon)) {
			ExceptionUtil.throwRuntimeException("当前用户无此订单");
		}
		order.put(OrderCommon.order_message, orderCommon.get(OrderCommon.order_message));
		order.put(Order.order_state, order.get(Order.order_state) + ":"
				+ Const.OrderStatusEnum.codeOf((Integer) order.get(Order.order_state)).getValue());
		String orderGoods = (String) order.get(Order.order_goods);
		order.put(Order.order_goods, JsonUtils.str2obj(orderGoods, List.class));

		return ResponseWrap.builder().appendData(order);
	}

	@Override
	public ResponseWrap deliver(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Order.buyer_id,
				OrderCommon.order_id, OrderCommon.shipping_express_id, shipping_code);
		Map<String, Object> order = orderDAO.getByBuyerIdAndOrderId((String) vo.get(Order.buyer_id),
				(String) vo.get(OrderCommon.order_id));
		Map<String, Object> orderCommon = orderCommonService
				.queryOrderByOrderIdList(Arrays.asList((String) vo.get(OrderCommon.order_id)))
				.get(0);
		if (CollectionUtil.isEmptyMap(order) || CollectionUtil.isEmptyMap(orderCommon)) {
			ExceptionUtil.throwRuntimeException("当前用户无此订单");
		}

		// 只有已付款的订单才能安排发货
		if ((Integer) order.get(Order.order_state) == Const.OrderStatusEnum.PAID.getCode()) {
			order.put(Order.order_state, Const.OrderStatusEnum.SHIPPED.getCode());
			CollectionUtil.replaceMapKey(order,
					new String[] { OrderGoods.order_id + "@" + Order.idx });
			orderDAO.update(order);
			// 同时更新order_common表中的信息
			CollectionUtil.copyMap(vo, orderCommon);
			// 更新发货时间
			orderCommon.put(OrderCommon.shipping_time, DateTimeUtil.currentDateTime());
			orderCommonService.update(orderCommon);
		} else {
			ExceptionUtil.throwRuntimeException("订单未付款，请确认");
		}
		return viewOrder(vo);
	}

	@Override
	public List<Map<String, Object>> buyerQuery(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Order.buyer_id, Const.USER_ID, "query_condition");
		if (orderDAO.queryOrderByBuyerId((String) vo.get(Order.buyer_id), null).size() < 1) {
			ExceptionUtil.throwRuntimeException("当前用户无订单记录");
		}
		Map<String, Object> queryCondition = (Map<String, Object>) vo.get("query_condition");

		return orderDAO.buyerQuery(queryCondition);

	}

	@Override
	public Map<String, Object> getByOrderId(String orderId) {

		return orderDAO.getById(null, null, null, null, orderId);
	}

	@Override
	public int updateOrder(Map<String, Object> order) {

		return orderDAO.update(order);

	}

	private void cleanCart(List<Map<String, Object>> orderItemList) {

		// 清除当前店铺下的指定条商品的数量
		cartService.batchCleanCart(orderItemList);

	}

	private void reduceProductStock(List<Map<String, Object>> orderItemList, String user_id) {

		goodsSpecService.batchUpdateGoodsStorge(orderItemList, user_id);

	}

	/**
	 * 计算当前订单的总金额
	 *
	 * @param orderItemList
	 * @return
	 */
	private BigDecimal getOrderTotalPrice(List<Map<String, Object>> orderItemList) {

		return orderItemList.stream()
				.map(e -> BigDecimal.valueOf(Double.valueOf((String) e.get(OrderGoods.goods_num)))
						.multiply((BigDecimal) e.get(OrderGoods.goods_price)))
				.reduce(BigDecimal.ZERO, BigDecimal::add);

	}

	/**
	 * 计算当前店铺订单的商品总数量
	 *
	 * @param shopOrderGoodsList
	 * @return
	 */
	private Integer getTotalGoodsNum(List<Map<String, Object>> shopOrderGoodsList) {

		return shopOrderGoodsList.stream()
				.map(e -> Integer.parseInt((String) e.get(OrderGoods.goods_num)))
				.reduce(0, Integer::sum);

	}

	// 生成订单详情列表
	@Transactional
	private List<Map<String, Object>> getCartOrderItem(Map<String, Object> vo) {

		// 获取当前订单的购物车商品列表
		List<Map<String, Object>> storeCartInfoList = (List<Map<String, Object>>) vo.get("store");
		// 提取公共信息，方便订单主表入库
		String buyer_id = (String) vo.get(Order.buyer_id);
		String buyer_name = (String) vo.get(Order.buyer_name);
		Integer order_from = (Integer) vo.get(Order.order_from);
		Integer order_type = (Integer) vo.get(Order.order_type);
		String payment_code = (String) vo.get(Order.payment_code);
		String crete_id = (String) vo.get(Const.USER_ID);
		List<Map<String, Object>> orderGoodsList = Lists.newArrayList();
		for (Map<String, Object> storeCartInfo : storeCartInfoList) {
			if (!CollectionUtil.isEmptyMap(storeCartInfo)) {
				String store_id = (String) storeCartInfo.get(Cart.store_id);
				// 生成当前店铺的订单主键ID
				String currentShopOrderId = CommonUtil.getUUID();
				// 当前店铺的订单总金额
				BigDecimal currentShopTotalAmount = new BigDecimal("0");
				List<Map<String, Object>> storeGoodsList = (List<Map<String, Object>>) storeCartInfo
						.get("goods");
				if (!CollectionUtil.isEmptyCollection(storeGoodsList)) {
					// 遍历当前店铺的商品列表
					for (Map<String, Object> goods : storeGoodsList) {
						Map<String, Object> orderGoods = Maps.newHashMap();
						// 如果有规格信息则按照规格ID查询当前商品的信息，否则按照商品ID在商品主表查询信息
						Map<String, Object> goodsInfo;
						// 反序列化规格组合列表
						List specGroupList = JsonUtils.str2obj(
								goods.get(GoodsSpecUtil.SPEC_PARAM).toString(), List.class);
						if (!CollectionUtil.isEmptyCollection(specGroupList)) {
							String specparam_id = GoodsSpecUtil
									.handleSpecParamSingle(new JSONObject(goods)).getSpecparam_id();
							goodsInfo = goodsSpecService.getGoodsPriceBySpecId(specparam_id);
							orderGoods.put(Const.flag, true);
						} else {
							goodsInfo = goodsService
									.getByGoodsId((String) goods.get(Cart.goods_id));
							orderGoods.put(Const.flag, false);
						}
						// 校验商品信息是否正确
						if (CollectionUtil.isEmptyMap(goodsInfo)) {
							ExceptionUtil.throwValidateException("店铺商品不存在");
						}
						// 校验库存
						if ((Integer) (goods.get(Cart.goods_num)) > (Integer) goodsInfo
								.get(GoodsSpec.goods_storage)) {
							ExceptionUtil.throwRuntimeException(
									"商品" + goodsInfo.get(GoodsSpec.goods_name) + "库存不足");
						}
						// 组装OrderGoods
						orderGoods.put(OrderGoods.goods_id, goods.get(Cart.goods_id));
						orderGoods.put(OrderGoods.goods_name, goods.get(OrderGoods.goods_name));
						orderGoods.put(OrderGoods.goods_price,
								goodsInfo.get(GoodsSpec.goods_price));
						orderGoods.put(OrderGoods.goods_image,
								goodsInfo.get(GoodsSpec.goods_image));
						orderGoods.put(OrderGoods.create_id, crete_id);
						orderGoods.put(OrderGoods.buyer_id, buyer_id);
						orderGoods.put(OrderGoods.store_id, store_id);
						orderGoods.put(OrderGoods.order_id, currentShopOrderId);
						orderGoods.put(OrderGoods.goods_num, goods.get(Cart.goods_num));
						orderGoods.put(OrderGoods.specparam_id, goodsInfo.get(Cart.specparam_id));
						orderGoods.put(OrderGoods.specparam_name,
								goodsInfo.get(Cart.specparam_name));
						// 商品成交价计算
						BigDecimal goods_pay_price = ((BigDecimal) goodsInfo
								.get(GoodsSpec.goods_price)).multiply(
										BigDecimal.valueOf((Integer) goods.get(Cart.goods_num)));
						orderGoods.put(OrderGoods.goods_pay_price, goods_pay_price);

						// 冗余字段，方便减库存用
						orderGoods.put("left_storage",
								(Integer) goodsInfo.get(GoodsSpec.goods_storage)
										- (Integer) goods.get(Cart.goods_num));
						orderGoodsList.add(orderGoods);
						currentShopTotalAmount = currentShopTotalAmount.add(goods_pay_price);

					}

				}
				storeCartInfo.put(Order.buyer_id, buyer_id);
				storeCartInfo.put(Order.buyer_name, buyer_name);
				storeCartInfo.put(Order.order_from, order_from);
				storeCartInfo.put(Order.order_type, order_type);
				storeCartInfo.put(Order.payment_code, payment_code);
				// 当前店铺的订单主表入库
				assembleOrder(storeCartInfo, currentShopTotalAmount, currentShopOrderId, crete_id);
				// 当前店铺的订单公共表入库
				assembleOrderCommon(currentShopOrderId, storeCartInfo);

			}

		}

		return orderGoodsList;

	}

	/**
	 * 订单主表入库
	 *
	 * @param vo:前端传递的VO对象
	 * @param payment：店铺下的订单总金额
	 * @param orderId：订单主ID
	 * @return
	 */
	private void assembleOrder(Map<String, Object> vo, BigDecimal payment, String orderId,
			String create_id) {

		ValidatorUtil.validateMapContainsKey(vo, Order.buyer_name, Order.buyer_id,
				Order.shipping_fee, Order.payment_code, "goods", Order.shipping_fee, Order.store_id,
				Order.store_name, Order.order_from);
		Map<String, Object> order = Maps.newHashMap();
		CollectionUtil.copyMap(vo, order);
		order.put(Order.add_time, DateTimeUtil.currentDateTime());
		order.put(Order.goods_amount, payment);
		order.put(Order.delete_state, Const.OrderStatusEnum.NO_DELETE.getCode());
		order.put(Order.order_state, Const.OrderStatusEnum.NO_PAY.getCode());
		order.put(Order.create_id, create_id);
		order.put(Order.order_goods, vo.get("goods").toString());
		order.put(Order.shipping_fee, vo.get(Order.shipping_fee));
		// 生成订单序列号
		String order_sn = gidGenerator.genOrderSequence();
		order.put(Order.order_sn, order_sn);
		// 计算订单总金额=商品总金额+运费
		BigDecimal order_amount = payment.add(new BigDecimal((String) vo.get(Order.shipping_fee)));
		order.put(Order.order_amount, order_amount);

		// 订单入库
		orderDAO.add(order, orderId);

	}

	/**
	 * 当前店铺的订单公共表入库
	 *
	 * @param currentShopOrderId:当前店铺下订单主表ID
	 * @param vo：前端传递的VO对象
	 */
	private void assembleOrderCommon(String currentShopOrderId, Map<String, Object> vo) {

		Map<String, Object> orderCommon = Maps.newHashMap();
		CollectionUtil.copyMap(vo, orderCommon);
		orderCommon.put(OrderCommon.order_id, currentShopOrderId);
		orderCommon.put(OrderCommon.create_id, vo.get(Const.USER_ID));
		// TODO:订单公共表的插入信息需要确认
		orderCommon.put(OrderCommon.reciver_info, "尽快发货");
		orderCommon.put(OrderCommon.deliver_explain, "");
		orderCommon.put(OrderCommon.evaluation_time, DateTimeUtil.currentDateTime());
		orderCommon.put(OrderCommon.evalseller_time, DateTimeUtil.currentDateTime());
		orderCommon.put(OrderCommon.reciver_name, "xiaohuangren");
		orderCommon.put(OrderCommon.reciver_city_id, "1");
		orderCommon.put(OrderCommon.order_message, "1");
		orderCommon.put(OrderCommon.shipping_express_id, "1");
		orderCommon.put(OrderCommon.evalseller_state, "1");
		orderCommon.put(OrderCommon.shipping_time, DateTimeUtil.currentDateTime());
		orderCommon.put(OrderCommon.reciver_province_id, "1");
		String orderCommonId = orderCommonService.add(orderCommon);

	}
}
