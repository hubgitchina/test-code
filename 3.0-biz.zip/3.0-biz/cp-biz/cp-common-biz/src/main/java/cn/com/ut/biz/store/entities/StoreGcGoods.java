
//------------------------------entity-start--------------------------------//
package cn.com.ut.biz.store.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class StoreGcGoods extends BaseEntity {


	/**
     * 店铺ID
     */
    public static final String store_id = "store_id";
	/**
     * 店铺商品分类ID
     */
    public static final String storegc_id = "storegc_id";
	/**
     * 商品ID
     */
    public static final String goods_id = "goods_id";
}
//------------------------------entity-end--------------------------------//
