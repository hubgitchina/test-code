package cn.com.ut.biz.refund.impl;

import cn.com.ut.biz.refund.RefundService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author zhouquanguo
 * @since on 2018/6/6.
 */
@Service
@Slf4j
public class RefundServiceImpl implements RefundService {

	@Override
	public void processRefund() {

		log.info("--- 退款处理完成 ---");

	}
}
