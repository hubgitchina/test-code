package cn.com.ut.biz.user.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.user.entities.UserAddress;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface UserAddressDAO extends JdbcOperation<UserAddress> {
	public int updateUserAddressAsNotDefault(String userId, String isDefault);

	public int updateAddressAsDefault(String id, String isDefault);

	public List<Map<String, Object>> queryUserAddress(String userId, PageBean page);

	public Map<String, Object> getDefaultAddr(String userId);

}
