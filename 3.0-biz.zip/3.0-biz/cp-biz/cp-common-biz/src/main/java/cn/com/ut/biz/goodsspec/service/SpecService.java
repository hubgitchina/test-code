package cn.com.ut.biz.goodsspec.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 商品规格业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface SpecService {

	/**
	 * 添加商品规格
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 修改商品规格
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询商品规格详情
	 */
	Map<String, Object> getDetail(Map<String, Object> vo);

	/**
	 * 删除商品规格
	 * 
	 * @param id
	 * @param appId
	 */
	void delete(Map<String, Object> vo);

	/**
	 * 查询所有的商品规格（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);
}
