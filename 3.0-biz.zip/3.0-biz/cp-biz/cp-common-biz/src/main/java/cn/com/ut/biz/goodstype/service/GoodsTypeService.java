package cn.com.ut.biz.goodstype.service;


import cn.com.ut.core.restful.ResponseWrap;


import java.util.Map;

/**
 * 商品类型业务层接口
 *
 * Created by zhouquanguo on 2018/5/9.
 */
public interface GoodsTypeService {
    /**
     * 新增产品类型
     *
     * @param vo
     * @return
     */
    String create(Map<String, Object> vo);

    /**
     * 更新商品类型
     *
     * @param vo
     * @return
     */
    String update(Map<String, Object> vo);

    /**
     * 获取类型详情
     *
     * @param vo
     * @return
     */
    Map<String, Object> getOne(Map<String, Object> vo);

    /**
     * 删除商品类型
     *
     * @param vo
     */
    void delete(Map<String, Object> vo);

    /**
     * 查询所有的商品类型详情
     *
     * @param
     * @return
     */
    ResponseWrap query(Map<String, Object> vo);
}
