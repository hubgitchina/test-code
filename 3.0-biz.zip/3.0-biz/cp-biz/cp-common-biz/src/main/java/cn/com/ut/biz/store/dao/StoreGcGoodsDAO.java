
//-----------------------------DAO-start---------------------------------//
package cn.com.ut.biz.store.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.store.entities.StoreGcGoods;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface StoreGcGoodsDAO extends JdbcOperation<StoreGcGoods> {

	List<Map<String, Object>> queryGoodsStoreClass(String storeId, String goodsId);

}
//-----------------------------DAO-end---------------------------------//