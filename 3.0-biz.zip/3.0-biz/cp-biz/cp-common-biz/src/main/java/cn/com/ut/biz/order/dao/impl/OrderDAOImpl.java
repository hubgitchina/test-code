
package cn.com.ut.biz.order.dao.impl;

import static cn.com.ut.biz.order.entities.Order.*;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import cn.com.ut.biz.order.entities.OrderGoods;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import cn.com.ut.biz.order.dao.OrderDAO;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.core.common.jdbc.PageBean;

import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 订单DAO层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
@Repository
public class OrderDAOImpl extends JdbcOperationsImpl<Order> implements OrderDAO {

	@Override
	public String add(Map<String, Object> vo, String orderId) {

		add(null, new String[] { store_id, delete_state, lock_state, goods_amount, payment_time,
				buyer_name, evaluation_state, buyer_id, shipping_fee, finnshed_time, order_from,
				order_amount, store_name, refund_amount, pay_sn, add_time, order_state,
				refund_state, order_type, order_sn, payment_code, delay_time, order_goods },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo, new String[] { store_id, delete_state, lock_state, goods_amount,
								payment_time, buyer_name, evaluation_state, buyer_id, shipping_fee,
								finnshed_time, order_from, order_amount, store_name, refund_amount,
								pay_sn, add_time, order_state, refund_state, order_type, order_sn,
								payment_code, delay_time, order_goods })
						.append(orderId, DateTimeUtil.currentDateTime(), vo.get(Order.create_id))
						.toArray());
		return orderId;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null, new String[] { store_id, delete_state, lock_state, goods_amount,
				payment_time, buyer_name, evaluation_state, buyer_id, shipping_fee, finnshed_time,
				order_from, order_amount, store_name, refund_amount, pay_sn, add_time, order_state,
				refund_state, order_type, order_sn, payment_code, delay_time, is_del },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo, new String[] { store_id, delete_state, lock_state, goods_amount,
								payment_time, buyer_name, evaluation_state, buyer_id, shipping_fee,
								finnshed_time, order_from, order_amount, store_name, refund_amount,
								pay_sn, add_time, order_state, refund_state, order_type, order_sn,
								payment_code, delay_time, is_del })
						.append(DateTimeUtil.currentDateTime(), vo.get(Order.update_id)).toArray(),
				(String) vo.get(Order.idx), null);
	}

	@Override
	public List<Map<String, Object>> getOrderSnById(List<Object> orderIdList) {

		SQLHelper table = SQLHelper.builder();
		table.append("ds_order").append(" o WHERE o.id {IN}");
		String tableSql = replaceInCase(table.toSQL(), new int[] { orderIdList.size() });
		ParameterBuilder param = ParameterBuilder.builder();
		param.appendColumns("o", Order.order_sn);
		param.appendColumns("o", idx);
		List<Object> args = new ArrayList<>();
		args.addAll(orderIdList);
		return queryPage(null, null, tableSql, true, param.toColumns(), null, null, null, null,
				null, args.toArray());

	}

	@Override
	public List<Map<String, Object>> queryOrderByBuyerId(String buyerId, PageBean pageBean) {

		String[] COLUMNS = new String[] { Order.idx + " as order_id", order_sn, buyer_id,
				buyer_name, payment_code, pay_sn, payment_time, shipping_fee, goods_amount,
				order_amount, store_id, store_name, add_time, finnshed_time, order_state,
				order_goods };
		return queryPage(pageBean, null, null, false, COLUMNS, null,
				new String[] { Order.buyer_id }, null, null, null, new Object[] { buyerId });
	}

	@Override
	public Map<String, Object> getByBuyerIdAndOrderId(String buyer_id, String order_id) {

		String[] COLUMNS = new String[] { Order.idx + " as order_id", order_sn, Order.buyer_id,
				buyer_name, payment_code, pay_sn, payment_time, shipping_fee, goods_amount,
				order_amount, store_id, store_name, add_time, finnshed_time, order_state,
				order_goods, delete_state, order_from };
		return getByKey(null, null, COLUMNS, null, new String[] { Order.buyer_id, Order.idx },
				new Object[] { buyer_id, order_id }, null);
	}

	@Override
	public List<Map<String, Object>> buyerQuery(Map<String, Object> queryCondition) {

		SQLHelper table = SQLHelper.builder();
		table.append(
				"ds_order o,ds_ordergoods g,ds_ordercommon c WHERE o.id = g.order_id AND g.order_id = c.order_id ");
		// 拼接查询条件
		Iterator iterator = queryCondition.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry map = (Map.Entry) iterator.next();
			String key = (String) map.getKey();
			String value = (String) map.getValue();

			if (key.equals(OrderGoods.goods_name) && StringUtils.isNotEmpty(value)) {
				table.append("AND g.goods_name LIKE '%" + value + "%'");
			}
			if (key.equals(OrderGoods.specparam_name) && StringUtils.isNotEmpty(value)) {
				table.append("AND g.specparam_name LIKE '%" + value + "%'");
			}
			if (key.equals(Order.store_name) && StringUtils.isNotEmpty(value)) {
				table.append("AND o.store_name LIKE '%" + value + "%'");
			}
			if (key.equals(Order.order_sn) && StringUtils.isNotEmpty(value)) {
				table.append("AND o.order_sn = " + value);
			}
			if (key.equals("param_from_time") && StringUtils.isNotEmpty(value)) {
				table.append("AND o.add_time >= '" + value + "'");
			}
			if (key.equals("param_to_time") && StringUtils.isNotEmpty(value)) {
				table.append("AND o.add_time <= '" + value + "'");
			}
			if (key.equals(Order.order_state) && StringUtils.isNotEmpty(value)) {
				table.append("AND o.order_state = " + value);
			}

		}
		ParameterBuilder parameterBuilder = ParameterBuilder.builder();
		parameterBuilder.appendColumns("o", Order.idx + " as order_id", Order.order_sn,
				Order.goods_amount, Order.order_amount, Order.pay_sn, Order.store_id,
				Order.store_name, Order.order_goods, Order.add_time, Order.payment_code,
				Order.payment_time, Order.finnshed_time);

		String sql = table.toSQL();

		return queryPage(null, null, sql, true, parameterBuilder.toColumns(), null, null, null,
				null, "o.add_time DESC", null);

	}

}
