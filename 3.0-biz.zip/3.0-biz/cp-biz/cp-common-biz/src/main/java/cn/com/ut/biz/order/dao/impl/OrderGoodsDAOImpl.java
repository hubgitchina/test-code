
package cn.com.ut.biz.order.dao.impl;

import static cn.com.ut.biz.order.entities.OrderGoods.store_id;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_name;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_image;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_price;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_id;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_num;
import static cn.com.ut.biz.order.entities.OrderGoods.buyer_id;
import static cn.com.ut.biz.order.entities.OrderGoods.order_id;
import static cn.com.ut.biz.order.entities.OrderGoods.goods_pay_price;
import static cn.com.ut.biz.order.entities.OrderGoods.specparam_id;
import static cn.com.ut.biz.order.entities.OrderGoods.specparam_name;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.order.dao.OrderGoodsDAO;
import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 订单商品表DAO层
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
@Repository
public class OrderGoodsDAOImpl extends JdbcOperationsImpl<OrderGoods> implements OrderGoodsDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null,
				new String[] { store_id, goods_name, goods_image, goods_price, goods_id, goods_num,
						buyer_id, order_id, goods_pay_price },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { store_id, goods_name, goods_image, goods_price,
										goods_id, goods_num, buyer_id, order_id, goods_pay_price })
						.append(id, DateTimeUtil.currentDateTime(), vo.get(OrderGoods.create_id))
						.toArray());
		return id;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null,
				new String[] { store_id, goods_name, goods_image, goods_price, goods_id, goods_num,
						buyer_id, order_id, goods_pay_price },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { store_id, goods_name, goods_image, goods_price,
										goods_id, goods_num, buyer_id, order_id, goods_pay_price })
						.append(DateTimeUtil.currentDateTime(), vo.get(OrderGoods.update_id))
						.toArray(),
				(String) vo.get(OrderGoods.idx), null);
	}

	@Override
	public void addBatch(List<Map<String, Object>> orderItemList) {

		for (Map<String, Object> orderItem : orderItemList) {
			orderItem.put(OrderGoods.idx, CommonUtil.getUUID());
			orderItem.put(OrderGoods.create_time, DateTimeUtil.currentDateTime());

		}
		addVoBatch(null,
				new String[] { store_id, goods_name, goods_image, goods_price, goods_id, goods_num,
						buyer_id, order_id, goods_pay_price, specparam_id, specparam_name },
				NAMES_ID_CT_CID, orderItemList);

	}

	@Override
	public List<Map<String, Object>> selectByOrderId(String orderId) {

		return queryForList(getJdbcTemplate(), "SELECT * FROM ds_ordergoods WHERE order_id=?",
				orderId);
	}

	@Override
	public List<Map<String, Object>> selectByOrderIdList(List<String> orderIdList) {

		String[] COLUMNS = new String[] { OrderGoods.idx + " as ordergoods_id", store_id,
				goods_name, goods_image, goods_price, goods_id, goods_num, order_id,
				goods_pay_price, specparam_id, specparam_name };
		SQLHelper table = SQLHelper.builder();
		table.append("ds_ordergoods").append(" d WHERE d.order_id {IN} AND d.is_del = 'N' ");
		String tableSql = replaceInCase(table.toSQL(), new int[] { orderIdList.size() });
		ParameterBuilder param = ParameterBuilder.builder();
		param.appendColumns("c", COLUMNS);
		List<Object> args = new ArrayList<>();
		args.addAll(orderIdList);
		return queryPage(null, null, tableSql, true, param.toColumns(), null, null, null, null,
				null, args.toArray());

	}
}
