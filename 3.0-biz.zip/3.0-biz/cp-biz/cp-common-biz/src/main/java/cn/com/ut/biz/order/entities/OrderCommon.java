
package cn.com.ut.biz.order.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 订单公共表实体类
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
public class OrderCommon extends BaseEntity {

	/**
	 * 收货人其它信息
	 */
	public static final String reciver_info = "reciver_info";
	/**
	 * 订单发货备注
	 */
	public static final String deliver_explain = "deliver_explain";
	/**
	 * 评价时间
	 */
	public static final String evaluation_time = "evaluation_time";
	/**
	 * 卖家评价买家的时间
	 */
	public static final String evalseller_time = "evalseller_time";
	/**
	 * 收货人姓名
	 */
	public static final String reciver_name = "reciver_name";
	/**
	 * 收货人市级ID
	 */
	public static final String reciver_city_id = "reciver_city_id";
	/**
	 * 订单留言
	 */
	public static final String order_message = "order_message";
	/**
	 * 配送公司ID
	 */
	public static final String shipping_express_id = "shipping_express_id";
	/**
	 * 卖家是否已评价买家(0未评价1已评价)
	 */
	public static final String evalseller_state = "evalseller_state";
	/**
	 * 订单ID
	 */
	public static final String order_id = "order_id";
	/**
	 * 配送时间
	 */
	public static final String shipping_time = "shipping_time";
	/**
	 * 收货人省级ID
	 */
	public static final String reciver_province_id = "reciver_province_id";
	/**
	 * 订单物流单号
	 */
	public static final String shipping_code = "shipping_code";

}
