package cn.com.ut.biz.goods.service.impl;

import static cn.com.ut.biz.goods.entities.Goods.brand_id;
import static cn.com.ut.biz.goods.entities.Goods.gc_id;
import static cn.com.ut.biz.goods.entities.Goods.goods_addtime;
import static cn.com.ut.biz.goods.entities.Goods.goods_body;
import static cn.com.ut.biz.goods.entities.Goods.goods_commend;
import static cn.com.ut.biz.goods.entities.Goods.goods_costprice;
import static cn.com.ut.biz.goods.entities.Goods.goods_freight;
import static cn.com.ut.biz.goods.entities.Goods.goods_marketprice;
import static cn.com.ut.biz.goods.entities.Goods.goods_name;
import static cn.com.ut.biz.goods.entities.Goods.goods_price;
import static cn.com.ut.biz.goods.entities.Goods.goods_serial;
import static cn.com.ut.biz.goods.entities.Goods.goods_shelftime;
import static cn.com.ut.biz.goods.entities.Goods.goods_state;
import static cn.com.ut.biz.goods.entities.Goods.goods_storage;
import static cn.com.ut.biz.goods.entities.Goods.goods_storage_alarm;
import static cn.com.ut.biz.goods.entities.Goods.is_virtual;
import static cn.com.ut.biz.goods.entities.Goods.price_max;
import static cn.com.ut.biz.goods.entities.Goods.price_min;
import static cn.com.ut.biz.goods.entities.Goods.spec_value;
import static cn.com.ut.biz.goods.entities.Goods.store_id;
import static cn.com.ut.biz.goods.entities.Goods.type_id;
import static cn.com.ut.biz.goods.entities.GoodsSpec.goods_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.user_id;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;

import cn.com.ut.biz.goods.dao.GoodsDAO;
import cn.com.ut.biz.goods.service.GoodsAttrIndexService;
import cn.com.ut.biz.goods.service.GoodsService;
import cn.com.ut.biz.goods.util.ConstGoodsUtil;
import cn.com.ut.biz.goodsimage.service.GoodsImagesService;
import cn.com.ut.biz.goodsspec.util.GoodsSpecUtil;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 商品信息业务层接口实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Service
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	private GoodsDAO goodsDAO;

	@Autowired
	private GoodsImagesService goodsImagesService;

	@Autowired
	private GoodsAttrIndexService goodsAttrIndexService;

	private static String[] checkCols = { goods_name, store_id, is_del };

	@Override
	public String addGoods(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, goods_name, gc_id, store_id, brand_id,
				type_id, goods_price, goods_marketprice, goods_costprice, goods_serial,
				goods_storage_alarm, goods_commend, goods_freight, is_virtual, goods_storage);

		String userId = (String) vo.get(user_id);
		vo.put(create_id, userId);

		// 添加商品时，同步设置最大价格和最小价格字段等同于商品价格
		String goodsPrice = (String) vo.get(goods_price);
		vo.put(price_min, goodsPrice);
		vo.put(price_max, goodsPrice);

		boolean isCanAdd = goodsDAO.checkUnique(checkCols,
				new Object[] { vo.get(goods_name), vo.get(store_id), ConstantUtil.FLAG_NO }, null,
				null);
		if (!isCanAdd) {
			ExceptionUtil.throwValidateException("该店铺下已存在同名商品");
		}

		// 设置商品添加时间（数据库为必填字段）
		vo.put(goods_addtime, DateTimeUtil.currentDateTime());

		return goodsDAO.insert(vo);
	}

	@Override
	public String updateGoods(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, goods_id, goods_name, gc_id, store_id,
				brand_id, type_id, goods_price, goods_marketprice, goods_costprice, goods_serial,
				goods_storage_alarm, goods_commend, goods_freight, is_virtual, goods_storage);

		String goodsId = (String) vo.get(goods_id);
		Map<String, Object> goodsInfo = goodsDAO.existGoods(goodsId);
		if (CollectionUtil.isEmptyMap(goodsInfo)) {
			ExceptionUtil.throwValidateException("商品不存在");
		}
		vo.put(idx, goodsId);

		String userId = (String) vo.get(user_id);
		vo.put(update_id, userId);

		// 修改商品时，同步设置最大价格和最小价格字段等同于商品价格
		String goodsPrice = (String) vo.get(goods_price);
		vo.put(price_min, goodsPrice);
		vo.put(price_max, goodsPrice);

		boolean isCanUpdate = goodsDAO.checkUnique(checkCols,
				new Object[] { vo.get(goods_name), vo.get(store_id), ConstantUtil.FLAG_NO },
				new String[] { idx }, new Object[] { goodsId });
		if (!isCanUpdate) {
			ExceptionUtil.throwValidateException("该店铺下已存在同名商品");
		}

		goodsDAO.update(vo);
		return goodsId;
	}

	@Override
	public Map<String, Object> getGoods(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, goods_id);

		String goodsId = (String) vo.get(goods_id);

		return goodsDAO.getGoods(goodsId);
	}

	@Override
	public void delete(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, user_id, goods_id);

		String userId = (String) vo.get(user_id);
		String goodsId = (String) vo.get(goods_id);

		// goodsDAO.delete(goodsId);

		goodsDAO.deleteUpdateById(null, new String[] { update_id, update_time },
				new Object[] { ConstantUtil.FLAG_YES, userId, DateTimeUtil.currentDateTime() },
				goodsId);
	}

	@Override
	public List<Map<String, Object>> queryStoreGoods(PageBean page, Map<String, Object> vo) {

		return goodsDAO.queryStoreGoods(page, vo);
	}

	@Override
	public List<Map<String, Object>> queryMallGoods(PageBean page) {

		return goodsDAO.queryMallGoods(page);
	}

	@Override
	public void updateGoodsState(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, goods_id, goods_state);

		String goodsId = (String) vo.get(goods_id);
		String goodsState = (String) vo.get(goods_state);

		// 判断是否为设置商品上架，1表示上架，同步设置表字段商品上架时间goods_shelftime
		if (ConstantUtil.FLAG_ONE.equals(goodsState)) {
			goodsDAO.updateById(null, new String[] { goods_state, goods_shelftime }, null,
					new Object[] { goodsState, DateTimeUtil.currentDateTime() }, goodsId);
		} else {
			goodsDAO.updateById(null, new String[] { goods_state }, null,
					new Object[] { goodsState }, goodsId);
		}
	}

	@Override
	public void updateGoodsContent(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, goods_id, goods_body);

		String goodsId = (String) vo.get(goods_id);
		String goodsBody = (String) vo.get(goods_body);

		goodsDAO.updateById(null, new String[] { goods_body }, null, new Object[] { goodsBody },
				goodsId);
	}

	@Override
	public Map<String, Object> getGoodsContent(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, goods_id);

		String goodsId = (String) vo.get(goods_id);

		return goodsDAO.getById(null, null, new String[] { "id AS goods_id", goods_body }, null,
				goodsId);
	}

	@Override
	public Map<String, Object> getByGoodsId(String goodsId) {

		return goodsDAO.getById(null, null, null, null, goodsId);
	}

	@Override
	public void batchUpdateGoodsStorage(List<Map<String, Object>> goodsDoNotHaveSpecList) {

		goodsDAO.batchUpdateGoodsStorage(goodsDoNotHaveSpecList);
	}

	@Override
	public List<Map<String, Object>> queryAllGoodsSpec(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, goods_id);

		String goodsId = (String) vo.get(goods_id);
		List<Map<String, Object>> allSpec = goodsDAO.queryAllGoodsSpec(goodsId);

		List<Map<String, Object>> goodsSpecValue = new ArrayList<>();

		if (!CollectionUtil.isEmptyCollection(allSpec)) {
			Map<String, Object> goodsMap = goodsDAO.getById(null, null, new String[] { spec_value },
					null, goodsId);

			JSONObject specCheckedJson = null;
			if (!CommonUtil.isEmpty(goodsMap, new String[] { spec_value })) {
				String specValue = (String) goodsMap.get(spec_value);
				JSONObject specJson = JSONObject.parseObject(specValue);
				specCheckedJson = specJson.getJSONObject(GoodsSpecUtil.SPEC_CHECKED);
			}

			String specId = "";
			String specName = "";
			List<Map<String, Object>> specValueList = new ArrayList<>();
			for (int i = 0; i < allSpec.size(); i++) {
				Map<String, Object> tempSpecMap = allSpec.get(i);
				String tempSpecId = (String) tempSpecMap.get(GoodsSpecUtil.SPEC_ID);
				String tempSpecName = (String) tempSpecMap.get(GoodsSpecUtil.SPEC_NAME);

				String tempSpecValueId = (String) tempSpecMap.get(GoodsSpecUtil.SPECVALUE_ID);
				String tempSpecValueName = (String) tempSpecMap.get(GoodsSpecUtil.SPECVALUE_NAME);

				String is_checked = ConstantUtil.FLAG_NO;
				if (specCheckedJson != null) {
					for (Map.Entry<String, Object> entry : specCheckedJson.entrySet()) {
						String checkedSpecId = entry.getKey();
						// 先验证规格ID是否相同，相同再进一步验证所属规格值是否相同
						if (checkedSpecId.equals(tempSpecId)) {
							JSONArray checkedSpecValueArray = (JSONArray) entry.getValue();
							for (int j = 0; j < checkedSpecValueArray.size(); j++) {
								String checkedSpecValueId = checkedSpecValueArray.getString(j);
								if (checkedSpecValueId.equals(tempSpecValueId)) {
									is_checked = ConstantUtil.FLAG_YES;
									break;
								}
							}
						}
					}
				}

				Map<String, Object> specValueMap = Maps.newLinkedHashMapWithExpectedSize(3);
				specValueMap.put(GoodsSpecUtil.SPECVALUE_ID, tempSpecValueId);
				specValueMap.put(GoodsSpecUtil.SPECVALUE_NAME, tempSpecValueName);
				specValueMap.put(ConstGoodsUtil.IS_CHECKED, is_checked);

				if (CommonUtil.isEmpty(specId)) {
					specId = tempSpecId;
					specName = tempSpecName;

					specValueList.add(specValueMap);
				} else if (specId.equals(tempSpecId)) {
					specValueList.add(specValueMap);
				} else {
					List<Map<String, Object>> tempValueList = new ArrayList<>();
					tempValueList.addAll(specValueList);

					Map<String, Object> tempMap = Maps.newLinkedHashMapWithExpectedSize(3);
					tempMap.put(GoodsSpecUtil.SPEC_ID, specId);
					tempMap.put(GoodsSpecUtil.SPEC_NAME, specName);
					tempMap.put(ConstGoodsUtil.SPECVALUES, tempValueList);
					goodsSpecValue.add(tempMap);

					specId = tempSpecId;
					specName = tempSpecName;
					specValueList.clear();
					specValueList.add(specValueMap);
				}

				// 循环到最后一个元素，即完成最后一个属性锁包含属性值的遍历，将该属性集合加入map
				if (i == (allSpec.size() - 1)) {
					Map<String, Object> tempMap = Maps.newLinkedHashMapWithExpectedSize(3);
					tempMap.put(GoodsSpecUtil.SPEC_ID, specId);
					tempMap.put(GoodsSpecUtil.SPEC_NAME, specName);
					tempMap.put(ConstGoodsUtil.SPECVALUES, specValueList);
					goodsSpecValue.add(tempMap);
				}
			}
		}

		return goodsSpecValue;
	}

	@Override
	public Map<String, Object> getGoodsDetail(Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);
		ValidatorUtil.validateMapContainsKey(vo, goods_id);

		String goodsId = (String) vo.get(goods_id);

		Map<String, Object> goodsDetails = goodsDAO.getGoodsDetail(goodsId);

		if (CollectionUtil.isEmptyMap(goodsDetails)) {
			ExceptionUtil.throwValidateException("商品信息异常");
		}

		List<Map<String, Object>> goodsImage = goodsImagesService.findByGoodsId(vo);

		List<Map<String, Object>> goodsSpec = queryAllGoodsSpec(vo);

		List<Map<String, Object>> goodsAttr = goodsAttrIndexService.queryGoodsAttr(vo);

		goodsDetails.put(ConstGoodsUtil.GOODS_IMAGE, goodsImage);
		goodsDetails.put(ConstGoodsUtil.GOODS_SPEC, goodsSpec);
		goodsDetails.put(ConstGoodsUtil.GOODS_ATTR, goodsAttr);

		return goodsDetails;
	}

	@Override
	public List<Map<String, Object>> queryIndex(PageBean page, Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);

		return goodsDAO.queryIndex(page, vo);
	}

	@Override
	public List<Map<String, Object>> queryGoodsInStore(PageBean page, Map<String, Object> vo) {

		vo = CollectionUtil.toInsensitiveMap(vo);

		return goodsDAO.queryGoodsInStore(page, vo);
	}
}
