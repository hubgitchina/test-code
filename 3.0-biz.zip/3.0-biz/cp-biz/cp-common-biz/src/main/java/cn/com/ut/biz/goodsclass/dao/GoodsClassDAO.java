package cn.com.ut.biz.goodsclass.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.goodsclass.entity.GoodsClass;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * Created by zhouquanguo on 2018/4/27.
 */
public interface GoodsClassDAO extends JdbcOperation<GoodsClass> {

	/**
	 * 查询当前分类下平级的子分类（不做递归查询）
	 *
	 * @param id
	 *            查询父分类的Id
	 * @return
	 */
	List<Map<String, Object>> queryChildrenParallel(String id);

	/**
	 * 查询当前分类的同级分类下是否有同名的分类
	 *
	 * @param gcName
	 *            分类名称
	 * @param parentId
	 *            父分类的id
	 * @param currentId
	 *            当前分类的Id
	 * @return
	 */
	List<Map<String, Object>> checkExist(String gcName, String parentId, String currentId);

	/**
	 * 逻辑删除，批量更新状态（假如当前分类下有子分类，将同步将子分类的is_del变成Y）
	 *
	 * @param idList
	 */
	void batchUpdateDelStatus(Object[] idList);

	/**
	 * 批量更新层级
	 * 
	 * @param nextLevelChildrenCategory
	 */
	void batchUpdateLevel(List<Map<String, Object>> nextLevelChildrenCategory);

	/**
	 * 更新一条记录
	 * 
	 * @param after
	 */
	void updateByPrimaryKey(Map<String, Object> after);

	/**
	 * 根据商品分类的ID查询店铺的所有分类
	 * 
	 * @param categoryIds
	 * @return
	 */
	List<Map<String, Object>> queryCategoryByCategoryIdList(List<String> categoryIds);

	/**
	 * 递归查找父节点下包含的所有子节点，将ID返回到childIds
	 * 
	 * @param parentId
	 * @param childIds
	 */
	void getAllChildById(String parentId, List<String> childIds);
}
