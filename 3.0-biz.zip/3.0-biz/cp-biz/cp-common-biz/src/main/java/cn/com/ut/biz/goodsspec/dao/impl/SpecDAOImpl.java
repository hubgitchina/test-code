package cn.com.ut.biz.goodsspec.dao.impl;

import static cn.com.ut.biz.goodsspec.entities.Spec.sort;
import static cn.com.ut.biz.goodsspec.entities.Spec.sp_name;
import static cn.com.ut.biz.goodsspec.entities.Spec.type_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.create_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;
import static cn.com.ut.core.dal.jdbc.BaseEntity.is_del;
import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.goodsspec.dao.SpecDAO;
import cn.com.ut.biz.goodsspec.entities.Spec;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * 商品规格DAO实现类
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
@Repository
public class SpecDAOImpl extends JdbcOperationsImpl<Spec> implements SpecDAO {

	private static String[] columns = { sp_name, type_id, sort };

	@Override
	public String insert(Map<String, ? extends Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp time = DateTimeUtil.currentDateTime();
		add(null, columns, NAMES, ParameterBuilder.builder().append(vo, columns)
				.append(id, time, time, vo.get(create_id), vo.get(create_id)).toArray());

		return id;
	}

	@Override
	public int update(Map<String, Object> vo) {

		return updateById(null, columns, NAMES_UT_UID,
				ParameterBuilder.builder().append(vo, columns)
						.append(DateTimeUtil.currentDateTime(), vo.get(update_id)).toArray(),
				(String) vo.get(idx));
	}

	@Override
	public List<Map<String, Object>> findAllPage(PageBean page) {

		return queryPage(page, null, null, false, new String[] { idx }, columns,
				new String[] { is_del }, null, null, create_time,
				new Object[] { ConstantUtil.FLAG_NO });
	}
}
