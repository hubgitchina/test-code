
//-----------------------------DAOImpl-start---------------------------------//
package cn.com.ut.biz.store.dao.impl;

import static cn.com.ut.biz.store.entities.StoreGcGoods.goods_id;
import static cn.com.ut.biz.store.entities.StoreGcGoods.store_id;
import static cn.com.ut.biz.store.entities.StoreGcGoods.storegc_id;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.store.dao.StoreGcGoodsDAO;
import cn.com.ut.biz.store.entities.StoreGcGoods;
import cn.com.ut.biz.store.entities.StoreGoodsClass;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

@Repository
public class StoreGcGoodsDAOImpl extends JdbcOperationsImpl<StoreGcGoods>
		implements StoreGcGoodsDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null, new String[] { store_id, storegc_id, goods_id }, NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo, new String[] { store_id, storegc_id, goods_id })
						.append(id, DateTimeUtil.currentDateTime(), vo.get(StoreGcGoods.create_id))
						.toArray());
		return id;
	}

	public int update(Map<String, Object> vo) {

		return updateById(null, new String[] { store_id, storegc_id, goods_id }, NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo, new String[] { store_id, storegc_id, goods_id })
						.append(DateTimeUtil.currentDateTime(), vo.get(StoreGcGoods.update_id))
						.toArray(),
				(String) vo.get(StoreGcGoods.idx), null);
	}

	@Override
	public List<Map<String, Object>> queryGoodsStoreClass(String storeId, String goodsId) {

		SQLHelper sqlBuilder = SQLHelper.builder().append(getTable(StoreGoodsClass.class))
				.append("sgc LEFT JOIN").append(getTable(StoreGcGoods.class))
				.append("sgcg ON sgc.id = sgcg.storegc_id")
				.append("where sgc.store_id = ? and sgcg.goods_id = ? order by sgc.sort");

		ParameterBuilder paramBuilder = ParameterBuilder.builder().appendColumns("sgc",
				StoreGoodsClass.storegc_name, StoreGoodsClass.idx,
				StoreGoodsClass.storegc_parent_id, StoreGoodsClass.level);
		paramBuilder.appendColumns("sgcg", goods_id);

		List<Map<String, Object>> list = queryPage(null, null, sqlBuilder.toSQL(), true,
				paramBuilder.toColumns(), null, null, null, null, null,
				new Object[] { storeId, goodsId });
		return list;

	}

}
// -----------------------------DAOImpl-end---------------------------------//