
//------------------------------entity-start--------------------------------//
package cn.com.ut.biz.complain.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class Complain extends BaseEntity {

	/**
	 * 投诉ID
	 */
	public static final String complain_id = "complain_id";
	/**
	 * 投诉主题
	 */
	public static final String complain_subject_content = "complain_subject_content";
	/**
	 * 投诉处理人ID
	 */
	public static final String complain_handle_member_id = "complain_handle_member_id";
	/**
	 * 申诉图片1
	 */
	public static final String appeal_image = "appeal_image";
	/**
	 * 投诉主题id
	 */
	public static final String complain_subject_id = "complain_subject_id";
	/**
	 * 申诉内容
	 */
	public static final String appeal_message = "appeal_message";
	/**
	 * 申诉时间
	 */
	public static final String appeal_datetime = "appeal_datetime";
	/**
	 * 被告ID
	 */
	public static final String accused_id = "accused_id";
	/**
	 * 被告名称
	 */
	public static final String accused_name = "accused_name";
	/**
	 * 最终处理人ID
	 */
	public static final String final_handle_member_id = "final_handle_member_id";
	/**
	 * 原告ID
	 */
	public static final String accuser_id = "accuser_id";
	/**
	 * 投诉时间
	 */
	public static final String complain_datetime = "complain_datetime";
	/**
	 * 投诉时间开始
	 */
	public static final String complain_datetime_from = "complain_datetime_from";
	/**
	 * 投诉时间结束
	 */
	public static final String complain_datetime_to = "complain_datetime_to";
	/**
	 * 投诉是否通过平台审批 1:未通过 2:通过
	 */
	public static final String complain_active = "complain_active";
	/**
	 * 投诉图片，最多上传三张
	 */
	public static final String complain_image = "complain_image";
	/**
	 * 最终处理时间
	 */
	public static final String final_handle_datetime = "final_handle_datetime";
	/**
	 * 投诉内容
	 */
	public static final String complain_content = "complain_content";
	/**
	 * 最终处理意见
	 */
	public static final String final_handle_message = "final_handle_message";
	/**
	 * 投诉状态 10:新投诉 20:投诉通过转给被投诉人 30:被投诉人已申诉 40:提交仲裁 99:已关闭
	 */
	public static final String complain_state = "complain_state";
	/**
	 * 订单商品ID
	 */
	public static final String order_goods_id = "order_goods_id";
	/**
	 * 订单ID
	 */
	public static final String order_id = "order_id";
	/**
	 * 原告用户名
	 */
	public static final String accuser_name = "accuser_name";
	/**
	 * 投诉处理时间
	 */
	public static final String complain_handle_datetime = "complain_handle_datetime";
	/**
	 * 商品表编号
	 */
	public static final String complain_goodsid = "complain_goodsid";
	/**
	 * 商品名称
	 */
	public static final String complain_goodsname = "complain_goodsname";
	/**
	 * 商品图片
	 */
	public static final String complain_goodsimage = "complain_goodsimage";
}
// ------------------------------entity-end--------------------------------//
