package cn.com.ut.biz.goodsclass.service;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/4/28.
 */
public interface GoodsClassService {

	/**
	 * 新增分类（计算其gc_full_path与level）
	 * 
	 * @param categoryDto
	 * @return
	 */
	String add(Map<String, Object> categoryDto);

	/**
	 * 逻辑删除分类（假如改分类下有子分类，将递归删除所有的子分类）
	 * 
	 * @param id
	 */
	void delete(String id);

	/**
	 * 获取当前分类下的平级子分类（不做递归）
	 * 
	 * @param categoryId
	 * @return
	 */
	List<Map<String, Object>> queryChildrenParallel(String categoryId);

	/**
	 * 递归查询当前分类下所有的子分类
	 * 
	 * @param categoryId
	 * @return
	 */
	List<Map<String, Object>> queryAllChildrenCategory(String categoryId);

	/**
	 * 更新分类，假如当前分类的父分类有变化，将更新分类的gc_full_path与level
	 * 
	 * @param categoryDto
	 */
	void update(Map<String, Object> categoryDto);

	/**
	 * 查询一条分类的信息
	 * 
	 * @param categoryId
	 * @return
	 */
	Map<String, Object> queryOne(String categoryId);

	/**
	 * 根据分类ID的列表查询当前店铺的所有分类
	 * 
	 * @param categoryIds
	 * @return
	 */
	List<Map<String, Object>> getCategoryByCategoryId(List<String> categoryIds);

	/**
	 * 递归查找父节点下包含的所有子节点，将ID返回到childIds
	 * 
	 * @param parentId
	 * @param childIds
	 */
	void getAllChildById(String parentId, List<String> childIds);
}
