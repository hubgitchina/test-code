package cn.com.ut.biz.refundreturn.service.impl;

import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.common.RefundReturnConst;
import cn.com.ut.biz.common.JsonUtils;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.biz.order.service.OrderGoodsService;
import cn.com.ut.biz.order.service.OrderService;
import cn.com.ut.biz.refund.RefundService;
import cn.com.ut.biz.refundreturn.dao.RefundReturnDAO;
import cn.com.ut.biz.refundreturn.entities.RefundReturn;
import cn.com.ut.biz.refundreturn.service.RefundReturnService;
import cn.com.ut.constant.api.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.GIDGenerator;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;
import com.google.common.base.Joiner;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 退货退款业务层实现类
 *
 * @author zhouquanguo
 * @since on 2018/6/4.
 */
@Service
public class RefundReturnServiceImpl implements RefundReturnService {

	@Autowired
	private RefundReturnDAO refundReturnDAO;

	@Autowired
	private OrderService orderService;

	@Autowired
	private GIDGenerator gidGenerator;
	@Autowired
	private OrderGoodsService orderGoodsService;

	@Autowired
	private RefundService refundService;

	@Override
	public String buyerSubmit(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, RefundReturn.buyer_id, RefundReturn.refund_amount,
				RefundReturn.refund_type, RefundReturn.goods_num, RefundReturn.order_goods_id,
				RefundReturn.order_id, RefundReturn.user_id, RefundReturn.reason_id,
				RefundReturn.reason_info);
		String orderId = (String) vo.get(RefundReturn.order_id);
		String orderGoodsId = (String) vo.get(RefundReturn.order_goods_id);
		// 查询订单信息
		Map<String, Object> order = orderService.getByOrderId(orderId);
		if (CollectionUtil.isEmptyMap(order)) {
			ExceptionUtil.throwRuntimeException("当前订单不存在或已过期");
		}
		// 未付款订单不能进行退货退款处理
		if ((int) order.get(Order.order_state) < Const.OrderStatusEnum.PAID.getCode()) {
			ExceptionUtil.throwValidateException("订单未付款，不能进行退货或者退款操作");
		}
		// 订单完成后默认15天内可以申请退货退款处理
		Timestamp orderFinishTime = (Timestamp) order.get(Order.finnshed_time);
		if (DateTimeUtil.currentDateTime().compareTo(DateTimeUtil.addDays(orderFinishTime,
				RefundReturnConst.OrderLimitDayEnum.ORDER_REFUND.getLimitDays())) > 0) {
			ExceptionUtil.throwValidateException("订单已经超时，不能进行退货或者退款操作");
		}
		// 验证是否重复提交退货或者退款申请
		Map<String, Object> existedRefundRecord = refundReturnDAO.getByOrderIdAndGoodId(orderId,
				orderGoodsId);
		if (!CollectionUtil.isEmptyMap(existedRefundRecord)) {
			ExceptionUtil.throwValidateException("退款已提交，请勿重复操作");
		}

		Map<String, Object> refundRecord = Maps.newHashMap();

		if (orderGoodsId.equals(RefundReturnConst.INVALID_ORDER_GOODS_ID)) {

			List<Map<String, Object>> orderGoodsList = orderGoodsService.selectByOrderId(orderId);
			// 全部退款商品图片之间用逗号分隔（假如商品图片为空则忽略空值）
			String goodsImages = Joiner.on(",").skipNulls().join(orderGoodsList.stream()
					.map(e -> e.get(OrderGoods.goods_image)).collect(Collectors.toList()));

			// 0表示全部退款
			refundRecord.put(RefundReturn.goods_id, RefundReturnConst.INVALID_ORDER_GOODS_ID);
			refundRecord.put(RefundReturn.order_goods_id, RefundReturnConst.INVALID_ORDER_GOODS_ID);

			// 根据order_goods字段查询订单的商品数量
			List<Map<String, Object>> orderGoods = JsonUtils
					.str2obj((String) order.get(Order.order_goods), List.class);
			int goodsNum = orderGoods.stream()
					.mapToInt(e -> (Integer) e.get(RefundReturn.goods_num)).sum();
			refundRecord.put(RefundReturn.goods_name, RefundReturnConst.ALL_GOODS);
			refundRecord.put(RefundReturn.goods_num, goodsNum);
			refundRecord.put(RefundReturn.refund_amount, order.get(Order.goods_amount));
			refundRecord.put(RefundReturn.goods_image, goodsImages);

		} else {
			Map<String, Object> orderGoods = orderGoodsService.getByOrderGoodsId(orderGoodsId);
			// 计算退款金额
			BigDecimal refundAmount = (new BigDecimal((Integer) vo.get(RefundReturn.goods_num)))
					.multiply((BigDecimal) orderGoods.get(OrderGoods.goods_price));
			order.put(Order.refund_amount, refundAmount);

			refundRecord.put(RefundReturn.goods_name, orderGoods.get(OrderGoods.goods_name));
			refundRecord.put(RefundReturn.goods_num, orderGoods.get(OrderGoods.goods_num));
			refundRecord.put(RefundReturn.refund_amount, refundAmount);
			refundRecord.put(RefundReturn.goods_id, orderGoods.get(OrderGoods.goods_id));
			refundRecord.put(RefundReturn.order_goods_id, orderGoods.get(OrderGoods.idx));
			refundRecord.put(RefundReturn.goods_image, orderGoods.get(OrderGoods.goods_image));
			refundRecord.put(RefundReturn.goods_image, orderGoods.get(OrderGoods.goods_image));

		}
		int refundType = (int) vo.get(RefundReturn.refund_type);
		// 组装退货退款的其他信息
		refundRecord.put(RefundReturn.refund_type, refundType);
		// 判断订单是否需要退货
		refundRecord.put(RefundReturn.return_type,
				refundType == RefundReturnConst.RefundType.REFUND ? 1 : 2);
		refundRecord.put(RefundReturn.reason_id, vo.get(RefundReturn.reason_id));
		refundRecord.put(RefundReturn.reason_info, vo.get(RefundReturn.reason_info));
		refundRecord.put(RefundReturn.create_id, vo.get(RefundReturn.user_id));
		refundRecord.put(RefundReturn.order_id, order.get(Order.idx));
		refundRecord.put(RefundReturn.order_sn, order.get(Order.order_sn));
		refundRecord.put(RefundReturn.refund_sn, gidGenerator.genReturnSequence());
		refundRecord.put(RefundReturn.store_name, order.get(RefundReturn.store_name));
		refundRecord.put(RefundReturn.store_id, order.get(RefundReturn.store_id));
		refundRecord.put(RefundReturn.buyer_id, order.get(RefundReturn.buyer_id));
		refundRecord.put(RefundReturn.buyer_name, order.get(RefundReturn.buyer_name));
		refundRecord.put(RefundReturn.pic_info, vo.get(RefundReturn.pic_info));
		refundRecord.put(RefundReturn.buyer_message, vo.get(RefundReturn.buyer_message));
		refundRecord.put(RefundReturn.order_goods_type, RefundReturnConst.OrderGoodsType.DEFULT);
		refundRecord.put(RefundReturn.seller_state,
				RefundReturnConst.SellerStateEnum.WAIT_FOR_AUDIT.getCode());
		refundRecord.put(RefundReturn.refund_state,
				RefundReturnConst.RefundStateEnum.PROCESSING.getCode());
		refundRecord.put(RefundReturn.goods_state,
				RefundReturnConst.GoodsStateEnum.PENDING_DELIVERY.getCode());
		refundRecord.put(RefundReturn.order_lock, RefundReturnConst.LockState.NO_LOCKING);
		refundRecord.put(RefundReturn.add_time, DateTimeUtil.currentDateTime());

		return refundReturnDAO.add(refundRecord);

	}

	@Override
	public void buyerCancel(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, RefundReturn.buyer_id, "refund_id",
				RefundReturn.user_id);
		String refundId = (String) vo.get("refund_id");
		// 查询当前的退货退款记录
		Map<String, Object> refundReturn = refundReturnDAO.getByRefundId(refundId);
		Map<String, Object> order = orderService
				.getByOrderId((String) refundReturn.get(RefundReturn.order_id));
		if (CollectionUtil.isEmptyMap(refundReturn)) {
			ExceptionUtil.throwValidateException("待取消的退款已过期或者不存在");
		}

		// 买家可以退款则关闭退款
		if (canCancelRefund(order, refundReturn)) {
			refundReturn.put(RefundReturn.refund_state,
					RefundReturnConst.RefundStateEnum.FINISH.getCode());
			refundReturn.put(RefundReturn.seller_state,
					RefundReturnConst.SellerStateEnum.AGREE.getCode());
			refundReturn.put(RefundReturn.is_del, ConstantUtil.FLAG_YES);
			refundReturnDAO.update(refundReturn);

		} else {
			ExceptionUtil.throwValidateException("订单已超时或退款已完成，无法进行当前操作");
		}
	}

	// 判断买家是否能取消当前订单
	private boolean canCancelRefund(Map<String, Object> order, Map<String, Object> refundReturn) {

		boolean flag = false;
		int orderState = (int) order.get(Order.order_state);
		int refundState = (int) refundReturn.get(RefundReturn.refund_state);
		int goodsState = (int) refundReturn.get(RefundReturn.goods_state);
		// 用户已支付未发货，当前退款流程正在进行中
		if (orderState == Const.OrderStatusEnum.PAID.getCode()
				&& (refundState == RefundReturnConst.RefundStateEnum.PROCESSING.getCode())) {
			flag = true;
			// 商家已发货，用户待发货状态也可以取消
		} else if (orderState > Const.OrderStatusEnum.PAID.getCode()
				&& (refundState == RefundReturnConst.RefundStateEnum.PROCESSING.getCode())
				&& goodsState < RefundReturnConst.GoodsStateEnum.WAIT_RECEIVE.getCode()) {
			flag = true;
		}
		return flag;

	}

	@Override
	public void sellerDeal(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "refund_id", RefundReturn.seller_state,
				RefundReturn.seller_message, "seller_id");
		String refundId = (String) vo.get("refund_id");
		// 查询当前的退货退款记录
		Map<String, Object> refundReturn = refundReturnDAO.getByRefundId(refundId);
		Map<String, Object> order = orderService
				.getByOrderId((String) refundReturn.get(RefundReturn.order_id));
		refundReturn.put(RefundReturn.seller_message, vo.get(RefundReturn.seller_message));
		int orderState = (int) order.get(Order.order_state);
		int sellerState = (int) vo.get(RefundReturn.seller_state);
		int refundType = (int) refundReturn.get(RefundReturn.refund_type);
		// 已付款但未发货
		if (orderState == Const.OrderStatusEnum.PAID.getCode()) {
			if (sellerState == RefundReturnConst.SellerStateEnum.AGREE.getCode()) {
				// FIXME 处理退款
				refundService.processRefund();
				// 更新退货退款信息
				refundReturn.put(RefundReturn.refund_state,
						RefundReturnConst.RefundStateEnum.FINISH.getCode());
				refundReturn.put(RefundReturn.seller_state, sellerState);
				refundReturn.put(RefundReturn.seller_time, DateTimeUtil.currentDateTime());
				refundReturn.put(RefundReturn.is_del, ConstantUtil.FLAG_YES);
				// 更新订单信息
				order.put(Order.order_state, Const.OrderStatusEnum.CANCELED.getCode());
				order.put(Order.refund_state, refundReturn.get(RefundReturn.order_goods_id)
						.equals(RefundReturnConst.INVALID_ORDER_GOODS_ID)
								? RefundReturnConst.RefundStatusEnum.FULL_REFUND.getCode()
								: RefundReturnConst.RefundStatusEnum.PARTIAL_REFUND.getCode());
				order.put(Order.refund_amount, refundReturn.get(RefundReturn.refund_amount));
				orderService.updateOrder(order);
			} else if (sellerState == RefundReturnConst.SellerStateEnum.DISAGREE.getCode()) {
				refundReturn.put(RefundReturn.refund_state,
						RefundReturnConst.RefundStateEnum.FINISH.getCode());
				refundReturn.put(RefundReturn.seller_state, sellerState);
				refundReturn.put(RefundReturn.seller_time, DateTimeUtil.currentDateTime());

			}
			// 已发货情况处理
		} else if (orderState >= 20) {
			if (sellerState == RefundReturnConst.SellerStateEnum.AGREE.getCode()) {
				// 卖家同意且无需退款
				if (refundType == RefundReturnConst.RefundType.REFUND) {
					// FIXME 处理退款
					refundService.processRefund();
					// 更新订单信息
					order.put(Order.order_state, Const.OrderStatusEnum.CANCELED.getCode());
					order.put(Order.refund_state, refundReturn.get(RefundReturn.order_goods_id)
							.equals(RefundReturnConst.INVALID_ORDER_GOODS_ID)
									? RefundReturnConst.RefundStatusEnum.FULL_REFUND.getCode()
									: RefundReturnConst.RefundStatusEnum.PARTIAL_REFUND.getCode());
					order.put(Order.refund_amount, refundReturn.get(RefundReturn.refund_amount));
					orderService.updateOrder(order);
					// 更新退货退款信息
					refundReturn.put(RefundReturn.seller_state,
							RefundReturnConst.RefundStateEnum.FINISH.getCode());
					refundReturn.put(RefundReturn.seller_state, sellerState);
					refundReturn.put(RefundReturn.is_del, ConstantUtil.FLAG_YES);
					refundReturn.put(RefundReturn.seller_time, DateTimeUtil.currentDateTime());
					// 卖家同意且需要退款
				} else if (refundType == RefundReturnConst.RefundType.RETURN_GOODS) {
					// 更新退货退款信息
					refundReturn.put(RefundReturn.refund_state,
							RefundReturnConst.RefundStateEnum.PROCESSING.getCode());
					refundReturn.put(RefundReturn.goods_state,
							RefundReturnConst.GoodsStateEnum.PENDING_DELIVERY.getCode());
					refundReturn.put(RefundReturn.seller_state, sellerState);
					refundReturn.put(RefundReturn.seller_time, DateTimeUtil.currentDateTime());

				}

			} else if (sellerState == RefundReturnConst.SellerStateEnum.DISAGREE.getCode()) {
				refundReturn.put(RefundReturn.refund_state,
						RefundReturnConst.RefundStateEnum.FINISH.getCode());
				refundReturn.put(RefundReturn.goods_state,
						RefundReturnConst.GoodsStateEnum.PENDING_DELIVERY.getCode());
				refundReturn.put(RefundReturn.seller_state, sellerState);
				refundReturn.put(RefundReturn.seller_time, DateTimeUtil.currentDateTime());

			}

		} else {
			ExceptionUtil.throwRuntimeException("订单未支付或已过期，不能进行相关操作");
		}

		// 更新退货退款信息
		refundReturnDAO.update(refundReturn);

	}

	@Override
	public void buyerDelivery(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, RefundReturn.buyer_id, "refund_id",
				RefundReturn.invoice_no, RefundReturn.express_id, RefundReturn.user_id);
		String refundId = (String) vo.get("refund_id");
		// 查询当前的退货退款记录
		Map<String, Object> refundReturn = refundReturnDAO.getByRefundId(refundId);
		if (CollectionUtil.isEmptyMap(refundReturn)) {
			ExceptionUtil.throwRuntimeException("当前退货订单不存在或已过期");
		}
		// 只有卖家同意退款且物流状态为待收货才能发货
		if ((int) refundReturn
				.get(RefundReturn.seller_state) != RefundReturnConst.SellerStateEnum.AGREE.getCode()
				|| (int) refundReturn
						.get(RefundReturn.goods_state) != RefundReturnConst.GoodsStateEnum.PENDING_DELIVERY
								.getCode()) {
			ExceptionUtil.throwValidateException("卖家正在处理，请耐心等待");

		}
		Timestamp timestamp = DateTimeUtil.currentDateTime();
		refundReturn.put(RefundReturn.ship_time, timestamp);
		refundReturn.put(RefundReturn.update_time, timestamp);
		refundReturn.put(RefundReturn.update_id, vo.get(RefundReturn.user_id));
		refundReturn.put(RefundReturn.express_id, vo.get(RefundReturn.express_id));
		refundReturn.put(RefundReturn.invoice_no, vo.get(RefundReturn.invoice_no));
		refundReturn.put(RefundReturn.goods_state,
				RefundReturnConst.GoodsStateEnum.WAIT_RECEIVE.getCode());
		refundReturn.put(RefundReturn.refund_state,
				RefundReturnConst.RefundStateEnum.PROCESSING.getCode());

		int effectedNum = refundReturnDAO.update(refundReturn);
		if (effectedNum < 1) {
			ExceptionUtil.throwRuntimeException("发货失败，请重试");
		}

	}

	@Override
	public void sellerReceive(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, RefundReturn.user_id, "refund_id", "seller_id",
				RefundReturn.goods_state);
		String refundId = (String) vo.get("refund_id");
		// 查询当前的退货退款记录
		Map<String, Object> refundReturn = refundReturnDAO.getByRefundId(refundId);
		Map<String, Object> order = orderService
				.getByOrderId((String) refundReturn.get(RefundReturn.order_id));
		if (CollectionUtil.isEmptyMap(refundReturn)
				|| (int) refundReturn
						.get(RefundReturn.refund_state) == RefundReturnConst.RefundStateEnum.FINISH
								.getCode()
				|| (int) order.get(Order.order_state) == Const.OrderStatusEnum.CANCELED
						.getCode()) {
			ExceptionUtil.throwRuntimeException("当前退货单不存在或已过期");
		}
		refundReturn.put(RefundReturn.goods_state, vo.get(RefundReturn.goods_state));
		int goodsState = (int) vo.get(RefundReturn.goods_state);
		// 未收到货则延长收货时间
		if (goodsState == RefundReturnConst.GoodsStateEnum.NOT_RECEIVED.getCode()) {
			Timestamp orderFinishTime = (Timestamp) order.get(Order.finnshed_time);
			refundReturn.put(RefundReturn.delay_time,
					DateTimeUtil.addDays(orderFinishTime, RefundReturnConst.DELAY_TIME));
			refundReturn.put(RefundReturn.refund_state,
					RefundReturnConst.RefundStateEnum.PROCESSING.getCode());
			refundReturn.put(RefundReturn.goods_state,
					RefundReturnConst.GoodsStateEnum.NOT_RECEIVED.getCode());
		} else if (goodsState == RefundReturnConst.GoodsStateEnum.RECEIVED.getCode()) {
			// FIXME 退款业务处理
			refundService.processRefund();
			// 更新订单
			order.put(Order.order_state, Const.OrderStatusEnum.CANCELED.getCode());
			order.put(Order.refund_state,
					refundReturn.get(RefundReturn.order_goods_id)
							.equals(RefundReturnConst.INVALID_ORDER_GOODS_ID)
									? RefundReturnConst.RefundStatusEnum.FULL_REFUND.getCode()
									: RefundReturnConst.RefundStatusEnum.PARTIAL_REFUND.getCode());
			order.put(Order.refund_amount, refundReturn.get(RefundReturn.refund_amount));
			orderService.updateOrder(order);
			// 更新退款退货信息
			refundReturn.put(RefundReturn.receive_time, DateTimeUtil.currentDateTime());
			refundReturn.put(RefundReturn.goods_state,
					RefundReturnConst.GoodsStateEnum.RECEIVED.getCode());
			refundReturn.put(RefundReturn.refund_state,
					RefundReturnConst.RefundStateEnum.FINISH.getCode());

		} else {
			ExceptionUtil.throwValidateException("收货状态不正确，请选择收货或者未收货");
		}
		int effectedNum = refundReturnDAO.update(refundReturn);
		if (effectedNum < 1) {
			ExceptionUtil.throwRuntimeException("处理失败，请重试");
		}

	}

	@Override
	public ResponseWrap queryBySeller(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, RefundReturn.store_id, "seller_id",
				Const.Page.PAGE_SIZE, Const.Page.PAGE_NO);
		PageBuilder pb = PageBuilder.build();
		PageBean pageBean = pb.buildSQL(vo);
		String storeId = (String) vo.get(RefundReturn.store_id);
		List<Map<String, Object>> refundList = refundReturnDAO.listRefundByStoreId(storeId,
				pageBean);
		Map<String, Object> result = Maps.newHashMap();
		if (CollectionUtil.isEmptyCollection(refundList)) {
			result.put("refund", "当前店铺无退款申请记录");
		} else {
			result.put("refund", refundList);
		}
		ResponseWrap responseWrap = ResponseWrap.builder();
		return responseWrap.appendData(result).appendPage(pageBean);

	}

	@Override
	public ResponseWrap queryByBuyer(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, RefundReturn.buyer_id, RefundReturn.user_id,
				Const.Page.PAGE_NO, Const.Page.PAGE_SIZE);
		PageBuilder pb = PageBuilder.build();
		PageBean pageBean = pb.buildSQL(vo);
		String buyerId = (String) vo.get(RefundReturn.buyer_id);
		List<Map<String, Object>> refundList = refundReturnDAO.listRefundByBuyerId(buyerId,
				pageBean);
		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> result = Maps.newHashMap();
		if (CollectionUtil.isEmptyCollection(refundList)) {
			result.put("refund", "当前买家无退款申请记录");
		} else {
			result.put("refund", refundList);
		}
		return responseWrap.appendData(result).appendPage(pageBean);
	}

	@Override
	public Map<String, Object> getRefund(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, RefundReturn.buyer_id, RefundReturn.user_id,
				"seller_id", "refund_id");
		String buyerId = (String) vo.get(RefundReturn.buyer_id);
		String refundId = (String) vo.get("refund_id");
		Map<String, Object> refund = refundReturnDAO.getByBuyerAndRefundId(buyerId, refundId);
		if (CollectionUtil.isEmptyMap(refund)) {
			ExceptionUtil.throwRuntimeException("当前买家无该退款记录");
		}

		return refund;
	}

}