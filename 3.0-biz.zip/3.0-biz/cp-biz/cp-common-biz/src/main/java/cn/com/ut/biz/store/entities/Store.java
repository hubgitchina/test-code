package cn.com.ut.biz.store.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class Store extends BaseEntity {

	// 店铺名称
	public static final String store_name = "store_name";
	// 用户ID
	public static final String member_id = "member_id";
	// 用户名
	public static final String member_name = "member_name";
	// 店铺公司名称
	public static final String store_company_name = "store_company_name";
	// 地区ID
	public static final String area_id = "area_id";
	// 地区名称
	public static final String area_info = "area_info";
	// 店铺地址
	public static final String store_address = "store_address";
	// 店铺状态:0关闭，1开启，2审核中
	public static final String store_state = "store_state";
	// 店铺关闭原因
	public static final String store_close_info = "store_close_info";
	// 店铺时间
	public static final String store_addtime = "store_addtime";
	// 店铺关闭时间
	public static final String store_endtime = "store_endtime";
	// 店铺LOGO
	public static final String store_logo = "store_logo";
	// 店铺Banner
	public static final String store_banner = "store_banner";
	// 店铺头像
	public static final String store_avatar = "store_avatar";
	// 店铺SEO关键字
	public static final String store_keywords = "store_keywords";
	// 店铺QQ
	public static final String store_qq = "store_qq";
	// 阿里旺旺
	public static final String store_ww = "store_ww";
	// 商家电话
	public static final String store_phone = "store_phone";
	// 主营商品
	public static final String store_mainbusiness = "store_mainbusiness";
	// 是否推荐:0否 1是
	public static final String store_recommend = "store_recommend";
	// 店铺当前主题
	public static final String store_theme = "store_theme";
	// 店铺信用
	public static final String store_credit = "store_credit";
	// 描述相符度分数
	public static final String store_desccredit = "store_desccredit";
	// 服务态度分数
	public static final String store_servicecredit = "store_servicecredit";
	// 发货速度分数
	public static final String store_deliverycredit = "store_deliverycredit";
	// 店铺收藏数量
	public static final String store_collect = "store_collect";
	// 店铺销量
	public static final String store_sales = "store_sales";
	// 工作时间
	public static final String store_workingtime = "store_workingtime";
	// 超出该金额免运费，大于0才表示该值有效
	public static final String store_free_price = "store_free_price";
	// 是否自营店铺 1是 0否
	public static final String is_platform_store = "is_platform_store";
	// 货到付款
	public static final String store_huodaofk = "store_huodaofk";

}
