package cn.com.ut.biz.refundreturn.dao.impl;

import cn.com.ut.biz.refundreturn.dao.RefundReturnDAO;

/**
* 退货退款DAO层实现类
* 
 * @author zhouquanguo
 * @since on 2018/6/4.
 */
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.return_type;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.ship_time;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.buyer_name;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.buyer_id;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.pic_info;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.reason_info;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.store_name;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.refund_amount;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.delay_time;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.store_id;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.goods_name;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.commis_rate;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.refund_type;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.buyer_message;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.invoice_no;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.receive_time;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.goods_id;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.seller_message;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.refund_sn;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.order_lock;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.order_goods_type;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.seller_time;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.reason_id;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.express_id;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.receive_message;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.goods_image;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.seller_state;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.goods_num;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.goods_state;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.order_goods_id;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.admin_message;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.order_id;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.refund_state;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.add_time;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.order_sn;
import static cn.com.ut.biz.refundreturn.entities.RefundReturn.admin_time;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.sql.SQLHelper;
import org.springframework.stereotype.Repository;

import cn.com.ut.biz.refundreturn.entities.RefundReturn;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

@Repository
public class RefundReturnDAOImpl extends JdbcOperationsImpl<RefundReturn>
		implements RefundReturnDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null,
				new String[] { return_type, ship_time, buyer_name, buyer_id, pic_info, reason_info,
						store_name, refund_amount, delay_time, store_id, goods_name, commis_rate,
						refund_type, buyer_message, invoice_no, receive_time, goods_id,
						seller_message, refund_sn, order_lock, order_goods_type, seller_time,
						reason_id, express_id, receive_message, goods_image, seller_state,
						goods_num, goods_state, order_goods_id, admin_message, order_id,
						refund_state, add_time, order_sn, admin_time },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder().append(vo, new String[] { return_type, ship_time,
						buyer_name, buyer_id, pic_info, reason_info, store_name, refund_amount,
						delay_time, store_id, goods_name, commis_rate, refund_type, buyer_message,
						invoice_no, receive_time, goods_id, seller_message, refund_sn, order_lock,
						order_goods_type, seller_time, reason_id, express_id, receive_message,
						goods_image, seller_state, goods_num, goods_state, order_goods_id,
						admin_message, order_id, refund_state, add_time, order_sn, admin_time })
						.append(id, DateTimeUtil.currentDateTime(), vo.get(RefundReturn.create_id))
						.toArray());

		return id;
	}

	@Override
	public Map<String, Object> getByRefundId(String refundId) {

		return getById(null, null, null, null, refundId);
	}

	@Override
	public List<Map<String, Object>> listRefundByStoreId(String storeId, PageBean pageBean) {

		SQLHelper table = SQLHelper.builder();
		table.append("ds_refundreturn")
				.append(" r WHERE r.refund_state in ('1','2')  AND r.is_del = 'N' ");
		return queryPage(pageBean, null, table.toSQL(), true,
				new String[] { buyer_id, buyer_name, refund_amount, goods_id, goods_name,
						refund_type, refund_sn, goods_image, goods_num, store_id, store_name,
						order_goods_id, order_id, refund_state, add_time, order_sn },
				null, new String[] { store_id }, null, null, add_time, new Object[] { storeId });

	}

	@Override
	public List<Map<String, Object>> listRefundByBuyerId(String buyerId, PageBean pageBean) {

		SQLHelper table = SQLHelper.builder();
		table.append("ds_refundreturn").append(" r WHERE  r.is_del = 'N' ");
		return queryPage(pageBean, null, table.toSQL(), true,
				new String[] { buyer_name, refund_amount, goods_id, goods_name, refund_type,
						refund_sn, goods_image, goods_num, store_id, store_name, order_goods_id,
						order_id, refund_state, add_time, order_sn },
				null, new String[] { buyer_id }, null, null, add_time, new Object[] { buyerId });

	}

	@Override
	public Map<String, Object> getByBuyerAndRefundId(String buyerId, String refundId) {

		return getByKey(null, null,
				new String[] { return_type, ship_time, buyer_id, buyer_name, buyer_message,
						pic_info, reason_id, reason_info, refund_amount, delay_time, goods_id,
						goods_name, refund_type, refund_sn, goods_image, goods_num, store_id,
						store_name, order_goods_id, order_id, refund_state, add_time, order_sn,
						invoice_no, receive_message, receive_time, seller_message, seller_time,
						express_id, seller_state, goods_state },
				null, new String[] { buyer_id, idx }, new Object[] { buyerId, refundId }, null);

	}

	@Override
	public Map<String, Object> getByOrderIdAndGoodId(String orderId, String orderGoodsId) {

		return getByProperties(new String[] { RefundReturn.order_id, RefundReturn.order_goods_id },
				new Object[] { orderId, orderGoodsId });
	}

	public int update(Map<String, Object> vo) {

		return updateById(null,
				new String[] { return_type, ship_time, buyer_name, buyer_id, pic_info, reason_info,
						store_name, refund_amount, delay_time, store_id, goods_name, commis_rate,
						refund_type, buyer_message, invoice_no, receive_time, goods_id,
						seller_message, refund_sn, order_lock, order_goods_type, seller_time,
						reason_id, express_id, receive_message, goods_image, seller_state,
						goods_num, goods_state, order_goods_id, admin_message, order_id,
						refund_state, add_time, order_sn, admin_time },
				NAMES_UT_UID, null,
				ParameterBuilder.builder().append(vo, new String[] { return_type, ship_time,
						buyer_name, buyer_id, pic_info, reason_info, store_name, refund_amount,
						delay_time, store_id, goods_name, commis_rate, refund_type, buyer_message,
						invoice_no, receive_time, goods_id, seller_message, refund_sn, order_lock,
						order_goods_type, seller_time, reason_id, express_id, receive_message,
						goods_image, seller_state, goods_num, goods_state, order_goods_id,
						admin_message, order_id, refund_state, add_time, order_sn, admin_time })
						.append(DateTimeUtil.currentDateTime(), vo.get(RefundReturn.update_id))
						.toArray(),
				(String) vo.get(RefundReturn.idx), null);
	}
}