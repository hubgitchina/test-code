package cn.com.ut.biz.store.dao;

import cn.com.ut.biz.store.entities.Store;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/9.
 */
public interface StoreDAO extends JdbcOperation<Store> {
    /**
     * 查询所有的店铺（带分页）
     *
     * @param pageBean
     * @return
     */
    List<Map<String, Object>> findAll(PageBean pageBean);

	/**
	 * 根据店铺名称模糊查询店铺
	 * @param storeName
	 * @return
	 */
	List<Map<String, Object>> selectByStoreName(String storeName,PageBean page);

	/**
	 * 根据用户Id统计店铺数量
	 * @param userId
	 * @return
	 */
	long countByUserId(String userId);
}
