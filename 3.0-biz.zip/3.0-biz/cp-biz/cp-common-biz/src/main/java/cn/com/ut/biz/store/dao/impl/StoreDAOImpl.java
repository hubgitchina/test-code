package cn.com.ut.biz.store.dao.impl;

import cn.com.ut.biz.store.dao.StoreDAO;
import cn.com.ut.biz.store.entities.Store;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/9.
 */
@Repository
public class StoreDAOImpl extends JdbcOperationsImpl<Store> implements StoreDAO {

	private String[] COLUMNS = new String[] { Store.store_name, Store.area_id, Store.area_info,
			Store.store_address, Store.store_company_name, Store.store_mainbusiness,
			Store.store_phone, Store.store_workingtime, Store.store_free_price,
			Store.is_platform_store, Store.store_huodaofk, Store.member_name };

	@Override
	public List<Map<String, Object>> findAll(PageBean pageBean) {

		return queryPage(pageBean, null, null, false, COLUMNS, new String[] { Store.idx },
				new String[] { Store.is_del }, null, null, Store.store_name,
				new Object[] { ConstantUtil.FLAG_NO });

	}

	@Override
	public List<Map<String, Object>> selectByStoreName(String storeName, PageBean page) {

		return query(page, null, null, null, null, null, null);

	}

	@Override
	public long countByUserId(String userId) {

		return count(null, Store.idx, new String[] { Store.create_id }, new Object[] { userId });
	}
}
