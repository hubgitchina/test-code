package cn.com.ut.biz.brand.dao.impl;

import cn.com.ut.biz.brand.dao.BrandDAO;
import cn.com.ut.biz.brand.entities.Brand;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/4/27.
 */
@Repository
public class BrandDAOImpl extends JdbcOperationsImpl<Brand> implements BrandDAO {
    @Override
    public List<Map<String, Object>> findAll(Map<String, Object> condition, PageBean pageBean) {
        String whereColumnJoin = null;
        if (condition.containsKey(Brand.brand_name)) {
            whereColumnJoin = String.format("ds_brand.brand_name like '%%%s%%' ", condition.get(Brand.brand_name));

        }
        return queryPage(pageBean, null, null, false, new String[]{Brand.idx,Brand.brand_name, Brand.brand_initial,Brand.store_id,
                Brand.sort,Brand.brand_recommend,Brand.brand_pic,Brand.brand_showtype},
                null, null, whereColumnJoin, null, null, null);
    }
}
