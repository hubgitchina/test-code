
//------------------------------entity-start--------------------------------//
package cn.com.ut.biz.complain.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class ComplainTalk extends BaseEntity {


	/**
     * 发言人类型(1-投诉人/2-被投诉人/3-平台)
     */
    public static final String talk_member_type = "talk_member_type";
	/**
     * 投诉ID
     */
    public static final String complain_id = "complain_id";
	/**
     * 发言人ID
     */
    public static final String talk_member_id = "talk_member_id";
	/**
     * 发言人用户名
     */
    public static final String talk_member_name = "talk_member_name";
	/**
     * 发言内容
     */
    public static final String talk_content = "talk_content";
	/**
     * 对话发表时间
     */
    public static final String talk_datetime = "talk_datetime";
	/**
     * 发言状态(1-显示/2-不显示)
     */
    public static final String talk_state = "talk_state";
	/**
     * 对话管理员
     */
    public static final String talk_admin = "talk_admin";
}
//------------------------------entity-end--------------------------------//
