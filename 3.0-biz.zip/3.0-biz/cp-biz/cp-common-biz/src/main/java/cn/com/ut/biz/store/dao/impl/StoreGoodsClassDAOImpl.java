
//-----------------------------DAOImpl-start---------------------------------//
package cn.com.ut.biz.store.dao.impl;

import static cn.com.ut.biz.store.entities.StoreGoodsClass.gc_full_path;
import static cn.com.ut.biz.store.entities.StoreGoodsClass.level;
import static cn.com.ut.biz.store.entities.StoreGoodsClass.sort;
import static cn.com.ut.biz.store.entities.StoreGoodsClass.store_id;
import static cn.com.ut.biz.store.entities.StoreGoodsClass.storegc_name;
import static cn.com.ut.biz.store.entities.StoreGoodsClass.storegc_parent_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.store.dao.StoreGoodsClassDAO;
import cn.com.ut.biz.store.entities.StoreGoodsClass;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

@Repository
public class StoreGoodsClassDAOImpl extends JdbcOperationsImpl<StoreGoodsClass>
		implements StoreGoodsClassDAO {

	public String add(Map<String, Object> vo) {

		add(null,
				new String[] { store_id, level, gc_full_path, storegc_name, sort,
						storegc_parent_id },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { store_id, level, gc_full_path, storegc_name, sort,
										storegc_parent_id })
						.append(vo.get(idx), DateTimeUtil.currentDateTime(),
								vo.get(StoreGoodsClass.create_id))
						.toArray());
		return (String) vo.get(idx);
	}

	public int update(Map<String, Object> vo) {

		return update(null, new String[] { storegc_name, sort }, NAMES_UT_UID,
				new String[] { store_id, idx },

				ParameterBuilder.builder().append(vo, new String[] { storegc_name, sort })
						.append(DateTimeUtil.currentDateTime(), vo.get(StoreGoodsClass.update_id))
						.toArray(),
				ParameterBuilder.builder().append(vo, new String[] { store_id, idx }).toArray());

	}
}
// -----------------------------DAOImpl-end---------------------------------//