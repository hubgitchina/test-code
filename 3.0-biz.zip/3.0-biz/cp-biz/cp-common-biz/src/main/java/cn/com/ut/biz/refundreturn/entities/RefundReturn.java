package cn.com.ut.biz.refundreturn.entities;

/**
* 退货退款实体类
* 
 * @author zhouquanguo
 * @since on 2018/6/4.
 */

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class RefundReturn extends BaseEntity {

	/**
	 * 退货类型:1:不用退货,2:需要退货
	 */
	public static final String return_type = "return_type";
	/**
	 * 发货时间,默认为0
	 */
	public static final String ship_time = "ship_time";
	/**
	 * 买家会员名
	 */
	public static final String buyer_name = "buyer_name";
	/**
	 * 买家ID
	 */
	public static final String buyer_id = "buyer_id";
	/**
	 * 退款退货图片
	 */
	public static final String pic_info = "pic_info";
	/**
	 * 原因内容
	 */
	public static final String reason_info = "reason_info";
	/**
	 * 店铺名称
	 */
	public static final String store_name = "store_name";
	/**
	 * 退款金额
	 */
	public static final String refund_amount = "refund_amount";
	/**
	 * 收货延迟时间,默认为0
	 */
	public static final String delay_time = "delay_time";
	/**
	 * 店铺ID
	 */
	public static final String store_id = "store_id";
	/**
	 * 商品名称
	 */
	public static final String goods_name = "goods_name";
	/**
	 * 佣金比例
	 */
	public static final String commis_rate = "commis_rate";
	/**
	 * 申请类型:1:退款,2:退货
	 */
	public static final String refund_type = "refund_type";
	/**
	 * 退款退货申请原因
	 */
	public static final String buyer_message = "buyer_message";
	/**
	 * 物流单号
	 */
	public static final String invoice_no = "invoice_no";
	/**
	 * 收货时间,默认为0
	 */
	public static final String receive_time = "receive_time";
	/**
	 * 商品ID,0:全部退款
	 */
	public static final String goods_id = "goods_id";
	/**
	 * 卖家备注
	 */
	public static final String seller_message = "seller_message";
	/**
	 * 申请编号
	 */
	public static final String refund_sn = "refund_sn";
	/**
	 * 订单锁定类型:1:不用锁定,2:需要锁定
	 */
	public static final String order_lock = "order_lock";
	/**
	 * 订单商品类型:1:默认2:抢购商品3:限时折扣商品4:组合套装
	 */
	public static final String order_goods_type = "order_goods_type";
	/**
	 * 卖家处理时间
	 */
	public static final String seller_time = "seller_time";
	/**
	 * 原因ID:0:其它
	 */
	public static final String reason_id = "reason_id";
	/**
	 * 物流公司编号
	 */
	public static final String express_id = "express_id";
	/**
	 * 收货备注
	 */
	public static final String receive_message = "receive_message";
	/**
	 * 商品图片
	 */
	public static final String goods_image = "goods_image";
	/**
	 * 卖家处理状态:1:待审核,2:同意,3:不同意
	 */
	public static final String seller_state = "seller_state";
	/**
	 * 商品数量
	 */
	public static final String goods_num = "goods_num";
	/**
	 * 物流状态:1:待发货,2:待收货,3:未收到,4:已收货
	 */
	public static final String goods_state = "goods_state";
	/**
	 * 订单商品ID,0:全部退款
	 */
	public static final String order_goods_id = "order_goods_id";
	/**
	 * 管理员备注
	 */
	public static final String admin_message = "admin_message";
	/**
	 * 订单ID
	 */
	public static final String order_id = "order_id";
	/**
	 * 申请状态:1:处理中,2:待管理员处理,3:已完成
	 */
	public static final String refund_state = "refund_state";
	/**
	 * 添加时间
	 */
	public static final String add_time = "add_time";
	/**
	 * 订单编号
	 */
	public static final String order_sn = "order_sn";
	/**
	 * 管理员处理时间
	 */
	public static final String admin_time = "admin_time";
}