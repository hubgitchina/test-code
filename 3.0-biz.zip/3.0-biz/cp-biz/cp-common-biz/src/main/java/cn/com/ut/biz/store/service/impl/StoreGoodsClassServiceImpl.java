
//-----------------------------ServiceImpl-start---------------------------------//
package cn.com.ut.biz.store.service.impl;

import static cn.com.ut.biz.store.entities.StoreGoodsClass.store_id;
import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.store.dao.StoreGcGoodsDAO;
import cn.com.ut.biz.store.dao.StoreGoodsClassDAO;
import cn.com.ut.biz.store.entities.StoreGcGoods;
import cn.com.ut.biz.store.entities.StoreGoodsClass;
import cn.com.ut.biz.store.service.StoreGoodsClassService;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;

/**
 * ServiceImpl
 * 
 * @author wuxiaohua
 * @since 2018年5月24日
 */
@Service
public class StoreGoodsClassServiceImpl implements StoreGoodsClassService {

	@Autowired
	private StoreGoodsClassDAO storeGoodsClassDAO;
	@Autowired
	private StoreGcGoodsDAO storeGcGoodsDAO;

	@Override
	public String addStoreClass(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo,
				new String[] { StoreGoodsClass.storegc_name, StoreGoodsClass.store_id });

		// 验证排序字段
		if (NumberUtil.isInteger((String) vo.get(StoreGoodsClass.sort))) {
			vo.put(StoreGoodsClass.sort, Integer.parseInt((String) vo.get(StoreGoodsClass.sort)));
		} else {
			vo.put(StoreGoodsClass.sort, 0);
		}

		// 如果父分类参数非空，检查父分类是否存在
		String parentId = (String) vo.get(StoreGoodsClass.storegc_parent_id);
		String id = CommonUtil.getUUID();
		if (CommonUtil.isEmpty(parentId)) {

			Map<String, Object> storeGoodsClassVo = storeGoodsClassDAO.getById(null, null,
					new String[] { StoreGoodsClass.level }, null, parentId);

			if (storeGoodsClassVo == null) {

				ExceptionUtil.throwServiceException("店铺商品父分类不存在");
			} else if (2 == (int) storeGoodsClassVo.get(StoreGoodsClass.level)) {

				ExceptionUtil.throwServiceException("该店铺商品父分类为二级分类，底下不能添加子分类");
			} else {

				vo.put(StoreGoodsClass.level, 2);
				vo.put(StoreGoodsClass.gc_full_path, id + "_" + parentId);
			}
		} else {

			vo.put(StoreGoodsClass.level, 1);
			vo.put(StoreGoodsClass.gc_full_path, id);
		}

		vo.put(StoreGoodsClass.idx, id);
		vo.put(StoreGoodsClass.create_id, vo.get(StoreGoodsClass.user_id));
		storeGoodsClassDAO.add(vo);

		return id;
	}

	@Override
	public int updateStoreClass(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, new String[] { StoreGoodsClass.storegc_name,
				StoreGoodsClass.store_id, StoreGoodsClass.idx });

		// 验证排序字段
		if (NumberUtil.isInteger((String) vo.get(StoreGoodsClass.sort))) {
			vo.put(StoreGoodsClass.sort, Integer.parseInt((String) vo.get(StoreGoodsClass.sort)));
		} else {
			vo.put(StoreGoodsClass.sort, 0);
		}

		return storeGoodsClassDAO.update(vo);
	}

	@Override
	public int deleteStoreClass(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo,
				new String[] { StoreGoodsClass.store_id, StoreGoodsClass.idx });

		// 验证店铺商品分类下是否有子分类
		long childCount = storeGoodsClassDAO.count(null, null,
				new String[] { StoreGoodsClass.storegc_parent_id },
				new Object[] { vo.get(StoreGoodsClass.idx) });

		if (childCount > 0) {
			ExceptionUtil.throwServiceException("该店铺商品分类下有子分类，不能被删除");
		}

		// 验证店铺商品分类是否有关联商品
		long goodsCount = storeGcGoodsDAO.count(null, null,
				new String[] { StoreGcGoods.storegc_id },
				new Object[] { vo.get(StoreGoodsClass.idx) });

		if (goodsCount > 0) {
			ExceptionUtil.throwServiceException("该店铺商品分类下有关联商品，不能被删除");
		}

		return storeGoodsClassDAO.delete(null,
				new String[] { StoreGoodsClass.store_id, StoreGoodsClass.idx },
				ParameterBuilder.builder().append(vo, new String[] { store_id, idx }).toArray());
	}

	@Override
	public List<Map<String, Object>> queryAll(String storeId) {

		if (CommonUtil.isEmpty(storeId)) {
			ExceptionUtil.throwValidateException("店铺参数不能为空");
		}

		List<Map<String, Object>> list = storeGoodsClassDAO.queryPage(null, null, null, false,
				new String[] { StoreGoodsClass.storegc_name, StoreGoodsClass.idx,
						StoreGoodsClass.storegc_parent_id, StoreGoodsClass.level,
						StoreGoodsClass.sort },
				null, new String[] { StoreGoodsClass.store_id }, null, null, StoreGoodsClass.sort,
				new Object[] { storeId });

		List<Map<String, Object>> parentChildList = CommonUtil.createTree(list,
				StoreGoodsClass.storegc_parent_id, StoreGoodsClass.idx, "child");

		return parentChildList;

	}

	@Override
	public List<Map<String, Object>> queryChild(String storeId, String parentId) {

		if (CommonUtil.isEmpty(storeId)) {
			ExceptionUtil.throwValidateException("店铺参数不能为空");
		}

		if (CommonUtil.isEmpty(parentId)) {
			ExceptionUtil.throwValidateException("店铺商品父分类参数不能为空");
		}

		List<Map<String, Object>> list = storeGoodsClassDAO.queryPage(null, null, null, false,
				new String[] { StoreGoodsClass.storegc_name, StoreGoodsClass.idx,
						StoreGoodsClass.storegc_parent_id, StoreGoodsClass.level,
						StoreGoodsClass.sort },
				null, new String[] { StoreGoodsClass.store_id, StoreGoodsClass.storegc_parent_id },
				null, null, StoreGoodsClass.sort, new Object[] { storeId, parentId });

		return list;

	}

	@Override
	public List<Map<String, Object>> queryGoodsStoreClass(String storeId, String goodsId) {

		if (CommonUtil.isEmpty(storeId)) {
			ExceptionUtil.throwValidateException("店铺参数不能为空");
		}

		if (CommonUtil.isEmpty(goodsId)) {
			ExceptionUtil.throwValidateException("商品参数不能为空");
		}

		List<Map<String, Object>> list = storeGcGoodsDAO.queryGoodsStoreClass(storeId, goodsId);
		List<Map<String, Object>> parentChildList = CommonUtil.createTree(list,
				StoreGoodsClass.storegc_parent_id, StoreGoodsClass.idx, "child");

		return parentChildList;
	}

	@Override
	public void updateGoodsStoreClass(Map<String, Object> vo) {

		if (CommonUtil.isEmpty((String) vo.get(StoreGcGoods.goods_id))) {
			ExceptionUtil.throwValidateException("商品参数不能为空");
		}

		if (CommonUtil.isEmpty((String) vo.get(StoreGcGoods.store_id))) {
			ExceptionUtil.throwValidateException("店铺参数不能为空");
		}

		if (CollectionUtil.isEmptyCollection((List<Object>) vo.get(StoreGcGoods.storegc_id))) {
			ExceptionUtil.throwValidateException("店铺商品分类参数不能为空");
		}

		storeGcGoodsDAO.delete(null, new String[] { StoreGcGoods.store_id, StoreGcGoods.goods_id },
				new Object[] { vo.get(StoreGcGoods.store_id), vo.get(StoreGcGoods.goods_id) });

		List<Object[]> parameterArrayBatch = new ArrayList<>();
		List<Object> storeGoodsClassList = (List<Object>) vo.get(StoreGcGoods.storegc_id);
		for (Object storeGoodsClass : storeGoodsClassList) {
			parameterArrayBatch
					.add(new Object[] { CommonUtil.getUUID(), vo.get(StoreGcGoods.store_id),
							vo.get(StoreGcGoods.goods_id), storeGoodsClass });
		}

		storeGcGoodsDAO
				.addBatch(null,
						new String[] { StoreGcGoods.idx, StoreGcGoods.store_id,
								StoreGcGoods.goods_id, StoreGcGoods.storegc_id },
						null, parameterArrayBatch);
	}
}
// -----------------------------ServiceImpl-end---------------------------------//