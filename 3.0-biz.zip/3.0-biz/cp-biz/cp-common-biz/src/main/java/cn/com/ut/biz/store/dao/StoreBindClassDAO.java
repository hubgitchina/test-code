package cn.com.ut.biz.store.dao;

import cn.com.ut.biz.store.entities.StoreBindClass;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/10.
 */
public interface StoreBindClassDAO extends JdbcOperation<StoreBindClass> {
	/**
	 * 获取当前店铺的分类ID
	 * 
	 * @param storeId
	 * @return
	 */
	List<Map<String, Object>> getBindClassId(String storeId);

	/**
	 * 新增店铺下的分类
	 * 
	 * @param vo
	 * @return
	 */
	String add(Map<String, Object> vo);

	/**
	 * 根据店铺ID列表查询绑定的分类ID列表
	 * 
	 * @param storeIdList
	 * @return
	 */
	List<Map<String, Object>> getClassByStoreIds(List<String> storeIdList);
}
