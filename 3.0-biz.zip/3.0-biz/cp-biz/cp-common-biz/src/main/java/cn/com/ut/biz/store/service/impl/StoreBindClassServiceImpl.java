package cn.com.ut.biz.store.service.impl;

import cn.com.ut.biz.store.dao.StoreBindClassDAO;
import cn.com.ut.biz.store.entities.StoreBindClass;
import cn.com.ut.biz.store.service.StoreBindClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/11.
 */
@Service
public class StoreBindClassServiceImpl implements StoreBindClassService {

	@Autowired
	private StoreBindClassDAO storeBindClassDAO;

	@Override
	public List<Map<String, Object>> getBindCategoryByStoreId(String storeId) {

		List<Map<String, Object>> classIdList = storeBindClassDAO.getBindClassId(storeId);
		return classIdList;
	}

	@Override
	public String create(Map<String, Object> vo) {

		return storeBindClassDAO.add(vo);
	}

	@Override
	public List<Map<String, Object>> getClassByStoreIds(List<String> storeIdList) {

		return storeBindClassDAO.getClassByStoreIds(storeIdList);
	}

	@Override
	public Map<String, Object> selectByStoreIdAndGcId(String storeId, String goodsClassId) {

		return storeBindClassDAO.getByProperties(
				new String[] { StoreBindClass.store_id, StoreBindClass.gc_id },
				new Object[] { storeId, goodsClassId });
	}

}
