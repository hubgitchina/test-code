
package cn.com.ut.biz.cart.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class Cart extends BaseEntity {

	/**
	 * 店铺ID
	 */
	public static final String store_id = "store_id";
	/**
	 * 商品名称
	 */
	public static final String goods_name = "goods_name";
	/**
	 * 商品价格
	 */
	public static final String goods_price = "goods_price";

	/**
	 * 商品ID
	 */
	public static final String goods_id = "goods_id";
	/**
	 * 商品数量
	 */
	public static final String goods_num = "goods_num";
	/**
	 * 店铺名称
	 */
	public static final String store_name = "store_name";

	/**
	 * 买家ID
	 */
	public static final String buyer_id = "buyer_id";
	/**
	 * 规格参数ID
	 */
	public static final String specparam_id = "specparam_id";
	/**
	 * 规格参数名称
	 */
	public static final String specparam_name = "specparam_name";
}
