
//-----------------------------DAO-start---------------------------------//
package cn.com.ut.biz.store.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.store.entities.StoreGoodsClass;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface StoreGoodsClassDAO extends JdbcOperation<StoreGoodsClass> {

}
//-----------------------------DAO-end---------------------------------//