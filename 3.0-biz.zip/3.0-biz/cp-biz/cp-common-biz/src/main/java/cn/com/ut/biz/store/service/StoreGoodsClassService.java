
//-----------------------------Service-start---------------------------------//
package cn.com.ut.biz.store.service;

import java.util.List;
import java.util.Map;

/**
 * Service
 * 
 * @author 
 * @since 
 */
public interface StoreGoodsClassService {

	void updateGoodsStoreClass(Map<String, Object> vo);

	List<Map<String, Object>> queryChild(String storeId, String parentId);

	List<Map<String, Object>> queryAll(String storeId);

	int deleteStoreClass(Map<String, Object> vo);

	int updateStoreClass(Map<String, Object> vo);

	String addStoreClass(Map<String, Object> vo);

	List<Map<String, Object>> queryGoodsStoreClass(String storeId, String goodsId);
	
	
}
//-----------------------------Service-end---------------------------------//