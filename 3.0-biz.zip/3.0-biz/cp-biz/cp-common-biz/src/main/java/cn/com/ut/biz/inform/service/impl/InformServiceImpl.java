
//-----------------------------ServiceImpl-start---------------------------------//
package cn.com.ut.biz.inform.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.inform.dao.InformDAO;
import cn.com.ut.biz.inform.entities.Inform;
import cn.com.ut.biz.inform.service.InformService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * ServiceImpl
 * 
 * @author 
 * @since 
 */
@Service
public class InformServiceImpl implements InformService {

	@Autowired
	private InformDAO informDAO;
	
}
//-----------------------------ServiceImpl-end---------------------------------//