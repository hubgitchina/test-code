package cn.com.ut.biz.store.service;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/11.
 */
public interface StoreBindClassService {
	/**
	 * 根据店铺id查询绑定的商品分类ID
	 * 
	 * @param storeId
	 * @return
	 */
	List<Map<String, Object>> getBindCategoryByStoreId(String storeId);

	/**
	 * 新增店铺分类
	 */
	String create(Map<String, Object> vo);

	/**
	 * 根据店铺ID的列表查询分类
	 * 
	 * @param storeIdList
	 * @return
	 */
	List<Map<String, Object>> getClassByStoreIds(List<String> storeIdList);

	/**
	 * 根据店铺ID和产品分类ID查询当前店铺是否已经绑定该分类
	 * 
	 * @param storeId
	 * @param goodsClassId
	 * @return
	 */
	Map<String, Object> selectByStoreIdAndGcId(String storeId, String goodsClassId);
}
