package cn.com.ut.biz.goodsspec.util;

import java.util.TreeSet;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
@EqualsAndHashCode(of = { "spec_id" })
public class SpecVo {

	private String spec_id;
	private String spec_name;
	private TreeSet<SpecValueVo> specvalues = new TreeSet<>();
}
