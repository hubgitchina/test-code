
package cn.com.ut.biz.order.dao;

import java.util.Map;

import cn.com.ut.biz.order.entities.OrderPay;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 订单支付DAO层
 *
 * @author zhouquanguo
 * @since 2018年5月18日
 */
public interface OrderPayDAO extends JdbcOperation<OrderPay> {
	/**
	 * 保存订单支付信息
	 **/
	String add(Map<String, Object> vo);
}
