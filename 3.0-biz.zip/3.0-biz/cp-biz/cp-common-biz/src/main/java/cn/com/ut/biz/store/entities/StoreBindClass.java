package cn.com.ut.biz.store.entities;

/**
 * Created by zhouquanguo on 2018/5/10.
 */

import cn.com.ut.core.dal.jdbc.BaseEntity;

public class StoreBindClass extends BaseEntity {

	/**
	 * 店铺ID
	 */
	public static final String store_id = "store_id";
	/**
	 * 商品分类
	 */
	public static final String gc_id = "gc_id";
	/**
	 * 状态0:审核中1:已审核 2:平台自营店铺
	 */
	public static final String storebindclass_state = "storebindclass_state";
}
