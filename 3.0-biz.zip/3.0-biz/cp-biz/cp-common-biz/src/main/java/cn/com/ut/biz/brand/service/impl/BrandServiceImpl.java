package cn.com.ut.biz.brand.service.impl;

import cn.com.ut.biz.brand.dao.BrandDAO;
import cn.com.ut.biz.brand.entities.Brand;
import cn.com.ut.biz.brand.service.BrandService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


/**
 * Created by zhouquanguo on 2018/4/26.
 */
@Service
public class BrandServiceImpl implements BrandService {

    @Autowired
    private BrandDAO brandDAO;

    @Override
    public String add(Map<String, Object> brandDto) {
        ValidatorUtil.validateMapContainsKey(brandDto, Brand.brand_name, Brand.brand_showtype,"user_id");
        boolean isNotRepeat = brandDAO.checkUnique(new String[]{Brand.brand_name}, new Object[]{brandDto.get(Brand.brand_name)}, null, null);
        if (!isNotRepeat) {
            ExceptionUtil.throwValidateException("品牌名称重复");
        }
        String brand_initial= ((String) brandDto.get(Brand.brand_name)).substring(0,1).toUpperCase();
        brandDto.put(Brand.brand_initial,brand_initial);
        String id = brandDAO.add(new String[]{Brand.brand_name, Brand.brand_initial,Brand.brand_showtype,Brand.brand_pic,Brand.brand_recommend
        ,Brand.sort,Brand.store_id}, brandDto);
        return id;
    }

    @Override
    public ResponseWrap deleteById(String brandId) {
        if (StringUtils.isEmpty(brandId)) {
            ExceptionUtil.throwValidateException("缺少必要的参数");
        }
        int resultCount = brandDAO.delete(brandId);
        if(!(resultCount>0)){
            ExceptionUtil.throwRuntimeException("系统内部错误");
        }
        ResponseWrap responseWrap = ResponseWrap.builder();
        return responseWrap;

    }

    @Override
    public Map<String, Object> getOne(String id) {

        return brandDAO.get(id);

    }

    @Override
    public List<Map<String, Object>> query(Map<String, Object> condition, PageBean pageBean) {

        return brandDAO.findAll(condition,pageBean);
    }

    @Override
    public ResponseWrap update(Map<String, Object> brandDto) {

        ValidatorUtil.validateMapContainsKey(brandDto,Brand.brand_name,Brand.brand_showtype,Brand.idx,"user_id");
        ResponseWrap responseWrap = ResponseWrap.builder();
        Map<String,Object> before = getOne((String) brandDto.get(Brand.idx));
        if( before == null || before.size()<1){
            ExceptionUtil.throwValidateException("待更新的品牌不存在");
        }
        if(before.get(Brand.brand_name) != brandDto.get(Brand.brand_name)){
            brandDto.put(Brand.brand_initial,((String) brandDto.get(Brand.brand_name)).substring(1,1).toUpperCase());
        }
        boolean isNotRepeat = brandDAO.checkUnique(new String[]{Brand.brand_name}, new Object[]{brandDto.get(Brand.brand_name)}, new String[]{Brand.idx}, new Object[]{brandDto.get(Brand.idx)});
        if (!isNotRepeat) {
            ExceptionUtil.throwValidateException("品牌名称重复");
        }

        brandDAO.update(new String[]{Brand.brand_name,Brand.brand_initial,Brand.brand_pic,Brand.brand_recommend,Brand.brand_showtype,Brand.update_id,Brand.update_time},brandDto);
        return responseWrap;
    }
}
