package cn.com.ut.biz.store.service;


import cn.com.ut.core.restful.ResponseWrap;

import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/9.
 */
public interface StoreService {
    /**
     * 新增店铺
     * @param vo
     * @return
     */
    String create(Map<String, Object> vo);

    /**
     * 更新店铺
     * @param vo
     * @return
     */
    String update(Map<String, Object> vo);

    /**
     * 获取店铺详情
     * @param vo
     * @return
     */
    Map<String,Object> getOne(Map<String, Object> vo);

    /**
     * 删除店铺
     * @param vo
     */
    void delete(Map<String, Object> vo);

    /**
     * 查询所有的店铺（带分页）
     * @param vo
     * @return
     */
    ResponseWrap query(Map<String, Object> vo);

    /**
     * 获取当前店铺关联的所有商品分类
     * @param storeId
     * @return
     */
    List<Map<String,Object>> getBindCategories(String storeId);

    /**
     * 插入店铺分类
     * @param vo
     */
    String addStoreCategory(Map<String, Object> vo);

    /**
     * 首页搜索框（按店铺）
     * @param vo
     */
    ResponseWrap searchByStoreName(Map<String, Object> vo);
}
