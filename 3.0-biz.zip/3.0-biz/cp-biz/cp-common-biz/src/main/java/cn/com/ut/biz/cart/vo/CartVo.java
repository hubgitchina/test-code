package cn.com.ut.biz.cart.vo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/11.
 */
@Getter
@Setter
@NoArgsConstructor
public class CartVo {


    /**
     * 当前店铺的购物车总金额
     */
    private BigDecimal shop_total_price;
    /**
     * 店铺名称
     */
    private String store_name;
    /**
     * 店铺购物车商品数量
     */
    private Integer store_goods_amount;
    /**
     * 店铺购物车列表
     */
    List<Map<String, Object>> goods;
    /**
     * 店铺ID
     */
    private String store_id;


}
