package cn.com.ut.biz.common;

public class ConfigConstant {

	public interface ComplainTimeLimit {

		/**
		 * 订单交易成功后允许发起投诉的天数限制
		 */
		int COMPLAIN_DAYS = 30;
	}

	public interface ComplainState {

		/**
		 * 新投诉
		 */
		int NEW = 10;
		/**
		 * 待申诉
		 */
		int WAIT_APPEAL = 20;
		/**
		 * 已申诉
		 */
		int APPEAL = 30;
		/**
		 * 待仲裁
		 */
		int ARBITRATE = 40;
		/**
		 * 已关闭
		 */
		int FINISH = 99;
		/**
		 * 待审核
		 */
		int WAIT_AUDIT = 1;
		/**
		 * 审核通过
		 */
		int AUDIT = 2;
	}

}
