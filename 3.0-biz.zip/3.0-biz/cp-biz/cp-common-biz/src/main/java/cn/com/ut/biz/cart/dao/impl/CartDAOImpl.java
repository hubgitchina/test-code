
package cn.com.ut.biz.cart.dao.impl;

import static cn.com.ut.biz.cart.entities.Cart.*;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import cn.com.ut.biz.cart.dao.CartDAO;
import cn.com.ut.biz.cart.entities.Cart;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.jdbc.ParameterBuilder;
import cn.com.ut.core.dal.sql.SQLHelper;

@Repository
public class CartDAOImpl extends JdbcOperationsImpl<Cart> implements CartDAO {

	public String add(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		add(null,
				new String[] { store_id, goods_name, goods_price, specparam_id, goods_id, goods_num,
						store_name, specparam_name, buyer_id },
				NAMES_ID_CT_CID,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { store_id, goods_name, goods_price, specparam_id,
										goods_id, goods_num, store_name, specparam_name, buyer_id })
						.append(id, DateTimeUtil.currentDateTime(), vo.get(Cart.create_id))
						.toArray());
		return id;
	}

	@Override
	public Map<String, Object> getByProductIdAndUserId(String buyerId, String goodsId,
			String storeId) {

		return get(null, null, false,
				new String[] { Cart.idx, store_id, goods_name, goods_price, specparam_id, goods_id,
						goods_num, store_name, specparam_name, buyer_id },
				null, new String[] { Cart.buyer_id, Cart.goods_id, Cart.store_id }, null, null,
				new Object[] { buyerId, goodsId, storeId });
	}

	public int update(Map<String, Object> vo) {

		return updateById(null,
				new String[] { store_id, goods_name, goods_price, specparam_id, goods_id, goods_num,
						store_name, specparam_name, buyer_id },
				NAMES_UT_UID, null,
				ParameterBuilder.builder()
						.append(vo,
								new String[] { store_id, goods_name, goods_price, specparam_id,
										goods_id, goods_num, store_name, specparam_name, buyer_id })
						.append(DateTimeUtil.currentDateTime(), vo.get(Cart.update_id)).toArray(),
				(String) vo.get(Cart.idx), null);
	}

	@Override
	public int getTotalCartCount(String buyerId) {

		return queryForInt(getJdbcTemplate(),
				"SELECT SUM(goods_num) FROM ds_cart WHERE buyer_id = ?", buyerId);
	}

	@Override
	public void batchCleanCart(List<Map<String, Object>> orderItemList) {

		SQLHelper sqlHelper = SQLHelper.builder();
		for (Map<String, Object> orderDetail : orderItemList) {
			if (!StringUtils.isEmpty((String) orderDetail.get(Cart.specparam_id))) {
				sqlHelper.append(
						"ds_cart d WHERE d.buyer_id = ? AND d.store_id = ? AND d.specparam_id =?");
				delete(null, new String[] { Cart.buyer_id, Cart.store_id, Cart.specparam_id },
						new Object[] { orderDetail.get(Cart.buyer_id),
								orderDetail.get(Cart.store_id),
								orderDetail.get(Cart.specparam_id) });
			} else {
				sqlHelper.append(
						"ds_cart d WHERE d.buyer_id = ? AND d.store_id = ? AND d.goods_id =?");
				delete(null, new String[] { Cart.buyer_id, Cart.store_id, Cart.goods_id }, null,
						null,
						new Object[] { orderDetail.get(Cart.buyer_id),
								orderDetail.get(Cart.store_id), orderDetail.get(Cart.goods_id) },
						null);

			}

		}
	}

	@Override
	public Map<String, Object> getBySpecIdAndUserId(String buyerId, String goodsId, String storeId,
			String specparam_id) {

		return get(null, null, false,
				new String[] { Cart.idx, store_id, goods_name, goods_price, Cart.specparam_id,
						goods_id, goods_num, store_name, specparam_name, buyer_id },
				null,
				new String[] { Cart.buyer_id, Cart.goods_id, Cart.store_id, Cart.specparam_id },
				null, null, new Object[] { buyerId, goodsId, storeId, specparam_id });
	}

	@Override
	public List<Map<String, Object>> queryCartList(String buyer_id) {

		return query(null, null, null,
				new String[] { Cart.idx, store_id, goods_name, goods_price, specparam_id, goods_id,
						goods_num, store_name, specparam_name, Cart.buyer_id },
				null, new String[] { Cart.buyer_id }, new Object[] { buyer_id });
	}
}
