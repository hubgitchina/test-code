
package cn.com.ut.biz.order.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 订单商品表实体类
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
public class OrderGoods extends BaseEntity {

	/**
	 * 店铺ID
	 */
	public static final String store_id = "store_id";
	/**
	 * 商品名称
	 */
	public static final String goods_name = "goods_name";
	/**
	 * 商品图片
	 */
	public static final String goods_image = "goods_image";
	/**
	 * 商品价格
	 */
	public static final String goods_price = "goods_price";
	/**
	 * 商品ID
	 */
	public static final String goods_id = "goods_id";
	/**
	 * 商品数量
	 */
	public static final String goods_num = "goods_num";
	/**
	 * 买家ID
	 */
	public static final String buyer_id = "buyer_id";
	/**
	 * 订单ID
	 */
	public static final String order_id = "order_id";
	/**
	 * 商品实际成交价
	 */
	public static final String goods_pay_price = "goods_pay_price";
	/**
	 * 规格参数ID
	 */
	public static final String specparam_id = "specparam_id";

	/**
	 * 规格参数名称
	 */
	public static final String specparam_name = "specparam_name";
}
