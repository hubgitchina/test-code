package cn.com.ut.biz.goods.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.goods.entities.GoodsSpec;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 商品规格信息DAO
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface GoodsSpecDAO extends JdbcOperation<GoodsSpec> {

	/**
	 * 批量更新商品的库存
	 * 
	 * @param goodsSpecList
	 */
	void batchUpdateGoodsStorage(List<Map<String, Object>> goodsSpecList);

	/**
	 * 根据规格参数ID查询当前的商品信息
	 * 
	 * @param specId
	 * @return
	 */
	Map<String, Object> getBySpecParamId(String specId);

}
