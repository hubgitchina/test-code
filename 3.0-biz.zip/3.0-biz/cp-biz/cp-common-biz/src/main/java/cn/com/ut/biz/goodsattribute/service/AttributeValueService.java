package cn.com.ut.biz.goodsattribute.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 商品属性值业务层接口
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public interface AttributeValueService {

	/**
	 * 更新商品属性下的属性值（多条属性值批量更新）
	 * 
	 * @param vo
	 */
	void updateAttrValue(Map<String, Object> vo);

	/**
	 * 添加商品属性值
	 * 
	 * @param vo
	 * @return
	 */
	String create(Map<String, Object> vo);

	/**
	 * 修改商品属性值
	 * 
	 * @param vo
	 * @return
	 */
	String update(Map<String, Object> vo);

	/**
	 * 查询商品属性值详情
	 */
	Map<String, Object> getDetail(Map<String, Object> vo);

	/**
	 * 删除商品属性值
	 * 
	 * @param id
	 * @param appId
	 */
	void delete(Map<String, Object> vo);

	/**
	 * 查询所有的商品属性值（带分页）
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findAllPage(PageBean page);
}
