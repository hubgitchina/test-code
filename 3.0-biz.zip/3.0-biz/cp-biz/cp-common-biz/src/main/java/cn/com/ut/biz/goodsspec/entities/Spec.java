package cn.com.ut.biz.goodsspec.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品规格表 ds_spec
 * 
 * @author wangpeng1
 * @since 2018年4月27日
 */
public class Spec extends BaseEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6892414017322876058L;
	/**
	 * 规格名称
	 */
	public static final String sp_name = "sp_name";
	/**
	 * 所属类型ID
	 */
	public static final String type_id = "type_id";
	/**
	 * 规格排序
	 */
	public static final String sort = "sort";
}
