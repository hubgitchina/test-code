package cn.com.ut.biz.session.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.permission.service.MenuService;
import cn.com.ut.biz.session.service.UserSessionService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 用户会话控制层
 * 
 * @author lanbin
 * @since 2017年3月13日
 */
@RestController
@RequestMapping(value = "/userSession")
public class UserSessionController {

	@Autowired
	private UserSessionService userSessionService;
	@Autowired
	private UserService userService;

	@Autowired
	private MenuService menuService;

	/**
	 * 用户登录
	 * 
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param loginType
	 *            登录类型
	 * @param randomCode
	 *            随机码（非必填）
	 * @return
	 */
	@ServiceComponent(session = false)
	@GetMapping(value = "/login")
	public ResponseWrap login(HttpServletResponse response,
			@RequestParam(value = "user_name") String userName,
			@RequestParam(value = "pwd") String password,
			@RequestParam(value = "login_type") String loginType,
			@RequestParam(value = "random_code", required = false) String randomCode,
			@RequestAttribute(value = "user") User user) {

		JSONObject data = userSessionService.login(userName, password, loginType,
				user.getSessionId(), randomCode, response);
		ResponseWrap responseWrap = ResponseWrap.builder();
		return responseWrap.appendRow(data);
	}

	/**
	 * 检查账户是否被锁定（多次密码错误时被锁定）
	 */
	@ServiceComponent(session = false)
	@GetMapping(value = "/accountLockCheck")
	public ResponseWrap accountLockCheck(@RequestParam(value = "user_name") String userName) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		int code = userService.accountLockCheck(userName);
		Map<String, Object> row = new HashMap<>();
		row.put("lock_code", code);
		return responseWrap.appendRow(row);
	}

	/**
	 * 退出登录
	 */
	@PostMapping(value = "/logout")
	@ServiceComponent(session = false)
	public ResponseWrap logout(@RequestAttribute(value = "user") User user) {

		if (!CommonUtil.isEmpty(user.getSessionId())) {
			userService.loginOut(user.getSessionId());
		}
		return ResponseWrap.builder();
	}

	/**
	 * 列出用户所有菜单
	 * 
	 * @param user
	 * @return
	 */
	@GetMapping("/listUserMenus")
	public ResponseWrap listUserMenus(@RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		List<Map<String, Object>> rows = menuService.listUserMenus(user);
		responseWrap.appendRows(rows);
		return responseWrap;
	}

	/**
	 * 获取会话信息
	 */
	@GetMapping(value = "/getUserSession")
	@ServiceComponent(session = false)
	public ResponseWrap getUserSession(@RequestAttribute(value = "user") User user,
			@RequestParam(name = "module_code", required = false) String moduleCode) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		Map<String, Object> row = userSessionService.getUserSession(user, moduleCode);

		return responseWrap.appendRow(row);
	}

}
