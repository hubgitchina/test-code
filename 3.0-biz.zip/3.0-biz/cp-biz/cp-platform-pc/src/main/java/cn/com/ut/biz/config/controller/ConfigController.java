package cn.com.ut.biz.config.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.system.entities.Config;
import cn.com.ut.biz.system.service.ConfigService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 系统配置管理
 * 
 * @author ouyuexing
 *
 */
@RestController
@RequestMapping(value = "/config")
public class ConfigController {

	@Autowired
	private ConfigService configService;

	/**
	 * 查询系统配置列表
	 */
	@GetMapping(value = "/find")
	public ResponseWrap find(@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendWhereConditions(Config.config_code, Config.config_name, Config.config_type);
		pb.appendSortConditions("biz." + Config.create_time);
		pb.appendSortConditions(Config.config_code, Config.config_name, Config.config_type);
		PageBean page = pb.buildSQL(pageMap);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);

		List<Map<String, Object>> itemList = configService.find(page);
		responseWrap.appendPage(page).appendRows(itemList);
		return responseWrap;
	}

	/**
	 * 创建系统配置
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();

		vo.put(Config.create_id, user.getUserId());
		String id = configService.create(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 更新系统配置
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> configVo = responseWrap.getJson();
		configVo.put(Config.update_id, user.getUserId());
		String id = configService.update(configVo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 查询详细系统配置
	 */
	@GetMapping(value = "/getDetail/{configId}")
	public ResponseWrap getDetail(@PathVariable String configId) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		Map<String, Object> row = configService.getDetail(configId);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 删除系统配置
	 */
	@DeleteMapping(value = "/delete/{configId}")
	public ResponseWrap delete(@PathVariable String configId) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		configService.delete(configId);
		return responseWrap;
	}

	/**
	 * 获取系统配置对应的值
	 */
	@PostMapping(value = "/getConfigValueByCode")
	public ResponseWrap getConfigValueByCode(@RequestBody ResponseWrap responseWrap) {

		JSONObject parJson = responseWrap.getJson();
		String configCode = parJson.getString("config_code");
		String value = configService.getConfigValueByCode(configCode);

		Map<String, Object> dataVo = new HashMap<>(1);
		dataVo.put("value", value);
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.appendRow(dataVo);
		return responseWrap;
	}

	/**
	 * 获取多个系统配置对应的值
	 */
	@PostMapping(value = "/getConfigValueByCodes")
	public ResponseWrap getConfigValueByCodes(@RequestBody ResponseWrap responseWrap) {

		JSONObject parJson = responseWrap.getJson();
		JSONArray configCodes = parJson.getJSONArray("config_codes");
		List<Map<String, Object>> resultList = configService.getConfigValueByCode(configCodes);

		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.appendRows(resultList);
		return responseWrap;
	}
}
