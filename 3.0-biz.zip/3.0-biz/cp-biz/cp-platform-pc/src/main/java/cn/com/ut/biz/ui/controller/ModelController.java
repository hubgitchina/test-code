
//-----------------------------Controller-start---------------------------------//
package cn.com.ut.biz.ui.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.ui.entities.Component;
import cn.com.ut.biz.ui.entities.Model;
import cn.com.ut.biz.ui.service.ModelService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * Controller
 * 
 * @author
 * @since
 */
@RestController
@RequestMapping(value = "/model")
public class ModelController {

	@Autowired
	private ModelService modelService;

	/**
	 * 创建模型
	 *
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping("/add")
	public ResponseWrap add(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(Component.create_id, user.getUserId());
		String id = modelService.add(vo);
		Map<String, Object> row = new HashMap<>();
		row.put(Component.idx, id);
		return responseWrap.appendData(row);
	}

	/**
	 * 删除模型
	 *
	 * @param id
	 * @return
	 */
	@DeleteMapping("/delete/{id}")
	public ResponseWrap delete(@PathVariable(value = "id") String id) {

		modelService.delete(id);
		return ResponseWrap.builder();
	}

	/**
	 * 查询模型列表（支持分页）
	 *
	 * @param multiValueMap
	 * @return
	 */
	@GetMapping("/queryPage")
	public ResponseWrap queryPage(@RequestParam MultiValueMap<String, Object> multiValueMap) {

		PageBean pageBean = PageBuilder.build().buildSQL(multiValueMap);
		List<Map<String, Object>> rows = modelService.query(pageBean);
		return ResponseWrap.builder().appendPage(pageBean).appendRows(rows);
	}

	/**
	 * 查询模型列表（支持分页）
	 *
	 * @param multiValueMap
	 * @return
	 */
	@GetMapping("/query")
	public ResponseWrap query(@RequestParam HashMap<String, Object> vo) {

		return ResponseWrap.builder().appendRows(modelService.query(vo));
	}

	/**
	 * 更新模型
	 *
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(Model.update_id, user.getUserId());
		modelService.update(vo);
		return responseWrap;
	}

	/**
	 * 查询模型信息
	 */
	@GetMapping(value = "/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = modelService.getDetail(id);
		responseWrap.appendData(row);
		return responseWrap;
	}

}
// -----------------------------Controller-end---------------------------------//