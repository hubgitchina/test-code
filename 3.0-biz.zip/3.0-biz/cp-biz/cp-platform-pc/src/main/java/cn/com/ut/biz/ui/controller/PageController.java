package cn.com.ut.biz.ui.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.ui.entities.Page;
import cn.com.ut.biz.ui.service.PageService;
import cn.com.ut.biz.ui.util.ZipIOUtil;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 应用定制页面控制层
 * 
 * @author wangpeng1
 * @since 2018年5月15日
 */
@RestController
@RequestMapping(value = "/page")
public class PageController {

	@Autowired
	private PageService pageService;

	/**
	 * 创建应用定制页面
	 *
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping("/add")
	public ResponseWrap add(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(Page.create_id, user.getUserId());
		String id = pageService.add(vo);
		Map<String, Object> row = new HashMap<>();
		row.put(Page.idx, id);
		return responseWrap.appendData(row);
	}

	/**
	 * 更新应用定制页面
	 *
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(Page.update_id, user.getUserId());
		pageService.update(vo);
		return responseWrap;
	}

	/**
	 * 查询应用定制页面（支持分页）
	 *
	 * @param multiValueMap
	 * @return
	 */
	@GetMapping("/queryPage")
	public ResponseWrap queryPage(@RequestParam MultiValueMap<String, Object> pageMap) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition(null, Page.page_name, EnumConstant.WhereCase.LIKE,
				EnumConstant.SqlType.STRING);
		pb.appendSortCondition(null, Page.create_time, EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> resultList = pageService.query(page);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 查询所有应用定制页面信息（树形结构）
	 *
	 * @param multiValueMap
	 * @return
	 */
	@PostMapping("/query")
	public ResponseWrap query(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> treeMap = pageService.queryTree(vo);
		responseWrap.appendData(treeMap);
		return responseWrap;
	}

	/**
	 * 删除应用定制页面
	 *
	 * @param id
	 * @return
	 */
	@DeleteMapping("/delete/{id}")
	public ResponseWrap delete(@PathVariable(value = "id") String id) {

		pageService.delete(id);
		return ResponseWrap.builder();
	}

	/**
	 * 查询应用定制页面详情
	 */
	@GetMapping(value = "/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = pageService.getDetail(id);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 将页面模型下的全部页面目录和文件按目录结构进行打包下载
	 * 
	 * @throws IOException
	 */
	@GetMapping(value = "/zipdown/{id}")
	@ServiceComponent(session = false)
	public void zipdown(@PathVariable String id, HttpServletResponse resp) throws IOException {

		List<Map<String, Object>> pageVos = pageService.queryByModel(id);
		pageService.buildFileFullPath(pageVos);

		String zipName = String.valueOf(System.currentTimeMillis());
		resp.setContentType("application/x-msdownload;charset=utf-8");
		resp.setHeader("content-disposition",
				"attachment;filename=" + URLEncoder.encode(zipName + ".zip", "utf-8"));
		OutputStream output = resp.getOutputStream();

		String temdir = System.getProperty("java.io.tmpdir");

		ZipIOUtil.buildTemdir(temdir + File.separator + "page");

		String zipPath = temdir + File.separator + "page" + File.separator + zipName
				+ File.separator;

		for (Map<String, Object> pageVo : pageVos) {

			boolean isDir = ConstantUtil.FLAG_YES.equals(pageVo.get(Page.is_dir));
			if (isDir) {
				File f = new File(zipPath + String.valueOf(pageVo.get("full_path"))
						+ String.valueOf(pageVo.get(Page.page_name)));
				if (!f.exists() && !f.isDirectory()) {
					f.mkdirs();
				}
			} else {
				FileOutputStream fos = new FileOutputStream(
						zipPath + String.valueOf(pageVo.get("full_path"))
								+ String.valueOf(pageVo.get(Page.page_name)));

				String pageView = pageVo.get(Page.page_view) == null ? ""
						: String.valueOf(pageVo.get(Page.page_view));

				fos.write(pageView.getBytes());
				fos.close();
			}
		}

		ZipOutputStream zos = new ZipOutputStream(output);
		ZipIOUtil.compress(new File(zipPath), "", zos);

		// 须关闭，避免ZIP文件打开出现警告
		zos.close();

	}

	/**
	 * 将页面模型下的单页面文件下载
	 * 
	 * @throws IOException
	 */
	@GetMapping(value = "/pagedown/{id}")
	@ServiceComponent(session = false)
	public void pagedown(@PathVariable String id, HttpServletResponse resp) throws IOException {

		Map<String, Object> pageVo = pageService.getPageById(id);
		if (pageVo == null) {

			ExceptionUtil.throwServiceException("页面文件无效");
		} else {

			String fileName = (String) pageVo.get(Page.page_name);
			String pageView = pageVo.get(Page.page_view) == null ? ""
					: String.valueOf(pageVo.get(Page.page_view));
			resp.setContentType("application/x-msdownload;charset=utf-8");
			resp.setHeader("content-disposition",
					"attachment;filename=" + URLEncoder.encode(fileName, "utf-8"));
			PrintWriter output = resp.getWriter();
			output.println(pageView);
			output.close();
		}
	}

}