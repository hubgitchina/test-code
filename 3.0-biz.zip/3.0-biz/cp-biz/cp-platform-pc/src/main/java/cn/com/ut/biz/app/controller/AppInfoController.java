package cn.com.ut.biz.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.app.entities.AppInfo;
import cn.com.ut.biz.app.service.AppInfoService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 应用信息控制层
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@RestController
@RequestMapping(value = "/appInfo")
public class AppInfoController {

	@Autowired
	private AppInfoService appInfoService;

	/**
	 * 添加应用
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();

		vo.put(AppInfo.create_id, user.getUserId());
		String id = appInfoService.create(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 更新应用信息
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(AppInfo.update_id, user.getUserId());
		String id = appInfoService.update(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 查询所有应用
	 */
	@GetMapping(value = "/findByUser")
	public ResponseWrap findByUser(@RequestParam MultiValueMap<String, Object> pageMap,
			@RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		List<Map<String, Object>> apiList = appInfoService.findByUser(user);
		responseWrap.appendRows(apiList);
		return responseWrap;
	}

	@GetMapping(value = "/findAllPage")
	public ResponseWrap findAllPage(@RequestParam MultiValueMap<String, Object> pageMap) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition(null, AppInfo.status, EnumConstant.WhereCase.EQ,
				EnumConstant.SqlType.STRING);
		pb.appendWhereCondition(null, AppInfo.app_name, EnumConstant.WhereCase.LIKE,
				EnumConstant.SqlType.STRING);
		pb.appendSortCondition(null, AppInfo.create_time, EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> resultList = appInfoService.findAllPage(page);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 查询应用AccessKey
	 */
	@GetMapping(value = "/getAccessKey/{id}")
	public ResponseWrap getAccessKey(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = appInfoService.getAccessKey(id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 为应用生成新的AccessKey
	 */
	@PostMapping(value = "/generateAccessKey")
	public ResponseWrap generateAccessKey(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(AppInfo.update_id, user.getUserId());
		String appKey = appInfoService.generateAccessKey(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("appKey", appKey);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 查询应用信息详情
	 */
	@GetMapping(value = "/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = appInfoService.getDetail(id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 删除应用
	 */
	@DeleteMapping(value = "/delete")
	public ResponseWrap delete(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		String id = TypeConvert.getStringValue(vo.get(AppInfo.idx));
		String appId = TypeConvert.getStringValue(vo.get(AppInfo.app_id));
		appInfoService.delete(id, appId);
		return responseWrap;
	}

	/**
	 * 提交审核
	 */
	@PostMapping(value = "/submitExamine")
	public ResponseWrap submitExamine(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(AppInfo.update_id, user.getUserId());
		appInfoService.submitExamine(vo);
		return responseWrap;
	}

	/**
	 * 审核应用信息
	 */
	@PostMapping(value = "/examineAppInfo")
	public ResponseWrap examineAppInfo(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(AppInfo.audit_operator, user.getUserId());
		appInfoService.examineAppInfo(vo);
		return ResponseWrap.builder();
	}

	/**
	 * 确认修改审核资料
	 */
	@GetMapping(value = "/confirmUpdate/{id}")
	public ResponseWrap confirmUpdate(@PathVariable String id) {

		appInfoService.confirmUpdate(id);
		return ResponseWrap.builder();
	}

	/**
	 * 应用上线
	 */
	@PostMapping(value = "/onlineApp")
	public ResponseWrap onlineApp(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(AppInfo.update_id, user.getUserId());
		appInfoService.onlineApp(vo);
		return responseWrap;
	}

	/**
	 * 应用下线
	 */
	@PostMapping(value = "/downlineApp")
	public ResponseWrap downlineApp(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(AppInfo.update_id, user.getUserId());
		appInfoService.downlineApp(vo);
		return responseWrap;
	}

	/**
	 * 是否已存在同名应用
	 */
	@PostMapping(value = "/existApp")
	public ResponseWrap existApp(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		int checkResult = appInfoService.existApp(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("checkResult", checkResult);
		responseWrap.appendRow(row);
		return responseWrap;
	}
}
