package cn.com.ut.biz.ui.controller;

import cn.com.ut.biz.ui.entities.Component;
import cn.com.ut.biz.ui.service.ComponentService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.restful.ResponseWrap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static cn.com.ut.core.dal.jdbc.BaseEntity.update_id;

/**
 * Created by zhouquanguo on 2018/4/25.
 */

@RestController
@RequestMapping("/component")
public class ComponentController {

    @Autowired
    private ComponentService componentService;

    /**
     * 创建组件
     *
     * @param responseWrap
     * @param user
     * @return
     */
    @PostMapping("/add")
    public ResponseWrap add(@RequestBody ResponseWrap responseWrap,
                            @RequestAttribute("user") User user) {

        Map<String, Object> componentVo = responseWrap.getJson();
        componentVo.put(Component.create_id, user.getUserId());
        String id = componentService.add(componentVo);
        Map<String, Object> row = new HashMap<>();
        row.put(Component.idx, id);
        return responseWrap.appendRow(row);
    }

    /**
     * 删除组件
     *
     * @param id
     * @return
     */
    @DeleteMapping("/delete/{id}")
    public ResponseWrap delete(@PathVariable(value = "id") String id) {

        componentService.delete(id);
        return ResponseWrap.builder();
    }

    /**
     * 查询组件列表（支持分页）
     *
     * @param multiValueMap
     * @return
     */
    @GetMapping("/query")
    public ResponseWrap query(@RequestParam MultiValueMap<String, Object> multiValueMap) {

        PageBean pageBean = PageBuilder.build().buildSQL(multiValueMap);
        List<Map<String, Object>> rows = componentService.query(pageBean);
        return ResponseWrap.builder().appendPage(pageBean).appendRows(rows);
    }

    /**
     * 更新组件
     *
     * @param responseWrap
     * @param user
     * @return
     */
    @PostMapping(value = "/update")
    public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
                               @RequestAttribute("user") User user) {

        Map<String, Object> vo = responseWrap.getJson();
        vo.put(update_id, user.getUserId());
        componentService.update(vo);
        return responseWrap;
    }

    /**
     * 查询组件信息
     */
    @GetMapping(value = "/getDetail/{componentId}")
    public ResponseWrap getDetail(@PathVariable String componentId) {

        ResponseWrap responseWrap = ResponseWrap.builder();
        responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
        Map<String, Object> row =componentService.getDetail(componentId);
        responseWrap.appendRow(row);
        return responseWrap;
    }



}
