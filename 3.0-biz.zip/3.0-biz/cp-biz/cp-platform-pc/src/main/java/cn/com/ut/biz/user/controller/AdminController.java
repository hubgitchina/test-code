package cn.com.ut.biz.user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.system.service.DictDataService;
import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.biz.user.service.AdminService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.restful.DictBuilder;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 系统管理员控制层 TODO 有待斟酌
 * 
 * @author lanbin
 * @since 2017/8/30
 */
@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;
	@Autowired
	private DictDataService dictDataService;

	/**
	 * 添加系统管理员用户,用户名和工号必须唯一
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parMap = responseWrap.getJson();
		parMap.put(BaseEntity.create_id, user.getUserId());
		String id = adminService.create(parMap);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);

		return responseWrap.appendRow(row);
	}

	/**
	 * 更新系统管理员
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parMap = responseWrap.getJson();
		parMap.put(BaseEntity.update_id, user.getUserId());
		adminService.update(parMap);
		return responseWrap;
	}

	/**
	 * 获取管理员详细信息
	 */
	@GetMapping("/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendRow(adminService.getDetailByUserId(null, id));
	}

	/**
	 * 获取系统管理员列表
	 */
	@GetMapping(value = "/find")
	public ResponseWrap find(@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendSortCondition(BaseEntity.create_time);
		pb.appendWhereCondition(UserManager.real_name);
		PageBean page = pb.buildSQL(pageMap);

		List<Map<String, Object>> rows = adminService.find(page, null);

		DictBuilder dictBuilder = DictBuilder.build().appendDict("is_locked", "IS_TRUE")
				.appendDict("is_del", "IS_TRUE");
		dictDataService.preDictHandle(rows, dictBuilder);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendPage(page).appendRows(rows);
	}

	/**
	 * 修改管理员密码
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/modifyAdminPwd")
	public ResponseWrap modifyAdminPwd(@RequestBody ResponseWrap responseWrap) {

		JSONObject vo = responseWrap.getJson();
		String adminUserId = vo.getString("user_id");
		String pwd = CommonUtil.encodeMD5(ConstantUtil.DEFAULT_ACCOUNT_PWD.getBytes());
		adminService.modifyAdminPwd(null, adminUserId, pwd);
		return ResponseWrap.builder();
	}

	/**
	 * 删除管理员
	 *
	 * @param id
	 * @return
	 */
	@DeleteMapping(value = "/delete/{id}")
	public ResponseWrap delete(@PathVariable String id) {

		adminService.delete(null, id);
		return ResponseWrap.builder();
	}
}
