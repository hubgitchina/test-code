package cn.com.ut.biz.user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.system.service.DictDataService;
import cn.com.ut.biz.user.entities.UserPVocation;
import cn.com.ut.biz.user.entities.UserParent;
import cn.com.ut.biz.user.entities.UserPeducation;
import cn.com.ut.biz.user.entities.UserPerson;
import cn.com.ut.biz.user.service.UserExpandService;
import cn.com.ut.biz.user.service.UserService;
import cn.com.ut.common.constant.platform.ConstantUtil;
import cn.com.ut.core.cache.CacheHelper;
import cn.com.ut.core.cache.session.SessionManagerImpl;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.restful.DictBuilder;
import cn.com.ut.core.restful.ResponseWrap;
import cn.com.ut.util.UserUtil;

/**
 * 用户控制层
 * 
 * @author: lanbin
 * @since: 2017年3月13日
 */
@RestController
@RequestMapping(value = "/user")
public class UserController {

	@Autowired
	private UserService userService;
	@Autowired
	private DictDataService dictDataService;

	@Autowired
	private CacheHelper cacheHelper;

	@Autowired
	private UserExpandService userExpandService;

	/**
	 * 列出指定用户拥有的用户组集合
	 * 
	 * @param pageMap
	 * @return
	 */
	@GetMapping(value = "/listUserRefGroups")
	public ResponseWrap listUserRefGroups(@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendSortCondition(BaseEntity.create_time);
		PageBean page = pb.buildSQL(pageMap);
		String userId = (String) pageMap.getFirst("user_id");
		List<Map<String, Object>> rows = userService.listUserRefGroups(page, userId);

		DictBuilder dictBuilder = DictBuilder.build().appendDict("group_type", "GROUP_TYPE")
				.appendDict("is_use", "IS_USE");
		dictDataService.preDictHandle(rows, dictBuilder);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendPage(page).appendRows(rows);
	}

	/**
	 * 列出指定用户拥有的用户组集合
	 * 
	 * @param pageMap
	 * @return
	 */
	@GetMapping(value = "/listUserRefRoles")
	public ResponseWrap listUserRefRoles(@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendSortCondition(BaseEntity.create_time);
		PageBean page = pb.buildSQL(pageMap);
		String userId = (String) pageMap.getFirst("user_id");
		List<Map<String, Object>> rows = userService.listUserRefRoles(page, userId);

		DictBuilder dictBuilder = DictBuilder.build().appendDict("role_type", "ROLE_TYPE")
				.appendDict("is_use", "IS_USE");
		dictDataService.preDictHandle(rows, dictBuilder);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendPage(page).appendRows(rows);
	}

	/**
	 * 手机号注册
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/registerByMobile")
	@ServiceComponent(session = false)
	public ResponseWrap registerByMobile(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("参数空");
		}
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		String id = userService.registerByMobile(vo);
		user.setUserId(id);
		userService.getLoginUserByUserId(user, ConstantUtil.LOGIN_TYPE.PC,
				new Long(ConstantUtil.SESSION_TIME.DEFAULT));
		Map<String, Object> map = new HashMap<>();
		map.put("user_name", user.getUserName());
		map.put("user_type", user.getUserType());
		map.put("user_id", user.getUserId());
		map.put("email", user.getEmail());
		map.put("mobile", user.getMobile());
		map.put("nick", user.getNick());
		map.put("email", user.getEmail());
		return ResponseWrap.builder().appendRow(map);
	}

	/**
	 * 根据用户名注册
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/registerByUserName")
	@ServiceComponent(session = false)
	public ResponseWrap registerByUserName(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("参数空");
		}
		vo.put("sessionId", user.getSessionId());
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		String id = userService.registerByUserName(vo);
		Map<String, Object> resMap = new HashMap<>();
		resMap.put("user_id", id);
		responseWrap.getResponseData().put("data", resMap);
		return responseWrap;
	}

	/**
	 * 修改用户名
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/updateUserName")
	public ResponseWrap updateUserName(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (responseWrap.getJson() == null
				|| CommonUtil.isEmpty(responseWrap.getJson().getString(UserParent.user_name))) {
			ExceptionUtil.throwValidateException("user_name 不能为空");
		}
		String userName = responseWrap.getJson().getString(UserParent.user_name);
		int tem = userService.updateUserName(user.getUserId(), userName);
		// 更新缓存
		if (tem > 0) {
			user.setUserName(userName);
			cacheHelper.replace(SessionManagerImpl.KEY_BEGIN_SESSION + user.getSessionId(), user);
			// sessionManager.addGlobalSession(user.getSessionId(), user);
		}
		return responseWrap;
	}

	/**
	 * 修改用户昵称
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/updateUserNick")
	public ResponseWrap updateUserNick(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (responseWrap.getJson() == null
				|| CommonUtil.isEmpty(responseWrap.getJson().getString(UserParent.nick_name))) {
			ExceptionUtil.throwValidateException("nick_name 不能为空");
		}
		String nickName = responseWrap.getJson().getString(UserParent.nick_name);
		int tem = userService.updateUserNick(user.getUserId(), nickName);
		// 更新缓存
		if (tem > 0) {
			user.setNick(nickName);
			cacheHelper.replace(SessionManagerImpl.KEY_BEGIN_SESSION + user.getSessionId(), user);
		}
		return responseWrap;
	}

	/**
	 * 获取用户列表
	 */
	@ServiceComponent(session = false)
	@GetMapping(value = "/findUser")
	public ResponseWrap findUser(@RequestParam MultiValueMap<String, Object> paramMap) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereConditions(UserParent.email, UserParent.user_name, UserParent.mobile,
				UserParent.nick_name, UserParent.user_type);
		pb.appendSortConditions(UserParent.create_time);
		PageBean page = pb.buildSQL(paramMap);
		List<Map<String, Object>> userList = userService.getUserList(page);
		responseWrap.appendPage(page);
		responseWrap.appendRows(userList);
		return responseWrap;
	}

	/**
	 * 修改密码
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/modifyPwd")
	public ResponseWrap modifyPwd(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能为空");
		}
		userService.modifyPwd(user.getUserId(), responseWrap.getJson());
		return responseWrap;
	}

	/**
	 * 忘记密码
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/forgetPwd")
	public ResponseWrap forgetPwd(@RequestBody ResponseWrap responseWrap) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能为空");
		}
		userService.forgetPwd(responseWrap.getJson());
		return responseWrap;
	}

	/**
	 * 修改手机
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/modifyMobile")
	public ResponseWrap modifyMobile(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能为空");
		}
		userService.modifyMobile(user, responseWrap.getJson());
		return responseWrap;
	}

	/**
	 * 绑定手机
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/bindMobile")
	public ResponseWrap bindMobile(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能为空");
		}
		userService.bindMobile(user, responseWrap.getJson());
		return responseWrap;
	}

	/**
	 * 根据用户名和密码登录
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/login")
	public ResponseWrap login(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		Map<String, Object> loginByPwd = responseWrap.getJson();
		userService.loginByPwd(user, loginByPwd, true);
		ResponseWrap reqponseWrap = ResponseWrap.builder();
		reqponseWrap.getResponseData().put("data", UserUtil.userToMap(user));
		return reqponseWrap;
	}

	/**
	 * 根据手机和验证码登录 用户不存在则注册
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/loginByMobile")
	public ResponseWrap loginByMobile(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		Map<String, Object> loginByMobileMap = responseWrap.getJson();
		userService.loginR(user, loginByMobileMap);
		ResponseWrap reqponseWrap = ResponseWrap.builder();
		reqponseWrap.getResponseData().put("data", UserUtil.userToMap(user));
		return reqponseWrap;
	}

	/**
	 * 注销登录
	 * 
	 * @param user
	 * @return
	 */
	@GetMapping(value = "/loginOut")
	public ResponseWrap loginOut(@RequestAttribute(value = "user") User user) {

		userService.loginOut(user.getSessionId());
		return ResponseWrap.builder();
	}

	/**
	 * 获取登录用户的信息
	 */
	@ServiceComponent(session = false)
	@GetMapping(value = "/getSession")
	public ResponseWrap getUserSession(@RequestAttribute(value = "user") User user) {

		ResponseWrap reqponseWrap = ResponseWrap.builder();
		reqponseWrap.getResponseData().put("data", UserUtil.userToMap(user));
		return reqponseWrap;
	}

	/**
	 * 获取用户信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@RequestMapping(value = "/getLoginUserInfo", method = RequestMethod.GET)
	@ServiceComponent(session = true)
	public ResponseWrap getUserInfo(@RequestAttribute(value = "user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> userMap = userService.getUserByUserId(user.getUserId());

		DictBuilder dictBuilder = DictBuilder.build().appendDict(UserParent.is_locked, "IS_TRUE")
				.appendDict(UserPerson.industry_nature, "CORP_TRADE")
				.appendDict(UserPerson.is_marital, "MARITAL_STATUS")
				.appendDict(UserPerson.education_level, "EDUCATION_LEVEL")
				.appendDict(UserPerson.monthly_income, "MONTHLY_INCOME");

		responseWrap.appendData(userMap, dictBuilder);
		return responseWrap;
	}

	/**
	 * 获取用户信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@RequestMapping(value = "/getUserInfoById/{id}", method = RequestMethod.GET)
	@ServiceComponent(session = true)
	public ResponseWrap getUserInfoById(@PathVariable(value = "id") String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();

		ValidatorUtil.requiredFieldMiss(new Object[] { id }, new String[] { id });
		Map<String, Object> userMap = userService.getUserByUserId(id);

		DictBuilder dictBuilder = DictBuilder.build().appendDict(UserParent.is_locked, "IS_TRUE")
				.appendDict(UserPerson.industry_nature, "CORP_TRADE")
				.appendDict(UserPerson.is_marital, "MARITAL_STATUS")
				.appendDict(UserPerson.education_level, "EDUCATION_LEVEL")
				.appendDict(UserPerson.monthly_income, "MONTHLY_INCOME");

		responseWrap.appendData(userMap, dictBuilder);
		return responseWrap;
	}

	/**
	 * 修改用户头像
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/updatePic")
	public ResponseWrap updatePic(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (responseWrap.getJson() == null
				|| CommonUtil.isEmpty(responseWrap.getJson().getString(UserPerson.user_pic))) {
			ExceptionUtil.throwValidateException("user_pic 不能为空");
		}
		String userPic = responseWrap.getJson().getString(UserPerson.user_pic);
		int tem = userExpandService.updateUserPic(user.getUserId(), userPic);
		// 更新缓存
		if (tem > 0) {
			user.setImage(userPic);
			cacheHelper.replace(SessionManagerImpl.KEY_BEGIN_SESSION + user.getSessionId(), user);
			// sessionManager.replaceAllSession(user.getSessionId(), user);
		}
		return responseWrap;
	}

	/**
	 * 修改用户基础信息生日和性别
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/updateUserPersion")
	public ResponseWrap updateUserPersion(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (responseWrap.getJson() == null) {
			ExceptionUtil.throwValidateException("请求参数 不能为空");
		}
		// 更新用户基础信息
		int tem = userExpandService.updateUserPersion(user.getUserId(), responseWrap.getJson());
		// 更新缓存
		if (tem > 0) {
			Map<String, Object> selfMap = user.getSelf();
			if (CollectionUtil.isEmptyMap(selfMap)) {
				selfMap = new HashMap<>();
				user.setSelf(selfMap);
			}
			selfMap.put(UserPerson.user_birthday,
					responseWrap.getJson().getString(UserPerson.user_birthday));
			selfMap.put(UserPerson.user_sex, responseWrap.getJson().getString(UserPerson.user_sex));
			cacheHelper.replace(SessionManagerImpl.KEY_BEGIN_SESSION + user.getSessionId(), user);
			// sessionManager.replaceAllSession(user.getSessionId(), user);
		}
		return responseWrap;
	}

	/**
	 * 获取登录用户教育信息
	 */
	@ServiceComponent(session = true)
	@GetMapping(value = "/findUserPEducation")
	public ResponseWrap findUserPEducation(@RequestAttribute(value = "user") User user) {

		List<Map<String, Object>> list = userExpandService.findUserPEducation(user.getUserId());
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.getResponseData().put("data", list);
		return responseWrap;
	}

	/**
	 * 添加用户教育经历
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/addUserPEducation")
	public ResponseWrap addUserPEducation(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能为空");
		}
		responseWrap.getJson().put(UserPeducation.user_id, user.getUserId());
		String id = userExpandService.addUserPEducation(responseWrap.getJson());
		Map<String, Object> res = new HashMap<>();
		res.put(BaseEntity.idx, id);
		responseWrap.getResponseData().put("data", res);
		return responseWrap;
	}

	/**
	 * 删除用户教育经历
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/delUserPEducation")
	public ResponseWrap delUserPEducation(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能为空");
		}
		String id = responseWrap.getJson().getString("id");
		userExpandService.delUserPEducation(id, user.getUserId());
		return responseWrap;
	}

	/**
	 * 获取登录用户工作经历
	 */
	@ServiceComponent(session = true)
	@GetMapping(value = "/findUserPVocation")
	public ResponseWrap findUserPVocation(@RequestAttribute(value = "user") User user) {

		List<Map<String, Object>> list = userExpandService.findUserPVocation(user.getUserId());
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.getResponseData().put("data", list);
		return responseWrap;
	}

	/**
	 * 添加用户工作经历
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/addUserPVocation")
	public ResponseWrap addUserPVocation(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能为空");
		}
		responseWrap.getJson().put(UserPVocation.user_id, user.getUserId());
		String id = userExpandService.addUserPVocation(responseWrap.getJson());
		Map<String, Object> res = new HashMap<>();
		res.put(BaseEntity.idx, id);
		responseWrap.getResponseData().put("data", res);
		return responseWrap;
	}

	/**
	 * 删除用户工作经历
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/delUserPVocation")
	public ResponseWrap delUserPVocation(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能为空");
		}
		String id = responseWrap.getJson().getString("id");
		userExpandService.delUserPVocation(id, user.getUserId());
		return responseWrap;
	}

	/**
	 * 修改用户个人信息
	 */
	@ServiceComponent(session = true)
	@PostMapping(value = "/updateUserPer")
	public ResponseWrap updateUserPer(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute(value = "user") User user) {

		if (CollectionUtil.isEmptyMap(responseWrap.getJson())) {
			ExceptionUtil.throwValidateException("请求参数不能空");
		}
		responseWrap.getJson().put(UserPerson.user_id, user.getUserId());
		userExpandService.updateUserPer(responseWrap.getJson());
		// 更新缓存
		return responseWrap;
	}

}
