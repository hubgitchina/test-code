package cn.com.ut.biz.developer.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.developer.entities.DevInfo;
import cn.com.ut.biz.developer.service.DevInfoService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 开发者信息控制层
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@RestController
@RequestMapping(value = "/devInfo")
public class DevInfoController {

	@Autowired
	private DevInfoService devInfoService;

	/**
	 * 添加开发者信息
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();

		vo.put(DevInfo.create_id, user.getUserId());
		String id = devInfoService.create(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 更新开发者信息
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(DevInfo.update_id, user.getUserId());
		String id = devInfoService.update(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 查询所有的开发者信息（带分页）
	 */
	@GetMapping(value = "/findAllPage")
	public ResponseWrap findAllPage(@RequestParam MultiValueMap<String, Object> pageMap) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		PageBuilder pb = PageBuilder.build();

		pb.appendWhereCondition(null, DevInfo.corp_name, EnumConstant.WhereCase.LIKE,
				EnumConstant.SqlType.STRING);
		pb.appendWhereCondition(null, DevInfo.status, EnumConstant.WhereCase.EQ,
				EnumConstant.SqlType.INT);
		pb.appendSortCondition(null, DevInfo.create_time, EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> resultList = devInfoService.findAllPage(page);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 查询开发者信息详情
	 */
	@GetMapping(value = "/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = devInfoService.getDetail(id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 删除开发者信息
	 */
	@DeleteMapping(value = "/delete/{id}")
	public ResponseWrap delete(@PathVariable String id) {

		devInfoService.delete(id);
		return ResponseWrap.builder();
	}

	/**
	 * 根据用户查询当前用户提交的企业审核信息
	 */
	@GetMapping(value = "/getDevInfoByUser")
	public ResponseWrap getDevInfoByUser(@RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = devInfoService.getDevInfoByUser(user);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 提交审核
	 */
	@PostMapping(value = "/submitExamine")
	public ResponseWrap submitExamine(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(DevInfo.update_id, user.getUserId());
		devInfoService.submitExamine(vo);
		return responseWrap;
	}

	/**
	 * 审核开发者提交的企业认证信息
	 */
	@PostMapping(value = "/examineDevInfo")
	public ResponseWrap examineDevInfo(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(DevInfo.audit_operator, user.getUserId());
		devInfoService.examineDevInfo(vo);
		return ResponseWrap.builder();
	}

	/**
	 * 确认修改审核资料
	 */
	@GetMapping(value = "/confirmUpdate/{id}")
	public ResponseWrap confirmUpdate(@PathVariable String id) {

		devInfoService.confirmUpdate(id);
		return ResponseWrap.builder();
	}

}
