package cn.com.ut.biz.business.template.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.business.entities.BizTemplate;
import cn.com.ut.biz.business.service.BizTemplateService;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 业务实例控制层
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@RestController
@RequestMapping(value = "/bizTemplate")
public class BizTemplateController {

	@Autowired
	private BizTemplateService bizTemplateService;

	/**
	 * 添加业务实例
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();

		vo.put(BizTemplate.create_id, user.getUserId());
		vo.put(BizTemplate.own_id, user.getUserId());
		String id = bizTemplateService.create(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 更新业务实例
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(BizTemplate.update_id, user.getUserId());
		String id = bizTemplateService.update(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 查询所有业务实例
	 */
	@GetMapping(value = "/findAll")
	public ResponseWrap findAll(@RequestParam MultiValueMap<String, Object> pageMap,
			@RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		String tmpType = TypeConvert.getStringValue(pageMap.getFirst(BizTemplate.tmp_type));
		List<Map<String, Object>> apiList = bizTemplateService.findAll(tmpType);
		responseWrap.appendRows(apiList);
		return responseWrap;
	}

	/**
	 * 根据用户信息查询所有业务实例及实例下所有实体
	 * 
	 * @param pageMap
	 * @param user
	 * @return
	 */
	@GetMapping(value = "/findTmpEntityByUser")
	public ResponseWrap findTmpEntityByUser(@RequestParam MultiValueMap<String, Object> pageMap,
			@RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		// String tmpType =
		// TypeConvert.getStringValue(pageMap.getFirst(BizTemplate.tmp_type));
		Map<String, Object> vo = new HashMap<>();
		vo.put(BizTemplate.create_id, user.getUserId());
		vo.put(BizTemplate.tmp_type, 0);
		List<Map<String, Object>> apiList = bizTemplateService.findTmpEntityByUser(vo);
		responseWrap.appendRows(apiList);
		return responseWrap;
	}

	/**
	 * 查询业务实例详情
	 */
	@GetMapping(value = "/getDetail/{templateId}")
	public ResponseWrap getDetail(@PathVariable String templateId) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		List<Map<String, Object>> rows = bizTemplateService.getDetail(templateId);
		responseWrap.appendRows(rows);
		return responseWrap;
	}

	/**
	 * 删除业务实例
	 */
	@DeleteMapping(value = "/delete/{templateId}")
	public ResponseWrap delete(@PathVariable String templateId) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		bizTemplateService.delete(templateId);
		return responseWrap;
	}

	/**
	 * 是否已存在同名业务实例
	 */
	@PostMapping(value = "/existTemplate")
	public ResponseWrap existTemplate(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		int checkResult = bizTemplateService.existTemplate(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("checkResult", checkResult);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 验证应用下是否已存在同名业务实例
	 */
	@PostMapping(value = "/existAppTemplate")
	public ResponseWrap existAppTemplate(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		int checkResult = bizTemplateService.existAppTemplate(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("checkResult", checkResult);
		responseWrap.appendRow(row);
		return responseWrap;
	}
}
