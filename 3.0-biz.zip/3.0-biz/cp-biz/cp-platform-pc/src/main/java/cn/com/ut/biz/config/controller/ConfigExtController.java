package cn.com.ut.biz.config.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.system.service.ConfigServiceRemote;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 系统配置管理（对外接口）
 * 
 * @author ouyuexing
 */
@RestController
@RequestMapping(value = "/ext/config")
public class ConfigExtController {

	@Autowired
	private ConfigServiceRemote configService;

	/**
	 * 获取系统配置(对外接口)
	 */
	@PostMapping(value = "/getConfigByCode")
	@ServiceComponent(session = false)
	public ResponseWrap getConfigByCode(@RequestBody ResponseWrap responseWrap) {

		JSONObject parJson = responseWrap.getJson();
		String configCode = parJson.getString("config_code");

		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		String value = configService.getConfigValueByCode(configCode);

		Map<String, Object> dataVo = new HashMap<>(1);
		dataVo.put("value", value);
		responseWrap.getResponseData().put("data", dataVo);
		return responseWrap;
	}

	/**
	 * 查询系统配置列表(对外接口)
	 */
	@PostMapping(value = "/find")
	@ServiceComponent(session = false)
	public ResponseWrap find(@RequestBody ResponseWrap responseWrap) {

		List<Map<String, Object>> itemList = configService.find(null);

		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.getResponseData().put("data", itemList);
		return responseWrap;
	}

}
