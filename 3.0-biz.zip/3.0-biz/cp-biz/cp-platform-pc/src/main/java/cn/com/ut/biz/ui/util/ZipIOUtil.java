package cn.com.ut.biz.ui.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.Map.Entry;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipIOUtil {

	public static void deleteFile(File file) {

		if (file.exists()) {// 判断文件是否存在
			if (file.isFile()) {// 判断是否是文件
				file.delete();// 删除文件
			} else if (file.isDirectory()) {// 否则如果它是一个目录
				File[] files = file.listFiles();// 声明目录下所有的文件 files[];
				for (int i = 0; i < files.length; i++) {// 遍历目录下所有的文件
					deleteFile(files[i]);// 把每个文件用这个方法进行迭代
				}
				file.delete();// 删除文件夹
			}
		}
	}

	public static void buildTemdir(String temdir) {

		File file = new File(temdir);
		if (!file.exists() && !file.isDirectory()) {
			file.mkdirs();
		} else {
			File[] files = file.listFiles();
			for (int i = 0; i < files.length; i++) {
				deleteFile(files[i]);
			}
		}
	}

	public static void zipOutput(OutputStream output, Map<String, byte[]> files)
			throws IOException {

		ZipOutputStream zos = new ZipOutputStream(output);
		BufferedOutputStream bos = new BufferedOutputStream(zos);

		for (Entry<String, byte[]> entry : files.entrySet()) {
			String fileName = entry.getKey(); // 每个zip文件名
			byte[] file = entry.getValue(); // 这个zip文件的字节

			BufferedInputStream bis = new BufferedInputStream(new ByteArrayInputStream(file));
			zos.putNextEntry(new ZipEntry(fileName));

			int len = 0;
			byte[] buf = new byte[10 * 1024];
			while ((len = bis.read(buf, 0, buf.length)) != -1) {
				bos.write(buf, 0, len);
			}
			bis.close();
			bos.flush();
		}
		bos.close();
	}

	public static void compress(File f, String baseDir, ZipOutputStream zos) {

		if (!f.exists()) {
			throw new RuntimeException("待压缩的文件目录或文件" + f.getName() + "不存在");
		}

		File[] fs = f.listFiles();
		BufferedInputStream bis = null;
		byte[] bufs = new byte[1024 * 10];
		FileInputStream fis = null;

		try {
			for (int i = 0; i < fs.length; i++) {
				String fName = fs[i].getName();
				if (fs[i].isFile()) {
					ZipEntry zipEntry = new ZipEntry(baseDir + fName);
					zos.putNextEntry(zipEntry);
					// 读取待压缩的文件并写进压缩包里
					fis = new FileInputStream(fs[i]);
					bis = new BufferedInputStream(fis, 1024 * 10);
					int read = 0;
					while ((read = bis.read(bufs, 0, 1024 * 10)) != -1) {
						zos.write(bufs, 0, read);
					}
					// 如果需要删除源文件，则需要执行下面语句
					// fis.close();
					// fs[i].delete();
				} else if (fs[i].isDirectory()) {
					if (fs[i].listFiles().length > 0) {
						compress(fs[i], baseDir + fName + File.separator, zos);
					} else { //支持空目录打包进ZIP
						ZipEntry zipEntry = new ZipEntry(baseDir + fName + File.separator);
						zos.putNextEntry(zipEntry);
					}
				}
			}
		} catch (IOException e) {

		} finally {
			// 关闭流
			try {
				if (bis != null)
					bis.close();

				if (fis != null)
					fis.close();

			} catch (IOException e) {

			}
		}

	}

}
