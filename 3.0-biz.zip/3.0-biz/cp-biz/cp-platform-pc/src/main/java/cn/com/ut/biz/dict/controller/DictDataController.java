package cn.com.ut.biz.dict.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.system.entities.DictData;
import cn.com.ut.biz.system.entities.DictType;
import cn.com.ut.biz.system.service.DictDataService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 字典项管理
 * 
 * @author ouyuexing·
 */
@RestController
@RequestMapping(value = "/dictData")
public class DictDataController {

	@Resource
	private DictDataService dictDataService;

	/**
	 * 创建数据字典项
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parVo = responseWrap.getJson();
		parVo.put(DictType.create_id, user.getUserId());
		String id = dictDataService.create(parVo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		return responseWrap.appendRow(row);
	}

	/**
	 * 更新数据字典项
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parVo = responseWrap.getJson();
		parVo.put(DictType.update_id, user.getUserId());
		String id = dictDataService.update(parVo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		return responseWrap.appendRow(row);
	}

	/**
	 * 查询字典内容详情
	 */
	@GetMapping(value = "/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		Map<String, Object> row = dictDataService.getDetail(id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 删除字典内容(标记删除)
	 */
	@DeleteMapping(value = "/delete/{id}")
	public ResponseWrap delete(@PathVariable String id, @RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		dictDataService.delMark(id, user.getUserId());
		return responseWrap;
	}

	/**
	 * 批量删除字典内容
	 * 
	 * @param responseWrap
	 *            ids
	 * @return
	 */
	@DeleteMapping(value = "/deleteAll")
	public ResponseWrap deleteAll(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		String ids = (String) vo.get("ids");
		String[] idArr = ids.split(",");
		dictDataService.delMark(idArr, user.getUserId());
		return responseWrap;
	}

	/**
	 * 查询指定字典类型下所有(包括启用和没有启用的)字典项
	 * 
	 * @param pageMap
	 *            字典类型 dict_type_id
	 * @return
	 */
	@GetMapping(value = "/findByDictTypeId")
	public ResponseWrap findDictDataByType(@RequestParam MultiValueMap<String, Object> pageMap) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition("sort_num", EnumConstant.SqlType.INT);
		pb.appendSortConditions(DictData.dict_code, DictData.dict_text);
		PageBean page = pb.buildSQL(pageMap);
		String dictTypeId = (String) pageMap.getFirst("dict_type_id");
		List<Map<String, Object>> row = dictDataService.findDictDataByType(dictTypeId, page);
		responseWrap.appendPage(page).appendRows(row);
		return responseWrap;
	}

	/**
	 * （其他模块使用）根据字典类型查询字典项
	 *
	 * @param dictType
	 * @return
	 */
	@GetMapping(value = "/findDictData/{dictType}")
	public ResponseWrap findDictData(@PathVariable("dictType") String dictType) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);

		List<Map<String, Object>> dictDataList = dictDataService.findDictData(dictType, null);
		responseWrap.appendRows(dictDataList);
		return responseWrap;
	}
}