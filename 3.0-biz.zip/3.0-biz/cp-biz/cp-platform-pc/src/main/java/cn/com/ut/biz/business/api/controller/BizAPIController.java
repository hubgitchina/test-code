package cn.com.ut.biz.business.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Maps;

import cn.com.ut.biz.business.entities.BizAPI;
import cn.com.ut.biz.business.service.BizAPIService;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 业务API控制层
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@RestController
@RequestMapping(value = "/bizAPI")
public class BizAPIController {

	@Autowired
	private BizAPIService bizAPIService;

	/**
	 * 添加业务API
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();

		vo.put(BizAPI.create_id, user.getUserId());
		String id = bizAPIService.create(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 更新业务API
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(BizAPI.update_id, user.getUserId());
		String id = bizAPIService.update(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 查询所有业务实体
	 */
	@GetMapping(value = "/findAllByEId")
	public ResponseWrap findAllByEId(@RequestParam MultiValueMap<String, Object> pageMap,
			@RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		String entityId = TypeConvert.getStringValue(pageMap.getFirst(BizAPI.entity_id));
		Map<String, Object> vo = Maps.newHashMapWithExpectedSize(1);
		vo.put(BizAPI.entity_id, entityId);
		List<Map<String, Object>> apiList = bizAPIService.findAllByEId(vo);
		responseWrap.appendRows(apiList);
		return responseWrap;
	}

	/**
	 * 查询业务API详情
	 */
	@GetMapping(value = "/getDetail/{apiId}")
	public ResponseWrap getDetail(@PathVariable String apiId) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = bizAPIService.getDetail(apiId);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 删除业务API
	 */
	@DeleteMapping(value = "/delete/{apiId}")
	public ResponseWrap delete(@PathVariable String apiId) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		bizAPIService.delete(apiId);
		return responseWrap;
	}
}
