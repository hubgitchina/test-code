package cn.com.ut.biz.dict.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.system.entities.DictData;
import cn.com.ut.biz.system.service.DictDataServiceRemote;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 数据字典（对外接口）
 * 
 * @author ouyuexing
 *
 */
@RestController
@RequestMapping(value = "/ext/dict")
public class DictExtController {

	@Autowired
	private DictDataServiceRemote dictDataService;

	/**
	 * 查询字典项
	 * 
	 * @param responseWrap
	 *            platform_code平台Code,dict_type字典类型
	 * @return
	 */
	@PostMapping(value = "/findDictData")
	@ServiceComponent(session = false)
	public ResponseWrap findDictData(@RequestBody ResponseWrap responseWrap) {

		JSONObject parJson = responseWrap.getJson();

		String dictType = parJson.getString(DictData.dict_type);
		List<Map<String, Object>> dictDataList = dictDataService.findDictDataExt(dictType);

		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.getResponseData().put("data", dictDataList);
		return responseWrap;
	}

	/**
	 * 查询多个字典项
	 *
	 * @param responseWrap
	 *            platform_code平台Code,dict_types字典类型(多个)
	 * @return
	 */
	@PostMapping(value = "/findDictDataByTypes")
	@ServiceComponent(session = false)
	public ResponseWrap findDictDataByTypes(@RequestBody ResponseWrap responseWrap) {

		JSONObject parJson = responseWrap.getJson();

		JSONArray dictTypes = parJson.getJSONArray("dict_types");
		List<Map<String, Object>> resultList = dictDataService.findDictDataExt(dictTypes);

		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.getResponseData().put("data", resultList);
		return responseWrap;
	}

	/**
	 * 查询平台所有字典类型下的字典项（对外接口）
	 * 
	 * @param responseWrap
	 *            platform_code
	 * @return
	 */
	@PostMapping(value = "/findAllDictData")
	@ServiceComponent(session = false)
	public ResponseWrap findAllDictData(@RequestBody ResponseWrap responseWrap) {

		List<Map<String, Object>> resultList = dictDataService.findDictDataExt();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.getResponseData().put("data", resultList);
		return responseWrap;
	}

}
