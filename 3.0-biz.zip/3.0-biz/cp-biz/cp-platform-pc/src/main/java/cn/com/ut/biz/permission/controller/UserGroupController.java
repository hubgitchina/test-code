package cn.com.ut.biz.permission.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.permission.entities.UserGroup;
import cn.com.ut.biz.permission.entities.UserGroupAndUser;
import cn.com.ut.biz.permission.service.UserGroupService;
import cn.com.ut.biz.system.service.DictDataService;
import cn.com.ut.biz.user.entities.UserManager;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.restful.DictBuilder;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 用户分组管理
 * 
 * @author lanbin
 * @since 2017/8/30
 */
@RestController
@RequestMapping("/userGroup")
public class UserGroupController {
	@Autowired
	private UserGroupService userGroupService;
	@Autowired
	private DictDataService dictDataService;

	/**
	 * 创建用户组
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parMap = responseWrap.getJson();
		parMap.put(UserGroup.create_id, user.getUserId());
		String id = userGroupService.create(responseWrap.getJson());
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		return responseWrap.appendRow(row);
	}

	/**
	 * 更新用户组
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parMap = responseWrap.getJson();
		parMap.put(UserGroup.update_id, user.getUserId());
		userGroupService.update(parMap);
		return responseWrap;
	}

	/**
	 * 删除用户组
	 * 
	 * @param id
	 * @return
	 */
	@DeleteMapping(value = "/delete/{id}")
	public ResponseWrap delete(@PathVariable String id) {

		userGroupService.delete(id);
		return ResponseWrap.builder();
	}

	/**
	 * 获取用户组详情
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping(value = "/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		Map<String, Object> row = userGroupService.getDetail(id);

		DictBuilder dictBuilder = DictBuilder.build().appendDict("group_class", "group_class")
				.appendDict("is_use", "IS_USE").appendDict("group_type", "group_type");
		dictDataService.preDictHandle(row, dictBuilder);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendRow(row);
	}

	/**
	 * 查询用户组列表
	 * 
	 * @param pageMap
	 * @return
	 */
	@GetMapping(value = "/find")
	public ResponseWrap find(@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendSortCondition(UserGroup.create_time);
		pb.appendWhereCondition(UserGroup.group_name);
		pb.appendWhereCondition(UserGroup.group_note);
		pb.appendWhereCondition(UserGroup.group_type);
		pb.appendWhereCondition(UserGroup.is_use);
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> rows = userGroupService.find(page);

		DictBuilder dictBuilder = DictBuilder.build().appendDict("group_class", "GROUP_CLASS")
				.appendDict("group_type", "GROUP_TYPE").appendDict("is_use", "IS_USE");
		dictDataService.preDictHandle(rows, dictBuilder);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendPage(page).appendRows(rows);
	}

	/**
	 * 列出用户组已关联的用户
	 * 
	 * @param pageMap
	 *            包含GROUP_ID
	 */
	@GetMapping(value = "/listRefUsers")
	public ResponseWrap listRefUsers(@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendWhereConditions(UserManager.real_name, UserManager.work_number);
		PageBean page = pb.buildSQL(pageMap);
		String groupId = (String) pageMap.getFirst("group_id");
		List<Map<String, Object>> rows = userGroupService.listRefUsers(page, groupId);
		DictBuilder dictBuilder = DictBuilder.build().appendDict("user_type", "USER_LOGIN_TYPE");
		dictDataService.preDictHandle(rows, dictBuilder);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.appendPage(page).appendRows(rows);
		return responseWrap;
	}

	/**
	 * 列出用户组未关联的用户
	 * 
	 * @param pageMap
	 *            包含GROUP_ID
	 */
	@GetMapping(value = "/listNoRefUsers")
	public ResponseWrap listNoRefUsers(@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition("um", "email", EnumConstant.WhereCase.EQ,
				EnumConstant.SqlType.STRING);
		pb.appendWhereCondition("um", "mobile", EnumConstant.WhereCase.EQ,
				EnumConstant.SqlType.STRING);
		PageBean page = pb.buildSQL(pageMap);
		String groupId = (String) pageMap.getFirst("group_id");
		List<Map<String, Object>> rows = userGroupService.listNoRefUsers(page, groupId);

		DictBuilder dictBuilder = DictBuilder.build().appendDict("user_type", "USER_LOGIN_TYPE");
		dictDataService.preDictHandle(rows, dictBuilder);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.appendPage(page).appendRows(rows);
		return responseWrap;
	}

	/**
	 * 根据USER_ID查询该用户所属的用户组
	 * 
	 * @param pageMap
	 * @param user
	 * @return
	 */
	@GetMapping(value = "/findGroupsByUserId")
	public ResponseWrap findGroupsByUserId(@RequestParam MultiValueMap<String, Object> pageMap,
			@RequestAttribute("user") User user) {

		PageBuilder pb = PageBuilder.build();
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> rows = userGroupService.findGroupsByUserId(user.getUserId(),
				page);
		DictBuilder dictBuilder = DictBuilder.build().appendDict("group_type", "GROUP_TYPE");
		dictDataService.preDictHandle(rows, dictBuilder);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendPage(page).appendRows(rows);
	}

	/**
	 * 对用户组添加用户
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/addUsers")
	public ResponseWrap addUsers(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> map = responseWrap.getJson();
		String groupId = (String) map.get(UserGroupAndUser.group_id);
		String userIds = (String) map.get("user_ids");
		List<String> users = CollectionUtil.splitStr2List(userIds, ",", true);
		userGroupService.addUsers(groupId, users, user.getUserId());
		return responseWrap;
	}

	/**
	 * 对用户组移除用户
	 * 
	 * @param responseWrap
	 * @return
	 */
	@DeleteMapping(value = "/removeUsers")
	public ResponseWrap removeUsers(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> map = responseWrap.getJson();
		String groupId = (String) map.get(UserGroupAndUser.group_id);
		String userIds = (String) map.get("user_ids");
		List<String> users = CollectionUtil.splitStr2List(userIds, ",", true);
		userGroupService.removeUsers(groupId, users);
		return responseWrap;
	}

}
