package cn.com.ut.biz.permission.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.permission.entities.Menu;
import cn.com.ut.biz.permission.service.MenuService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 菜单管理
 * 
 * @author lanbin
 * @since 2017/8/31
 */
@RestController
@RequestMapping("/menu")
public class MenuController {
	@Autowired
	private MenuService menuService;

	/**
	 * 菜单管理查询所有菜单（分页、不分级）
	 * 
	 * @param pageMap
	 * @returna
	 */
	@GetMapping(value = "/queryAllBackgroundMenu")
	public ResponseWrap queryAllBackgroundMenu(
			@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendWhereConditions(Menu.menu_comment, Menu.menu_url, Menu.menu_text);
		pb.appendSortCondition(Menu.create_time);
		PageBean page = pb.buildSQL(pageMap);

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		List<Map<String, Object>> rows = menuService.queryAllBackgroundMenu(page);
		return responseWrap.appendPage(page).appendRows(rows);
	}

	/**
	 * 菜单管理查询所有菜单（分页、分级）
	 * 
	 * @param pageMap
	 *            包含PARENT_ID，可以为空
	 * @return
	 */
	@GetMapping(value = "/queryBackgroundMenu")
	public ResponseWrap queryBackgroundMenu(@RequestParam MultiValueMap<String, Object> pageMap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition(Menu.menu_comment.toLowerCase());
		PageBean page = pb.buildSQL(pageMap);
		String parentId = (String) pageMap.getFirst("parent_id");
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendPage(page)
				.appendRows(menuService.queryBackgroundMenu(parentId, page));
	}

	/**
	 * 创建系统菜单
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parMap = responseWrap.getJson();
		parMap.put(Menu.create_id, user.getUserId());
		String id = menuService.create(parMap);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		return responseWrap.appendRow(row);
	}

	/**
	 * 更新指定的系统菜单
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parMap = responseWrap.getJson();
		parMap.put(Menu.update_id, user.getUserId());
		menuService.update(parMap);
		return responseWrap;
	}

	/**
	 * 获取指定的系统菜单的详细信息
	 * 
	 * @param id
	 * @return
	 */
	@GetMapping("/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendRow(menuService.getDetail(id));
	}

	/**
	 * 删除指定的系统菜单
	 * 
	 * @param id
	 * @return
	 */
	@DeleteMapping(value = "/delete/{id}")
	public ResponseWrap delete(@PathVariable String id) {

		menuService.delete(id);
		return ResponseWrap.builder();
	}

	/**
	 * 设置同一级菜单的默认排序
	 * 
	 * @return
	 */
	@PostMapping(value = "/updateMenuSortDefault")
	public ResponseWrap updateMenuSortDefault() {

		menuService.updateMenuSortDefault();
		return ResponseWrap.builder();
	}

	/**
	 * 树型展示全部系统菜单
	 * 
	 * @param roleId
	 * @return
	 */
	@GetMapping("/listMenus")
	public ResponseWrap listMenus(@RequestParam("role_id") String roleId) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		return responseWrap.appendRows(menuService.listMenuTree(roleId));
	}

}