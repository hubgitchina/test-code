package cn.com.ut;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

import cn.com.ut.config.thirdlogin.QQLoginModule;
import cn.com.ut.config.thirdlogin.SinaLoginModule;
import cn.com.ut.config.thirdlogin.WechatLoginModule;

//@EnableDiscoveryClient
@Configuration
@ComponentScan
@EnableConfigurationProperties({ QQLoginModule.class, WechatLoginModule.class,
		SinaLoginModule.class })
@PropertySource({ "classpath:/cn/com/ut/config/properties/database.properties",
		"classpath:/cn/com/ut/config/properties/constant.properties" })
@ImportResource({ "classpath:/cn/com/ut/config/datasource/tm-ctx.xml" })
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class Application extends BaseApplication {

	public static void main(String[] args) {

		SpringApplication application = new SpringApplication(Application.class);
		application.setBannerMode(Banner.Mode.OFF);
		application.run(args);
	}
}
