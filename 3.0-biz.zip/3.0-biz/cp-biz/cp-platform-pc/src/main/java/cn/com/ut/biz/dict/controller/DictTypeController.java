package cn.com.ut.biz.dict.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.system.entities.DictType;
import cn.com.ut.biz.system.service.DictTypeService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.restful.DictBuilder;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 字典类型
 * 
 * @author lanbin
 */
@RestController
@RequestMapping(value = "/dictType")
public class DictTypeController {

	@Autowired
	private DictTypeService dictTypeService;

	/**
	 * 创建字典类型
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		String userId = user.getUserId();
		Map<String, Object> parVo = responseWrap.getJson();
		parVo.put(DictType.create_id, userId);
		String id = dictTypeService.create(responseWrap.getJson());

		Map<String, Object> row = new HashMap<>();
		row.put(BaseEntity.idx, id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 更新字典类型
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> parVo = responseWrap.getJson();
		String userId = user.getUserId();
		parVo.put(DictType.update_id, userId);
		String id = dictTypeService.update(parVo);
		Map<String, Object> row = new HashMap<>();
		row.put(BaseEntity.idx, id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 查询字典类型列表
	 */
	@GetMapping(value = "/find")
	public ResponseWrap find(@RequestParam MultiValueMap<String, Object> mapPage) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereConditions(DictType.dicttype_code, DictType.dicttype_text);
		pb.appendSortConditions(DictType.dicttype_code, DictType.group_code,
				"biz." + DictType.create_time);
		PageBean page = pb.buildSQL(mapPage);

		List<Map<String, Object>> rows = dictTypeService.find(page);
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.appendPage(page).appendRows(rows, DictBuilder.build()
				.appendDict(DictType.is_use, "IS_TRUE").appendDict(DictType.is_del, "IS_TRUE"));
		return responseWrap;
	}

	/**
	 * 查询字典类型详情
	 */
	@GetMapping(value = "/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = dictTypeService.getDetail(id);
		responseWrap.setUpperLowerCase(EnumConstant.UpperLowerCase.LOWER);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 删除字典类型
	 */
	@DeleteMapping("/delete/{id}")
	public ResponseWrap delete(@PathVariable String id, @RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		dictTypeService.delMark(id, user.getUserId());
		return responseWrap;
	}
}
