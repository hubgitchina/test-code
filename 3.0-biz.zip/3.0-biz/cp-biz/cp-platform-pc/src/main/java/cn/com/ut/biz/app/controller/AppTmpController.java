package cn.com.ut.biz.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.app.entities.AppInfo;
import cn.com.ut.biz.app.entities.AppTmp;
import cn.com.ut.biz.app.service.AppTmpService;
import cn.com.ut.biz.business.entities.BizTemplate;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 应用与业务模板控制层
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@RestController
@RequestMapping(value = "/appTmp")
public class AppTmpController {

	@Autowired
	private AppTmpService appTmpService;

	/**
	 * 自定义创建应用下的实例
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();

		vo.put(BizTemplate.create_id, user.getUserId());
		vo.put(BizTemplate.own_id, user.getUserId());
		String id = appTmpService.create(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 通过模板创建应用下的实例
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/createByTemplate")
	public ResponseWrap createByTemplate(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();

		vo.put(BizTemplate.tmp_type, 1);
		vo.put(BizTemplate.create_id, user.getUserId());
		vo.put(BizTemplate.own_id, user.getUserId());
		String id = appTmpService.createAppTmp(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 更新应用下的模板信息
	 * 
	 * @param responseWrap
	 * @param user
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		vo.put(AppInfo.update_id, user.getUserId());
		String id = appTmpService.update(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 查询应用所有业务模板
	 */
	@GetMapping(value = "/findTmpByAppId")
	public ResponseWrap findTmpByAppId(@RequestParam MultiValueMap<String, Object> pageMap,
			@RequestAttribute("user") User user) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		String appId = TypeConvert.getStringValue(pageMap.getFirst(AppTmp.app_id));
		List<Map<String, Object>> apiList = appTmpService.findTmpByAppId(appId);
		responseWrap.appendRows(apiList);
		return responseWrap;
	}

	/**
	 * 查询应用下模板详情
	 */
	@GetMapping(value = "/getDetail/{id}")
	public ResponseWrap getDetail(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		Map<String, Object> row = appTmpService.getDetail(id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 删除应用下的模板
	 */
	@DeleteMapping(value = "/delete/{id}")
	public ResponseWrap delete(@PathVariable String id) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		appTmpService.delete(id);
		return responseWrap;
	}
}
