package cn.com.ut.biz.user.service.impl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.restful.httpclient.RestHttpClient;
import cn.com.ut.biz.user.service.UserRemoteService;
import cn.com.ut.constant.api.ConstantUtil;

@Service
public class UserRemoteServiceImpl implements UserRemoteService {

	@Autowired
	private RestHttpClient restHttpClient;

	@Override
	public User getUser(User user) {

		if (user == null || CommonUtil.isEmpty(user.getUserId())) {
			return user;
		}
		return setUserByMap(user);
	}

	@Override
	public Map<String, Object> getUserMap(String userId) {

		Map<String, Object> parMap = new HashMap<>();
		parMap.put("user_id", userId);
		JSONObject userJB = restHttpClient.exchangePostForEntity(parMap,
				ConstantUtil.RPC_PROJRCT.USERCENTER, ConstantUtil.API_USERCENTER.GETUSERINFO);

		if (userJB == null || userJB.getJSONObject("data") == null) {
			return null;
		}
		return userJB.getJSONObject("data");
	}

	@Override
	public List<Map<String, Object>> getUserName(Collection<String> userIds) {

		Map<String, Object> parMap = new HashMap<>();
		parMap.put("userids", userIds);
		JSONObject userJB = restHttpClient.exchangePostForEntity(parMap,
				ConstantUtil.RPC_PROJRCT.USERCENTER, ConstantUtil.API_USERCENTER.GET_USER_NAME);

		if (userJB == null || userJB.getJSONArray("data") == null) {
			return null;
		}
		JSONArray jarr = userJB.getJSONArray("data");
		return new ArrayList(jarr);
	}

	/**
	 * 把map数据设置到用户信息中
	 * 
	 * @param user
	 * @param userMap
	 */
	private User setUserByMap(User user) {

		Map<String, Object> userMap = getUserMap(user.getUserId());
		if (CollectionUtil.isEmptyMap(userMap)) {
			return user;
		}
		user.setEmail((String) userMap.get("email"));
		user.setNick((String) userMap.get("nick_name"));
		user.setUserName((String) userMap.get("user_name"));
		user.setMobile((String) userMap.get("mobile"));
		user.setUserId((String) userMap.get("user_id"));
		user.setUserType((String) userMap.get("user_type"));
		user.setImage((String) userMap.get("user_pic"));
		return user;
	}
}
