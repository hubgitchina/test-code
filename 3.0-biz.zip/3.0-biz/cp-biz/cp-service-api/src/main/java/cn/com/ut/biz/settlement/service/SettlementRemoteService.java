package cn.com.ut.biz.settlement.service;

import java.util.Map;

public interface SettlementRemoteService {

	/**
	 * 标记结算规则已使用
	 * 
	 * @param ruleId
	 */
	void signRuleInUse(String ruleId);

	/**
	 * 提交交易传播链信息
	 * 
	 * @param vo
	 */
	void submitTradeShare(Map<String, Object> vo);

}
