package cn.com.ut.biz.settlement.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.settlement.service.SettlementRemoteService;
import cn.com.ut.constant.api.ConstantUtil;
import cn.com.ut.core.restful.httpclient.RestHttpClient;

@Service
public class SettlementRemoteServiceImpl implements SettlementRemoteService {

	@Autowired
	private RestHttpClient restHttpClient;

	/**
	 * 标记结算规则已使用
	 */
	@Override
	public void signRuleInUse(String ruleId) {

		Map<String, Object> parMap = new HashMap<>();
		parMap.put("rule_id", ruleId);
		restHttpClient.exchangePostForEntity(parMap, ConstantUtil.RPC_PROJRCT.SETTLEMENTRULE,
				ConstantUtil.API_SETTLEMENTRULE.MARKUP_CHECKOUT_RULE);
	}

	/**
	 * 提交交易传播链信息
	 */
	@Override
	public void submitTradeShare(Map<String, Object> vo) {

		restHttpClient.exchangePostForEntity(vo, ConstantUtil.RPC_PROJRCT.SETTLEMENTRULE,
				ConstantUtil.API_SETTLEMENTRULE.SUBMIT_TRADE_SHARE_CHAIN);
	}

}
