package cn.com.ut.constant.api;

/**
 * 常量工具类
 * 
 * @author wuxiaohua
 * @since 2013-10-10
 * @update 2015-12-4
 *
 */
public class ConstantUtil {

	/**
	 * 其他标识:Y
	 */
	public static final String FLAG_YES = "Y";
	/**
	 * 其他标识:N
	 */
	public static final String FLAG_NO = "N";

	/**
	 * project远程项目
	 */
	public interface RPC_PROJRCT {
		/**
		 * 用户中心服务
		 */
		String USERCENTER = "rpc.project.usercenter";

		/**
		 * 基础数据服务中心
		 */
		String BASEDATA = "rpc.project.basedata";

		/**
		 * 结算规则服务
		 */
		String SETTLEMENTRULE = "rpc.project.settlementrule";

		/**
		 * 第三方支付服务
		 */
		String THIRDPAY = "rpc.project.thirdpay";

		/**
		 * 传播链服务
		 */
		String TRANSMISSIONCHAIN = "rpc.project.transmissionchain";

		/**
		 * 流程定制服务
		 */
		String CUSTOMFLOW = "rpc.project.customflow";

		/**
		 * 商业服务平台
		 */
		String COMMERCE = "rpc.project.commerce";

		/**
		 * 编译器服务
		 */
		String COMPLIPE = "rpc.project.complipe";
	}

	/**
	 * 用户信息服务的API
	 */
	public interface API_USERCENTER {

		/**
		 * 解析token
		 */
		String ANATOKEN = "/user/anaToken";

		/**
		 * 获取用户信息
		 */
		String GETUSERINFO = "/user/getUserInfo";

		/**
		 * 获取手机验证码
		 */
		String MOBILEVER = "/verification/mobilever";

		/**
		 * 手机号登录
		 */
		String LOGINBYMOBILE = "/user/loginByMobile";

		/**
		 * 根据多个用户ID获取用户名
		 */
		String GET_USER_NAME = "/user/getUserName";
	}

	/**
	 * 编译器服务
	 */
	public interface API_COMPLIPE {

		/**
		 * 编译菜谱
		 */
		String COMPILERECIPE = "";

	}

	/**
	 * 商业服务平台
	 */
	public interface API_COMMERCE {

		/**
		 * 商品上架
		 */
		String ONSALEGOODS = "/goods/createGoods";

		/**
		 * 获取商品信息
		 */
		String GETGOODSINFO = "/goods/getGoodsInfo";

		/**
		 * 获取订单信息
		 */
		String GETORDERDETAIL = "/order/getOrderDetail";

		/**
		 * 生成订单
		 */
		String CREATEORDER = "/order/createOrder";

		/**
		 * 获取有价信息体id
		 */
		String CREATEVALUABLEINFO = "/valuableinfo/createValuableinfo";

		/**
		 * 获取商品的传播路径
		 */
		String FIND_GOODS_SHARE_CHAIN = "/shareChain/findGoodsShareChain";

		/**
		 * 获取商品结算规则
		 */
		String GETCHECKOUTRULE = "/entityinfo/getCheckoutRule";

		/**
		 * 设置商品的结算规则
		 */
		String BINDCHECKOUTRULE = "/entityinfo/bindCheckoutRule";

		/**
		 * 获取商品的订单列表
		 */
		String QUERYORDERBYGOODID = "/order/queryOrder";

		/**
		 * 查看订单分成信息
		 */
		String GETORDERSHARINGINFO = "/sharinginfo/getOrderSharinginfo";

		/**
		 * 支付成功修改订单状态
		 */
		String PAYSUCCESSUPDATEORDER = "";

		/**
		 * 退款成功修改订单状态
		 */
		String REFUNDSUCCESSUPDATEORDER = "";
	}

	/**
	 * 流程定制服务平台
	 */
	public interface API_CUSTOMFLOW {
		/**
		 * 获取条件流程和结果流程
		 */
		String GET_WORK_FLOW_NODE = "/demo/getWorkFlowNode";
		/**
		 * 获取当前定制流程
		 */
		String GET_CURRENT_WORK_FLOW = "/demo/getCurrentWorkFlow";
		/**
		 * 保存定制流程
		 */
		String SAVE_WORK_FLOW = "/demo/saveWorkFlow";
		/**
		 * 编译定制流程
		 */
		String COMPILE_WORK_FLOW = "/demo/compileWorkFlow";
		/**
		 * 设置定制流程
		 */
		String SET_WORK_FLOW = "/demo/setWorkFlow";
		/**
		 * 根据流程事件跳转
		 */
		String GET_NEXT_WORK_FLOW = "/demo/getNextWorkFlow";
	}

	/**
	 * 传播链服务
	 */
	public interface API_TRANSMISSIONCHAIN {

		/**
		 * 记录分享路径
		 */
		String GET_SPREAD_RESOURCE_URI = "";

		/**
		 * 拉取分享路径
		 */
		String PULL_SHARE_CHAIN = "/spread/getRecord";
	}

	/**
	 * 第三方支付
	 */
	public interface API_THIRDPAY {

		/**
		 * 微信APP支付
		 */
		String WECHATAPPPAY = "";
	}

	/**
	 * 结算规则服务
	 */
	public interface API_SETTLEMENTRULE {

		/**
		 * 获取可用的结算规则列表
		 */
		String GETBALANCERULES = "";

		/**
		 * 创建结算规则
		 */
		String CREATEBALANCERULE = "";

		/**
		 * 标记结算规则已使用
		 */
		String MARKUP_CHECKOUT_RULE = "";
		/**
		 * 提交交易传播链信息
		 */
		String SUBMIT_TRADE_SHARE_CHAIN = "/SettlementRule/Run";
	}

	public interface APPKEY_VALUE {

		/**
		 * 传播链平台APP_ID
		 */
		String TRANSMISSIONCHAIN_APPID = "transmissionchain.appid";

		/**
		 * 传播链平台APP_KEY
		 */
		String TRANSMISSIONCHAIN_KEY = "transmissionchain.key";
	}

}
