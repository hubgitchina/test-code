package cn.com.ut.biz.user.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cn.com.ut.core.common.system.beans.User;

public interface UserRemoteService {

	/**
	 * 获取用户信息
	 * 
	 * @param userId
	 * @return
	 */
	User getUser(User user);

	/**
	 * 获取用户信息
	 * 
	 * @param userId
	 * @return
	 */
	Map<String, Object> getUserMap(String userId);

	/**
	 * 根据多个用户ID获取用户名
	 * @param userIds
	 * @return
	 */
	List<Map<String,Object>> getUserName(Collection<String> userIds);

}
