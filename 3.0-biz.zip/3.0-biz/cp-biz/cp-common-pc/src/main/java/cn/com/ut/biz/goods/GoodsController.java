package cn.com.ut.biz.goods;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.biz.goods.service.GoodsAttrIndexService;
import cn.com.ut.biz.goods.service.GoodsService;
import cn.com.ut.biz.goods.service.GoodsSpecService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 商品信息控制层
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@RestController
@RequestMapping(value = "/goods")
public class GoodsController {

	@Autowired
	private GoodsService goodsService;

	@Autowired
	private GoodsSpecService goodsSpecService;

	@Autowired
	private GoodsAttrIndexService goodsAttrIndexService;

	/**
	 * 添加商品信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/addGoods")
	public ResponseWrap addGoods(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();

		String id = goodsService.addGoods(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 更新商品信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/updateGoods")
	public ResponseWrap updateGoods(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		goodsService.updateGoods(vo);
		return responseWrap;
	}

	/**
	 * 查询商品详情
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/getGoods")
	public ResponseWrap getGoods(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> row = goodsService.getGoods(vo);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 根据店铺ID查询商品信息列表（带分页）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/queryStoreGoods")
	public ResponseWrap queryStoreGoods(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();

		ValidatorUtil.validateMapContainsKey(vo, "pageno", "pagesize", "store_id");

		PageBuilder pb = PageBuilder.build();

		pb.appendWhereCondition("g", Goods.goods_name, EnumConstant.WhereCase.LIKE,
				EnumConstant.SqlType.STRING);
		pb.appendSortCondition("g", "update_time", EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(vo);
		List<Map<String, Object>> resultList = goodsService.queryStoreGoods(page, vo);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 查询商城全部商品（带分页）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/queryMallGoods")
	public ResponseWrap queryMallGoods(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();

		ValidatorUtil.validateMapContainsKey(vo, "pageno", "pagesize");

		PageBuilder pb = PageBuilder.build();

		// pb.appendWhereCondition(null, GoodsAttribute.attr_show,
		// EnumConstant.WhereCase.EQ,
		// EnumConstant.SqlType.STRING);
		pb.appendSortCondition(null, "g.create_time", EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(vo);
		List<Map<String, Object>> resultList = goodsService.queryMallGoods(page);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 更新商品上下架状态
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/updateGoodsState")
	public ResponseWrap updateGoodsState(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		goodsService.updateGoodsState(vo);
		return responseWrap;
	}

	/**
	 * 更新商品详情页内容
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/updateGoodsContent")
	public ResponseWrap updateGoodsContent(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		goodsService.updateGoodsContent(vo);
		return responseWrap;
	}

	/**
	 * 获取商品详情页内容
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/getGoodsContent")
	public ResponseWrap getGoodsContent(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> row = goodsService.getGoodsContent(vo);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 更新商品关联规格信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/updateGoodsSpec")
	public ResponseWrap updateGoodsSpec(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		goodsSpecService.updateGoodsSpec(vo);
		return responseWrap;
	}

	/**
	 * 更新商品关联属性
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/updateGoodsAttr")
	public ResponseWrap updateGoodsAttr(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		goodsAttrIndexService.updateGoodsAttr(vo);
		return responseWrap;
	}

	/**
	 * 获取商品关联属性
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/queryGoodsAttr")
	public ResponseWrap queryGoodsAttr(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		List<Map<String, Object>> rows = goodsAttrIndexService.queryGoodsAttr(vo);
		Map<String, Object> attr = new HashMap<>();
		attr.put("attr", rows);
		responseWrap.appendData(attr);
		return responseWrap;
	}

	/**
	 * 查询商品所有规格和规格值
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/queryAllGoodsSpec")
	public ResponseWrap queryAllGoodsSpec(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		List<Map<String, Object>> rows = goodsService.queryAllGoodsSpec(vo);
		Map<String, Object> spec = new HashMap<>();
		spec.put("goods_spec", rows);
		responseWrap.appendData(spec);
		return responseWrap;
	}

	/**
	 * 查询商品详情页（消费者查看）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/getGoodsDetail")
	public ResponseWrap getGoodsDetail(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> row = goodsService.getGoodsDetail(vo);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 商品搜索（商城首页）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/queryIndex")
	public ResponseWrap queryIndex(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		ValidatorUtil.validateMapContainsKey(vo, "pageno", "pagesize");
		PageBuilder pb = PageBuilder.build();
		PageBean page = pb.buildSQL(vo);
		List<Map<String, Object>> rows = goodsService.queryIndex(page, vo);
		responseWrap.appendPage(page).appendData(rows);
		return responseWrap;
	}

	/**
	 * 店铺商品查询（消费者在店铺搜索商品）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/queryGoodsInStore")
	public ResponseWrap queryGoodsInStore(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		ValidatorUtil.validateMapContainsKey(vo, "pageno", "pagesize", "store_id");
		PageBuilder pb = PageBuilder.build();
		PageBean page = pb.buildSQL(vo);
		List<Map<String, Object>> rows = goodsService.queryGoodsInStore(page, vo);
		responseWrap.appendPage(page).appendData(rows);
		return responseWrap;
	}
}