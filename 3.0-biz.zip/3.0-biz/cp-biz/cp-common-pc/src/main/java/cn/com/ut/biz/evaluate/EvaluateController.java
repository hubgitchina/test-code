package cn.com.ut.biz.evaluate;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.evaluate.service.EvaluateGoodsService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 信誉评价控制层
 * 
 * @author wangpeng1
 * @since 2018年6月4日
 */
@RestController
@RequestMapping(value = "/evaluate")
public class EvaluateController {

	@Autowired
	private EvaluateGoodsService evaluateGoodsService;

	/**
	 * 提交商品评价和店铺评价
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/submit")
	public ResponseWrap submit(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		responseWrap.appendData(evaluateGoodsService.submit(vo));
		return responseWrap;
	}

	/**
	 * 上传晒单图片
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/uploadImages")
	public ResponseWrap uploadImages(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		evaluateGoodsService.uploadImages(vo);
		return responseWrap;
	}

	/**
	 * 商家解释商品评价
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/explain")
	public ResponseWrap explain(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		evaluateGoodsService.explain(vo);
		return responseWrap;
	}

	/**
	 * 买家查询商品评价列表（带分页）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/queryByBuyer")
	public ResponseWrap queryByBuyer(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		return evaluateGoodsService.queryByBuyer(vo, responseWrap);
	}

	/**
	 * 商家查询商品评价列表（带分页）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/queryBySeller")
	public ResponseWrap queryBySeller(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		return evaluateGoodsService.queryBySeller(vo, responseWrap);
	}
}