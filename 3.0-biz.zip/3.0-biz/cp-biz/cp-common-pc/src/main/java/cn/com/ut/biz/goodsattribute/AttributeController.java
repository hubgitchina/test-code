package cn.com.ut.biz.goodsattribute;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.goodsattribute.entities.Attribute;
import cn.com.ut.biz.goodsattribute.service.AttributeService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 商品属性控制层
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@RestController
@RequestMapping(value = "/goodsAttr")
public class AttributeController {

	@Autowired
	private AttributeService attributeService;

	/**
	 * 添加商品属性
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();

		String id = attributeService.create(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 更新商品属性
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		String id = attributeService.update(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 查询所有的商品属性（带分页）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/findAllPage")
	public ResponseWrap findAllPage(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();

		ValidatorUtil.validateMapContainsKey(vo, "pageno", "pagesize");

		MultiValueMap<String, Object> pageMap = new LinkedMultiValueMap<>();

		pageMap.setAll(vo);

		PageBuilder pb = PageBuilder.build();

		pb.appendWhereCondition(null, Attribute.attr_show, EnumConstant.WhereCase.EQ,
				EnumConstant.SqlType.STRING);
		pb.appendSortCondition(null, Attribute.create_time, EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> resultList = attributeService.findAllPage(page);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 查询商品属性详情
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/getDetail")
	public ResponseWrap getDetail(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> row = attributeService.getDetail(vo);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 删除商品属性
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/delete")
	public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		attributeService.delete(vo);
		return responseWrap;
	}
}
