package cn.com.ut.biz.refundreturn;

import cn.com.ut.biz.refundreturn.service.RefundReturnService;
import cn.com.ut.core.restful.ResponseWrap;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @author zhouquanguo
 * @since on 2018/6/4.
 */
@RestController
@RequestMapping(value = "/refund")
public class RefundReturnController {

	@Autowired
	private RefundReturnService refundReturnService;

	/**
	 * 买家提交退款申请
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping("/buyerSubmit")
	public ResponseWrap buyerSubmit(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		String refundId = refundReturnService.buyerSubmit(vo);
		Map<String, Object> result = Maps.newHashMap();
		result.put("refund_id", refundId);
		return responseWrap.appendData(result);
	}

	/**
	 * 买家取消退款申请
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping("/buyerCancel")
	public ResponseWrap buyerCancel(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		refundReturnService.buyerCancel(vo);
		return responseWrap;
	}

	/**
	 * 卖家处理退款申请
	 * 
	 */
	@PostMapping("/sellerDeal")
	public ResponseWrap sellerDeal(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		refundReturnService.sellerDeal(vo);
		return responseWrap.appendData(Maps.newHashMap());
	}

	/**
	 * 买家发货
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping("/buyerDelivery")
	public ResponseWrap buyerDelivery(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		refundReturnService.buyerDelivery(vo);
		return responseWrap.appendData(Maps.newHashMap());
	}

	/**
	 * 商家收货处理
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping("/sellerReceive")
	public ResponseWrap sellerReceive(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		refundReturnService.sellerReceive(vo);
		return responseWrap.appendData(Maps.newHashMap());
	}

	/**
	 * 商家查询退款申请列表
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping("/queryBySeller")
	public ResponseWrap queryBySeller(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		return refundReturnService.queryBySeller(vo);

	}

	/**
	 * 买家查询退款申请列表
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping("/queryByBuyer")
	public ResponseWrap queryByBuyer(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		return refundReturnService.queryByBuyer(vo);

	}

	/**
	 * 查看退款处理详情
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping("/getRefund")
	public ResponseWrap getRefund(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> refund = refundReturnService.getRefund(vo);
		return responseWrap.appendData(refund);
	}

}