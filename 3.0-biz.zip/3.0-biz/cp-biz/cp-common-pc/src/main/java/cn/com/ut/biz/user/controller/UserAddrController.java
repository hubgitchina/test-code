package cn.com.ut.biz.user.controller;

import static cn.com.ut.core.dal.jdbc.BaseEntity.idx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.user.entities.UserAddress;
import cn.com.ut.biz.user.service.UserAddrService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * UserAddrController
 * 
 * @author
 * @since
 */
@RestController
@RequestMapping(value = "/userAddr")
public class UserAddrController {
	@Autowired
	private UserAddrService userAddrService;

	/**
	 * 查询用户地址列表
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/find")
	public ResponseWrap find(@RequestBody ResponseWrap responseWrap) {

		PageBuilder pb = PageBuilder.build();
		pb.appendSortConditions(UserAddress.is_default, UserAddress.update_time);
		PageBean page = pb.buildSQL(responseWrap.getJson());
		List<Map<String, Object>> userAddrVOs = userAddrService
				.find(responseWrap.getJson().getString(UserAddress.user_id), page);
		return ResponseWrap.builder().appendPage(page).appendRows(userAddrVOs);
	}

	/**
	 * 获取某条用户地址详情
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/getDetail")
	public ResponseWrap getDetail(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> map = userAddrService
				.getDetail(responseWrap.getJson().getString(UserAddress.idx));
		return ResponseWrap.builder().appendRow(map);
	}

	/**
	 * 添加一条用户地址信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap) {

		String id = userAddrService.create(responseWrap.getJson());
		Map<String, Object> row = new HashMap<>();
		row.put(idx, id);
		responseWrap.appendRow(row);
		return responseWrap;
	}

	/**
	 * 更新某条用户地址信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap) {

		userAddrService.update(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 删除某条用户地址
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/delete")
	public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {

		userAddrService.delete(responseWrap.getJson().getString(UserAddress.user_id),
				responseWrap.getJson().getString(UserAddress.idx));
		return ResponseWrap.builder();
	}

	/**
	 * 设置某条用户地址为默认地址
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/setDefaultAddr")
	public ResponseWrap setDefaultAddr(@RequestBody ResponseWrap responseWrap) {

		userAddrService.setDefault(responseWrap.getJson().getString(UserAddress.user_id),
				responseWrap.getJson().getString(UserAddress.idx));
		return ResponseWrap.builder();
	}
}
