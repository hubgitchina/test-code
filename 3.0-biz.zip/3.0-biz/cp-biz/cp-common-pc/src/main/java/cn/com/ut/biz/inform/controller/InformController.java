
//-----------------------------Controller-start---------------------------------//
package cn.com.ut.biz.inform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.inform.service.InformService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * Controller
 * 
 * @author wuxiaohua
 * @since 2018年6月5日
 */
@RestController
@RequestMapping(value = "/inform")
public class InformController {

	@Autowired
	private InformService informService;

	/**
	 * 个人提交举报
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/submit")
	@ServiceComponent(session = false)
	public ResponseWrap apply(@RequestBody ResponseWrap responseWrap) {

		return ResponseWrap.builder();
	}

	/**
	 * 个人取消举报
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/cancel")
	@ServiceComponent(session = false)
	public ResponseWrap cancel(@RequestBody ResponseWrap responseWrap) {

		return ResponseWrap.builder();
	}

	/**
	 * 管理者查询举报记录
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryByAdmin")
	@ServiceComponent(session = false)
	public ResponseWrap queryByAdmin(@RequestBody ResponseWrap responseWrap) {

		return ResponseWrap.builder();
	}

	/**
	 * 查询个人发起的举报记录
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryByCustomer")
	@ServiceComponent(session = false)
	public ResponseWrap queryByCustomer(@RequestBody ResponseWrap responseWrap) {

		return ResponseWrap.builder();
	}

	/**
	 * 查看举报详细
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/getDetail")
	@ServiceComponent(session = false)
	public ResponseWrap getDetail(@RequestBody ResponseWrap responseWrap) {

		return ResponseWrap.builder();
	}

	/**
	 * 管理者处理举报
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/deal")
	@ServiceComponent(session = false)
	public ResponseWrap deal(@RequestBody ResponseWrap responseWrap) {

		return ResponseWrap.builder();
	}

}

// -----------------------------Controller-end---------------------------------//