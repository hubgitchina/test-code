package cn.com.ut.biz.goodsclass;

import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.goodsclass.entity.GoodsClass;
import cn.com.ut.biz.goodsclass.service.GoodsClassService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.restful.ResponseWrap;
import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * Created by zhouquanguo on 2018/4/28.
 */
@RestController
@RequestMapping(value = "/goodsclass")
public class GoodsClassController {

    @Autowired
    private GoodsClassService goodsClassService;

    /**
     * 新增商品分类（同时拼接其level与gc_full_path）
     *
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/add")
    @ServiceComponent(session = false)
    public ResponseWrap add(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> categoryDto = responseWrap.getJson();
        String id = goodsClassService.add(categoryDto);
        Map<String, Object> objectMap = new HashedMap();
        objectMap.put("id", id);
        return responseWrap.appendData(objectMap);
    }

    /**
     * 逻辑删除分类（is_del=Y）。假如当前分类下有子分类，将递归地逻辑删除所有子分类
     *
     * @param responseWrap
     * @return
     */
    @DeleteMapping(value = "/delete")
    @ServiceComponent(session = false)
    public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> objectMap = responseWrap.getJson();
        String id = (String) objectMap.get(GoodsClass.idx);
        goodsClassService.delete(id);
        return responseWrap;
    }

    /**
     * 查询当前分类下平级的子节点分类信息，并且不递归查询.
     *
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/queryParallelCategory")
    @ServiceComponent(session = false)
    public ResponseWrap queryParallelCategory(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> objectMap = responseWrap.getJson();
        String id = (String) objectMap.get(GoodsClass.idx);
        List<Map<String, Object>> resultList = goodsClassService.queryChildrenParallel(id);
        //对查询结果进行排序
        List<Map<String, Object>>  sortedList= resultList.stream().sorted((o1,o2) -> ((Integer) o1.get(GoodsClass.sort) -(Integer) o2.get(GoodsClass.sort))).collect(Collectors.toList());
        //对查询结果组装树形结构
        responseWrap.appendData(sortedList);

        return responseWrap;
    }


    /**
     * 递归查询当前分类下的所有子分类信息
     *
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/queryAllChildrenCategory")
    @ServiceComponent(session = false)
    public ResponseWrap queryAllChildrenCategory(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> objectMap = responseWrap.getJson();
        String categoryId = (String) objectMap.get(GoodsClass.idx);
        List<Map<String, Object>> resultList = goodsClassService.queryAllChildrenCategory(categoryId);
        //对查询结果进行排序
        List<Map<String, Object>>  sortedList= resultList.stream().sorted((o1,o2) -> ((Integer) o1.get(GoodsClass.sort) -(Integer) o2.get(GoodsClass.sort))).collect(Collectors.toList());
        //对查询结果组装树形结构
        List<Map<String, Object>> result = CollectionUtil.createTreeList(sortedList,GoodsClass.gc_parent_id,GoodsClass.idx, Const.NODE_NAME);
        responseWrap.appendData(result);
        return responseWrap;

    }

    /**
     * 更新商品分类
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/update")
    @ServiceComponent(session = false)
    public ResponseWrap update(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> objectMap = responseWrap.getJson();
        goodsClassService.update(objectMap);
        return responseWrap;

    }

    /**
     * 查询一条商品分类详情
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/query")
    @ServiceComponent(session = false)
    public ResponseWrap query(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> objectMap = responseWrap.getJson();
        String categoryId = (String) objectMap.get(GoodsClass.idx);
        Map<String,Object> result = goodsClassService.queryOne(categoryId);

        responseWrap.appendData(result);
        return responseWrap;

    }


}
