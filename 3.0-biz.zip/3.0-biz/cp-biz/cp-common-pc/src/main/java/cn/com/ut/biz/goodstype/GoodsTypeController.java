package cn.com.ut.biz.goodstype;

import cn.com.ut.biz.goodstype.service.GoodsTypeService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 商品类型控制层
 * <p>
 * Created by zhouquanguo on 2018/5/9.
 */

@RestController
@RequestMapping(value = "/goodstype")
public class GoodsTypeController {

    @Autowired
    private GoodsTypeService goodsTypeService;

    /**
     * 新增商品类型
     *
     * @return
     */
    @ServiceComponent(session = false)
    @PostMapping(value = "/create")
    public ResponseWrap create(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> vo = responseWrap.getJson();
        String id = goodsTypeService.create(vo);
        Map<String, Object> row = new HashMap<>();
        row.put("id", id);
        responseWrap.appendData(row);
        return responseWrap;

    }

    /**
     * 更新商品类型
     *
     * @param responseWrap
     * @return
     */
    @ServiceComponent(session = false)
    @PostMapping(value = "/update")
    public ResponseWrap update(@RequestBody ResponseWrap responseWrap) {

        Map<String, Object> vo = responseWrap.getJson();
        String id = goodsTypeService.update(vo);
        Map<String, Object> row = new HashMap<>();
        row.put("id", id);
        responseWrap.appendData(row);
        return responseWrap;
    }


    /**
     * 获取商品类型详情
     *
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/get")
    @ServiceComponent(session = false)
    public ResponseWrap get(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> vo = responseWrap.getJson();
        Map<String, Object> brand = goodsTypeService.getOne(vo);
        return responseWrap.appendData(brand);

    }


    /**
     * 删除商品类型
     *
     * @param responseWrap
     * @return
     */
    @ServiceComponent(session = false)
    @PostMapping(value = "/delete")
    public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {

        Map<String, Object> vo = responseWrap.getJson();
        goodsTypeService.delete(vo);
        return responseWrap;
    }


    /**
     * 查询所有的商品详情（带分页）
     *
     * @param responseWrap
     * @return
     */
    @ServiceComponent(session = false)
    @PostMapping(value = "/query")
    public ResponseWrap query(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> vo = responseWrap.getJson();
        return goodsTypeService.query(vo);
    }


}
