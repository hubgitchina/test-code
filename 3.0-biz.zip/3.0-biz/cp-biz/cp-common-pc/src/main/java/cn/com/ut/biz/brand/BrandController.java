package cn.com.ut.biz.brand;

import cn.com.ut.biz.brand.entities.Brand;
import cn.com.ut.biz.brand.service.BrandService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Map;

import java.util.stream.Collectors;

/**
 * Created by zhouquanguo on 2018/4/26.
 */

@RestController
@RequestMapping(value = "/brand")
public class BrandController {

    @Autowired
    private BrandService brandService;

    /**
     * 新增品牌
     *
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/add")
    @ServiceComponent(session = false)
    public ResponseWrap add(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> brandDto = responseWrap.getJson();
        brandDto.put(Brand.create_id,brandDto.get("user_id"));
        String id = brandService.add(brandDto);
        Map<String,Object> result= new HashedMap();
        result.put("id",id);
        responseWrap.appendData(result);
        return responseWrap;
    }

    /**
     * 删除品牌
     *
     * @param responseWrap
     * @return
     */
    @DeleteMapping(value = "/delete")
    @ServiceComponent(session = false)
    public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {
        JSONObject jsonObject = responseWrap.getJson();
        String brandId = jsonObject.getString("id");
        return brandService.deleteById(brandId);

    }

    /**
     * 获取品牌
     *
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/get")
    @ServiceComponent(session = false)
    public ResponseWrap get(@RequestBody ResponseWrap responseWrap) {
        JSONObject brandDto = responseWrap.getJson();
        String id = brandDto.getString("id");
        Map<String, Object> brand = brandService.getOne(id);

        return responseWrap.appendData(brand);

    }

    /**
     * 查询品牌列表（支持分页与品牌名称的模糊查询）
     *
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/query")
    @ServiceComponent(session = false)
    public ResponseWrap query(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> vo = responseWrap.getJson();
        ValidatorUtil.validateMapContainsKey(vo, "pageno", "pagesize");
        MultiValueMap<String, Object> pageMap = new LinkedMultiValueMap<>();
        pageMap.setAll(vo);
        PageBuilder pb = PageBuilder.build();
        PageBean pageBean = pb.buildSQL(pageMap);
        List<Map<String, Object>> resultList = brandService.query(vo,pageBean);
        //对查询结果进行排序
        List<Map<String, Object>>  sortedList= resultList.stream().sorted((o1,o2) -> - ((Integer) o1.get(Brand.sort) -(Integer) o2.get(Brand.sort))).collect(Collectors.toList());
        responseWrap.appendPage(pageBean).appendData(sortedList);
        return responseWrap;

    }

    /**
     * 更新品牌
     *
     * @param responseWrap
     * @return
     */
    @PostMapping(value = "/update")
    @ServiceComponent(session = false)
    public ResponseWrap update(@RequestBody ResponseWrap responseWrap) {
        Map<String, Object> brandDto = responseWrap.getJson();
        brandDto.put(Brand.update_id,brandDto.get("user_id"));
        ResponseWrap result = brandService.update(brandDto);
        return result;

    }


}
