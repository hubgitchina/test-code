
package cn.com.ut.biz.order;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.common.JsonUtils;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.service.OrderPayService;
import cn.com.ut.biz.order.service.OrderService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 订单Controller层
 *
 * @author zhouquanguo
 * @since 2018年5月23日
 */
@RestController
@RequestMapping(value = "/order")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@Autowired
	private OrderPayService orderPayService;

	/**
	 * 订单预览
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/previewOrder")
	@ServiceComponent(session = false)
	public ResponseWrap previewOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> result = orderService.previewOrder(vo);
		return responseWrap.appendData(result);
	}

	/**
	 * 提交订单
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/submitOrder")
	@ServiceComponent(session = false)
	public ResponseWrap submitOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		List<Map<String, Object>> orderInfo = orderService.submitOrder(vo);
		return responseWrap.appendData(orderInfo);
	}

	/**
	 * 订单取消
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/cancelOrder")
	@ServiceComponent(session = false)
	public ResponseWrap cancelOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		orderService.cancel(vo);
		return responseWrap;
	}

	/**
	 * 买家订单确认收货
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/confirmOrder")
	@ServiceComponent(session = false)
	public ResponseWrap confirmOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		orderService.confirmOrder(vo);

		return responseWrap;
	}

	/**
	 * 付款前商家修改订单信息
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/modifyOrder")
	@ServiceComponent(session = false)
	public ResponseWrap modifyOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		orderService.modifyOrder(vo);
		return responseWrap;
	}

	/**
	 * 订单支付
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/payOrder")
	@ServiceComponent(session = false)
	public ResponseWrap payOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		orderPayService.payOrder(vo);
		return responseWrap;
	}

	/**
	 * 商家订单发货
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/deliver")
	@ServiceComponent(session = false)
	public ResponseWrap deliver(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		return orderService.deliver(vo);

	}

	/**
	 * 查看订单详情
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/viewOrder")
	@ServiceComponent(session = false)
	public ResponseWrap viewOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		return orderService.viewOrder(vo);

	}

	/**
	 * 查询订单列表
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryOrders")
	@ServiceComponent(session = false)
	public ResponseWrap queryOrders(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		return orderService.queryOrders(vo);

	}

	/**
	 * 订单删除
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/deleteOrder")
	@ServiceComponent(session = false)
	public ResponseWrap deleteOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		orderService.deleteOrder(vo);
		return responseWrap;
	}

	/**
	 * 买家查询订单明细
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/buyerQuery")
	@ServiceComponent(session = false)
	public ResponseWrap buyerQuery(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		List<Map<String, Object>> queryOrderResult = orderService.buyerQuery(vo);
		for (Map<String, Object> orderItem : queryOrderResult) {
			orderItem.put(Order.order_goods,
					JsonUtils.str2obj((String) orderItem.get(Order.order_goods), List.class));
		}
		return responseWrap.appendData(queryOrderResult);
	}

}
