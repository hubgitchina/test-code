package cn.com.ut.biz.cart;

import cn.com.ut.biz.cart.service.CartService;

import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/11.
 */
@RestController
@RequestMapping(value = "/cart")
public class CartController {

	@Autowired
	private CartService cartService;

	/**
	 * 添加购物车
	 *
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/add")
	public ResponseWrap addCart(@RequestBody ResponseWrap responseWrap) {

		JSONObject vo = responseWrap.getJson();
		String cartId = cartService.add(vo);
		Map<String, Object> data = Maps.newHashMap();
		data.put("cart_id", cartId);
		return responseWrap.appendData(data);

	}

	/**
	 * 查询当前用户购物车右上方的商品数量
	 *
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/getCartCount")
	public ResponseWrap getCartCount(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> userCartDetail = cartService.getCartCount(vo);
		return responseWrap.appendData(userCartDetail);

	}

	/**
	 * 查询当前用户的购物车列表
	 *
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/query")
	public ResponseWrap query(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> cartVoList = cartService.list(vo);
		return responseWrap.appendData(cartVoList);

	}

	/**
	 * 删除购物车中的商品
	 *
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/delete")
	public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		cartService.delete(vo);
		return responseWrap;

	}

	/**
	 * 修改购物车中的商品数量
	 *
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/updateGoodsNumber")
	public ResponseWrap updateGoodsNumber(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		cartService.updateGoodsNumber(vo);
		return responseWrap;

	}

}
