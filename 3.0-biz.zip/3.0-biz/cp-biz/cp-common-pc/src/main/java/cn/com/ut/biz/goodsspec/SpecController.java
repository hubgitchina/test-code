package cn.com.ut.biz.goodsspec;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.goodsspec.entities.Spec;
import cn.com.ut.biz.goodsspec.service.SpecService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 商品规格控制层
 * 
 * @author wangpeng1
 * @since 2018年4月13日
 */
@RestController
@RequestMapping(value = "/goodsSpec")
public class SpecController {

	@Autowired
	private SpecService specService;

	/**
	 * 添加商品规格
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();

		String id = specService.create(vo);

		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 更新商品规格
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		String id = specService.update(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 查询所有的商品规格（带分页）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/findAllPage")
	public ResponseWrap findAllPage(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();

		ValidatorUtil.validateMapContainsKey(vo, "pageno", "pagesize");

		MultiValueMap<String, Object> pageMap = new LinkedMultiValueMap<>();

		pageMap.setAll(vo);

		PageBuilder pb = PageBuilder.build();

		// pb.appendWhereCondition(null, GoodsImages.corp_name,
		// EnumConstant.WhereCase.LIKE,
		// EnumConstant.SqlType.STRING);
		pb.appendSortCondition(null, Spec.create_time, EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> resultList = specService.findAllPage(page);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 查询商品规格详情
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/getDetail")
	public ResponseWrap getDetail(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> row = specService.getDetail(vo);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 删除商品规格
	 * 
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/delete")
	public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		specService.delete(vo);
		return responseWrap;
	}
}
