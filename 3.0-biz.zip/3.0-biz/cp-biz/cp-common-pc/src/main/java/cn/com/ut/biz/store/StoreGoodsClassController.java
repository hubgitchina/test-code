
//-----------------------------Controller-start---------------------------------//
package cn.com.ut.biz.store;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.store.entities.StoreGcGoods;
import cn.com.ut.biz.store.entities.StoreGoodsClass;
import cn.com.ut.biz.store.service.StoreGoodsClassService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * Controller
 * 
 * @author
 * @since
 */
@RestController
@RequestMapping(value = "/storeGoodsClass")
public class StoreGoodsClassController {

	@Autowired
	private StoreGoodsClassService storeGoodsClassService;

	/**
	 * 新增店铺商品分类
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/add")
	@ServiceComponent(session = false)
	public ResponseWrap add(@RequestBody ResponseWrap responseWrap) {

		String id = storeGoodsClassService.addStoreClass(responseWrap.getJson());
		Map<String, Object> data = new HashMap<>();
		data.put(StoreGoodsClass.idx, id);
		return ResponseWrap.builder().appendData(data);
	}

	/**
	 * 更新店铺商品分类
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/update")
	@ServiceComponent(session = false)
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap) {

		storeGoodsClassService.updateStoreClass(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 删除店铺商品分类
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/delete")
	@ServiceComponent(session = false)
	public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {

		storeGoodsClassService.deleteStoreClass(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 查询全部店铺商品分类
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryAll")
	@ServiceComponent(session = false)
	public ResponseWrap queryAll(@RequestBody ResponseWrap responseWrap) {

		List<Map<String, Object>> list = storeGoodsClassService
				.queryAll(responseWrap.getJson().getString(StoreGoodsClass.store_id));
		Map<String, Object> data = new HashMap<>();
		data.put("goods_class", list);
		return ResponseWrap.builder().appendData(data);
	}

	/**
	 * 查询某店铺商品分类下的子分类
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryChild")
	@ServiceComponent(session = false)
	public ResponseWrap queryChild(@RequestBody ResponseWrap responseWrap) {

		List<Map<String, Object>> list = storeGoodsClassService.queryChild(
				responseWrap.getJson().getString(StoreGoodsClass.store_id),
				responseWrap.getJson().getString(StoreGoodsClass.storegc_parent_id));
		Map<String, Object> data = new HashMap<>();
		data.put("goods_class", list);
		return ResponseWrap.builder().appendData(data);
	}

	/**
	 * 编辑某商品关联的店铺商品分类
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/updateGoodsStoreClass")
	@ServiceComponent(session = false)
	public ResponseWrap updateGoodsStoreClass(@RequestBody ResponseWrap responseWrap) {

		storeGoodsClassService.updateGoodsStoreClass(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 查询某商品关联的店铺商品分类
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryGoodsStoreClass")
	@ServiceComponent(session = false)
	public ResponseWrap queryGoodsStoreClass(@RequestBody ResponseWrap responseWrap) {

		List<Map<String, Object>> list = storeGoodsClassService.queryGoodsStoreClass(
				responseWrap.getJson().getString(StoreGcGoods.store_id),
				responseWrap.getJson().getString(StoreGcGoods.goods_id));
		Map<String, Object> data = new HashMap<>();
		data.put("goods_class", list);
		return ResponseWrap.builder().appendData(data);
	}

}

// -----------------------------Controller-end---------------------------------//