package cn.com.ut.biz.store;

import cn.com.ut.biz.common.Const;
import cn.com.ut.biz.goodsclass.entity.GoodsClass;
import cn.com.ut.biz.store.entities.Store;
import cn.com.ut.biz.store.service.StoreService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.restful.ResponseWrap;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhouquanguo on 2018/5/9.
 */
@RestController
@RequestMapping(value = "/store")
public class StoreController {

	@Autowired
	private StoreService storeService;

	/**
	 * 新增店铺
	 *
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/create")
	public ResponseWrap create(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		String id = storeService.create(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("id", id);
		responseWrap.appendData(row);
		return responseWrap;

	}

	/**
	 * 更新店铺
	 *
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/update")
	public ResponseWrap update(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		String id = storeService.update(vo);
		Map<String, Object> result = new HashMap<>();
		result.put("id", id);
		responseWrap.appendData(result);
		return responseWrap;
	}

	/**
	 * 获取店铺详情
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/get")
	@ServiceComponent(session = false)
	public ResponseWrap get(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> brand = storeService.getOne(vo);
		return responseWrap.appendData(brand);

	}

	/**
	 * 删除店铺
	 *
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/delete")
	public ResponseWrap delete(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		storeService.delete(vo);
		return responseWrap;
	}

	/**
	 * 查询所有的店铺（带分页）
	 *
	 * @param responseWrap
	 * @return
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/query")
	public ResponseWrap query(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		return storeService.query(vo);
	}

	/**
	 * 获取当期店铺的分类树
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/getStoreBindCategories")
	public ResponseWrap getBindCategory(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		ValidatorUtil.validateMapContainsKey(vo, Const.USER_ID, Store.idx);
		String storeId = (String) vo.get(Store.idx);
		List<Map<String, Object>> goodsClassList = storeService.getBindCategories(storeId);
		List<Map<String, Object>> goodsTreeList = CollectionUtil.createTreeList(goodsClassList,
				GoodsClass.gc_parent_id, GoodsClass.idx, Const.NODE_NAME);
		return responseWrap.appendData(goodsTreeList);
	}

	/**
	 * 新增店铺商品分类并且插入到商品分类表
	 */
	@ServiceComponent(session = false)
	@PostMapping(value = "/addStoreCategory")
	public ResponseWrap addStoreCategory(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		String storeBindClassId = storeService.addStoreCategory(vo);
		Map<String, Object> result = Maps.newHashMap();
		result.put(BaseEntity.idx, storeBindClassId);
		return responseWrap.appendData(result);
	}

    /**
     * 首页搜索框（按店铺）
     * @param responseWrap
     * @return
     */
    @ServiceComponent(session = false)
    @PostMapping(value = "/storeSearch")
    public ResponseWrap storeSearch(@RequestBody ResponseWrap responseWrap) {
        Map<String,Object> vo = responseWrap.getJson();
        return storeService.searchByStoreName(vo);
    }


}
