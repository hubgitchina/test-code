
//-----------------------------Controller-start---------------------------------//
package cn.com.ut.biz.complain.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.complain.entities.Complain;
import cn.com.ut.biz.complain.service.ComplainService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * Controller
 * 
 * @author wuxiaohua
 * @since 2018年6月5日
 */
@RestController
@RequestMapping(value = "/complain")
public class ComplainController {

	@Autowired
	private ComplainService complainService;

	/**
	 * 提交投诉申请
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/apply")
	@ServiceComponent(session = false)
	public ResponseWrap apply(@RequestBody ResponseWrap responseWrap) {

		String complianId = complainService.apply(responseWrap.getJson());
		Map<String, Object> data = new HashMap<>();
		data.put(Complain.idx, complianId);
		return ResponseWrap.builder().appendData(data);
	}

	/**
	 * 查询投诉记录列表（管理者）
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryByAdmin")
	@ServiceComponent(session = false)
	public ResponseWrap queryByAdmin(@RequestBody ResponseWrap responseWrap) {

		return complainService.queryByAdmin(responseWrap.getJson());
	}

	/**
	 * 查询店铺收到的投诉记录
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryByStore")
	@ServiceComponent(session = false)
	public ResponseWrap queryByStore(@RequestBody ResponseWrap responseWrap) {

		return complainService.queryByStore(responseWrap.getJson());
	}

	/**
	 * 查询个人发起的投诉记录
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryByCustomer")
	@ServiceComponent(session = false)
	public ResponseWrap queryByCustomer(@RequestBody ResponseWrap responseWrap) {

		return complainService.queryByCustomer(responseWrap.getJson());
	}

	/**
	 * 查询投诉详细
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/getDetail")
	@ServiceComponent(session = false)
	public ResponseWrap getDetail(@RequestBody ResponseWrap responseWrap) {

		complainService.getDetail(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 取消个人发起的投诉申请
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/cancelByCustomer")
	@ServiceComponent(session = false)
	public ResponseWrap cancelByCustomer(@RequestBody ResponseWrap responseWrap) {

		complainService.cancelByCustomer(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 关闭投诉申请（管理者）
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/closeByAdmin")
	@ServiceComponent(session = false)
	public ResponseWrap closeByAdmin(@RequestBody ResponseWrap responseWrap) {

		complainService.closeByAdmin(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 审核投诉申请（管理者）
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/auditByAdmin")
	@ServiceComponent(session = false)
	public ResponseWrap auditByAdmin(@RequestBody ResponseWrap responseWrap) {

		complainService.auditByAdmin(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 被投诉店铺提交申诉
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/appeal")
	@ServiceComponent(session = false)
	public ResponseWrap appeal(@RequestBody ResponseWrap responseWrap) {

		complainService.appeal(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 参与方发表对话
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/talk")
	@ServiceComponent(session = false)
	public ResponseWrap talk(@RequestBody ResponseWrap responseWrap) {

		complainService.talk(responseWrap.getJson());
		return ResponseWrap.builder();
	}

	/**
	 * 投诉方或被投诉方提交仲裁
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/toJudge")
	@ServiceComponent(session = false)
	public ResponseWrap toJudge(@RequestBody ResponseWrap responseWrap) {

		complainService.toJudge(responseWrap.getJson());
		return ResponseWrap.builder();
	}

}
// -----------------------------Controller-end---------------------------------//