package cn.com.ut.biz.shoppingcart.service;

import java.util.List;
import java.util.Map;

/**
 * 购物车Service层
 * 
 * @author wangpeng1
 * @since 2018年1月24日
 */
public interface ShoppingCartService {

	/**
	 * 添加商品到购物车 （同一商品不同SKU视为多条商品加入购物车）
	 * 
	 * @param vo
	 * @param userId
	 * @return
	 */
	String addCartGoods(Map<String, Object> vo);

	/**
	 * 查看购物车中的商品
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryShoppingCart(Map<String, Object> vo);

	/**
	 * 修改购物车中的商品
	 * 
	 * @param vo
	 * @param userId
	 * @return
	 */
	String updateCartGoods(Map<String, Object> vo);

	/**
	 * 删除购物车中的商品
	 * 
	 * @param vo
	 * @param userId
	 * @return
	 */
	int removeCartGoods(Map<String, Object> vo);
}