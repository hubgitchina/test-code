package cn.com.ut.biz.valuableinfo.service;

import java.util.List;
import java.util.Map;

/**
 * 传播链服务层
 * 
 * @author lanbin
 * @date 2017-12-27
 */
public interface SharingChainService {

	/**
	 * 创建传播链
	 * 
	 * @param vo
	 * @return
	 */
	String createShareChain(Map<String, Object> vo);

	/**
	 * getShareChain
	 * 
	 * @param id
	 * @return
	 */
	Map<String, Object> getShareChain(String id);

	/**
	 * 获取商品的传播路径
	 * 
	 * @param goodsId
	 * @return
	 */
	// List<List<String>> findGoodsShareChain(String goodsId);

	/**
	 * 获取交易完整传播链路
	 * 
	 * @param shareChainEndId
	 *            传播链结束id
	 * @return
	 */
	List<String> getCompleteTradeChain(String shareChainEndId);

	/**
	 * 根据商品ID获取该商品所有传播路径 （替换findGoodsShareChainByFunc）
	 * 
	 * @param goodsId
	 * @return
	 */
	List<List<String>> findGoodsShareChain(String goodsId);

	/**
	 * 根据交易结束的传播链ID查找完整的传播链信息
	 * 
	 * @param shareId
	 * @return
	 */
	List<String> findTradeShareChain(String shareId);

	/**
	 * 根据成交的传播链ID查找完整的传播链信息
	 * 
	 * @param shareId
	 * @return
	 */
	List<Map<String, Object>> getTradeShare(String shareId);
}
