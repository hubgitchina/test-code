package cn.com.ut.biz.shoppingcart.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.shoppingcart.dao.ShoppingCartDAO;
import cn.com.ut.biz.shoppingcart.entities.ShoppingCart;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.sql.SQLHelper;

@Repository
public class ShoppingCartDAOImpl extends JdbcOperationsImpl<ShoppingCart>
		implements ShoppingCartDAO {

	/**
	 * 添加商品到购物车 （同一商品不同SKU视为多条商品加入购物车）
	 */
	@Override
	public String addCartGoods(Map<String, Object> vo) {

		String[] names = { ShoppingCart.cart_type, ShoppingCart.goods_id, ShoppingCart.shop_id,
				ShoppingCart.buyer_id, ShoppingCart.goods_number, ShoppingCart.goods_sku };

		return add(names, vo);
	}

	/**
	 * 查看购物车中的商品
	 */
	@Override
	public List<Map<String, Object>> queryShoppingCart(Map<String, Object> vo) {

		// String[] names = { ShoppingCart.idx, ShoppingCart.cart_type,
		// ShoppingCart.goods_id,
		// ShoppingCart.shop_id, ShoppingCart.goods_number,
		// ShoppingCart.goods_sku };
		// return queryPage(null, null, null, false, names, null,
		// new String[] { ShoppingCart.buyer_id }, null, null,
		// ShoppingCart.create_time,
		// new Object[] { vo.get(ShoppingCart.buyer_id) });

		String sql = "select sc.id cart_id, sc.goods_id, sc.goods_number, sc.goods_sku, sc.shop_id, g.goods_name, g.goods_price"
				+ " from t_cs_shoppingcart sc left join t_cs_goods g on sc.goods_id = g.id where sc.buyer_id = ?";
		return queryForList(getJdbcTemplate(), sql, vo.get(ShoppingCart.buyer_id));
	}

	/**
	 * 修改购物车中的商品
	 */
	@Override
	public int updateCartGoods(Map<String, Object> vo) {

		String[] names = new String[] { ShoppingCart.goods_number, ShoppingCart.goods_sku };
		return update(names, vo);
	}

	/**
	 * 删除购物车中的商品
	 */
	@Override
	public int removeCartGoods(List<String> shoppingCartIds) {

		return delete(null, null, ShoppingCart.idx + SQLHelper.IN_REPLACE,
				new int[] { shoppingCartIds.size() }, shoppingCartIds.toArray(), null);
	}

	/**
	 * 查找非SKU商品
	 */
	@Override
	public Map<String, Object> getGoodsNoSKU(String shoppingCartId, String goodsId,
			String buyerId) {

		if (CommonUtil.isEmpty(shoppingCartId)) {
			String[] selectCol = new String[] { ShoppingCart.idx, ShoppingCart.goods_id,
					ShoppingCart.goods_number };

			String[] keyCol = new String[] { ShoppingCart.goods_id, ShoppingCart.buyer_id };

			return getByKey(null, null, selectCol, null, keyCol, new Object[] { goodsId, buyerId },
					null);
		} else {
			String sql = "select sc.id, sc.goods_id, sc.goods_number from t_cs_shoppingcart sc "
					+ "where sc.goods_id = ? and sc.buyer_id = ? and sc.id <> ?";
			return queryForMap(getJdbcTemplate(), sql,
					new Object[] { goodsId, buyerId, shoppingCartId });
		}
	}

	/**
	 * 查找SKU商品
	 */
	@Override
	public Map<String, Object> getGoodsBySKU(String shoppingCartId, String goodsId, String goodsSKU,
			String buyerId) {

		if (CommonUtil.isEmpty(shoppingCartId)) {
			String[] selectCol = new String[] { ShoppingCart.idx, ShoppingCart.goods_id,
					ShoppingCart.goods_number, ShoppingCart.goods_sku };

			String[] keyCol = new String[] { ShoppingCart.goods_id, ShoppingCart.buyer_id,
					ShoppingCart.goods_sku };

			return getByKey(null, null, selectCol, null, keyCol,
					new Object[] { goodsId, buyerId, goodsSKU }, null);
		} else {
			String sql = "select sc.id, sc.goods_id, sc.goods_number, sc.goods_sku from t_cs_shoppingcart sc "
					+ "where sc.goods_id = ? and sc.buyer_id = ? and sc.goods_sku = ? and sc.id <> ?";
			return queryForMap(getJdbcTemplate(), sql,
					new Object[] { goodsId, buyerId, goodsSKU, shoppingCartId });
		}
	}
}
