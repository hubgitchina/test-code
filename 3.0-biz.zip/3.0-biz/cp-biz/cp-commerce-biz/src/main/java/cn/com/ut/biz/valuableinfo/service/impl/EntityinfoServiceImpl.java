package cn.com.ut.biz.valuableinfo.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.ut.biz.goods.dao.GoodsDAO;
import cn.com.ut.biz.valuableinfo.dao.EntityinfoContentDAO;
import cn.com.ut.biz.valuableinfo.dao.ValuableinfoBodyDAO;
import cn.com.ut.biz.valuableinfo.entities.EntityinfoContent;
import cn.com.ut.biz.valuableinfo.service.EntityinfoService;
import cn.com.ut.constant.admin.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 实体信息服务层，包括交易信息
 * 
 * @author lanbin
 * @since 2017/12/25
 */
@Service
public class EntityinfoServiceImpl implements EntityinfoService {

	@Autowired
	private EntityinfoContentDAO entityinfoContentDAO;
	@Autowired
	private ValuableinfoBodyDAO valuableinfoBodyDAO;
	@Autowired
	private GoodsDAO goodsDAO;

	@Override
	public String createEntityinfoContent(Map<String, Object> vo) {

		String goodsId = (String) vo.get(EntityinfoContent.goods_id);
		String valueBodyId = (String) vo.get(EntityinfoContent.valuableinfo_body_id);
		ValidatorUtil.validateMapContainsKey(vo, EntityinfoContent.valuableinfo_body_id,
				EntityinfoContent.goods_id);

		boolean noSuchGoods = goodsDAO.checkUnique(new String[] { BaseEntity.idx },
				new Object[] { goodsId }, null, null);
		if (noSuchGoods) {
			ExceptionUtil.throwServiceException("该商品不存在");
		}

		boolean isExistGoods = !entityinfoContentDAO.checkUnique(
				new String[] { EntityinfoContent.goods_id }, new Object[] { goodsId }, null, null);
		if (isExistGoods) {
			ExceptionUtil.throwServiceException("实体信息表商品ID重复");
		}

		boolean noSuchValuableinfoBody = valuableinfoBodyDAO.checkUnique(
				new String[] { BaseEntity.idx }, new Object[] { valueBodyId }, null, null);
		if (noSuchValuableinfoBody) {
			ExceptionUtil.throwServiceException("该有价信息体不存在");
		}
		return entityinfoContentDAO.add(vo);
	}

	@Override
	public void bindCheckoutRule(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, EntityinfoContent.checkout_rule_id,
				EntityinfoContent.goods_id);
		String goodsId = (String) vo.get(EntityinfoContent.goods_id);
		Map<String, Object> entMap = entityinfoContentDAO.getByKey(null, null, null, null,
				new String[] { EntityinfoContent.goods_id, EntityinfoContent.is_del },
				new Object[] { goodsId, ConstantUtil.FLAG_NO }, null);
		if (CollectionUtil.isEmptyMap(entMap)) {
			ExceptionUtil.throwServiceException("该商品对应的实体信息不存在");
		}
		entMap.put(EntityinfoContent.checkout_rule_id, vo.get(EntityinfoContent.checkout_rule_id));
		entMap.put(EntityinfoContent.update_id, vo.get(EntityinfoContent.update_id));
		entityinfoContentDAO.update(entMap);
	}

	@Override
	public Map<String, Object> getCheckoutRule(String goodsId) {

		if (CommonUtil.isEmpty(goodsId)) {
			ExceptionUtil.throwValidateException("商品ID为空");
		}
		Map<String, Object> entityinfoMap = entityinfoContentDAO.getByKey(null, null,
				new String[] { EntityinfoContent.checkout_rule_id }, null,
				new String[] { EntityinfoContent.goods_id }, new Object[] { goodsId }, null);

		if (CollectionUtil.isEmptyMap(entityinfoMap)) {
			ExceptionUtil.throwValidateException("商品结算规则信息不存在");
		}
		return entityinfoMap;
	}
}