package cn.com.ut.biz.valuableinfo.dao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.valuableinfo.dao.ShareChainDAO;
import cn.com.ut.biz.valuableinfo.entities.ShareChain;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import cn.com.ut.core.dal.sql.SQLHelper;

/**
 * 有价信息体
 * 
 * @author ouyuexing
 *
 */
@Repository
public class ShareChainDAOImpl extends JdbcOperationsImpl<ShareChain> implements ShareChainDAO {

	String[] COLUMNS = { ShareChain.share_chain_id, ShareChain.entityinfo_content_id,
			ShareChain.parent_id, ShareChain.sharer, ShareChain.receiver };

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

	@Override
	public List<String> getCompleteTradeChain(String shareChainEndId) {

		String sql = " SELECT getCompleteTradeChain(?) AS path ";
		Map<String, Object> resultMap = queryForMap(getJdbcTemplate(), sql, shareChainEndId);
		String resultStr = (String) resultMap.get("path");
		return Arrays.asList(resultStr.split(">"));
	}

	@Override
	@Deprecated
	public List<List<String>> findGoodsShareChainByFunc(String goodsId) {

		SQLHelper sqlHelper = SQLHelper.builder();
		sqlHelper.append(" SELECT findGoodsShareChain(?) AS path");
		Map<String, Object> resultMap = queryForMap(getJdbcTemplate(), sqlHelper.toSQL(), goodsId);
		String resultStr = (String) resultMap.get("path");
		List<List<String>> resultList = new ArrayList<>();
		List<String> tempList = Arrays.asList(resultStr.split("@"));
		for (String str : tempList) {
			resultList.add(Arrays.asList(str.split(">")));
		}
		// List<String> list = findGoodsShareChain(goodsId);
		// System.out.println(list);
		return resultList;
	}

	@Override
	public String[] findTradeShareChain(String shareId) {

		String sql = "select findTradeShareChain(?) sharers";
		Map<String, Object> map = queryForMap(getJdbcTemplate(), sql, shareId);
		String sharers = TypeConvert.getStringValue(map.get("sharers"));
		return sharers.split(",");
	}

	@Override
	public String[][] findGoodsShareChain(String goodsId) {

		String sql = "select sc.share_chain_id id, sc.parent_id, sc.sharer,	sc.receiver from t_vi_share_chain sc left join t_vi_entityinfo_content e on e.id = sc.entityinfo_content_id where e.goods_id = ? order by sc.parent_id";
		List<Map<String, Object>> shareList = queryForList(getJdbcTemplate(), sql, goodsId);

		if (!CollectionUtil.isEmptyCollection(shareList)) {

			// 获取商品传播链的根节点集合，并从列表删除根节点传播链记录
			List<Map<String, Object>> rootList = new ArrayList<>();
			Iterator<Map<String, Object>> rootIt = shareList.iterator();
			while (rootIt.hasNext()) {
				Map<String, Object> map = rootIt.next();
				String parentId = TypeConvert.getStringValue(map.get("parent_id"));
				if (CommonUtil.isEmpty(parentId)) {
					rootList.add(map);
					rootIt.remove();
				}
			}

			// 设定StringBuilder初始大小为返回传播链集合的分享者ID数目乘以32位，加上每个分享者ID后面会跟一个“，”或者“#”字符，故而最后是乘以33
			int sbLength = shareList.size() * 33;
			StringBuilder totalBuilder = new StringBuilder(sbLength);
			for (Map<String, Object> rootMap : rootList) {
				String rootId = TypeConvert.getStringValue(rootMap.get("id"));
				String rootSharer = TypeConvert.getStringValue(rootMap.get("sharer"));
				String receiver = TypeConvert.getStringValue(rootMap.get("receiver"));

				getAllShareChain(rootId, shareList, rootSharer, totalBuilder, receiver);

			}
			// System.out.println(totalBuilder.length() + "***" +
			// totalBuilder.capacity());

			String totalSharer = totalBuilder.toString();
			if (totalBuilder.length() > 0) {
				totalSharer = totalSharer.substring(0, totalSharer.length() - 1);
			}
			// 用来存放最终的商品传播链路径
			String[][] allSharer = new String[totalSharer.split("#").length][];
			for (int i = 0; i < totalSharer.split("#").length; i++) {
				String tempSharer = totalSharer.split("#")[i];
				allSharer[i] = tempSharer.split(",");
			}
			return allSharer;
		} else {
			return new String[0][];
		}

	}

	/**
	 * 递归查找商品所有传播链分支详情
	 * 
	 * @param rootId
	 * @param shareList
	 * @param returnSharer
	 * @param resultList
	 */
	private void getAllShareChain(String rootId, List<Map<String, Object>> shareList,
			String returnSharer, StringBuilder totalSharer, String receiver) {

		// 用于判断是否到达当前这条传播链的尽头
		boolean flag = false;
		for (int i = 0; i < shareList.size(); i++) {
			Map<String, Object> map = shareList.get(i);
			String id = TypeConvert.getStringValue(map.get("id"));
			String parentId = TypeConvert.getStringValue(map.get("parent_id"));
			String sharer = TypeConvert.getStringValue(map.get("sharer"));
			String receiverId = TypeConvert.getStringValue(map.get("receiver"));
			if (rootId.equals(parentId)) {
				// 删除数组已使用元素，减少递归循环次数，提高性能
				shareList.remove(map);
				i--;

				flag = true;

				// 设置StringBuilder初始大小，优化内存占用，提高性能
				int sbLength = returnSharer.length() + sharer.length() + 1;
				StringBuilder tempSharer = new StringBuilder(sbLength);
				tempSharer.append(returnSharer).append(",").append(sharer);

				getAllShareChain(id, shareList, tempSharer.toString(), totalSharer, receiverId);

				if (i < 0) {
					// 当循环游标变成负数，且集合为空时，直接跳出循环
					if (CollectionUtil.isEmptyCollection(shareList)) {
						break;
					}
				}
			}
		}
		if (!flag) {
			totalSharer.append(returnSharer).append(",").append(receiver).append("#");
		}
	}

	@Override
	public List<Map<String, Object>> findTradeSuccessSharer(String shareId) {

		String sql = "select T2.sharer, T2.receiver, T2.share_way, T2.create_time from (select @r as _id,"
				+ " (select @r := parent_id from t_vi_share_chain "
				+ "where share_chain_id = _id limit 1) as parent_id, "
				+ "@l := @l + 1 as lvl from (select @r := ?, @l := 0) vars, "
				+ "t_vi_share_chain h where @r != '') T1 join t_vi_share_chain T2 on "
				+ "T1._id = T2.share_chain_id order by T1.lvl desc";
		return queryForList(getJdbcTemplate(), sql, shareId);
	}
}
