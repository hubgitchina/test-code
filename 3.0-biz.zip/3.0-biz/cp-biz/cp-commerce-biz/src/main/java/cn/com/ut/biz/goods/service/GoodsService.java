package cn.com.ut.biz.goods.service;

import java.util.Map;

public interface GoodsService {

	/**
	 * 上架商品(创建商品)
	 * 
	 * @param vo
	 * @return
	 */
	String createGoods(Map<String, Object> vo);

	/**
	 * 查看商品信息
	 * 
	 * @param GoodsId
	 * @return
	 */
	Map<String, Object> getById(Map<String, Object> vo);

}
