package cn.com.ut.biz.valuableinfo.dao.impl;

import cn.com.ut.biz.valuableinfo.dao.ValuableinfoContentDAO;
import cn.com.ut.biz.valuableinfo.entities.ValuableinfoContent;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * 有价信息内容
 * 
 * @author ouyuexing
 *
 */
@Repository
public class ValuableinfoContentDAOImpl extends JdbcOperationsImpl<ValuableinfoContent>
		implements ValuableinfoContentDAO {

	String[] COLUMNS = { ValuableinfoContent.default_checkout_rule,
			ValuableinfoContent.default_price, ValuableinfoContent.valuableinfo_body_id};

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

}
