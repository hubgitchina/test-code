package cn.com.ut.biz.valuableinfo.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.valuableinfo.entities.Tradeinfo;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 交易信息
 * 
 * @author ouyuexing
 *
 */
public interface TradeinfoDAO extends JdbcOperation<Tradeinfo> {

	/**
	 * 查询交易信息
	 * 
	 * @param pageBean
	 *            分页信息
	 * @param id
	 *            交易信息ID
	 * @return
	 */
	List<Map<String, Object>> findTradeinfo(PageBean pageBean, String id);

	/**
	 * 查询传播成交商品总数和最新数据（可根据传入num设置显示最新的多少条数据）
	 * 
	 * @param num
	 * @return
	 */
	Map<String, Object> queryTopTradeInfo(int num);

	/**
	 * 查询传播链成交商品分页列表
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findTradeGoodsPage(PageBean page);
}
