package cn.com.ut.biz.order.service.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import cn.com.ut.biz.goods.dao.GoodsDAO;
import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.biz.order.dao.OrderDAO;
import cn.com.ut.biz.order.dao.OrderGoodsDAO;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.biz.order.service.OrderService;
import cn.com.ut.biz.user.service.UserRemoteService;
import cn.com.ut.biz.valuableinfo.dao.EntityinfoContentDAO;
import cn.com.ut.biz.valuableinfo.dao.ShareChainDAO;
import cn.com.ut.biz.valuableinfo.entities.EntityinfoContent;
import cn.com.ut.biz.valuableinfo.entities.ShareChain;
import cn.com.ut.biz.valuableinfo.service.TradeinfoService;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.GIDGenerator;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.restful.httpclient.RestHttpClient;

@Service
public class OrderServiceImpl implements OrderService {

	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private GoodsDAO goodsDAO;
	@Autowired
	private OrderGoodsDAO orderGoodsDAO;
	@Autowired
	private GIDGenerator gidGenerator;
	@Autowired
	private UserRemoteService userRemoteService;
	@Autowired
	private ShareChainDAO shareChainDAO;
	@Autowired
	private TradeinfoService tradeinfoService;
	@Autowired
	private EntityinfoContentDAO entityinfoContentDAO;
	@Autowired
	private RestTemplate springRestTemplate;
	@Autowired
	private RestHttpClient restHttpClient;

	/**
	 * 创建订单(同时插入订单表和订单商品表) 商品ID 商品数量 传播链ID 创建人ID
	 */
	@Override
	public Map<String, Object> createOrder(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, OrderGoods.goods_id, OrderGoods.goods_number,
				"share_id", "user_id");
		CollectionUtil.replaceMapKey(vo, new String[] { "share_id@" + ShareChain.share_chain_id });

		String goodsNumber = TypeConvert.getStringValue(vo.get(OrderGoods.goods_number));
		boolean noInterger = !NumberUtil.isInteger(goodsNumber, 1);
		if (noInterger) {
			ExceptionUtil.throwValidateException("商品数量要求为正整数!");
		}

		String goodsId = (String) vo.get(OrderGoods.goods_id);
		Map<String, Object> goodsVo = goodsDAO.getDetail(goodsId);
		if (CollectionUtil.isEmptyMap(goodsVo)) {
			ExceptionUtil.throwValidateException("不存在此商品！");
		}

		String shareChainId = TypeConvert.getStringValue(vo.get(ShareChain.share_chain_id));
		String userId = (String) vo.get(Goods.user_id);

		// 传播链验证逻辑
		shareChainCheck(shareChainId, goodsId);

		// 计算订单总价
		String goodsPriceStr = TypeConvert.getStringValue(goodsVo.get(Goods.goods_price));
		BigDecimal orderAmount = new BigDecimal(goodsPriceStr)
				.multiply(new BigDecimal(goodsNumber));

		// 生成定单号
		String orderSn = gidGenerator.genOrderSequence();
		// 将订单插入订单表
		Map<String, Object> orderVo = new HashMap<String, Object>();
		orderVo.put(Order.order_code, orderSn);
		orderVo.put(Order.order_amount, orderAmount);
		orderVo.put(Order.buyer_id, userId);
		orderVo.put(Order.seller_id, goodsVo.get(Goods.user_id));
		orderVo.put(Order.deal_status, 0);
		orderVo.put(Order.create_id, userId);
		orderVo.put(Order.share_chain_id, shareChainId);
		String orderId = orderDAO.addOrder(orderVo);

		// 将订单信息插入订单商品表
		Map<String, Object> orderGoodsVo = new HashMap<String, Object>();
		orderGoodsVo.put(OrderGoods.order_id, orderId);
		orderGoodsVo.put(OrderGoods.create_id, userId);
		orderGoodsVo.put(OrderGoods.goods_price, orderAmount);
		orderGoodsVo.put(OrderGoods.goods_number, goodsNumber);
		orderGoodsVo.put(OrderGoods.goods_id, goodsId);
		orderGoodsDAO.addOrderGoods(orderGoodsVo);

		// 返回订单ID和订单总价
		Map<String, Object> row = new HashMap<String, Object>();
		row.put(Order.order_amount, orderAmount);
		// 其他平台的order_id指的是数据库order_sn
		row.put("order_id", orderSn);
		return row;
	}

	@Override
	public void shareChainCheck(String shareChainId, String goodsId) {

		// shareChainId为空或者为0，表示第一个分享者自己下单
		if (CommonUtil.isEmpty(shareChainId) || "0".equals(shareChainId)) {
			shareChainId = "0";
			return;
		}

		// shareChainId非0，但没有找到记录，需要主动向传播链平台拉取数据
		long count = shareChainDAO.count(null, ShareChain.share_chain_id,
				new String[] { ShareChain.share_chain_id }, new Object[] { shareChainId });

		if (count == 0) {

			Map<String, Object> dataMap = new HashMap<>();
			dataMap.put("recordId", Long.valueOf(shareChainId));

			String jsonStrData = JSON.toJSONString(dataMap);
			String ts = System.currentTimeMillis() + "";
			String appId = restHttpClient.getPropertiesValue(
					cn.com.ut.constant.api.ConstantUtil.APPKEY_VALUE.TRANSMISSIONCHAIN_APPID);
			String key = restHttpClient.getPropertiesValue(
					cn.com.ut.constant.api.ConstantUtil.APPKEY_VALUE.TRANSMISSIONCHAIN_KEY);
			String preSign = appId + jsonStrData + key + ts;
			String sign = CommonUtil.encodeMD5(preSign.getBytes());

			Map<String, String> formParam = new HashMap<>();
			formParam.put("appid", appId);
			formParam.put("sign", sign);
			formParam.put("data", jsonStrData);
			formParam.put("ts", ts);

			JSONObject jo = formPost(formParam,
					cn.com.ut.constant.api.ConstantUtil.RPC_PROJRCT.TRANSMISSIONCHAIN,
					cn.com.ut.constant.api.ConstantUtil.API_TRANSMISSIONCHAIN.PULL_SHARE_CHAIN);
			if (jo == null || jo.isEmpty() || jo.getJSONObject("data") == null
					|| jo.getJSONObject("data").isEmpty()) {
				ExceptionUtil.throwValidateException("不存在此传播链信息!");
			}

			Map<String, Object> entityinfoMap = entityinfoContentDAO.getByKey(null, null, null,
					null, new String[] { EntityinfoContent.goods_id }, new Object[] { goodsId },
					null);
			if (CollectionUtil.isEmptyMap(entityinfoMap)) {
				ExceptionUtil.throwServiceException("找不到商品对应的实体");
			}

			JSONObject data = jo.getJSONObject("data");
			int lastRecordId = data.getIntValue("lastRecordId");
			Map<String, Object> shareChainVo = new HashMap<>();
			shareChainVo.put(ShareChain.parent_id,
					lastRecordId == 0 ? null : String.valueOf(lastRecordId));
			shareChainVo.put(ShareChain.share_chain_id, shareChainId);
			shareChainVo.put(ShareChain.sharer, data.getString("originalUserId"));
			shareChainVo.put(ShareChain.receiver, data.getString("targetUserId"));
			shareChainVo.put(ShareChain.entityinfo_content_id,
					entityinfoMap.get(EntityinfoContent.idx));
			shareChainDAO.add(shareChainVo);

		}

	}

	private JSONObject formPost(Map<String, String> vo, String restCtx, String restApi) {

		HttpHeaders headers = new HttpHeaders();
		MediaType type = MediaType
				.parseMediaType("application/x-www-form-urlencoded; charset=UTF-8");
		headers.setContentType(type);
		headers.add("Accept", MediaType.APPLICATION_JSON.toString());

		MultiValueMap<String, String> formParam = new LinkedMultiValueMap<String, String>();
		Set<Map.Entry<String, String>> set = vo.entrySet();
		Iterator<Map.Entry<String, String>> iter = set.iterator();
		while (iter.hasNext()) {
			Entry<String, String> entry = iter.next();
			formParam.add(entry.getKey(), (String) entry.getValue());
		}

		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<MultiValueMap<String, String>>(
				formParam, headers);
		ResponseEntity<String> responseEntity = springRestTemplate.postForEntity(
				restHttpClient.getPropertiesValue(restCtx) + restApi, entity, String.class);
		if (responseEntity != null && !CommonUtil.isEmpty(responseEntity.getBody())) {
			logger.debug("response body===={}", responseEntity.getBody());
			return JSON.parseObject(responseEntity.getBody());
		}

		return new JSONObject();

	}

	/**
	 * 根据goodsId查询订单列表 商品ID
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String, Object>> queryOrder(Map<String, Object> vo, PageBean page) {

		ValidatorUtil.validateMapContainsKey(vo, OrderGoods.goods_id);

		// 查询商品订单列表
		String goodsId = TypeConvert.getStringValue(vo.get(OrderGoods.goods_id));
		List<Map<String, Object>> orderVos = orderGoodsDAO.listOrderGoods(goodsId, page);
		if (!CollectionUtil.isEmptyCollection(orderVos)) {
			Set<String> buyerIds = Sets.newHashSetWithExpectedSize(orderVos.size());
			for (Map<String, Object> map : orderVos) {
				if (map.get(Order.buyer_id) != null) {
					String buyerId = TypeConvert.getStringValue(map.get(Order.buyer_id));
					buyerIds.add(buyerId);
				}
			}
			Map<String, Object> userMap = null;
			if (!CollectionUtil.isEmptyCollection(buyerIds)) {
				List<Map<String, Object>> buyerList = userRemoteService.getUserName(buyerIds);
				if (CollectionUtil.isEmptyCollection(buyerList)) {
					ExceptionUtil.throwServiceException("用户信息异常");
				}

				userMap = Maps.newHashMapWithExpectedSize(buyerList.size());

				for (Map<String, Object> map : buyerList) {
					userMap.put(map.get("user_id").toString(), map.get("user_name"));
				}
			}
			for (Map<String, Object> orderMap : orderVos) {
				if (!CollectionUtil.isEmptyMap(userMap)) {
					String userKey = TypeConvert.getStringValue(orderMap.get(Order.buyer_id));
					if (CommonUtil.isEmpty(userKey)) {
						orderMap.put(Order.buyer_id, "");
					} else {
						String userName = TypeConvert.getStringValue(userMap.get(userKey));
						orderMap.put(Order.buyer_id, userName);
					}
				}
				if (orderMap.get(Order.deal_time) != null) {
					Date sqlDealTime = (Date) orderMap.get(Order.deal_time);
					long dealTime = sqlDealTime.getTime();
					orderMap.put(Order.deal_time, dealTime);
				}
			}
			return orderVos;
		} else {
			return Collections.EMPTY_LIST;
		}
	}

	/**
	 * 更新订单支付状态
	 */
	@Override
	public void notifyPayStatus(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "order_no", "out_trade_no", Order.pay_time);
		CollectionUtil.replaceMapKey(vo,
				new String[] { "order_no@" + Order.order_code, "out_trade_no@" + Order.pay_no });

		Map<String, Object> orderMap = orderDAO.getByOrderCode((String) vo.get(Order.order_code));
		if (CollectionUtil.isEmptyMap(orderMap)) {
			ExceptionUtil.throwValidateException("没有此订单信息！");
		}
		String oldOrderStatus = TypeConvert.getStringValue(orderMap.get(Order.deal_status));
		if ("1".equals(oldOrderStatus)) {
			ExceptionUtil.throwValidateException("订单已支付！");
		} else if ("0".equals(oldOrderStatus)) {
			Timestamp formatTime = DateTimeUtil.dateTimeFormat((String) vo.get(Order.pay_time),
					ConstantUtil.DATETIME_FORMAT);
			vo.put(Order.pay_time, formatTime);
			vo.put(Order.update_time, new Date());
			vo.put(Order.deal_status, 1);
			orderDAO.updateByOrderCode(vo);
			// 订单交易成功开始结算分成
			tradeinfoService.createTradeinfoByOrder((String) orderMap.get(BaseEntity.idx));
		} else {
			ExceptionUtil.throwValidateException("支付状态不正确！");
		}
	}

	/**
	 * 查询订单详情
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getOrderDetail(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "order_id");
		CollectionUtil.replaceMapKey(vo, new String[] { "order_id@" + Order.order_code });

		Map<String, Object> orderMap = orderDAO.getOrderCode((String) vo.get(Order.order_code));
		if (!CollectionUtil.isEmptyMap(orderMap)) {
			// 调用用户中心服务
			String buyerId = TypeConvert.getStringValue(orderMap.get(Order.buyer_id));
			if (!CommonUtil.isEmpty(buyerId)) {
				Map<String, Object> userMap = userRemoteService.getUserMap(buyerId);
				if (CollectionUtil.isEmptyMap(userMap)) {
					orderMap.put(Order.buyer_id, null);
				} else {
					orderMap.put(Order.buyer_id, userMap.get("user_name"));
				}
			}

			Date time = (Date) orderMap.get(Order.deal_time);
			if (time == null) {
				time = new Date();
			}
			orderMap.put(Order.deal_time, time.getTime() / 1000);
			return orderMap;
		} else {
			return Collections.EMPTY_MAP;
		}

	}
}
