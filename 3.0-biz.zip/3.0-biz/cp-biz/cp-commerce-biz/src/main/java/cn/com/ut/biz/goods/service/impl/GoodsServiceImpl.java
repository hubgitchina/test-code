package cn.com.ut.biz.goods.service.impl;

import cn.com.ut.biz.goods.dao.GoodsDAO;
import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.biz.goods.service.GoodsService;
import cn.com.ut.biz.user.service.UserRemoteService;
import cn.com.ut.biz.valuableinfo.dao.ValuableinfoBodyDAO;
import cn.com.ut.biz.valuableinfo.service.EntityinfoService;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	private GoodsDAO goodsDAO;

	@Autowired
	private EntityinfoService entityinfoService;

	@Autowired
	private ValuableinfoBodyDAO valuableinfoBodyDAO;

	@Autowired
	private UserRemoteService userRemoteService;

	/**
	 * 商品上架(创建商品信息)
	 */
	@Override
	public String createGoods(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "valuableinfo_id", Goods.goods_name,
				Goods.goods_price, Goods.user_id);

		boolean isExistGoods = !goodsDAO.checkUnique(
				new String[] { Goods.user_id, Goods.goods_name },
				new Object[] { vo.get(Goods.user_id), vo.get(Goods.goods_name) }, null, null);
		if (isExistGoods) {
			ExceptionUtil.throwValidateException("商品已上架！");
		}

		// 验证goods_price是否合法
		String goodsPrice = TypeConvert.getStringValue(vo.get(Goods.goods_price));
		if (!(NumberUtil.isDecimal(goodsPrice, false, 10, 2))) {
			ExceptionUtil.throwValidateException("请输入正确商品价格格式！");
		}

		String vInfoId = (String) vo.get("valuableinfo_id");
		boolean noSuchValuebleInfo = valuableinfoBodyDAO
				.checkUnique(new String[] { BaseEntity.idx }, new Object[] { vInfoId }, null, null);
		if (noSuchValuebleInfo) {
			ExceptionUtil.throwValidateException("不存在此有价信息!");
		}
		String userId = (String) vo.get(Goods.user_id);
		String id = goodsDAO.addGoods(vo);

		// 创建实体信息内容
		Map<String, Object> bindMap = new HashMap<>();
		bindMap.put("valuableinfo_body_id", vInfoId);
		bindMap.put("goods_id", id);
		bindMap.put("user_id", userId);
		bindMap.put("create_id", userId);
		entityinfoService.createEntityinfoContent(bindMap);
		return id;
	}

	/**
	 * 查看商品信息
	 */
	@Override
	public Map<String, Object> getById(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "goods_id");
		String goodsId = (String) vo.get("goods_id");
		Map<String, Object> goodsVo = goodsDAO.getDetail(goodsId);
		if (!CollectionUtil.isEmptyMap(goodsVo)) {
			String userId = (String) goodsVo.get(Goods.user_id);
			if (CommonUtil.isEmpty(userId)) {
				goodsVo.put("seller_name", null);
			} else {
				Map<String, Object> userMap = userRemoteService.getUserMap(userId);
				if (CollectionUtil.isEmptyMap(userMap)) {
					goodsVo.put("seller_name", null);
				} else {
					String sellerName = (String) userMap.get("user_name");
					goodsVo.put("seller_name", sellerName);
				}
			}
			goodsVo.remove(Goods.user_id);
		}
		return goodsVo;
	}
}
