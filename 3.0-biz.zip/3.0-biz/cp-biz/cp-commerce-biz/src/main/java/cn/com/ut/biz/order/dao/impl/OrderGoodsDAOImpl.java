package cn.com.ut.biz.order.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.order.dao.OrderGoodsDAO;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

@Repository
public class OrderGoodsDAOImpl extends JdbcOperationsImpl<OrderGoods> implements OrderGoodsDAO {

	/**
	 * 创建订单商品信息
	 */
	@Override
	public String addOrderGoods(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		vo.put(OrderGoods.create_time, new Timestamp(System.currentTimeMillis()));
		vo.put(OrderGoods.create_id, vo.get(OrderGoods.create_id));
		String[] names = { OrderGoods.idx, OrderGoods.order_id, OrderGoods.create_id,
				OrderGoods.create_time, OrderGoods.update_id, OrderGoods.update_time,
				OrderGoods.goods_price, OrderGoods.goods_number, OrderGoods.goods_id };

		add(null, names, null,
				new Object[] { id, vo.get(OrderGoods.order_id), vo.get(OrderGoods.create_id),
						vo.get(OrderGoods.create_time), vo.get(OrderGoods.create_id),
						vo.get(OrderGoods.create_time), vo.get(OrderGoods.goods_price),
						vo.get(OrderGoods.goods_number), vo.get(OrderGoods.goods_id) });
		return id;
	}

	/**
	 * 查看订单列表
	 */
	@Override
	public List<Map<String, Object>> listOrderGoods(String goodsId, PageBean page) {

		StringBuilder table = new StringBuilder();
		table.append(" t_cs_order a ").append("left join t_cs_order_goods b on a.id=b.order_id ");
		return query(page, null, table.toString(),
				new String[] { "a.order_code as order_id", "a." + Order.buyer_id,
						"a." + Order.deal_time, "a." + Order.deal_status,
						"a." + Order.order_amount },
				null, new String[] { "b.goods_id" }, new Object[] { goodsId });

	}

	/**
	 * 查看订单商品详情
	 */
	@Override
	public Map<String, Object> getByOrderId(String orderCode) {

		return getByKey(null, null,
				new String[] { "order_code as order_id", Order.order_amount, Order.buyer_id,
						Order.deal_time, Order.deal_status },
				null, new String[] { Order.order_code }, new Object[] { orderCode }, null);
	}

}
