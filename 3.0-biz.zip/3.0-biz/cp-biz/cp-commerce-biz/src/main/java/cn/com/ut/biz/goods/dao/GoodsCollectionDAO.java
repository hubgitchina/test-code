package cn.com.ut.biz.goods.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.goods.entities.GoodsCollection;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 商品收藏DAO层
 * 
 * @author wangpeng1
 * @since 2018年1月24日
 */
public interface GoodsCollectionDAO extends JdbcOperation<GoodsCollection> {

	/**
	 * 收藏购物车中的商品
	 * 
	 * @param vos
	 * @return
	 */
	int[] collectCartGoods(List<Map<String, Object>> vos);
}
