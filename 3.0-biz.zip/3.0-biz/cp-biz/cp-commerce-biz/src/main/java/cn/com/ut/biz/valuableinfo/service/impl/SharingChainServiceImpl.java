package cn.com.ut.biz.valuableinfo.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import cn.com.ut.biz.user.service.UserRemoteService;
import cn.com.ut.biz.valuableinfo.dao.EntityinfoContentDAO;
import cn.com.ut.biz.valuableinfo.dao.ShareChainDAO;
import cn.com.ut.biz.valuableinfo.entities.EntityinfoContent;
import cn.com.ut.biz.valuableinfo.entities.ShareChain;
import cn.com.ut.biz.valuableinfo.service.SharingChainService;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 传播链服务层，包括传播链
 * 
 * @author lanbin
 * @since 2017/12/25
 */
@Service
public class SharingChainServiceImpl implements SharingChainService {

	@Autowired
	private ShareChainDAO shareChainDAO;
	@Autowired
	private EntityinfoContentDAO entityinfoContentDAO;
	@Autowired
	private UserRemoteService userRemoteService;

	@Override
	public String createShareChain(Map<String, Object> vo) {

		String goodId = (String) vo.get(EntityinfoContent.goods_id);

		Map<String, Object> entityinfoMap = entityinfoContentDAO.getByKey(null, null, null, null,
				new String[] { EntityinfoContent.goods_id }, new Object[] { goodId }, null);
		if (CollectionUtil.isEmptyMap(entityinfoMap)) {
			ExceptionUtil.throwServiceException("找不到商品对应的实体");
		}
		boolean isExist = !shareChainDAO.checkUnique(new String[] { ShareChain.share_chain_id },
				new Object[] { vo.get(ShareChain.share_chain_id) }, null, null);
		if (isExist) {
			// ExceptionUtil.throwServiceException("传播链重复");
			return null;
		}

		String entityinfoContentId = (String) entityinfoMap.get(EntityinfoContent.idx);
		vo.put(ShareChain.entityinfo_content_id, entityinfoContentId);

		// 增加parentID父传播链ID验证，如果传过来为0，则置空存入数据库，节省数据库空间
		String parentId = TypeConvert.getStringValue(vo.get(ShareChain.parent_id));
		if (CommonUtil.isEmpty(parentId) || "0".equals(parentId)) {
			vo.put(ShareChain.parent_id, "");
		}
		return shareChainDAO.add(vo);
	}

	@Override
	public Map<String, Object> getShareChain(String id) {

		ValidatorUtil.requiredFieldMiss(new Object[] { id });
		return shareChainDAO.get(id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<List<String>> findGoodsShareChain(String goodsId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { goodsId });
		String[][] allSharer = shareChainDAO.findGoodsShareChain(goodsId);
		if (allSharer.length > 0) {
			Set<String> sharerIds = Sets.newHashSetWithExpectedSize(allSharer.length);
			for (String[] sharerInAChain : allSharer) {
				sharerIds.addAll(Arrays.asList(sharerInAChain));
			}
			List<Map<String, Object>> sharerIdList = userRemoteService.getUserName(sharerIds);
			if (CollectionUtil.isEmptyCollection(sharerIdList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}
			Map<String, String> userIdAndName = Maps
					.newHashMapWithExpectedSize(sharerIdList.size());
			for (Map<String, Object> map : sharerIdList) {
				userIdAndName.put(map.get("user_id").toString(), map.get("user_name").toString());
			}
			List<List<String>> allSharerName = Lists.newArrayListWithCapacity(allSharer.length);
			for (String[] sharers : allSharer) {
				List<String> tempList = new ArrayList<>(sharers.length);
				for (String sharer : sharers) {
					tempList.add(userIdAndName.get(sharer));
				}
				allSharerName.add(tempList);
			}
			return allSharerName;
		} else {
			return Collections.EMPTY_LIST;
		}
	}

	@Override
	public List<String> getCompleteTradeChain(String shareChainEndId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { shareChainEndId });
		List<String> sharerIds = shareChainDAO.getCompleteTradeChain(shareChainEndId);
		List<Map<String, Object>> sharerList = userRemoteService.getUserName(sharerIds);
		return CollectionUtil.listManyToOne(sharerList, "user_name");
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> findTradeShareChain(String shareId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { shareId });
		List<Map<String, Object>> sharerIds = shareChainDAO.findTradeSuccessSharer(shareId);
		if (!CollectionUtil.isEmptyCollection(sharerIds)) {
			// 将最后一条传播链的接收人取出放入集合尾部，实现最后购买人信息在该有效传播链的最后节点
			String lastUserId = TypeConvert
					.getStringValue(sharerIds.get(sharerIds.size() - 1).get("receiver"));
			if (CommonUtil.isEmpty(lastUserId)) {
				ExceptionUtil.throwValidateException("传播链最后接收人为空");
			}
			Map<String, Object> lastUser = new HashMap<>(2);
			lastUser.put("sharer", lastUserId);
			sharerIds.add(lastUser);
			Set<String> sharerIdSet = Sets.newHashSetWithExpectedSize(sharerIds.size());
			for (Map<String, Object> map : sharerIds) {
				sharerIdSet.add(String.valueOf(map.get("sharer")));
			}
			List<Map<String, Object>> sharerList = userRemoteService.getUserName(sharerIdSet);
			if (CollectionUtil.isEmptyCollection(sharerList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}
			List<String> sharerNames = Lists.newArrayListWithCapacity(sharerList.size());
			Map<String, String> userIdAndName = Maps.newHashMapWithExpectedSize(sharerList.size());
			for (Map<String, Object> map : sharerList) {
				userIdAndName.put(map.get("user_id").toString(),
						String.valueOf(map.get("user_name")));
			}
			for (Map<String, Object> map : sharerIds) {
				String sharerName = userIdAndName.get(map.get("sharer"));
				if (CommonUtil.isNotEmpty(sharerName)) {
					sharerNames.add(sharerName);
				}
			}
			return sharerNames;
		} else {
			return Collections.EMPTY_LIST;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String, Object>> getTradeShare(String shareId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { shareId });
		List<Map<String, Object>> sharerIds = shareChainDAO.findTradeSuccessSharer(shareId);
		if (!CollectionUtil.isEmptyCollection(sharerIds)) {
			// 将最后一条传播链的接收人取出放入集合尾部，实现最后购买人信息在该有效传播链的最后节点
			String lastUserId = TypeConvert
					.getStringValue(sharerIds.get(sharerIds.size() - 1).get("receiver"));
			if (CommonUtil.isEmpty(lastUserId)) {
				ExceptionUtil.throwValidateException("传播链最后接收人为空");
			}
			Map<String, Object> lastUser = new HashMap<>(2);
			lastUser.put("sharer", lastUserId);
			sharerIds.add(lastUser);

			Set<String> sharerIdSet = Sets.newHashSetWithExpectedSize(sharerIds.size());
			for (Map<String, Object> map : sharerIds) {
				sharerIdSet.add(String.valueOf(map.get("sharer")));
			}
			List<Map<String, Object>> userList = userRemoteService.getUserName(sharerIdSet);
			if (CollectionUtil.isEmptyCollection(userList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}

			List<Map<String, Object>> sharerList = Lists.newArrayListWithCapacity(sharerIds.size());
			for (Map<String, Object> map : sharerIds) {
				Map<String, Object> tempMap = Maps.newHashMapWithExpectedSize(2);
				tempMap.put("sharer", map.get("sharer"));
				tempMap.put("create_time", map.get("create_time"));
				String shareWay = (String) map.get("share_way");
				if ("wx".equals(shareWay)) {
					tempMap.put("share_way", "微信");
				} else if ("wb".equals(shareWay)) {
					tempMap.put("share_way", "微博");
				} else if ("qq".equals(shareWay)) {
					tempMap.put("share_way", "腾讯");
				}
				for (Map<String, Object> userMap : userList) {
					String sharerId = (String) map.get("sharer");
					String userId = (String) userMap.get("user_id");
					if (sharerId.equals(userId)) {
						String userName = (String) userMap.get("user_name");
						tempMap.put("sharer_name", userName);
					}
				}
				sharerList.add(tempMap);
			}
			return sharerList;
		} else {
			return Collections.EMPTY_LIST;
		}
	}
}
