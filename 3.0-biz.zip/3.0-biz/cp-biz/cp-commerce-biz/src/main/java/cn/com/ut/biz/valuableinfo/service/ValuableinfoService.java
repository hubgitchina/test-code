package cn.com.ut.biz.valuableinfo.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 有价信息体服务层，包括有价信息体、有价信息内容、有价信息内容扩展
 * 
 * @author lanbin
 * @date 2017-12-27
 */
public interface ValuableinfoService {
	/**
	 * 创建有价信息体
	 * 
	 * @param vo
	 * @return
	 */
	String createValuableinfo(Map<String, Object> vo);

	/**
	 * 查看有价信息体
	 * 
	 * @param id
	 * @return
	 */
	Map<String, Object> getValuableinfo(String id);

	/**
	 * 查询有价信息体总数和最新数据（可根据传入num设置显示最新的多少条数据）
	 * 
	 * @param num
	 * @return
	 */
	Map<String, Object> queryTopValuableInfo(Map<String, Object> vo);

	/**
	 * 查询有价信息体分页列表
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findValuablePage(PageBean page);
}
