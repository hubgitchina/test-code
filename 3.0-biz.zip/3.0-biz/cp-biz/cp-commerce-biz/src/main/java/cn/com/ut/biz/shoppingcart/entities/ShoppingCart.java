package cn.com.ut.biz.shoppingcart.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 购物车表实体类(t_cs_shoppingcart)
 * 
 * @author wangpeng1
 * @since 2018年1月24日
 */
public class ShoppingCart extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * 购物车ID
	 */
	public static final String cart_id = "cart_id";
	/**
	 * 购物车类型，引用字典CART_TYPE
	 */
	public static final String cart_type = "cart_type";
	/**
	 * 商品ID
	 */
	public static final String goods_id = "goods_id";
	/**
	 * 店铺ID
	 */
	public static final String shop_id = "shop_id";
	/**
	 * 购买者ID
	 */
	public static final String buyer_id = "buyer_id";
	/**
	 * 商品数量
	 */
	public static final String goods_number = "goods_number";
	/**
	 * 商品是否有SKU属性
	 */
	public static final String is_sku = "is_sku";
	/**
	 * 商品SKU编码
	 */
	public static final String goods_sku = "goods_sku";
}
