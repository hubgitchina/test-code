package cn.com.ut.biz.valuableinfo.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.google.common.collect.Maps;

import cn.com.ut.biz.valuableinfo.dao.TradeinfoDAO;
import cn.com.ut.biz.valuableinfo.entities.Tradeinfo;
import cn.com.ut.constant.admin.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 交易信息
 * 
 * @author ouyuexing
 *
 */
@Repository
public class TradeinfoDAOImpl extends JdbcOperationsImpl<Tradeinfo> implements TradeinfoDAO {

	String[] COLUMNS = { Tradeinfo.amount, Tradeinfo.buyer, Tradeinfo.entityinfo_content_id,
			Tradeinfo.order_id, Tradeinfo.share_chain_end_id };

	@Override
	public String add(Map<String, Object> vo) {

		vo.put(BaseEntity.create_id, vo.get("user_id"));
		vo.put(BaseEntity.create_time, DateTimeUtil.currentDateTime());
		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

	@Override
	public List<Map<String, Object>> findTradeinfo(PageBean pageBean, String id) {

		return queryPage(pageBean, null, null, false, COLUMNS, null,
				new String[] { BaseEntity.idx }, null, null, BaseEntity.create_time,
				new Object[] { id });
	}

	@Override
	public Map<String, Object> queryTopTradeInfo(int num) {

		long totalV = count(null, null, null, null);

		if (num <= 0) {
			num = 5;
		} else if (num > 10) {
			num = 10;
		}
		String sql = "select t.buyer, t.create_time, g.goods_name from t_vi_tradeinfo t left join t_vi_entityinfo_content ec on t.entityinfo_content_id = ec.id left join t_cs_goods g on ec.goods_id = g.id where t.is_del=? AND ec.is_del=? AND g.is_del=? order by t.create_time desc limit ?";
		List<Map<String, Object>> valuableList = queryForList(getJdbcTemplate(), sql,
				ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO, num);

		Map<String, Object> map = Maps.newHashMapWithExpectedSize(2);
		map.put("totalT", totalV);
		map.put("homeT", valuableList);

		return map;
	}

	@Override
	public List<Map<String, Object>> findTradeGoodsPage(PageBean page) {

		StringBuffer table = new StringBuffer();
		String[] selectColumnArray = new String[] { "g.id", "g.goods_name", "t.amount",
				"t.create_time", "t.share_chain_end_id" };
		table.append("t_vi_tradeinfo t ")
				.append("LEFT JOIN t_vi_entityinfo_content ec ON t.entityinfo_content_id = ec.id ")
				.append("LEFT JOIN t_cs_goods g ON ec.goods_id = g.id");
		return queryPage(page, null, table.toString(), false, selectColumnArray, null,
				new String[] { "t.is_del", "ec.is_del", "g.is_del" }, null, null, null,
				new Object[] { ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO });
	}
}
