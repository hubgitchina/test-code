package cn.com.ut.biz.valuableinfo.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.valuableinfo.entities.ShareChain;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 传播链
 * 
 * @author ouyuexing
 *
 */
public interface ShareChainDAO extends JdbcOperation<ShareChain> {

	/**
	 * 获取交易完整传播链路
	 * 
	 * @param shareChainEndId
	 *            传播链结束id
	 * @return 一条传播链所有传播者的用户ID
	 */
	List<String> getCompleteTradeChain(String shareChainEndId);

	/**
	 * 根据商品ID获取该商品所有传播路径（调用函数的方法，效率较低）
	 * 
	 * @param goodsId
	 * @return 所有传播链所有传播者的用户ID
	 */
	@Deprecated
	List<List<String>> findGoodsShareChainByFunc(String goodsId);

	/**
	 * 根据商品ID获取该商品所有传播路径 （替换findGoodsShareChainByFunc）
	 * 
	 * @param goodsId
	 * @return 所有传播链所有传播者的用户ID
	 */
	String[][] findGoodsShareChain(String goodsId);

	/**
	 * 根据交易结束的传播链ID查找完整的传播链信息
	 * 
	 * @param shareId
	 * @return
	 */
	String[] findTradeShareChain(String shareId);

	/**
	 * 根据交易结束的传播链ID查找这条完整的传播链用户信息
	 * 
	 * @param shareId
	 * @return
	 */
	List<Map<String, Object>> findTradeSuccessSharer(String shareId);
}
