package cn.com.ut.biz.valuableinfo.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import cn.com.ut.biz.user.service.UserRemoteService;
import cn.com.ut.biz.valuableinfo.dao.SharinginfoDAO;
import cn.com.ut.biz.valuableinfo.dao.TradeinfoDAO;
import cn.com.ut.biz.valuableinfo.entities.Sharinginfo;
import cn.com.ut.biz.valuableinfo.entities.Tradeinfo;
import cn.com.ut.biz.valuableinfo.service.SharinginfoService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 分成信息服务层，包括分成信息
 * 
 * @author lanbin
 * @since 2017/12/25
 */
@Service
public class SharinginfoServiceImpl implements SharinginfoService {

	@Autowired
	private SharinginfoDAO sharinginfoDAO;
	@Autowired
	private TradeinfoDAO tradeinfoDAO;
	@Autowired
	private UserRemoteService userRemoteService;

	@Override
	public List<Map<String, Object>> getSharinginfo(String id) {

		if (CommonUtil.isEmpty(id)) {
			ExceptionUtil.throwValidateException("分成信息id不能为空");
		}
		return sharinginfoDAO.getSharinginfo(id);
	}

	@Override
	public List<Map<String, Object>> listSharinginfo(PageBean page, String sharer) {

		if (CommonUtil.isEmpty(sharer)) {
			ExceptionUtil.throwValidateException("分享者不能为空");
		}
		return sharinginfoDAO.listSharinginfo(page, sharer);
	}

	public String createSharinginfoOld(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, Sharinginfo.tradeinfo_id, Sharinginfo.pay_type,
				Sharinginfo.sharer, Sharinginfo.amount);
		if (!NumberUtil.isDecimal(vo.get(Sharinginfo.amount).toString(), false, 10, 2)) {
			ExceptionUtil.throwValidateException("分成金额格式有误");
		}
		// boolean isExist = !sharinginfoDAO.checkUnique(
		// new String[] { Sharinginfo.tradeinfo_id, Sharinginfo.sharer },
		// new Object[] { vo.get(Sharinginfo.tradeinfo_id),
		// vo.get(Sharinginfo.sharer) }, null,
		// null);
		// if (isExist) {
		// ExceptionUtil.throwValidateException("已存在分成记录");
		// }
		return sharinginfoDAO.save(vo);
	}

	@Override
	public void createSharinginfo(JSONObject jo) {

		ValidatorUtil.validateMapContainsKey(jo, Sharinginfo.tradeinfo_id, "sharers");
		String tradeinfoId = jo.getString(Sharinginfo.tradeinfo_id);
		long count = tradeinfoDAO.count(null, Tradeinfo.idx, new String[] { Tradeinfo.idx },
				new Object[] { tradeinfoId });
		if (count == 0) {
			ExceptionUtil.throwValidateException("无效的交易ID");
		}

		// 如果收到重复的交易分成信息，直接忽略，给结算规则平台返回的结果为code=0
		long sharinginfoCount = sharinginfoDAO.count(null, Sharinginfo.tradeinfo_id,
				new String[] { Sharinginfo.tradeinfo_id }, new Object[] { tradeinfoId });
		if (sharinginfoCount > 0) {
			return;
		}

		JSONArray ja = jo.getJSONArray("sharers");
		if (ja == null || ja.isEmpty()) {
			ExceptionUtil.throwValidateException("分成信息格式有误");
		}

		List<Map<String, Object>> vos = new ArrayList<>();
		java.util.Date time = new java.util.Date();
		for (int i = 0; i < ja.size(); i++) {

			JSONObject sharer = ja.getJSONObject(i);
			ValidatorUtil.validateMapContainsKey(sharer, Sharinginfo.sharer);
			if (!NumberUtil.isDecimal(sharer.getString(Sharinginfo.amount), false, 10, 2)) {
				ExceptionUtil.throwValidateException("分成金额格式有误");
			}

			Map<String, Object> vo = new HashMap<String, Object>();
			vo.put(Sharinginfo.tradeinfo_id, jo.get(Sharinginfo.tradeinfo_id));
			vo.put(Sharinginfo.sharer, sharer.get(Sharinginfo.sharer));
			vo.put(Sharinginfo.pay_type, sharer.get(Sharinginfo.pay_type));
			vo.put(Sharinginfo.amount, sharer.getBigDecimal(Sharinginfo.amount));
			vo.put(Sharinginfo.idx, CommonUtil.getUUID());
			vo.put(Sharinginfo.create_time, time);
			vos.add(vo);
		}
		if (!vos.isEmpty()) {
			sharinginfoDAO.addVoBatch(null,
					new String[] { Sharinginfo.idx, Sharinginfo.create_time, Sharinginfo.sharer,
							Sharinginfo.pay_type, Sharinginfo.amount, Sharinginfo.tradeinfo_id },
					null, vos);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String, Object>> getOrderSharinginfo(String orderId) {

		// ValidatorUtil.requiredFieldMiss(new Object[] { orderId });
		List<Map<String, Object>> sharingInfoList = sharinginfoDAO.getOrderSharinginfo(orderId);
		if (!CollectionUtil.isEmptyCollection(sharingInfoList)) {
			List<String> sharerIds = Lists.newArrayListWithCapacity(sharingInfoList.size());
			for (Map<String, Object> map : sharingInfoList) {
				String sharerId = TypeConvert.getStringValue(map.get("user_id"));
				sharerIds.add(sharerId);
			}
			List<Map<String, Object>> sharerList = userRemoteService.getUserName(sharerIds);
			if (CollectionUtil.isEmptyCollection(sharerList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}
			Map<String, Object> userMap = Maps.newHashMapWithExpectedSize(sharingInfoList.size());
			for (Map<String, Object> map : sharerList) {
				userMap.put(map.get("user_id").toString(), map.get("user_name"));
			}
			for (Map<String, Object> map : sharingInfoList) {
				String userKey = TypeConvert.getStringValue(map.get("user_id"));
				map.put("user_id", userMap.get(userKey));
			}
			return sharingInfoList;
		} else {
			return Collections.EMPTY_LIST;
		}
	}

	@Override
	public Object getOrderTotalSharinginfo(String orderId) {

		ValidatorUtil.requiredFieldMiss(new Object[] { orderId });
		return sharinginfoDAO.getOrderTotalSharinginfo(orderId);
	}

	@Override
	public Map<String, Object> queryTopSharingInfo(Map<String, Object> vo) {

		int num = 0;
		if (vo != null && vo.get("num") != null) {
			num = Integer.parseInt(vo.get("num").toString());
		}
		Map<String, Object> sharingMap = sharinginfoDAO.queryTopSharingInfo(num);
		List<Map<String, Object>> sharingList = (ArrayList) sharingMap.get("homeS");
		if (!CollectionUtil.isEmptyCollection(sharingList)) {
			Set<String> sharerIdSet = Sets.newHashSetWithExpectedSize(sharingList.size());
			for (Map<String, Object> map : sharingList) {
				sharerIdSet.add(String.valueOf(map.get("sharer")));
			}
			List<Map<String, Object>> userList = userRemoteService.getUserName(sharerIdSet);
			if (CollectionUtil.isEmptyCollection(userList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}
			for (Map<String, Object> map : sharingList) {
				for (Map<String, Object> userMap : userList) {
					String createId = (String) map.get("sharer");
					String userId = (String) userMap.get("user_id");
					if (createId.equals(userId)) {
						String userName = (String) userMap.get("user_name");
						map.put("sharer_name", userName);
					}
				}
			}
		}
		return sharingMap;
	}

	@Override
	public List<Map<String, Object>> findSettlementPage(PageBean page) {

		List<Map<String, Object>> sharingList = sharinginfoDAO.findSettlementPage(page);
		if (!CollectionUtil.isEmptyCollection(sharingList)) {
			Set<String> sharerIdSet = Sets.newHashSetWithExpectedSize(sharingList.size());
			for (Map<String, Object> map : sharingList) {
				sharerIdSet.add(String.valueOf(map.get("sharer")));
			}
			List<Map<String, Object>> userList = userRemoteService.getUserName(sharerIdSet);
			if (CollectionUtil.isEmptyCollection(userList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}
			for (Map<String, Object> map : sharingList) {
				for (Map<String, Object> userMap : userList) {
					String sharerId = (String) map.get("sharer");
					String userId = (String) userMap.get("user_id");
					if (sharerId.equals(userId)) {
						String userName = (String) userMap.get("user_name");
						map.put("sharer_name", userName);
					}
				}
			}
		}
		return sharingList;
	}

	@Override
	public List<Map<String, Object>> findSettlementDetails(PageBean page, String sharer) {

		return sharinginfoDAO.findSettlementDetails(page, sharer);
	}
}
