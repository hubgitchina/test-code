package cn.com.ut.biz.goods.dao;

import java.util.Map;

import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

public interface GoodsDAO extends JdbcOperation<Goods> {

	/**
	 * 商品上架(创建商品信息)
	 * 
	 * @param vo
	 * @return
	 */
	String addGoods(Map<String, Object> vo);

	/**
	 * 查看商品信息
	 * 
	 * @param goodsId
	 *            商品ID
	 * @return
	 */
	Map<String, Object> getDetail(String goodsId);
}
