package cn.com.ut.biz.valuableinfo.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.google.common.collect.Maps;

import cn.com.ut.biz.valuableinfo.dao.SharinginfoDAO;
import cn.com.ut.biz.valuableinfo.entities.Sharinginfo;
import cn.com.ut.constant.admin.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 分成信息
 * 
 * @author ouyuexing
 *
 */
@Repository
public class SharinginfoDAOImpl extends JdbcOperationsImpl<Sharinginfo> implements SharinginfoDAO {

	String[] COLUMNS = { Sharinginfo.amount, Sharinginfo.pay_type, Sharinginfo.sharer,
			Sharinginfo.tradeinfo_id };

	@Override
	public String save(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

	@Override
	public List<Map<String, Object>> listSharinginfo(PageBean page, String sharer) {

		return query(page, null, null,
				new String[] { Sharinginfo.idx, Sharinginfo.pay_type, Sharinginfo.amount,
						Sharinginfo.sharer, Sharinginfo.tradeinfo_id, Sharinginfo.create_time },
				null, new String[] { Sharinginfo.sharer }, new Object[] { sharer });
	}

	@Override
	public List<Map<String, Object>> getOrderSharinginfo(String orderId) {

		String table = "t_vi_sharinginfo si LEFT JOIN t_vi_tradeinfo tf on si.tradeinfo_id = tf.id";
		return queryPage(null, null, table, false,
				new String[] { "si.sharer AS user_id", "SUM(si.amount) AS amount" }, null,
				new String[] { "tf.order_id", "tf.is_del", "si.is_del" }, null, null, null,
				"si.sharer", null, null,
				new Object[] { orderId, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO });
	}

	@Override
	public Object getOrderTotalSharinginfo(String orderId) {

		String table = "t_vi_sharinginfo si LEFT JOIN t_vi_tradeinfo tf on si.tradeinfo_id = tf.id";
		List<Map<String, Object>> res = queryPage(null, null, table, false,
				new String[] { "SUM(si.amount) as amount" }, null, new String[] { "tf.order_id" },
				null, null, null, "tf.order_id", null, null, new Object[] { orderId });
		if (CollectionUtil.isEmptyCollection(res)) {
			return 0;
		}
		return res.get(0).get("amount");
	}

	@Override
	public List<Map<String, Object>> getSharinginfo(String orderId) {

		return getById(null, null,
				new String[] { Sharinginfo.idx, Sharinginfo.pay_type, Sharinginfo.amount,
						Sharinginfo.sharer, Sharinginfo.tradeinfo_id, Sharinginfo.create_time },
				null, orderId);
	}

	@Override
	public Map<String, Object> queryTopSharingInfo(int num) {

		long totalV = count(null, null, null, null);

		if (num <= 0) {
			num = 5;
		} else if (num > 10) {
			num = 10;
		}
		String sql = "select si.sharer, si.amount, si.create_time from t_vi_sharinginfo si where si.is_del=? order by si.create_time desc limit ?";
		List<Map<String, Object>> valuableList = queryForList(getJdbcTemplate(), sql,
				ConstantUtil.FLAG_NO, num);

		Map<String, Object> map = Maps.newHashMapWithExpectedSize(2);
		map.put("totalS", totalV);
		map.put("homeS", valuableList);

		return map;
	}

	@Override
	public List<Map<String, Object>> findSettlementPage(PageBean page) {

		String[] selectColumnArray = new String[] { Sharinginfo.idx, Sharinginfo.sharer,
				"SUM(amount) as amount", Sharinginfo.pay_type, "MAX(create_time) as create_time" };
		return queryPage(page, null, null, false, selectColumnArray, null,
				new String[] { Sharinginfo.is_del }, null, null, null, "sharer", null,
				"MAX(create_time) DESC", new Object[] { ConstantUtil.FLAG_NO });
	}

	@Override
	public List<Map<String, Object>> findSettlementDetails(PageBean page, String sharer) {

		StringBuffer table = new StringBuffer();
		String[] selectColumnArray = new String[] { "g.goods_name", "s.id", "s.amount",
				"s.pay_type", "s.create_time" };
		table.append("t_vi_sharinginfo s ")
				.append("LEFT JOIN t_vi_tradeinfo t on s.tradeinfo_id = t.id ")
				.append("LEFT JOIN t_vi_entityinfo_content ec on t.entityinfo_content_id = ec.id ")
				.append("LEFT JOIN t_cs_goods g on ec.goods_id = g.id");
		return queryPage(page, null, table.toString(), false, selectColumnArray, null,
				new String[] { "s.sharer" }, null, null, "s.create_time desc",
				new Object[] { sharer });
	}
}
