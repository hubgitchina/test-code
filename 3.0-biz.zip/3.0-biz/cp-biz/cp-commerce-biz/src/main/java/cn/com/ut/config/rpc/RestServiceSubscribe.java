package cn.com.ut.config.rpc;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RestServiceSubscribe {

}
