package cn.com.ut.biz.valuableinfo.dao.impl;

import cn.com.ut.biz.valuableinfo.dao.EntityinfoContentDAO;
import cn.com.ut.biz.valuableinfo.entities.EntityinfoContent;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * 有价信息体
 * 
 * @author ouyuexing
 *
 */
@Repository
public class EntityinfoContentDAOImpl extends JdbcOperationsImpl<EntityinfoContent>
		implements EntityinfoContentDAO {

	String[] COLUMNS = { EntityinfoContent.checkout_rule_id, EntityinfoContent.goods_id,
			EntityinfoContent.valuableinfo_body_id };

	@Override
	public String add(Map<String, Object> vo) {

		return add(new String[] { EntityinfoContent.checkout_rule_id, EntityinfoContent.goods_id,
				EntityinfoContent.valuableinfo_body_id }, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

}
