package cn.com.ut.biz.goods.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品表信息表 t_cs_goods
 * 
 * @author gaolei
 * @since 2017年12月29日
 */
public class Goods extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * 商品名称
	 */
	public static final String goods_name = "goods_name";
	/**
	 * 商品描述
	 */
	public static final String goods_desc = "goods_desc";
	/**
	 * 商品url
	 */
	public static final String goods_url = "goods_url";
	/**
	 * 商品价格
	 */
	public static final String goods_price = "goods_price";
	/**
	 * 商家用户
	 */
	public static final String user_id = "user_id";
}
