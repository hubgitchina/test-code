package cn.com.ut.biz.valuableinfo.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Sets;

import cn.com.ut.biz.user.service.UserRemoteService;
import cn.com.ut.biz.valuableinfo.dao.ValuableinfoBodyDAO;
import cn.com.ut.biz.valuableinfo.dao.ValuableinfoContentDAO;
import cn.com.ut.biz.valuableinfo.entities.ValuableinfoBody;
import cn.com.ut.biz.valuableinfo.entities.ValuableinfoContent;
import cn.com.ut.biz.valuableinfo.service.ValuableinfoService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

/**
 * 有价信息体服务层，包括有价信息体、有价信息内容、有价信息内容扩展
 * 
 * @author lanbin
 * @date 2017-12-27
 */
@Service
public class ValuableinfoServiceImpl implements ValuableinfoService {

	@Autowired
	private ValuableinfoBodyDAO valuableinfoBodyDAO;
	@Autowired
	private ValuableinfoContentDAO valuableinfoContentDAO;

	@Autowired
	private UserRemoteService userRemoteService;

	@Override
	public String createValuableinfo(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "user_id");
		String userId = (String) vo.get("user_id");
		vo.put(ValuableinfoBody.business_type, "RECIPE");
		vo.put(ValuableinfoBody.creator, userId);
		vo.put(ValuableinfoBody.create_id, userId);
		String valuableinfoBodyId = valuableinfoBodyDAO.add(vo);
		vo.put(ValuableinfoContent.valuableinfo_body_id, valuableinfoBodyId);
		valuableinfoContentDAO.add(vo);
		// vo.put(ValuableinfoContentExtendRecipe.valuableinfo_content_id,
		// contentId);
		// vRecipeDAO.add(vo);
		return valuableinfoBodyId;
	}

	@Override
	public Map<String, Object> getValuableinfo(String id) {

		return valuableinfoBodyDAO.getById(id);
	}

	@Override
	public Map<String, Object> queryTopValuableInfo(Map<String, Object> vo) {

		int num = 0;
		if (vo != null && vo.get("num") != null) {
			num = Integer.parseInt(vo.get("num").toString());
		}
		Map<String, Object> valuableMap = valuableinfoBodyDAO.queryTopValuableInfo(num);
		List<Map<String, Object>> valuableList = (ArrayList) valuableMap.get("homeV");
		if (!CollectionUtil.isEmptyCollection(valuableList)) {
			Set<String> sharerIdSet = Sets.newHashSetWithExpectedSize(valuableList.size());
			for (Map<String, Object> map : valuableList) {
				sharerIdSet.add(String.valueOf(map.get("creator")));
			}
			List<Map<String, Object>> userList = userRemoteService.getUserName(sharerIdSet);
			if (CollectionUtil.isEmptyCollection(userList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}
			for (Map<String, Object> map : valuableList) {
				for (Map<String, Object> userMap : userList) {
					String createId = (String) map.get("creator");
					String userId = (String) userMap.get("user_id");
					if (createId.equals(userId)) {
						String userName = (String) userMap.get("user_name");
						map.put("create_name", userName);
					}
				}
			}
		}
		return valuableMap;
	}

	@Override
	public List<Map<String, Object>> findValuablePage(PageBean page) {

		List<Map<String, Object>> valuableList = valuableinfoBodyDAO.findValuablePage(page);
		if (!CollectionUtil.isEmptyCollection(valuableList)) {
			Set<String> sharerIdSet = Sets.newHashSetWithExpectedSize(valuableList.size());
			for (Map<String, Object> map : valuableList) {
				sharerIdSet.add(String.valueOf(map.get("creator")));
			}
			List<Map<String, Object>> userList = userRemoteService.getUserName(sharerIdSet);
			if (CollectionUtil.isEmptyCollection(userList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}
			for (Map<String, Object> map : valuableList) {
				for (Map<String, Object> userMap : userList) {
					String createId = (String) map.get("creator");
					String userId = (String) userMap.get("user_id");
					if (createId.equals(userId)) {
						String userName = (String) userMap.get("user_name");
						map.put("create_name", userName);
					}
				}
			}
		}
		return valuableList;
	}
}
