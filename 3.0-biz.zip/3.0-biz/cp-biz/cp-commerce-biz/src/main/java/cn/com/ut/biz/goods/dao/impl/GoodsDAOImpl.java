package cn.com.ut.biz.goods.dao.impl;

import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.goods.dao.GoodsDAO;
import cn.com.ut.biz.goods.entities.Goods;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

@Repository
public class GoodsDAOImpl extends JdbcOperationsImpl<Goods> implements GoodsDAO {

	/**
	 * 商品上架(创建商品信息)
	 */
	@Override
	public String addGoods(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		vo.put(Goods.create_time, DateTimeUtil.currentDateTime());
		vo.put(Goods.update_id, vo.get(Goods.user_id));
		vo.put(Goods.create_id, vo.get(Goods.user_id));
		String[] names = { Goods.idx, Goods.goods_name, Goods.goods_desc, Goods.goods_price,
				Goods.goods_url, Goods.create_id, Goods.create_time, Goods.update_id,
				Goods.update_time, Goods.user_id };

		add(null, names, null,
				new Object[] { id, vo.get(Goods.goods_name), vo.get(Goods.goods_desc),
						vo.get(Goods.goods_price), vo.get(Goods.goods_url), vo.get(Goods.create_id),
						vo.get(Goods.create_time), vo.get(Goods.create_id),
						vo.get(Goods.create_time), vo.get(Goods.user_id) });
		return id;
	}

	/**
	 * 查看商品信息
	 */
	@Override
	public Map<String, Object> getDetail(String goodsId) {

		return getById(null, null, new String[] { Goods.goods_name, Goods.goods_desc,
				Goods.goods_price, Goods.goods_url, Goods.user_id }, null, goodsId);
	}
}
