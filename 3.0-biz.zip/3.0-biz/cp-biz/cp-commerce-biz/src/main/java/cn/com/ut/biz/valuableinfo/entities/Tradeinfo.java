package cn.com.ut.biz.valuableinfo.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 交易信息
 * 
 * @author ouyuexing
 *
 */
public class Tradeinfo extends BaseEntity {

	private static final long serialVersionUID = 8643145529118226226L;

	/**
	 * 实体信息内容
	 */
	public static final String entityinfo_content_id = "entityinfo_content_id";
	/**
	 * 订单ID
	 */
	public static final String order_id = "order_id";
	/**
	 * 传播链结束 ID
	 */
	public static final String share_chain_end_id = "share_chain_end_id";

	/**
	 * 成交用户 ID
	 */
	public static final String buyer = "buyer";

	/**
	 * 成交金额
	 */
	public static final String amount = "amount";
}
