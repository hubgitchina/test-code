package cn.com.ut.biz.shoppingcart.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;

import cn.com.ut.biz.shoppingcart.dao.ShoppingCartDAO;
import cn.com.ut.biz.shoppingcart.entities.ShoppingCart;
import cn.com.ut.biz.shoppingcart.service.ShoppingCartService;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {

	@Autowired
	private ShoppingCartDAO shoppingCartDAO;

	/**
	 * 添加商品到购物车 （同一商品不同SKU视为多条商品加入购物车）
	 */
	@Override
	public String addCartGoods(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, ShoppingCart.is_sku, ShoppingCart.goods_id,
				ShoppingCart.goods_number, ShoppingCart.buyer_id);
		String goodsNumber = TypeConvert.getStringValue(vo.get(ShoppingCart.goods_number));
		if (!NumberUtil.isInteger(goodsNumber, 1)) {
			ExceptionUtil.throwValidateException("商品数量不正确");
		}

		// 先判断该商品是否有SKU属性，有SKU和没有SKU的商品处理逻辑会有所不同
		String isSKU = TypeConvert.getStringValue(vo.get(ShoppingCart.is_sku));
		String goodsId = TypeConvert.getStringValue(vo.get(ShoppingCart.goods_id));
		String buyerId = TypeConvert.getStringValue(vo.get(ShoppingCart.buyer_id));
		Map<String, Object> cartGoods = null;
		if ("Y".equals(isSKU)) {
			ValidatorUtil.validateMapContainsKey(vo, ShoppingCart.goods_sku);
			String goodsSKU = TypeConvert.getStringValue(vo.get(ShoppingCart.goods_sku));
			cartGoods = shoppingCartDAO.getGoodsBySKU(null, goodsId, goodsSKU, buyerId);
		} else {
			cartGoods = shoppingCartDAO.getGoodsNoSKU(null, goodsId, buyerId);
		}

		String operation = null;

		// 判断购物车是否已存在该商品，不存在则验证库存合理之后添加，存在则在原数据上修改数量并验证库存合理之后更新
		if (CollectionUtil.isEmptyMap(cartGoods)) {
			// 需验证商品库存是否足够，暂时预留
			// TODO

			if (!"Y".equals(isSKU)) {
				// 非SKU商品时，设置SKU字段为空值，因为数据库空值不占空间，NULL会占空间
				vo.put(ShoppingCart.goods_sku, "");
			}
			vo.put(ShoppingCart.create_id, buyerId);
			shoppingCartDAO.addCartGoods(vo);

			operation = "add";
		} else {
			// 获取已有该商品的数量
			String hasGoodsNum = TypeConvert
					.getStringValue(cartGoods.get(ShoppingCart.goods_number));
			int nowGoodsNum = Integer.parseInt(hasGoodsNum) + Integer.parseInt(goodsNumber);
			// 需验证商品库存是否足够，暂时预留
			// TODO

			if (!"Y".equals(isSKU)) {
				// 非SKU商品时，设置SKU字段为空值，因为数据库空值不占空间，NULL会占空间
				cartGoods.put(ShoppingCart.goods_sku, "");
			}
			cartGoods.put(ShoppingCart.goods_number, nowGoodsNum);
			cartGoods.put(ShoppingCart.update_id, buyerId);
			shoppingCartDAO.updateCartGoods(cartGoods);

			operation = "update";
		}

		return operation;
	}

	/**
	 * 查看购物车中的商品
	 */
	@Override
	public List<Map<String, Object>> queryShoppingCart(Map<String, Object> vo) {

		return shoppingCartDAO.queryShoppingCart(vo);
	}

	/**
	 * 修改购物车中的商品
	 */
	@Override
	public String updateCartGoods(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, ShoppingCart.is_sku, ShoppingCart.cart_id,
				ShoppingCart.goods_id, ShoppingCart.goods_number, ShoppingCart.buyer_id);
		String goodsNumber = TypeConvert.getStringValue(vo.get(ShoppingCart.goods_number));
		if (!NumberUtil.isInteger(goodsNumber, 1)) {
			ExceptionUtil.throwValidateException("商品数量不正确");
		}

		// 先判断该商品是否有SKU属性，有SKU和没有SKU的商品处理逻辑会有所不同
		String isSKU = TypeConvert.getStringValue(vo.get(ShoppingCart.is_sku));
		String cartId = TypeConvert.getStringValue(vo.get(ShoppingCart.cart_id));
		String goodsId = TypeConvert.getStringValue(vo.get(ShoppingCart.goods_id));
		String buyerId = TypeConvert.getStringValue(vo.get(ShoppingCart.buyer_id));

		String operation = null;

		Map<String, Object> cartGoods = null;
		if ("Y".equals(isSKU)) {
			ValidatorUtil.validateMapContainsKey(vo, ShoppingCart.goods_sku);
			String goodsSKU = TypeConvert.getStringValue(vo.get(ShoppingCart.goods_sku));
			cartGoods = shoppingCartDAO.getGoodsBySKU(cartId, goodsId, goodsSKU, buyerId);
		}

		// 判断购物车是否已存在该商品，不存在则验证库存合理之后修改当前记录，存在则在已有记录上修改数量并验证库存合理之后更新，同时删除当前记录
		if (CollectionUtil.isEmptyMap(cartGoods)) {
			// 需验证商品库存是否足够，暂时预留
			// TODO

			if (!"Y".equals(isSKU)) {
				// 非SKU商品时，设置SKU字段为空值，因为数据库空值不占空间，NULL会占空间
				vo.put(ShoppingCart.goods_sku, "");
			}
			vo.put(ShoppingCart.idx, cartId);
			vo.put(ShoppingCart.update_id, buyerId);
			shoppingCartDAO.updateCartGoods(vo);

			operation = "update";
		} else {
			// 获取已有该商品的数量
			String hasGoodsNum = TypeConvert
					.getStringValue(cartGoods.get(ShoppingCart.goods_number));
			int nowGoodsNum = Integer.parseInt(hasGoodsNum) + Integer.parseInt(goodsNumber);

			// 需验证商品库存是否足够，暂时预留
			// TODO

			cartGoods.put(ShoppingCart.update_id, buyerId);
			cartGoods.put(ShoppingCart.goods_number, nowGoodsNum);
			shoppingCartDAO.updateCartGoods(cartGoods);

			// 更新已有商品记录的数量后，删除当前商品记录
			shoppingCartDAO.delete(vo.get(ShoppingCart.cart_id).toString());

			operation = "remove";
		}

		return operation;
	}

	/**
	 * 删除购物车中的商品
	 * 
	 * @param vo
	 * @param userId
	 * @return
	 */
	public int removeCartGoods(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, ShoppingCart.goods_id);
		String deleteIds = TypeConvert.getStringValue(vo.get(ShoppingCart.goods_id));
		List<String> listIds = JSONArray.parseArray(deleteIds, String.class);
		if (listIds.isEmpty()) {
			ExceptionUtil.throwValidateException("商品ID为空");
		}
		return shoppingCartDAO.removeCartGoods(listIds);
	}
}
