package cn.com.ut.biz.valuableinfo.service;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 分成信息
 * 
 * @author lanbin
 * @date 2017-12-27
 */
public interface SharinginfoService {

	/**
	 * 获取订单分成信息
	 * 
	 * @param orderId
	 * @return
	 */
	List<Map<String, Object>> getSharinginfo(String orderId);

	/**
	 * 查询分成信息列表
	 * 
	 * @param page
	 * @param sharer
	 * @return
	 */
	List<Map<String, Object>> listSharinginfo(PageBean page, String sharer);

	/**
	 * 创建分成信息
	 * 
	 * @param vo
	 * @return
	 */
	String createSharinginfoOld(Map<String, Object> vo);

	/**
	 * 获取订单分成信息
	 * 
	 * @param orderId
	 * @return
	 */
	List<Map<String, Object>> getOrderSharinginfo(String orderId);

	/**
	 * 获取订单的总价
	 * 
	 * @param orderId
	 * @return
	 */
	Object getOrderTotalSharinginfo(String orderId);

	void createSharinginfo(JSONObject jo);

	/**
	 * 查询结算分成总数和最新数据（可根据传入num设置显示最新的多少条数据）
	 * 
	 * @param num
	 * @return
	 */
	Map<String, Object> queryTopSharingInfo(Map<String, Object> vo);

	/**
	 * 查询结算分成分页列表
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findSettlementPage(PageBean page);

	/**
	 * 根据传播人ID查询详细分成记录列表
	 * 
	 * @param sharer
	 * @return
	 */
	List<Map<String, Object>> findSettlementDetails(PageBean page, String sharer);
}
