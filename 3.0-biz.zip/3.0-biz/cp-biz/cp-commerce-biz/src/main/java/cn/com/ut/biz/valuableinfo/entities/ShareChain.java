package cn.com.ut.biz.valuableinfo.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 传播链
 * 
 * @author ouyuexing
 *
 */
public class ShareChain extends BaseEntity {

	private static final long serialVersionUID = 8643145529118226226L;

	public static final String entityinfo_content_id = "entityinfo_content_id";

	/**
	 * 父传播链 ID
	 */
	public static final String parent_id = "parent_id";
	/**
	 * 传播链ID
	 */
	public static final String share_chain_id = "share_chain_id";
	/**
	 * 分享者
	 */
	public static final String sharer = "sharer";
	/**
	 * 接收者
	 */
	public static final String receiver = "receiver";

}
