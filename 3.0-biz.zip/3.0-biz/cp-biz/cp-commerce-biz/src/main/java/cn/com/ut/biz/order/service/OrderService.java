package cn.com.ut.biz.order.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

public interface OrderService {

	/**
	 * 创建订单(同时插入订单表和订单商品表)
	 * @param vo TODO
	 * 
	 * @return
	 */
	Map<String, Object> createOrder(Map<String, Object> vo);

	/**
	 * 查看订单列表
	 * 
	 * @param vo
	 *            商品ID
	 * @param page TODO
	 * @return
	 */
	List<Map<String, Object>> queryOrder(Map<String, Object> vo, PageBean page);

	/**
	 * 更新订单支付状态
	 * 
	 * @param vo
	 */
	void notifyPayStatus(Map<String, Object> vo);
	
	/**
	 * 查询订单详情
	 * 
	 * @param orderCode
	 *            订单id
	 * @return
	 */
	Map<String, Object> getOrderDetail(Map<String, Object> vo);

	void shareChainCheck(String shareChainId, String goodsId);
}