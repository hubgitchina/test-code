package cn.com.ut.biz.goods.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 商品收藏表实体类(t_cs_goods_collection)
 * 
 * @author wangpeng1
 * @since 2018年1月24日
 */
public class GoodsCollection extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * 商品ID
	 */
	public static final String goods_id = "goods_id";
	/**
	 * 用户ID
	 */
	public static final String user_id = "user_id";
	/**
	 * 商品所属店铺ID
	 */
	public static final String shop_id = "shop_id";

}
