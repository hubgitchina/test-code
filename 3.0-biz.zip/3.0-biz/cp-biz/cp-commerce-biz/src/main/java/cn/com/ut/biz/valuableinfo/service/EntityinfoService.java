package cn.com.ut.biz.valuableinfo.service;

import java.util.Map;

/**
 * 实体信息服务层，包括实体信息内容
 * 
 * @author lanbin
 * @date 2017-12-27
 */
public interface EntityinfoService {

	/**
	 * 创建实体信息内容
	 * 
	 * @param vo
	 * @return
	 */
	String createEntityinfoContent(Map<String, Object> vo);

	/**
	 * 绑定商品结算规则
	 * 
	 * @param vo
	 * @return
	 */
	void bindCheckoutRule(Map<String, Object> vo);

	/**
	 * 获取商品结算规则
	 * 
	 * @param goodsId
	 * @return
	 */
	Map<String, Object> getCheckoutRule(String goodsId);
}
