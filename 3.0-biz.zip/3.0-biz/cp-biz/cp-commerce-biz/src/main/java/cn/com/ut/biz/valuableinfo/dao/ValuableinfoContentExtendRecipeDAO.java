package cn.com.ut.biz.valuableinfo.dao;


import cn.com.ut.biz.valuableinfo.entities.ValuableinfoContentExtendRecipe;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 有价信息内容扩展 - 电子菜谱
 * 
 * @author ouyuexing
 *
 */
public interface ValuableinfoContentExtendRecipeDAO
		extends JdbcOperation<ValuableinfoContentExtendRecipe> {

}
