package cn.com.ut.biz.goods.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.goods.dao.GoodsCollectionDAO;
import cn.com.ut.biz.goods.entities.GoodsCollection;
import cn.com.ut.biz.goods.service.GoodsCollectionService;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.converter.DateTimeUtil;
import cn.com.ut.core.common.util.converter.TypeConvert;
import cn.com.ut.core.common.util.validator.ValidatorUtil;

@Service
public class GoodsCollectionServiceImpl implements GoodsCollectionService {

	@Autowired
	private GoodsCollectionDAO goodsCollectionDAO;

	/**
	 * 收藏购物车中的商品
	 */
	@Override
	public int[] collectCartGoods(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, GoodsCollection.user_id, "goods_info");
		String userId = TypeConvert.getStringValue(vo.get(GoodsCollection.user_id));
		String goodsInfo = TypeConvert.getStringValue(vo.get("goods_info"));
		JSONArray goodsArray = JSONObject.parseArray(goodsInfo);
		if (goodsArray.isEmpty()) {
			ExceptionUtil.throwValidateException("商品信息为空");
		}

		List<Map<String, Object>> goodsList = new ArrayList<>(goodsArray.size());
		for (int i = 0; i < goodsArray.size(); i++) {
			JSONObject goods = goodsArray.getJSONObject(i);

			Map<String, Object> colGoods = new HashMap<>(2);
			String goodsId = goods.getString("goods_id");
			if (CommonUtil.isEmpty(goodsId)) {
				ExceptionUtil.throwRuntimeException("商品ID不能为空");
			}
			// 验证当前用户是否已收藏该商品，存在则跳过
			boolean isHasGoods = goodsCollectionDAO.checkUnique(
					new String[] { GoodsCollection.goods_id, GoodsCollection.user_id },
					new Object[] { goodsId, userId }, null, null);
			if (isHasGoods) {
				String shopId = goods.getString("shop_id");
				colGoods.put(GoodsCollection.idx, CommonUtil.getUUID());
				colGoods.put(GoodsCollection.goods_id, goodsId);
				colGoods.put(GoodsCollection.shop_id, shopId);
				colGoods.put(GoodsCollection.user_id, userId);
				colGoods.put(GoodsCollection.create_id, userId);
				colGoods.put(GoodsCollection.create_time, DateTimeUtil.currentDateTime());
				goodsList.add(colGoods);
			}
		}

		if (goodsList.isEmpty()) {
			return new int[0];
		} else {
			return goodsCollectionDAO.collectCartGoods(goodsList);
		}
	}
}
