package cn.com.ut.biz.valuableinfo.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 有价信息内容扩展 - 电子菜谱
 * 
 * @author ouyuexing
 *
 */
public class ValuableinfoContentExtendRecipe extends BaseEntity {

	private static final long serialVersionUID = 8643145529118226226L;

	/**
	 * 有价信息内容ID
	 */
	public static final String valuableinfo_content_id = "valuableinfo_content_id";

	/**
	 * 电子菜谱ID
	 */
	public static final String recipe_id = "recipe_id";

	/**
	 * 电子菜谱名称
	 */
	public static final String recipe_name = "recipe_name";

	/**
	 * 电子菜谱描述
	 */
	public static final String recipe_desc = "recipe_desc";

}
