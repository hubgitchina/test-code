package cn.com.ut.biz.goods.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.goods.dao.GoodsCollectionDAO;
import cn.com.ut.biz.goods.entities.GoodsCollection;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

@Repository
public class GoodsCollectionDAOImpl extends JdbcOperationsImpl<GoodsCollection>
		implements GoodsCollectionDAO {

	/**
	 * 收藏购物车中的商品
	 */
	@Override
	public int[] collectCartGoods(List<Map<String, Object>> vos) {

		String[] names = new String[] { GoodsCollection.goods_id, GoodsCollection.user_id,
				GoodsCollection.shop_id };
		return addVoBatch(null, names, NAMES_ID_CT_CID, vos);
	}
}
