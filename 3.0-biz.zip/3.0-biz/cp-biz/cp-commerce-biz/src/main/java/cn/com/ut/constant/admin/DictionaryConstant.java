package cn.com.ut.constant.admin;

/**
 * 字典数据常量
 * 
 * @author wuxiaohua
 * @since 2015-6-17
 * @update 2015-6-17
 */
public class DictionaryConstant {

}
