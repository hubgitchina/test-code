package cn.com.ut.constant.admin;

/**
 * 常量工具类
 * 
 * @author wuxiaohua
 * @since 2013-10-10
 * @update 2015-12-4
 *
 */
public class ConstantUtil {

	/**
	 * 其他标识:Y
	 */
	public static final String FLAG_YES = "Y";
	/**
	 * 其他标识:N
	 */
	public static final String FLAG_NO = "N";

	/**
	 * 会话标识
	 */
	public static final String SESSIONKEY = "sessionKey";
	
	
	/**
	 * 会话失效，请重新登录
	 */
	public static final String ERR_SESSION_EXPIRE = "会话失效，请重新登录!";

}
