package cn.com.ut.biz.valuableinfo.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 实体信息内容
 * 
 * @author ouyuexing
 *
 */
public class EntityinfoContent extends BaseEntity {

	private static final long serialVersionUID = 8643145529118226226L;

	/**
	 * 有价信息实体ID
	 */
	public static final String valuableinfo_body_id = "valuableinfo_body_id";

	/**
	 * 商品ID
	 */
	public static final String goods_id = "goods_id";

	/**
	 * 结算规则ID
	 */
	public static final String checkout_rule_id = "checkout_rule_id";

}
