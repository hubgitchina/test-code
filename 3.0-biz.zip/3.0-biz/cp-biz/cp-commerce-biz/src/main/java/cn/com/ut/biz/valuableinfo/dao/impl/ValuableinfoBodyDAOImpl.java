package cn.com.ut.biz.valuableinfo.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.google.common.collect.Maps;

import cn.com.ut.biz.valuableinfo.dao.ValuableinfoBodyDAO;
import cn.com.ut.biz.valuableinfo.entities.ValuableinfoBody;
import cn.com.ut.constant.admin.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

/**
 * 有价信息体
 * 
 * @author ouyuexing
 *
 */
@Repository
public class ValuableinfoBodyDAOImpl extends JdbcOperationsImpl<ValuableinfoBody>
		implements ValuableinfoBodyDAO {

	String[] COLUMNS = { ValuableinfoBody.business_type, ValuableinfoBody.creator };

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

	@Override
	public Map<String, Object> getById(String id) {

		StringBuffer table = new StringBuffer();
		table.append("t_vi_valuableinfo_body vb ")
				.append("LEFT JOIN t_vi_valuableinfo_content vc ON vc.valuableinfo_body_id = vb.id ")
				.append(" LEFT JOIN t_vi_valuableinfo_content_extend_recipe vcr ON vcr.valuableinfo_content_id = vc.id");
		return getByKey(null, table.toString(),
				new String[] { "vb.business_type", "vb.id", "vc.default_price",
						"vc.default_checkout_rule", "vcr.recipe_desc" },
				null, new String[] { "vb.id" }, new Object[] { id }, cachedParameter);
	}

	@Override
	public Map<String, Object> queryTopValuableInfo(int num) {

		long totalV = count(null, null, null, null);

		if (num <= 0) {
			num = 5;
		} else if (num > 10) {
			num = 10;
		}
		String sql = "select vb.id, vb.business_type, vb.creator, vb.create_time, g.goods_name from t_vi_valuableinfo_body vb left join t_vi_entityinfo_content ec on vb.id = ec.valuableinfo_body_id left join t_cs_goods g on ec.goods_id = g.id where vb.is_del=? AND ec.is_del=? AND g.is_del=? order by vb.create_time desc limit ?";
		List<Map<String, Object>> valuableList = queryForList(getJdbcTemplate(), sql,
				ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO, num);

		Map<String, Object> map = Maps.newHashMapWithExpectedSize(2);
		map.put("totalV", totalV);
		map.put("homeV", valuableList);

		return map;
	}

	@Override
	public List<Map<String, Object>> findValuablePage(PageBean page) {

		StringBuffer table = new StringBuffer();
		String[] selectColumnArray = new String[] { "vb.id", "vb.business_type", "vb.creator",
				"g.goods_name", "vb.create_time" };
		table.append("t_vi_valuableinfo_body vb ")
				.append("left join t_vi_entityinfo_content ec on vb.id = ec.valuableinfo_body_id ")
				.append("left join t_cs_goods g on ec.goods_id = g.id");
		return queryPage(page, null, table.toString(), false, selectColumnArray, null,
				new String[] { "vb.is_del", "ec.is_del", "g.is_del" }, null, null, null,
				new Object[] { ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO, ConstantUtil.FLAG_NO });
	}
}
