package cn.com.ut.biz.shoppingcart.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.shoppingcart.entities.ShoppingCart;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 购物车DAO层
 * 
 * @author wangpeng1
 * @since 2018年1月24日
 */
public interface ShoppingCartDAO extends JdbcOperation<ShoppingCart> {

	/**
	 * 添加商品到购物车 （同一商品不同SKU视为多条商品加入购物车）
	 * 
	 * @param vo
	 * @return
	 */
	String addCartGoods(Map<String, Object> vo);

	/**
	 * 查看购物车中的商品
	 * 
	 * @param vo
	 * @return
	 */
	List<Map<String, Object>> queryShoppingCart(Map<String, Object> vo);

	/**
	 * 修改购物车中的商品
	 * 
	 * @param vo
	 * @param userId
	 * @return
	 */
	int updateCartGoods(Map<String, Object> vo);

	/**
	 * 删除购物车中的商品
	 * 
	 * @param shoppingCartIds
	 * @return
	 */
	int removeCartGoods(List<String> shoppingCartIds);

	/**
	 * 查找非SKU商品
	 * 
	 * @param goodsId
	 * @param buyerId
	 * @param shopId
	 * @return
	 */
	Map<String, Object> getGoodsNoSKU(String shoppingCartId, String goodsId, String buyerId);

	/**
	 * 查找SKU商品
	 * 
	 * @param goodsId
	 * @param goodsSKU
	 * @param buyerId
	 * @param shopId
	 * @return
	 */
	Map<String, Object> getGoodsBySKU(String shoppingCartId, String goodsId, String goodsSKU,
			String buyerId);

}
