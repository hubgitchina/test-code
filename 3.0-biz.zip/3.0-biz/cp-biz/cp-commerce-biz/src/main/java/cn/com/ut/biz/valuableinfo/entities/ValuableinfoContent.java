package cn.com.ut.biz.valuableinfo.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 有价信息内容
 * 
 * @author ouyuexing
 *
 */
public class ValuableinfoContent extends BaseEntity {

	private static final long serialVersionUID = 8643145529118226226L;

	/**
	 * 有价信息内容表主键
	 */
	public static final String valuableinfo_body_id = "valuableinfo_body_id";

	/**
	 * 默认价格
	 */
	public static final String default_price = "default_price";

	/**
	 * 默认规则
	 */
	public static final String default_checkout_rule = "default_checkout_rule";

}
