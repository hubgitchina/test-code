package cn.com.ut.biz.order.dao.impl;

import java.sql.Timestamp;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.com.ut.biz.order.dao.OrderDAO;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;

@Repository
public class OrderDAOImpl extends JdbcOperationsImpl<Order> implements OrderDAO {

	/**
	 * 创建订单
	 */
	@Override
	public String addOrder(Map<String, Object> vo) {

		String id = CommonUtil.getUUID();
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());

		String[] names = { Order.idx, Order.order_code, Order.order_amount, Order.buyer_id,
				Order.seller_id, Order.create_time, Order.create_id, Order.update_time,
				Order.update_id, Order.deal_status, Order.deal_time, Order.share_chain_id };

		add(null, names, null,
				new Object[] { id, vo.get(Order.order_code), vo.get(Order.order_amount),
						vo.get(Order.buyer_id), vo.get(Order.seller_id), currentTime,
						vo.get(Order.create_id), currentTime, vo.get(Order.create_id),
						vo.get(Order.deal_status), currentTime, vo.get(Order.share_chain_id) });

		return id;
	}

	/**
	 * 查看订单详情
	 */
	@Override
	public Map<String, Object> getByOrderId(String orderId) {

		return getById(null, null, new String[] { Order.order_code, Order.order_amount,
				Order.buyer_id, Order.deal_time, Order.deal_status }, null, orderId);
	}

	/**
	 * 根据order_code和deal_status更新订单支付状态
	 */
	@Override
	public int updateOrderStatus(String orderCode, int dealStatus) {

		return update(null, new String[] { Order.deal_status, Order.update_time }, null, null,
				new String[] { Order.order_code }, null, null,
				new Object[] { dealStatus, new Timestamp(System.currentTimeMillis()) },
				new Object[] { orderCode }, null);
	}

	/**
	 * 根据order_code更新订单支付状态
	 */
	@Override
	public int updateByOrderCode(Map<String, Object> vo) {

		return update(null,
				new String[] { Order.deal_status, Order.pay_time, Order.pay_no, Order.update_time },
				null, null, new String[] { Order.order_code }, null, null,
				new Object[] { vo.get(Order.deal_status), vo.get(Order.pay_time),
						vo.get(Order.pay_no), vo.get(Order.update_time) },
				new Object[] { vo.get(Order.order_code) }, null);
	}

	/**
	 * 根据order_code查询订单支付信息
	 */
	@Override
	public Map<String, Object> getByOrderCode(String orderCode) {

		return getByKey(null, null,
				new String[] { Order.idx, Order.order_code, Order.order_amount, Order.buyer_id,
						Order.deal_time, Order.deal_status, Order.pay_time, Order.pay_way },
				null, new String[] { Order.order_code }, new Object[] { orderCode }, null);
	}

	/**
	 * 根据订单编码获取订单信息
	 */
	@Override
	public Map<String, Object> getOrderCode(String orderCode) {

		return getByKey(null, null,
				new String[] { "order_code as order_id", Order.order_amount, Order.buyer_id,
						Order.deal_time, Order.deal_status },
				null, new String[] { Order.order_code }, new Object[] { orderCode }, null);
	}

}
