package cn.com.ut.biz.valuableinfo.dao;


import cn.com.ut.biz.valuableinfo.entities.EntityinfoContent;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 实体信息内容
 * 
 * @author ouyuexing
 *
 */
public interface EntityinfoContentDAO extends JdbcOperation<EntityinfoContent> {

}
