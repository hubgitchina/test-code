package cn.com.ut.biz.order.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 订单商品信息 t_cs_order_goods
 * 
 * @author gaolei
 * @since 2017年12月26日
 */
public class OrderGoods extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * 订单编号
	 */
	public static final String order_id = "order_id";
	/**
	 * 商品价格
	 */
	public static final String goods_price = "goods_price";
	/**
	 * 数量
	 */
	public static final String goods_number = "goods_number";
	/**
	 * 商品ID
	 */
	public static final String goods_id = "goods_id";
}
