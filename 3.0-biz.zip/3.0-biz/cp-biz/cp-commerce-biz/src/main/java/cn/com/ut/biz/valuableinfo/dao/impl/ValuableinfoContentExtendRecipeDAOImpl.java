package cn.com.ut.biz.valuableinfo.dao.impl;

import cn.com.ut.biz.valuableinfo.dao.ValuableinfoContentExtendRecipeDAO;
import cn.com.ut.biz.valuableinfo.entities.ValuableinfoContentExtendRecipe;
import cn.com.ut.core.dal.jdbc.JdbcOperationsImpl;
import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * 有价信息内容扩展 - 电子菜谱
 * 
 * @author ouyuexing
 *
 */
@Repository
public class ValuableinfoContentExtendRecipeDAOImpl
		extends JdbcOperationsImpl<ValuableinfoContentExtendRecipe>
		implements ValuableinfoContentExtendRecipeDAO {

	String[] COLUMNS = { ValuableinfoContentExtendRecipe.recipe_desc,
			ValuableinfoContentExtendRecipe.recipe_id, ValuableinfoContentExtendRecipe.recipe_name,
			ValuableinfoContentExtendRecipe.valuableinfo_content_id};

	@Override
	public String add(Map<String, Object> vo) {

		return add(COLUMNS, vo);
	}

	@Override
	public int update(Map<String, Object> vo) {

		return update(COLUMNS, vo);
	}

}
