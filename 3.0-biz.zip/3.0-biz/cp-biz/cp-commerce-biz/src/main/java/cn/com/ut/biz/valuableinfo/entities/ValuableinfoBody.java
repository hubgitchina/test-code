package cn.com.ut.biz.valuableinfo.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 有价信息体
 * 
 * @author ouyuexing
 *
 */
public class ValuableinfoBody extends BaseEntity {

	private static final long serialVersionUID = 8643145529118226226L;

	/**
	 * 业务类型
	 */
	public static final String business_type = "business_type";

	/**
	 * 创作者
	 */
	public static final String creator = "creator";

}
