package cn.com.ut.biz.valuableinfo.service;

import java.util.List;
import java.util.Map;

import cn.com.ut.core.common.jdbc.PageBean;

/**
 * 交易信息
 * 
 * @author lanbin
 * @since 2017/12/25
 */
public interface TradeinfoService {

	/**
	 * 获取交易信息
	 * 
	 * @param id
	 * @return
	 */
	Map<String, Object> getTradeinfo(String id);

	/**
	 * 创建交易
	 * 
	 * @param vo
	 * @return
	 */
	String createTradeinfo(Map<String, Object> vo);

	/**
	 * 查询交易
	 * 
	 * @param pageBean
	 * @param id
	 * @return
	 */
	List<Map<String, Object>> findTradeinfo(PageBean pageBean, String id);

	void createTradeinfoByOrder(String orderId);

	/**
	 * 查询传播成交商品总数和最新数据（可根据传入num设置显示最新的多少条数据）
	 * 
	 * @param num
	 * @return
	 */
	Map<String, Object> queryTopTradeInfo(Map<String, Object> vo);

	/**
	 * 查询传播链成交商品分页列表
	 * 
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> findTradeGoodsPage(PageBean page);
}
