package cn.com.ut.biz.order.dao;

import java.util.Map;

import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 订单信息表
 * 
 * @author gaolei
 * @since 2017年12月26日
 */
public interface OrderDAO extends JdbcOperation<Order> {

	/**
	 * 创建订单
	 * 
	 * @param vo
	 * @return
	 */
	String addOrder(Map<String, Object> vo);

	/**
	 * 查看订单详情
	 * 
	 * @param orderId
	 *            订单ID
	 * @return
	 */
	Map<String, Object> getByOrderId(String orderId);

	/**
	 * 根据order_code更新订单支付状态
	 * 
	 * @param orderCode
	 * @param dealStatus
	 */
	int updateOrderStatus(String orderCode, int dealStatus);

	/**
	 * 根据order_code更新订单支付状态
	 * 
	 * @param vo
	 * @return
	 */
	int updateByOrderCode(Map<String, Object> vo);

	/**
	 * 根据order_code查询订单详情
	 * 
	 * @param orderCode
	 * @return
	 */
	Map<String, Object> getByOrderCode(String orderCode);

	/**
	 * 根据订单编码获取订单信息
	 * 
	 * @param orderCode
	 * @return
	 */
	Map<String, Object> getOrderCode(String orderCode);

}
