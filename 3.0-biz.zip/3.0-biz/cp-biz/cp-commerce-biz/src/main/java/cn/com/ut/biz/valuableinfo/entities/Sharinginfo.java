package cn.com.ut.biz.valuableinfo.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 分成信息
 * 
 * @author ouyuexing
 *
 */
public class Sharinginfo extends BaseEntity {

	private static final long serialVersionUID = 8643145529118226226L;

	/**
	 * 交易信息ID
	 */
	public static final String tradeinfo_id = "tradeinfo_id";

	/**
	 * 传播者用户ID
	 */
	public static final String sharer = "sharer";

	/**
	 * 分成金额
	 */
	public static final String amount = "amount";

	/**
	 * 支付方式
	 */
	public static final String pay_type = "pay_type";

}
