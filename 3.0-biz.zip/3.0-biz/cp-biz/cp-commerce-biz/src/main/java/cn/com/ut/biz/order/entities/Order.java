package cn.com.ut.biz.order.entities;

import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 订单信息表 t_cs_order
 * 
 * @author gaolei
 * @since 2017年12月26日
 */
public class Order extends BaseEntity {

	private static final long serialVersionUID = 1L;

	/**
	 * 订单编号
	 */
	public static final String order_code = "order_code";
	/**
	 * 订单金额
	 */
	public static final String order_amount = "order_amount";
	/**
	 * 买家
	 */
	public static final String buyer_id = "buyer_id";
	/**
	 * 商家
	 */
	public static final String seller_id = "seller_id";
	/**
	 * 交易状态
	 */
	public static final String deal_status = "deal_status";
	/**
	 * 交易时间
	 */
	public static final String deal_time = "deal_time";
	/**
	 * 传播链ID
	 */
	public static final String share_chain_id = "share_chain_id";
	/**
	 * 支付流水号
	 */
	public static final String pay_no = "pay_no";
	/**
	 * 支付方式（0微信、1支付宝、2银联）
	 */
	public static final String pay_way = "pay_way";
	/**
	 * 支付时间
	 */
	public static final String pay_time = "pay_time";

}
