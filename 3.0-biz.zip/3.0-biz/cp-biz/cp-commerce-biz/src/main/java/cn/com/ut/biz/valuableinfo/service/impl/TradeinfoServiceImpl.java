package cn.com.ut.biz.valuableinfo.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Sets;

import cn.com.ut.biz.order.dao.OrderDAO;
import cn.com.ut.biz.order.dao.OrderGoodsDAO;
import cn.com.ut.biz.order.entities.Order;
import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.biz.settlement.service.SettlementRemoteService;
import cn.com.ut.biz.user.service.UserRemoteService;
import cn.com.ut.biz.valuableinfo.dao.EntityinfoContentDAO;
import cn.com.ut.biz.valuableinfo.dao.ShareChainDAO;
import cn.com.ut.biz.valuableinfo.dao.TradeinfoDAO;
import cn.com.ut.biz.valuableinfo.entities.EntityinfoContent;
import cn.com.ut.biz.valuableinfo.entities.ShareChain;
import cn.com.ut.biz.valuableinfo.entities.Tradeinfo;
import cn.com.ut.biz.valuableinfo.service.TradeinfoService;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;

/**
 * 交易信息服务层，包括交易信息
 * 
 * @author lanbin
 * @since 2017/12/25
 */
@Service
public class TradeinfoServiceImpl implements TradeinfoService {

	@Autowired
	private TradeinfoDAO tradeinfoDAO;
	@Autowired
	private ShareChainDAO shareChainDAO;
	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private EntityinfoContentDAO entityinfoContentDAO;
	@Autowired
	private OrderGoodsDAO orderGoodsDAO;
	@Autowired
	private SettlementRemoteService settlementRemoteService;

	@Autowired
	private ThreadPoolTaskExecutor taskExecutor;

	@Autowired
	private UserRemoteService userRemoteService;

	@Override
	public Map<String, Object> getTradeinfo(String id) {

		return tradeinfoDAO.get(id);
	}

	/**
	 * 订单支付成功后，创建交易记录，通知结算规则平台进行结算分成
	 * 
	 * @param orderId
	 */
	@Override
	@Transactional
	public void createTradeinfoByOrder(String orderId) {

		// 传播链为0的记录表示分享着自己下单，不需要进行结算分成
		Map<String, Object> orderVo = orderDAO.get(orderId);
		if ("0".equals(orderVo.get(Order.share_chain_id))) {
			return;
		}

		List<Map<String, Object>> settlementVos = createTradeinfoByOrderCommit(orderVo);
		settlement(settlementVos);

	}

	/**
	 * 通知结算平台
	 * 
	 * @param settlementVos
	 */
	private void settlement(List<Map<String, Object>> settlementVos) {

		if (CollectionUtil.isEmptyCollection(settlementVos))
			return;

		for (Map<String, Object> settlementVo : settlementVos)
			// 通知结算规则平台进行结算分成
			taskExecutor.execute(new Runnable() {

				@Override
				public void run() {

					settlementRemoteService.submitTradeShare(settlementVo);

				}
			});
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public List<Map<String, Object>> createTradeinfoByOrderCommit(Map<String, Object> orderVo) {

		List<Map<String, Object>> settlementVos = new ArrayList<>();
		String orderId = (String) orderVo.get(BaseEntity.idx);
		// 查询订单商品，目前只有一个商品
		List<Map<String, Object>> goodsVos = orderGoodsDAO.query(null, null, null, null, null,
				new String[] { OrderGoods.order_id }, new Object[] { orderId });
		for (Map<String, Object> goodsVo : goodsVos) {

			String goodsId = (String) goodsVo.get(OrderGoods.goods_id);

			// 获取有价信息实体
			Map<String, Object> entityinfoContentVo = entityinfoContentDAO.getByProperties(
					new String[] { EntityinfoContent.goods_id }, new Object[] { goodsId });
			if (CollectionUtil.isEmptyMap(entityinfoContentVo)
					|| entityinfoContentVo.get(EntityinfoContent.checkout_rule_id) == null) {
				// ExceptionUtil.throwValidateException("有价信息实体不存在");
				return settlementVos;
			}

			Map<String, Object> tradeinfoVo = new HashMap<String, Object>();
			tradeinfoVo.put(Tradeinfo.amount,
					new BigDecimal((int) goodsVo.get(OrderGoods.goods_number))
							.multiply((BigDecimal) goodsVo.get(OrderGoods.goods_price)));
			tradeinfoVo.put(Tradeinfo.buyer, orderVo.get(Order.buyer_id));
			tradeinfoVo.put(Tradeinfo.entityinfo_content_id,
					entityinfoContentVo.get(BaseEntity.idx));
			tradeinfoVo.put(Tradeinfo.order_id, orderId);
			tradeinfoVo.put(Tradeinfo.share_chain_end_id, orderVo.get(Order.share_chain_id));

			// 判断是否已经创建过交易记录
			boolean isExistOrderId = tradeinfoDAO.checkUnique(
					new String[] { Tradeinfo.order_id, Tradeinfo.share_chain_end_id,
							Tradeinfo.entityinfo_content_id, Tradeinfo.buyer },
					new Object[] { orderId, tradeinfoVo.get(Tradeinfo.share_chain_end_id),
							tradeinfoVo.get(Tradeinfo.entityinfo_content_id),
							tradeinfoVo.get(Tradeinfo.buyer) },
					null, null);

			if (!isExistOrderId) {
				ExceptionUtil.throwValidateException("已存在交易信息！");
			}

			String tradeinfoId = tradeinfoDAO.add(tradeinfoVo);

			// 根据传播ID获取交易参与者用户ID集合
			List<Map<String, Object>> sharerIds = shareChainDAO
					.findTradeSuccessSharer((String) orderVo.get(Order.share_chain_id));
			List<String> sharers = CollectionUtil.listManyToOne(sharerIds, "sharer");

			Map<String, Object> checkoutVo = new HashMap<>();
			checkoutVo.put("goods_id", goodsId);
			checkoutVo.put("rule_id", Long.parseLong(
					(String) entityinfoContentVo.get(EntityinfoContent.checkout_rule_id)));
			checkoutVo.put("amount", tradeinfoVo.get(Tradeinfo.amount));
			checkoutVo.put("chain", sharers);
			checkoutVo.put("tradeinfo_id", tradeinfoId);
			settlementVos.add(checkoutVo);

		}

		return settlementVos;
	}

	@Override
	public String createTradeinfo(Map<String, Object> vo) {

		ValidatorUtil.validateMapContainsKey(vo, "goods_id", Tradeinfo.share_chain_end_id,
				Tradeinfo.buyer, Tradeinfo.amount, Tradeinfo.order_id);

		if (!NumberUtil.isDecimal(vo.get(Tradeinfo.amount).toString(), false, 10, 2)) {
			ExceptionUtil.throwValidateException("成交金额格式不正确");
		}

		String goodsId = (String) vo.get("goods_id");
		Map<String, Object> entityinfoContentVo = entityinfoContentDAO.getByProperties(
				new String[] { EntityinfoContent.goods_id }, new Object[] { goodsId });
		if (CollectionUtil.isEmptyMap(entityinfoContentVo)) {
			ExceptionUtil.throwValidateException("有价信息实体不存在");
		}
		vo.put(Tradeinfo.entityinfo_content_id, entityinfoContentVo.get(BaseEntity.idx));

		boolean noSuchShareChainEndId = shareChainDAO.checkUnique(
				new String[] { ShareChain.share_chain_id },
				new Object[] { vo.get(Tradeinfo.share_chain_end_id) }, null, null);
		if (noSuchShareChainEndId) {
			ExceptionUtil.throwValidateException("传播链ID不存在");
		}

		boolean noSuchOrderId = orderDAO.checkUnique(new String[] { Order.order_code },
				new Object[] { vo.get(Tradeinfo.order_id) }, null, null);
		if (noSuchOrderId) {
			ExceptionUtil.throwValidateException("订单不存在");
		}

		boolean isExistOrderId = tradeinfoDAO.checkUnique(
				new String[] { Tradeinfo.order_id, Tradeinfo.share_chain_end_id,
						Tradeinfo.entityinfo_content_id, Tradeinfo.buyer },
				new Object[] { vo.get(Tradeinfo.order_id), vo.get(Tradeinfo.share_chain_end_id),
						vo.get(Tradeinfo.entityinfo_content_id), vo.get(Tradeinfo.buyer) },
				null, null);

		if (!isExistOrderId) {
			ExceptionUtil.throwValidateException("已存在交易信息！");
		}

		vo.put("create_id", vo.get("user_id"));
		return tradeinfoDAO.add(vo);
	}

	@Override
	public List<Map<String, Object>> findTradeinfo(PageBean pageBean, String id) {

		return tradeinfoDAO.findTradeinfo(pageBean, id);
	}

	@Override
	public Map<String, Object> queryTopTradeInfo(Map<String, Object> vo) {

		int num = 0;
		if (vo != null && vo.get("num") != null) {
			num = Integer.parseInt(vo.get("num").toString());
		}

		Map<String, Object> tradeMap = tradeinfoDAO.queryTopTradeInfo(num);
		List<Map<String, Object>> tradeList = (ArrayList) tradeMap.get("homeT");
		if (!CollectionUtil.isEmptyCollection(tradeList)) {
			Set<String> sharerIdSet = Sets.newHashSetWithExpectedSize(tradeList.size());
			for (Map<String, Object> map : tradeList) {
				sharerIdSet.add(String.valueOf(map.get("buyer")));
			}
			List<Map<String, Object>> userList = userRemoteService.getUserName(sharerIdSet);
			if (CollectionUtil.isEmptyCollection(userList)) {
				ExceptionUtil.throwServiceException("用户信息异常");
			}
			for (Map<String, Object> map : tradeList) {
				for (Map<String, Object> userMap : userList) {
					String buyerId = (String) map.get("buyer");
					String userId = (String) userMap.get("user_id");
					if (buyerId.equals(userId)) {
						String userName = (String) userMap.get("user_name");
						map.put("buyer_name", userName);
					}
				}
			}
		}
		return tradeMap;
	}

	@Override
	public List<Map<String, Object>> findTradeGoodsPage(PageBean page) {

		return tradeinfoDAO.findTradeGoodsPage(page);
	}
}
