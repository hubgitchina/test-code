package cn.com.ut.biz.valuableinfo.dao;


import cn.com.ut.biz.valuableinfo.entities.ValuableinfoContent;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 有价信息内容
 * 
 * @author ouyuexing
 *
 */
public interface ValuableinfoContentDAO extends JdbcOperation<ValuableinfoContent> {

}
