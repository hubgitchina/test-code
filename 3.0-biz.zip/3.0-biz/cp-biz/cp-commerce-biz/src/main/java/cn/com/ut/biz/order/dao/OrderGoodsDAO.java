package cn.com.ut.biz.order.dao;

import java.util.List;
import java.util.Map;

import cn.com.ut.biz.order.entities.OrderGoods;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.dal.jdbc.JdbcOperation;

/**
 * 
 * @author gaolei
 * @since 2017年12月27日
 */
public interface OrderGoodsDAO extends JdbcOperation<OrderGoods> {

	/**
	 * 创建订单商品信息
	 */
	String addOrderGoods(Map<String, Object> vo);

	/**
	 * 查看订单列表
	 */
	List<Map<String, Object>> listOrderGoods(String goodsId, PageBean page);

	/**
	 * 查询订单详情
	 * 
	 * @param orderCode
	 *            订单id
	 * @return
	 */
	Map<String, Object> getByOrderId(String orderCode);
}
