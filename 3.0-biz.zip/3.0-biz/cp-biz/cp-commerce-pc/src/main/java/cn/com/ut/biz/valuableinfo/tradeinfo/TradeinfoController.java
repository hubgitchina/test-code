package cn.com.ut.biz.valuableinfo.tradeinfo;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.valuableinfo.service.TradeinfoService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 交易信息（为其他平台提供的对外服务接口）
 * 
 * @author wangpeng1
 * @since 2017年12月20日
 */
@RestController
@RequestMapping(value = "/tradeinfo")
public class TradeinfoController {

	@Autowired
	private TradeinfoService tradeinfoService;

	/**
	 * 创建交易信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/createTradeinfo")
	@ServiceComponent(session = false)
	public ResponseWrap createTradeinfo(@RequestBody ResponseWrap responseWrap) {

		tradeinfoService.createTradeinfo(responseWrap.getJson());
		return responseWrap;
	}

	/**
	 * 获取交易信息 TODO 最新接口文档暂无
	 */
	@PostMapping(value = "/getTradeinfo")
	@ServiceComponent(session = false)
	public ResponseWrap getTradeinfo(@RequestBody ResponseWrap responseWrap) {

		String id = responseWrap.getJson().getString("id");
		responseWrap.appendRow(tradeinfoService.getTradeinfo(id));
		return responseWrap;
	}

	/**
	 * 查询交易信息 TODO 最新接口文档暂无
	 * 
	 * @return
	 */
	@PostMapping(value = "/findTradeinfo")
	@ServiceComponent(session = false)
	public ResponseWrap findTradeinfo(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> jsonMap = responseWrap.getJson();
		String tradeInfoId = (String) jsonMap.get("id");
		PageBuilder pageBuilder = PageBuilder.build();
		PageBean pageBean = pageBuilder.buildSQL(jsonMap);
		responseWrap.appendPage(pageBean);
		responseWrap.appendData(tradeinfoService.findTradeinfo(pageBean, tradeInfoId));
		return responseWrap;
	}

}
