package cn.com.ut.biz.valuableinfo.entityinfo;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.valuableinfo.entities.EntityinfoContent;
import cn.com.ut.biz.valuableinfo.service.EntityinfoService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.NumberUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;
import cn.com.ut.core.restful.httpclient.RestHttpClient;

/**
 * 实体信息（为其他平台提供的对外服务接口）
 * 
 * @author wangpeng1
 * @since 2017年12月20日
 */
@RestController
@RequestMapping(value = "/entityinfo")
public class EntityinfoController {
	@Autowired
	private EntityinfoService entityinfoService;
	@Autowired
	private RestHttpClient restHttpClient;

	/**
	 * 创建实体信息内容
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/createEntityinfoContent")
	@ServiceComponent(session = false)
	public ResponseWrap createEntityinfoContent(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		entityinfoService.createEntityinfoContent(vo);
		return responseWrap;
	}

	/**
	 * 绑定商品结算规则
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/bindCheckoutRule")
	@ServiceComponent(session = false)
	public ResponseWrap bindCheckoutRule(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		entityinfoService.bindCheckoutRule(vo);
		return responseWrap;
	}

	/**
	 * 获取商品结算规则
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/getCheckoutRule")
	@ServiceComponent(session = false)
	public ResponseWrap getCheckoutRule(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		String goodsId = (String) vo.get(EntityinfoContent.goods_id);
		Map<String, Object> map = entityinfoService.getCheckoutRule(goodsId);
		responseWrap.appendData(map);
		return responseWrap;
	}

	/**
	 * 标记结算规则已使用(有价信息体商品绑定结算规则后调用)
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/markupCheckoutRule")
	@ServiceComponent(session = false)
	public Object markupCheckoutRule(@RequestBody ResponseWrap responseWrap) {

		JSONObject dataSend = responseWrap.getJson();
		ValidatorUtil.validateMapContainsKey(dataSend, "rule_id");
		return restHttpClient.exchangePostForEntity(dataSend,
				cn.com.ut.constant.api.ConstantUtil.RPC_PROJRCT.TRANSMISSIONCHAIN,
				cn.com.ut.constant.api.ConstantUtil.API_SETTLEMENTRULE.MARKUP_CHECKOUT_RULE);
	}

	/**
	 * 提交交易传播链信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/submitTradeShareChain")
	@ServiceComponent(session = false)
	public Object submitTradeShareChain(@RequestBody ResponseWrap responseWrap) {

		JSONObject dataSend = responseWrap.getJson();
		ValidatorUtil.validateMapContainsKey(dataSend, "goods_id", "rule_id", "tradeinfo_id",
				"amount", "chain");
		if (!NumberUtil.isDecimal(dataSend.get("amount").toString(), false, 10, 2)) {
			ExceptionUtil.throwValidateException("参数amount格式有误");
		}
		return restHttpClient.exchangePostForEntity(dataSend,
				cn.com.ut.constant.api.ConstantUtil.RPC_PROJRCT.TRANSMISSIONCHAIN,
				cn.com.ut.constant.api.ConstantUtil.API_SETTLEMENTRULE.SUBMIT_TRADE_SHARE_CHAIN);
	}
}