package cn.com.ut.config.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

@Configuration
// @EnableWebMvc
@ServletComponentScan(basePackages = "cn.com.ut")
public class PsWebConfig extends WebConfig {

	private static final String[] excludePathPatterns = new String[] { "/BreakPointServlet/**",
			"/DfsDownLoad/**", "/FileDownLoad/**", "/FileLoad/**", "/FilemanagerjsonServlet/**",
			"/FileUpload/**", "/RandomCode/**", "/ShortUrl/**", "/UploadjsonServlet/**",
			"/ShopView/**", "/TunaAppSrv/**", "/rest/**" };

	@Autowired
	private PsWebInterceptor webInterceptor;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {

		registry.addInterceptor(webInterceptor).addPathPatterns("/**")
				.excludePathPatterns(excludePathPatterns);
	}
}
