package cn.com.ut.config.web;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;

import cn.com.ut.core.cache.CacheHelper;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.system.beans.RequestHeader;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 拦截器
 */
@Component
public class PsWebInterceptor extends HandlerInterceptorAdapter implements InitializingBean {

	private static final Logger logger = LoggerFactory.getLogger(PsWebInterceptor.class);

	@Override
	public void afterPropertiesSet() throws Exception {

	}

	public static final String KEY_BEGIN_SESSION = "s/";
	/**
	 * cookie有效时间，单位为秒
	 */
	public static final int COOKIE_TIMEOUT = 60 * 60 * 24 * 7; // 7天

	/**
	 * 全局缓存时间，超长，用于主机、创作软件
	 */
	public static final int LONG_EXPIRE_SECONDS_GLOBAL_SESSION = 60 * 20;

	@Autowired(required = false)
	private CacheHelper cacheHelper;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
			Object handler) throws Exception {

		// if it's hessian rpc invoke, the class type of handler is
		// HessianServiceExporter
		if (!(handler instanceof HandlerMethod) || ((HandlerMethod) handler)
				.getBean() instanceof org.springframework.boot.autoconfigure.web.ErrorController)
			return true;

		response.addHeader("Access-Control-Allow-Origin", "*");
		response.addHeader("Access-Control-Allow-Headers",
				"Origin, X-Requested-With, Content-Type, Accept");

		HandlerMethod handlerMethod = (HandlerMethod) handler;
		User user = loadRequestBasicInfo(request, response);
		ResponseWrap responseWrap = ResponseWrap.builder();

		boolean checkEnable = true;
		// 加载会话
		User userTem = cacheHelper.get(KEY_BEGIN_SESSION + user.getSessionId());
		if (userTem != null) {
			user = userTem;
		}

		if (!handlerMethod.hasMethodAnnotation(ServiceComponent.class)
				|| handlerMethod.getMethodAnnotation(ServiceComponent.class).session()) {
			checkEnable = (user != null && user.getUserId() != null && user.getSessionId() != null);
			if (!checkEnable) {

				responseWrap.setCodeMsg(
						Integer.parseInt(
								cn.com.ut.core.common.constant.ConstantUtil.RC_SESSION_EXPIRE),
						cn.com.ut.core.common.constant.ConstantUtil.ERR_SESSION_EXPIRE);
				logger.debug(cn.com.ut.core.common.constant.ConstantUtil.ERR_SESSION_EXPIRE);
			} else {
				cacheHelper.touch(KEY_BEGIN_SESSION + user.getSessionId(),
						LONG_EXPIRE_SECONDS_GLOBAL_SESSION);
			}
		}

		logger.debug("==auth=={}", checkEnable);
		request.setAttribute("user", user);

		if (!checkEnable) {
			response.setContentType(cn.com.ut.core.common.constant.ConstantUtil.CONTENT_TYPE_JSON);
			byte[] bs = JSON.toJSONBytes(responseWrap.getResponseData(),
					SerializerFeature.WriteNullStringAsEmpty);
			response.setContentLength(bs.length);
			response.getOutputStream().write(bs);
			response.getOutputStream().flush();
		}

		return checkEnable;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {

		logger.debug("==postHandle==");
	}

	protected User loadRequestBasicInfo(HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		// request header
		StringBuilder info = new StringBuilder();
		info.append("\nContentType ContentLength==").append(request.getContentType()).append(" ")
				.append(request.getContentLength());
		info.append("\nLocalAddr LocalName LocalPort==").append(request.getLocalAddr()).append(" ")
				.append(request.getLocalName()).append(" ").append(request.getLocalPort());
		info.append("\nRemoteAddr RemoteHost RemotePort==").append(request.getRemoteAddr())
				.append(" ").append(request.getRemoteHost()).append(" ")
				.append(request.getRemotePort());
		info.append("\nRemoteUser==").append(request.getRemoteUser());
		info.append("\nPathInfo PathTranslated==").append(request.getPathInfo()).append(" ")
				.append(request.getPathTranslated());
		info.append("\nRequestURI RequestURL==").append(request.getRequestURI()).append(" ")
				.append(request.getRequestURL());
		info.append("\nScheme==").append(request.getScheme());
		info.append("\nServerName ServerPort==").append(request.getServerName()).append(" ")
				.append(request.getServerPort());

		RequestHeader requestHeader = new RequestHeader();
		requestHeader.setServerName(request.getServerName());
		requestHeader.setServerPort(request.getServerPort());
		requestHeader.setRemoteAddr(request.getRemoteAddr());

		for (Enumeration<String> names = request.getHeaderNames(); names.hasMoreElements();) {
			String name = names.nextElement();
			String value = request.getHeader(name);
			info.append("\nHeader ").append(name).append("==").append(value);
			if (RequestHeader.REFERER.equals(name)) {
				requestHeader.setReferer(value);
			}
			if (RequestHeader.X_FORWARDED_FOR.equals(name)) {
				requestHeader.setxForwardedFor((value));
			}
			if (RequestHeader.X_REQUESTED_WITH.equals(name)) {
				requestHeader.setxRequestedWith(value);
			}
		}
		logger.debug("request header{}", info.toString());
		User user = loadRequestBasicInfoByCookie(request, response, requestHeader);
		return user;
	}

	private User loadRequestBasicInfoByCookie(HttpServletRequest request,
			HttpServletResponse response, RequestHeader requestHeader) {

		String sessionKey = null;
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				logger.debug(cookie.getName() + "==" + cookie.getValue());
				// 获取会话认证标识
				if (cn.com.ut.core.common.constant.ConstantUtil.SESSIONKEY
						.equals(cookie.getName())) {
					sessionKey = cookie.getValue();
				}
			}
		}
		User user = new User();
		if (sessionKey == null) {
			sessionKey = CommonUtil.getUUID();
			logger.debug("new sid==" + sessionKey);
			addCookie(request, response, cn.com.ut.core.common.constant.ConstantUtil.SESSIONKEY,
					sessionKey, null, null, -1);
		}

		user.setSessionId(sessionKey);

		return user;
	}

	/**
	 * 生成Cookie对象
	 * 
	 * @param request
	 *            http请求
	 * @param response
	 *            http响应
	 * @param name
	 *            Cookie键
	 * @param value
	 *            Cookie值
	 * @param path
	 *            路径
	 * @param domain
	 *            域名
	 * @param expiry
	 *            生命期
	 * @return Cookie
	 */
	private Cookie addCookie(HttpServletRequest request, HttpServletResponse response, String name,
			String value, String path, String domain, int expiry) {

		Cookie cookie = new Cookie(name, value);
		if (path == null)
			cookie.setPath("/");
		// if (domain == null)
		// cookie.setDomain(ConstantUtil.DEFAULT_DOMAIN);
		cookie.setMaxAge(expiry);
		response.addCookie(cookie);
		return cookie;
	}

}