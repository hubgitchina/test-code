package cn.com.ut.biz.order;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.order.service.OrderService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 订单信息
 * 
 * @author gaolei
 * @since 2017年12月28日
 */
@RestController
@RequestMapping(value = "/order")
public class OrderController {

	@Autowired
	private OrderService orderService;

	/**
	 * 创建订单(同时插入订单表和订单商品表) 商品ID 商品数量 传播链ID 创建人ID
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/createOrder")
	@ServiceComponent(session = false)
	public ResponseWrap createOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> row = orderService.createOrder(responseWrap.getJson());
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 查看订单列表 goodsId 商品ID
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryOrder")
	@ServiceComponent(session = false)
	public ResponseWrap queryOrder(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		List<Map<String, Object>> rows = orderService.queryOrder(vo, null);
		responseWrap.appendData(rows);
		return responseWrap;
	}

	/**
	 * 更新订单支付状态
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/notifyPayStatus")
	@ServiceComponent(session = false)
	public ResponseWrap notifyPayStatus(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		orderService.notifyPayStatus(vo);
		return responseWrap;
	}

	/**
	 * 获取订单详情
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/getOrderDetail")
	@ServiceComponent(session = false)
	public ResponseWrap getOrderDetail(@RequestBody ResponseWrap responseWrap) {

		responseWrap.appendData(orderService.getOrderDetail(responseWrap.getJson()));
		return responseWrap;
	}

	/**
	 * 测试拉取传播路径
	 * 
	 * @param shareChainId
	 * @param goodsId
	 */
	@GetMapping(value = "/getChain")
	@ServiceComponent(session = false)
	public void getChain(@RequestParam(name = "shareChainId") String shareChainId,
			@RequestParam(name = "goodsId") String goodsId) {

		orderService.shareChainCheck(shareChainId, goodsId);
	}
}
