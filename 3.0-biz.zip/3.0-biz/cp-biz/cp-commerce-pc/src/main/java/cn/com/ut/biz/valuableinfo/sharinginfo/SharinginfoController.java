package cn.com.ut.biz.valuableinfo.sharinginfo;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.order.dao.OrderDAO;
import cn.com.ut.biz.valuableinfo.entities.Tradeinfo;
import cn.com.ut.biz.valuableinfo.service.SharinginfoService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.dal.jdbc.BaseEntity;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 分成信息（为其他平台提供的对外服务接口）
 * 
 * @author wangpeng1
 * @since 2017年12月20日
 */
@RestController
@RequestMapping(value = "/sharinginfo")
public class SharinginfoController {

	@Autowired
	private OrderDAO orderDAO;
	@Autowired
	private SharinginfoService sharinginfoService;

	/**
	 * 创建分成信息
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/createSharinginfo")
	@ServiceComponent(session = false)
	public ResponseWrap createSharinginfo(@RequestBody ResponseWrap responseWrap) {

		sharinginfoService.createSharinginfo(responseWrap.getJson());
		return responseWrap;
	}

	/**
	 * 获取分成信息
	 * 
	 * @param responseWrap
	 *            TODO 最新接口文档暂无
	 * @return
	 */
	@PostMapping(value = "/getSharinginfo")
	@ServiceComponent(session = false)
	public ResponseWrap getSharinginfo(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> jsonMap = responseWrap.getJson();
		String id = (String) jsonMap.get("id");
		responseWrap.appendData(sharinginfoService.getSharinginfo(id));
		return responseWrap;
	}

	/**
	 * 查询分成信息列表 TODO 最新接口文档暂无
	 */
	@PostMapping(value = "/listSharinginfo")
	@ServiceComponent(session = false)
	public ResponseWrap listSharinginfo(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> jsonMap = responseWrap.getJson();
		PageBuilder pageBuilder = PageBuilder.build();
		PageBean pageBean = pageBuilder.buildSQL(jsonMap);
		String sharer = (String) jsonMap.get("sharer");
		responseWrap.appendData(sharinginfoService.listSharinginfo(pageBean, sharer));
		return responseWrap;
	}

	/**
	 * 获取订单分成信息
	 *
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/getOrderSharinginfo")
	@ServiceComponent(session = false)
	public ResponseWrap getOrderSharinginfo(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> jsonMap = responseWrap.getJson();
		ValidatorUtil.validateMapContainsKey(jsonMap, Tradeinfo.order_id);
		String orderCode = (String) jsonMap.get(Tradeinfo.order_id);
		Map<String, Object> orderVo = orderDAO.getByOrderCode(orderCode);
		String orderId = orderVo == null ? null : (String) orderVo.get(BaseEntity.idx);
		List<Map<String, Object>> resultList = sharinginfoService.getOrderSharinginfo(orderId);
		// Object zonjine =
		// sharinginfoService.getOrderTotalSharinginfo(orderId);
		// responseWrap.getResponseData().put("TOTAL_SHARE_AMOUNT", zonjine);
		responseWrap.appendData(resultList);
		return responseWrap;
	}
}
