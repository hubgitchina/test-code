package cn.com.ut.biz.valuableinfo.manage;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Maps;

import cn.com.ut.biz.valuableinfo.service.SharinginfoService;
import cn.com.ut.biz.valuableinfo.service.TradeinfoService;
import cn.com.ut.biz.valuableinfo.service.ValuableinfoService;
import cn.com.ut.core.common.system.beans.User;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 有价信息数据管理平台 - 首页信息
 * 
 * @author wangpeng1
 * @since 2018年4月11日
 */
@RestController
@RequestMapping(value = "/homeInfo")
public class HomeInfoController {

	@Autowired
	private ValuableinfoService valuableinfoService;

	@Autowired
	private TradeinfoService tradeinfoService;

	@Autowired
	private SharinginfoService sharinginfoService;

	/**
	 * 查询首页有价信息、成交信息和分成信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/findHomeInfo")
	public ResponseWrap findHomeInfo(@RequestBody ResponseWrap responseWrap,
			@RequestAttribute("user") User user) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> data = Maps.newHashMapWithExpectedSize(3);
		data.put("valuable", valuableinfoService.queryTopValuableInfo(vo));
		data.put("trade", tradeinfoService.queryTopTradeInfo(vo));
		data.put("sharing", sharinginfoService.queryTopSharingInfo(vo));
		responseWrap.appendData(data);
		return responseWrap;
	}
}
