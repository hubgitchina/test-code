package cn.com.ut.biz.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.restful.ResponseWrap;

@RestController
@RequestMapping(value = "/demo")
public class DemoController {

	@ServiceComponent(session = false)
	@RequestMapping(value = "/echo", method = { RequestMethod.GET, RequestMethod.POST })
	public ResponseWrap echo(@RequestParam(required = false) String input) {

		Map<String, Object> vo = new HashMap<>();
		vo.put("echo", CommonUtil.isEmpty(input) ? "hello" : "hello " + input);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.appendData(vo);
		return responseWrap;

	}
}
