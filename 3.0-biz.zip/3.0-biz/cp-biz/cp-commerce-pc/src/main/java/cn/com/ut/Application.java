package cn.com.ut;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

//@EnableDiscoveryClient
@Configuration
@ComponentScan
@PropertySource({ "classpath:/cn/com/ut/config/properties/database.properties",
		"classpath:/cn/com/ut/config/properties/constant.properties" })
@ImportResource({ "classpath:/cn/com/ut/config/datasource/tm-ctx.xml" })
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class Application extends BaseApplication {

	public static void main(String[] args) {

		SpringApplication application = new SpringApplication(Application.class);
		application.setBannerMode(Banner.Mode.OFF);
		application.run(args);
	}
}
