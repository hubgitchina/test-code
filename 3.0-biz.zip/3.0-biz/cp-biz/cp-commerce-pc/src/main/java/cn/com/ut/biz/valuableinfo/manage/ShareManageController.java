package cn.com.ut.biz.valuableinfo.manage;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.valuableinfo.service.SharingChainService;
import cn.com.ut.biz.valuableinfo.service.TradeinfoService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 有价信息数据管理平台 - 传播链管理
 * 
 * @author wangpeng1
 * @since 2018年4月12日
 */
@RestController
@RequestMapping(value = "/shareManage")
public class ShareManageController {

	@Autowired
	private TradeinfoService tradeinfoService;

	@Autowired
	private SharingChainService sharingChainService;

	/**
	 * 查询传播链成交商品分页列表数据
	 * 
	 * @param pageMap
	 * @return
	 */
	@GetMapping(value = "/findTradeGoods")
	public ResponseWrap findTradeGoodsPage(@RequestParam MultiValueMap<String, Object> pageMap) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition("g", "goods_name", EnumConstant.WhereCase.LIKE,
				EnumConstant.SqlType.STRING);
		// pb.appendWhereCondition("vb", "create_id", EnumConstant.WhereCase.EQ,
		// EnumConstant.SqlType.STRING);
		// pb.appendWhereCondition("vb", "business_type",
		// EnumConstant.WhereCase.EQ,
		// EnumConstant.SqlType.STRING);
		pb.appendSortCondition(null, "t.create_time", EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> resultList = tradeinfoService.findTradeGoodsPage(page);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 获取交易完整传播链路
	 * 
	 * @param responseWrap
	 *            {share_chain_end_id:传播链结束id}
	 * @return
	 */
	@PostMapping(value = "getTradeShare")
	public ResponseWrap getTradeShare(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> jsonMap = responseWrap.getJson();
		String shareChainEndId = (String) jsonMap.get("share_chain_end_id");
		responseWrap.getResponseData().put("data",
				sharingChainService.getTradeShare(shareChainEndId));
		return responseWrap;
	}
}
