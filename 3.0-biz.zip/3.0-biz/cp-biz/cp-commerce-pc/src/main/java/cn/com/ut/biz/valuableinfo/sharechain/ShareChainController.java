package cn.com.ut.biz.valuableinfo.sharechain;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;

import cn.com.ut.biz.valuableinfo.entities.EntityinfoContent;
import cn.com.ut.biz.valuableinfo.entities.ShareChain;
import cn.com.ut.biz.valuableinfo.service.SharingChainService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.common.util.validator.ValidatorUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 传播链（为其他平台提供的对外服务接口）
 * 
 * @author wangpeng1
 * @since 2017年12月20日
 */
@RestController
@RequestMapping(value = "/shareChain")
public class ShareChainController {

	@Autowired
	private SharingChainService sharingChainService;

	/**
	 * 创建传播链
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/createShareChain")
	@ServiceComponent(session = false)
	public ResponseWrap createShareChain(@RequestBody ResponseWrap responseWrap) {

		JSONObject jb = responseWrap.getJson();
		ValidatorUtil.validateMapContainsKey(jb, "originalUserId", "recordId", "commodityId",
				"targetUserId");
		CollectionUtil.replaceMapKey(jb, new String[] { "originalUserId@" + ShareChain.sharer,
				"lastRecordId@" + ShareChain.parent_id, "recordId@" + ShareChain.share_chain_id,
				"commodityId@" + EntityinfoContent.goods_id,
				"targetUserId@" + ShareChain.receiver });
		sharingChainService.createShareChain(jb);
		return responseWrap;
	}

	/**
	 * 获取商品的传播路径
	 */
	@PostMapping(value = "/findGoodsShareChain")
	@ServiceComponent(session = false)
	public ResponseWrap findGoodsShareChain(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> json = responseWrap.getJson();
		String goodsId = (String) json.get("goods_id");
		responseWrap.getResponseData().put("data",
				sharingChainService.findGoodsShareChain(goodsId));
		return responseWrap;
	}

	/**
	 * 查看传播链 TODO 最新接口文档暂无
	 */
	@GetMapping(value = "/getShareChain")
	@ServiceComponent(session = false)
	public ResponseWrap getShareChain(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> jsonMap = responseWrap.getJson();
		if (CollectionUtil.isEmptyMap(jsonMap)) {
			ExceptionUtil.throwValidateException("参数空");
		}
		String id = (String) jsonMap.get("id");
		sharingChainService.getShareChain(id);
		return responseWrap;
	}

	/**
	 * 获取交易完整传播链路
	 * 
	 * @param responseWrap
	 *            {share_chain_end_id:传播链结束id}
	 * @return
	 */
	@PostMapping(value = "getCompleteTradeChain")
	@ServiceComponent(session = false)
	public ResponseWrap getCompleteTradeChain(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> jsonMap = responseWrap.getJson();
		String shareChainEndId = (String) jsonMap.get("share_chain_end_id");
		responseWrap.getResponseData().put("data",
				sharingChainService.findTradeShareChain(shareChainEndId));
		return responseWrap;
	}

}
