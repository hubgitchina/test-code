package cn.com.ut.biz.goods;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.goods.service.GoodsCollectionService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 商品收藏接口controller层
 * 
 * @author wangpeng1
 * @since 2018年1月24日
 */
@RestController
@RequestMapping(value = "/goodsCollection")
public class GoodsCollectionController {

	@Autowired
	private GoodsCollectionService goodsCollectionService;

	/**
	 * 收藏购物车中的商品
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/collectCartGoods")
	@ServiceComponent(session = false)
	public ResponseWrap collectCartGoods(@RequestBody ResponseWrap responseWrap) {

		goodsCollectionService.collectCartGoods(responseWrap.getJson());
		return responseWrap;
	}
}
