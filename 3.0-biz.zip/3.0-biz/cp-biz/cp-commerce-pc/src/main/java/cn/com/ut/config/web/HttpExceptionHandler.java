package cn.com.ut.config.web;

import java.net.ConnectException;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;

import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 该类主要对远程调用异常作统一处理
 * 
 * 全局异常处理，只对业务Controller生效(basePackages用于排除系统Controller)
 * 
 * -1 表示程序员可预见主动抛出的异常，-2表示预料之外的异常
 * 
 * @author wuxiaohua
 *
 */
@RestControllerAdvice(annotations = RestController.class, basePackages = { "cn.com.ut.biz" })
public class HttpExceptionHandler {

	@ExceptionHandler({ HttpClientErrorException.class })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseWrap deal(HttpClientErrorException ex) {

		// ExceptionUtil.logError(ex);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setCodeMsg(ConstantUtil.UNKNOWN_ERR_CODE,
				"调用远程服务异常，请检查服务地址是否正确： " + ex.getMessage());
		return responseWrap;
	}

	@ExceptionHandler({ ConnectException.class })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseWrap deal(ConnectException ex) {

		// ExceptionUtil.logError(ex);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setCodeMsg(ConstantUtil.UNKNOWN_ERR_CODE,
				"调用远程服务异常，请检查服务是否正常运行： " + ex.getMessage());
		return responseWrap;
	}
}
