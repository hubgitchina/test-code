package cn.com.ut.biz.shoppingcart;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.shoppingcart.service.ShoppingCartService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 购物车接口controller层
 * 
 * @author wangpeng1
 * @since 2018年1月24日
 */
@RestController
@RequestMapping(value = "/shoppingCart")
public class ShoppingCartController {

	@Autowired
	private ShoppingCartService shoppingCartService;

	/**
	 * 添加商品到购物车 （同一商品不同SKU视为多条商品加入购物车）
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/addCartGoods")
	@ServiceComponent(session = false)
	public ResponseWrap addCartGoods(@RequestBody ResponseWrap responseWrap) {

		shoppingCartService.addCartGoods(responseWrap.getJson());
		return responseWrap;
	}

	/**
	 * 查看购物车中的商品
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/queryShoppingCart")
	@ServiceComponent(session = false)
	public ResponseWrap queryShoppingCart(@RequestBody ResponseWrap responseWrap) {

		List<Map<String, Object>> listGoods = shoppingCartService
				.queryShoppingCart(responseWrap.getJson());
		return responseWrap.appendData(listGoods);
	}

	/**
	 * 修改购物车中的商品
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/updateCartGoods")
	@ServiceComponent(session = false)
	public ResponseWrap updateCartGoods(@RequestBody ResponseWrap responseWrap) {

		shoppingCartService.updateCartGoods(responseWrap.getJson());
		return responseWrap;
	}

	/**
	 * 删除购物车中的商品
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/removeCartGoods")
	@ServiceComponent(session = false)
	public ResponseWrap removeCartGoods(@RequestBody ResponseWrap responseWrap) {

		shoppingCartService.removeCartGoods(responseWrap.getJson());
		return responseWrap;
	}

}
