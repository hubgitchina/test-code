package cn.com.ut.biz.goods;

import cn.com.ut.biz.goods.service.GoodsService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.restful.ResponseWrap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 商品信息
 * 
 * @author gaolei
 * @since 2017年12月28日
 */
@RestController
@RequestMapping(value = "/goods")
public class GoodsController {

	@Autowired
	private GoodsService goodsService;

	/**
	 * 上架商品(创建商品)
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/createGoods")
	@ServiceComponent(session = false)
	public ResponseWrap createGoods(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		String id = goodsService.createGoods(vo);
		Map<String, Object> row = new HashMap<>();
		row.put("goods_id", id);
		responseWrap.appendData(row);
		return responseWrap;
	}

	/**
	 * 查看商品信息
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/getGoodsInfo")
	@ServiceComponent(session = false)
	public ResponseWrap getGoodsInfo(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> row = goodsService.getById(responseWrap.getJson());
		responseWrap.appendData(row);
		return responseWrap;
	}
}
