package cn.com.ut.biz.valuableinfo.manage;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.valuableinfo.service.SharinginfoService;
import cn.com.ut.core.common.constant.EnumConstant;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.jdbc.PageBuilder;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 有价信息数据管理平台 - 有价信息管理
 * 
 * @author wangpeng1
 * @since 2018年4月12日
 */
@RestController
@RequestMapping(value = "/settlementManage")
public class SettlementManageController {

	@Autowired
	private SharinginfoService sharinginfoService;

	/**
	 * 查询有价信息体分页列表数据
	 * 
	 * @param pageMap
	 * @return
	 */
	@GetMapping(value = "/findSettlement")
	public ResponseWrap findSettlementPage(@RequestParam MultiValueMap<String, Object> pageMap) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		PageBuilder pb = PageBuilder.build();
		pb.appendWhereCondition(null, "sharer", EnumConstant.WhereCase.LIKE,
				EnumConstant.SqlType.STRING);
		// pb.appendSortCondition(null, Sharinginfo.create_time,
		// EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(pageMap);
		List<Map<String, Object>> resultList = sharinginfoService.findSettlementPage(page);
		responseWrap.appendPage(page);
		responseWrap.appendData(resultList);
		return responseWrap;
	}

	/**
	 * 根据传播人ID查询详细分成记录列表
	 * 
	 * @param sharerId
	 * @return
	 */
	@GetMapping(value = "/findSharingBySharer")
	public ResponseWrap findSettlementDetails(@RequestParam MultiValueMap<String, Object> pageMap) {

		ResponseWrap responseWrap = ResponseWrap.builder();
		PageBuilder pb = PageBuilder.build();
		// pb.appendWhereCondition(null, "sharer", EnumConstant.WhereCase.LIKE,
		// EnumConstant.SqlType.STRING);
		// pb.appendSortCondition(null, Sharinginfo.create_time,
		// EnumConstant.OrderBy.DESC);
		PageBean page = pb.buildSQL(pageMap);
		String sharerId = (String) pageMap.getFirst("sharer");
		List<Map<String, Object>> rows = sharinginfoService.findSettlementDetails(page, sharerId);
		responseWrap.appendPage(page).appendRows(rows);
		return responseWrap;
	}

}
