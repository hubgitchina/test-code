package cn.com.ut.biz.valuableinfo.valuableinfo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.ut.biz.valuableinfo.service.ValuableinfoService;
import cn.com.ut.core.common.annotation.ServiceComponent;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.ExceptionUtil;
import cn.com.ut.core.restful.ResponseWrap;

/**
 * 有价信息体（为其他平台提供的对外服务接口）
 * 
 * @author wangpeng1
 * @since 2017年12月20日
 */
@RestController
@RequestMapping(value = "/valuableinfo")
public class ValuableinfoController {

	@Autowired
	private ValuableinfoService valuableinfoService;

	/**
	 * 创建有价信息体
	 * 
	 * @param responseWrap
	 * @return
	 */
	@PostMapping(value = "/createValuableinfo")
	@ServiceComponent(session = false)
	public ResponseWrap createValuableinfo(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		Map<String, Object> data = new HashMap<>();
		data.put("valuableinfo_id", valuableinfoService.createValuableinfo(vo));
		responseWrap.appendData(data);
		return responseWrap;
	}

	/**
	 * 查看有价信息体 TODO 最新接口文档暂无
	 * 
	 * @return
	 */
	@GetMapping(value = "/getValuableinfo")
	@ServiceComponent(session = false)
	public ResponseWrap getValuableinfo(@RequestBody ResponseWrap responseWrap) {

		Map<String, Object> vo = responseWrap.getJson();
		if (CollectionUtil.isEmptyMap(vo)) {
			ExceptionUtil.throwValidateException("参数空");
		}
		String id = (String) vo.get("id");
		responseWrap.appendData(valuableinfoService.getValuableinfo(id));
		return responseWrap;
	}

}
