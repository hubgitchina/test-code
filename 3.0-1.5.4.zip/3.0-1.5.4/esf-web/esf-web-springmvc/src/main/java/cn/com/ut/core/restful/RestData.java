package cn.com.ut.core.restful;

import java.io.Serializable;

public class RestData implements Serializable {

	private static final long serialVersionUID = -65449146761898871L;

}
