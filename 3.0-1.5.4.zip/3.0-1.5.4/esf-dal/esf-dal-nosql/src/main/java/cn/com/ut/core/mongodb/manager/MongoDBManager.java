package cn.com.ut.core.mongodb.manager;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cn.com.ut.core.common.util.io.FileUtil;
import cn.com.ut.core.common.util.xml.XmlUtil;
import cn.com.ut.core.mongodb.config.MongoAuth;
import cn.com.ut.core.mongodb.config.MongoConfig;
import cn.com.ut.core.mongodb.element.CollElement;

/**
 * 数据库对象管理
 * 
 * @author wuxiaohua
 * @since 2015-12-30
 */
@Component
public class MongoDBManager {

	@Autowired
	private MongoConfig config;

	public Map<String, CollElement> collMap = new TreeMap<String, CollElement>();

	/**
	 * 根据实体类获取集合
	 * 
	 * @param entity
	 * @return
	 */
	public CollElement getCollElement(String entity) {

		if (entity == null) {
			throw new IllegalArgumentException("entity is null");
		}

		return collMap.get(entity);
	}

	/**
	 * 解析数据库配置，构建数据库对象
	 */
	@PostConstruct
	public void init() {

		List<URL> urls = FileUtil.listUrls(config.getOrmapper(), "mongo-db-*.xml");
		if (urls != null) {
			for (URL url : urls) {
				Document resDoc = null;
				try {
					resDoc = XmlUtil.readXml(url);
				} catch (DocumentException e) {
				}
				if (resDoc != null) {
					putDBElement(resDoc.getRootElement());
				}
			}
		}
	}

	/**
	 * 解析实体类关系表映射关系
	 * 
	 * @param root
	 *            文档元素
	 */
	private void putDBElement(Element root) {

		List<Element> servers = root.elements("server");
		if (servers != null && !servers.isEmpty()) {
			for (Element server : servers) {

				String serverName = server.attributeValue("name");

				List<Element> dbElements = server.elements();
				if (dbElements != null && !dbElements.isEmpty()) {

					for (Element dbElement : dbElements) {

						String dbName = dbElement.attributeValue("name");
						MongoAuth mongoAuth = null;
						for (MongoAuth auth : config.getMongoAuths()) {
							if (auth.getCluster().equals(serverName)
									&& auth.getDbInfo().getName().equals(dbName)) {
								mongoAuth = auth;
							}
						}

						List<CollElement> colls = XmlUtil.toElementList(dbElement.elements(),
								CollElement.class);

						if (colls != null && !colls.isEmpty()) {
							for (CollElement coll : colls) {
								coll.setMongoAuth(mongoAuth);
								collMap.put(coll.getEntity(), coll);
							}
						}
					}
				}

			}
		}
	}

	@PreDestroy
	public void destroy() {

		collMap.clear();
	}

	public static void main(String[] args) {

		MongoDBManager m = new MongoDBManager();
		m.init();
		// System.out.println(m.collMap);
	}
}
