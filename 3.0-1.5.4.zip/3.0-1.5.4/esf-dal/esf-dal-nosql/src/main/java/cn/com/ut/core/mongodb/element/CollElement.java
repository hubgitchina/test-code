package cn.com.ut.core.mongodb.element;

import cn.com.ut.core.mongodb.config.MongoAuth;

public class CollElement extends MongoBaseElement implements Comparable<CollElement> {

	private static final long serialVersionUID = 6386717907349870138L;

	private DBElement db;
	private String entity;
	private MongoAuth mongoAuth;

	public MongoAuth getMongoAuth() {

		return mongoAuth;
	}

	public void setMongoAuth(MongoAuth mongoAuth) {

		this.mongoAuth = mongoAuth;
	}

	public DBElement getDb() {

		return db;
	}

	public void setDb(DBElement db) {

		this.db = db;
	}

	public String getEntity() {

		return entity;
	}

	public void setEntity(String entity) {

		this.entity = entity;
	}

	@Override
	public int compareTo(CollElement o) {

		return this.getEntity().compareTo(o.getEntity());
	}

}
