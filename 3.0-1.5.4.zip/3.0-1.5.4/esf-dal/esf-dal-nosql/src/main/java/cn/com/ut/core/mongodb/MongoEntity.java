package cn.com.ut.core.mongodb;

import java.io.Serializable;

/**
 * 实体类基类
 * 
 * @author wuxiaohua
 * @since 2015-12-30
 */
public class MongoEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String _id = "_id";
	public static final String create_id = "create_id";
	public static final String update_id = "update_id";
	public static final String create_time = "create_time";
	public static final String update_time = "update_time";
}
