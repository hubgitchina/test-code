package cn.com.ut.core.mongodb.element;

public class HostElement extends MongoBaseElement {

	private static final long serialVersionUID = -4622195018861719818L;

	private String addr;
	private String port;
	private ServerElement server;

	public String getAddr() {

		return addr;
	}

	public void setAddr(String addr) {

		this.addr = addr;
	}

	public String getPort() {

		return port;
	}

	public void setPort(String port) {

		this.port = port;
	}

	public ServerElement getServer() {

		return server;
	}

	public void setServer(ServerElement server) {

		this.server = server;
	}

}
