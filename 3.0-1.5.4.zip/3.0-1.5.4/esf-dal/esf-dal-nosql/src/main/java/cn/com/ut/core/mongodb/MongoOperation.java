package cn.com.ut.core.mongodb;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBEncoder;
import com.mongodb.DBObject;
import com.mongodb.MapReduceOutput;
import com.mongodb.MongoClient;
import com.mongodb.QueryOperators;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;
import com.mongodb.WriteConcern;
import com.mongodb.WriteResult;

import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.jdbc.PageBean;
import cn.com.ut.core.common.mongodb.ObjectUtils;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.mongodb.config.MongoConfig;
import cn.com.ut.core.mongodb.element.CollElement;
import cn.com.ut.core.mongodb.element.DBElement;
import cn.com.ut.core.mongodb.element.ServerElement;
import cn.com.ut.core.mongodb.manager.MongoClientManager;
import cn.com.ut.core.mongodb.manager.MongoDBManager;

@Repository
public class MongoOperation<E extends MongoEntity>
		implements MongoOperationApi<E>, InitializingBean {

	private static final Logger logger = LoggerFactory.getLogger(MongoOperation.class);

	/**
	 * 默认连接端口
	 */
	public static final int DEFAULT_PORT = 27017;

	/**
	 * 实体关系配置管理
	 */
	@Resource
	private MongoDBManager mongoDBManager;
	@Autowired
	private MongoConfig config;

	/**
	 * 服务器配置管理
	 */
	@Resource
	private MongoClientManager mongoClientManager;

	protected MongoClient client;
	protected DB db;
	protected DBCollection coll;
	protected Class<E> entity;

	/**
	 * 获取数据库
	 * 
	 * @return 数据库对象
	 */
	protected DB getDB() {

		return db;
	}

	/**
	 * 根据实体类获取数据库
	 * 
	 * @param entity
	 *            实体类
	 * @return 数据库
	 */
	protected DB getDB(Class<E> entity) {

		if (entity != null) {
			CollElement collElement = mongoDBManager.getCollElement(entity.getName());
			MongoClient client = getClient(entity);
			db = client.getDB(collElement.getMongoAuth().getDbInfo().getName());
			return db;
		}

		return null;
	}

	/**
	 * 获取数据库连接
	 * 
	 * @param entity
	 *            实体类
	 * @return 数据库连接
	 */
	protected MongoClient getClient(Class<E> entity) {

		if (entity != null) {
			CollElement collElement = mongoDBManager.getCollElement(entity.getName());
			MongoClient client = mongoClientManager
					.getMongoClient(collElement.getMongoAuth().getCluster());
			return client;
		}

		return null;
	}

	/**
	 * 获取数据表Collection
	 * 
	 * @param entity
	 *            实体类
	 * @return 数据表
	 */
	protected DBCollection getColl(Class<E> entity) {

		if (entity != null) {
			CollElement collElement = mongoDBManager.getCollElement(entity.getName());
			DB db = getDB(entity);
			coll = db.getCollection(collElement.getName());
		}

		return null;
	}

	protected MongoClient getClient() {

		return client;
	}

	protected DBCollection getColl() {

		return coll;
	}

	protected Class<E> getEntity() {

		return entity;
	}

	/**
	 * 根据泛型参数获取实体类
	 */
	protected void loadEntity() {

		Type type = this.getClass().getGenericSuperclass();

		if (type instanceof ParameterizedType) {
			ParameterizedType pt = (ParameterizedType) type;
			Type[] types = pt.getActualTypeArguments();
			entity = (Class<E>) types[0];
		}
	}

	/**
	 * 初始化
	 */
	@Override
	public void afterPropertiesSet() throws Exception {

		if (!ConstantUtil.FLAG_TRUE.equals(config.getEnable()))
			return;

		loadEntity();
		if (getEntity() != null) {
			CollElement collElement = mongoDBManager.getCollElement(getEntity().getName());
			client = mongoClientManager.getMongoClient(collElement.getMongoAuth().getCluster());
			db = client.getDB(collElement.getMongoAuth().getDbInfo().getName());
			coll = db.getCollection(collElement.getName());
		}
	}

	/**
	 * 解析服务器连接
	 * 
	 * @param mongos
	 *            服务器连接
	 * @return 连接对象数组
	 * @throws UnknownHostException
	 */
	protected List<ServerAddress> parseMongoAddress(String mongos) throws UnknownHostException {

		List<ServerAddress> list = new ArrayList<ServerAddress>();

		if (mongos == null || mongos.trim().length() == 0)
			return list;

		String[] urls = mongos.split(",");
		for (String url : urls) {
			String[] array = url.split(":");
			if (array.length == 2) {
				list.add(new ServerAddress(array[0], Integer.parseInt(array[1])));
			} else {
				list.add(new ServerAddress(array[0], DEFAULT_PORT));
			}
		}

		return list;
	}

	/**
	 * getWriteConcern
	 */
	public WriteConcern getWriteConcern(DB db) {

		return db.getWriteConcern();
	}

	/**
	 * getReadPreference
	 */
	public ReadPreference getReadPreference(DB db) {

		return db.getReadPreference();
	}

	/**
	 * Get the count of documents in collection that would match a criteria.
	 * 
	 * @param query
	 *            specifies the selection criteria
	 * @param fields
	 *            this is ignored
	 * @param limit
	 *            limit the count to this value
	 * @param skip
	 *            number of documents to skip
	 * @param readPrefs
	 *            {@link ReadPreference} to be used for this operation
	 * @return the number of documents that matches selection criteria
	 */
	public long getCount(DBCollection collection, DBObject query, DBObject fields, long limit,
			long skip, ReadPreference readPrefs) {

		if (collection == null) {
			collection = getColl();
		}
		if (readPrefs == null) {
			readPrefs = collection.getReadPreference();
		}
		long count = collection.getCount(query, fields, limit, skip, readPrefs);
		logger.debug("count=={}", count);
		return count;
	}

	/**
	 * @see #getCount(DBCollection, DBObject, DBObject, long, long,
	 *      ReadPreference)
	 * @param query
	 * @return
	 */
	public long getCount(DBObject query) {

		return getCount(null, query, null, 0, 0, null);
	}

	/**
	 * Get a single document from collection.
	 * 
	 * @param criteria
	 *            the selection criteria using query operators.
	 * @param fields
	 *            specifies which projection MongoDB will return from the
	 *            documents in the result set.
	 * @param orderBy
	 *            A document whose fields specify the attributes on which to
	 *            sort the result set.
	 * @param readPreference
	 *            {@code ReadPreference} to be used for this operation
	 * @return A document that satisfies the query specified as the argument to
	 *         this method, or {@code null} if no such object exists
	 */
	public DBObject findOne(DBCollection collection, DBObject criteria, DBObject fields,
			DBObject orderBy, ReadPreference readPreference) {

		if (collection == null)
			collection = getColl();

		if (readPreference == null)
			readPreference = collection.getReadPreference();

		return collection.findOne(criteria, fields, orderBy, readPreference);
	}

	public DBObject findOne(DBObject criteria, DBObject fields, DBObject orderBy) {

		return findOne(null, criteria, fields, orderBy, null);
	}

	public DBObject findOne(DBObject criteria, DBObject fields) {

		return findOne(criteria, fields, null);
	}

	public DBObject findOne(DBObject criteria) {

		return findOne(criteria, null);
	}

	/**
	 * @see #findOne(DBObject, DBObject)
	 */
	public DBObject findById(DBObject fields, String _id) {

		return findOne(new BasicDBObject(MongoEntity._id, _id), fields);
	}

	/**
	 * 查询返回游标
	 * 
	 * @param collection
	 *            数据表
	 * @param where
	 *            查询条件
	 * @param keys
	 *            查询字段
	 * @return
	 */
	public DBCursor find(DBCollection collection, DBObject where, DBObject keys) {

		if (collection == null)
			collection = getColl();
		return collection.find(where, keys);
	}

	public DBCursor find(DBObject where, DBObject keys) {

		return find(null, where, keys);
	}

	public DBCursor findOrder(DBObject where, DBObject keys, DBObject orderBy) {

		DBCursor cursor = find(where, keys);
		cursor.sort(orderBy);
		return cursor;
	}

	public DBCursor find(DBObject where) {

		return find(where, null);
	}

	/**
	 * 查询返回游标
	 * 
	 * @param where
	 *            查询条件
	 * @param keys
	 *            查询字段
	 * @param sort
	 *            排序字段
	 * @param skip
	 *            起始记录index
	 * @param limit
	 *            页size
	 * @return
	 */
	public DBCursor find(DBObject where, DBObject keys, DBObject sort, int skip, int limit) {

		logger.debug("where=={}", where);
		logger.debug("sort=={}", sort);

		DBCursor cursor = find(null, where, keys);
		cursor.skip(skip);
		cursor.limit(limit);
		if (sort != null)
			cursor.sort(sort);
		return cursor;
	}

	/**
	 * 查询返回游标
	 * 
	 * @param where
	 *            查询条件
	 * @param keys
	 *            查询字段
	 * @param page
	 *            分页信息
	 * @return
	 */
	public DBCursor find(DBObject where, DBObject keys, PageBean page) {

		DBObject query = new BasicDBObject();
		if (page != null && !((BasicDBObject) page.getMongoWhere()).isEmpty()) {
			if (where != null)
				query.put(QueryOperators.AND, new DBObject[] { where, page.getMongoWhere() });
			else
				query = page.getMongoWhere();
		} else {
			if (where != null)
				query = where;
		}

		int skip = 0;
		int limit = 0;
		DBObject sort = null;
		if (page != null) {
			sort = page.getMongoSort();
			skip = page.getCursorSkip();
			if (page.isPageShow()) {
				limit = page.getCursorLimit();
				page.setTotalCount((int) getCount(query));
			}
		}

		return find(query, keys, sort, skip, limit);
	}

	/**
	 * 分页查询
	 * 
	 * @param where
	 *            查询条件
	 * @param keys
	 *            查询字段
	 * @param page
	 *            分页参数
	 * @return
	 */
	public List<Map<String, Object>> query(DBObject where, DBObject keys, PageBean page) {

		DBCursor cursor = find(where, keys, page);
		return cursorToList(cursor);
	}

	public List<Map<String, Object>> query(DBObject where, DBObject keys) {

		return query(where, keys, null);
	}

	/**
	 * 分页查询
	 * 
	 * @param where
	 *            查询条件
	 * @param keys
	 *            查询字段
	 * @param page
	 *            分页参数
	 * @return
	 */
	public List<DBObject> queryList(DBObject where, DBObject keys, PageBean page) {

		DBCursor cursor = find(where, keys, page);
		return cursorToObjects(cursor);
	}

	/**
	 * Insert documents into a collection. If the collection does not exists on
	 * the server, then it will be created. If the new document does not contain
	 * an '_id' field, it will be added.
	 */
	public WriteResult insert(DBCollection collection, List<DBObject> list) {

		if (collection == null)
			collection = getColl();
		return collection.insert(list, collection.getWriteConcern(), null);
	}

	/**
	 * 插入一条文档
	 * 
	 * @param collecion
	 *            数据表
	 * @param Object
	 *            文档对象
	 * @return
	 */
	public WriteResult insert(DBCollection collection, DBObject object) {

		if (collection == null)
			collection = getColl();
		WriteResult writeResult = collection.insert(object);
		return writeResult;
	}

	/**
	 * @see #insert(DBCollection, DBObject)
	 */
	public WriteResult insert(DBObject object) {

		return insert(null, object);
	}

	/**
	 * @see #insert(DBObject)
	 */
	public WriteResult insertMap(Map<String, Object> vo) {

		return insert(new BasicDBObject(vo));
	}

	/**
	 * 插入一条文档
	 * 
	 * @param vo
	 *            文档对象
	 * @return 主键
	 */
	public String addOne(Map<String, Object> vo) {

		String _id = CommonUtil.getUUID();
		vo.put(MongoEntity._id, _id);
		insertMap(vo);
		return _id;
	}

	/**
	 * Modify an existing document or documents in collection. By default the
	 * method updates a single document.
	 * 
	 * @param query
	 *            the selection criteria for the update
	 * @param object
	 *            the modifications to apply
	 * @param upsert
	 *            when true, inserts a document if no document matches the
	 *            update query criteria
	 * @param multi
	 *            when true, updates all documents in the collection that match
	 *            the update query criteria, otherwise only updates one
	 * @param concern
	 *            {@code WriteConcern} to be used during operation
	 * @param encoder
	 *            the DBEncoder to use
	 * @return the result of the operation
	 */
	public WriteResult update(DBCollection collection, DBObject query, DBObject object,
			boolean upsert, boolean multi, WriteConcern concern, DBEncoder encoder) {

		if (collection == null)
			collection = getColl();
		if (concern == null)
			concern = collection.getWriteConcern();

		return collection.update(query, object, upsert, multi, concern, encoder);
	}

	/**
	 * @see #update(DBCollection, DBObject, DBObject, boolean, boolean,
	 *      WriteConcern, DBEncoder)
	 */
	public WriteResult update(DBObject query, DBObject object, boolean upsert, boolean multi) {

		return update(null, query, object, upsert, multi, null, null);
	}

	/**
	 * @see #update(DBObject, DBObject, boolean, boolean)
	 */
	public WriteResult update(DBObject query, DBObject object) {

		return update(query, object, false, false);
	}

	/**
	 * @see #update(DBObject, DBObject)
	 */
	public int updateN(DBObject query, DBObject objec) {

		WriteResult result = update(query, objec);
		int count = result.getN();
		logger.debug("update count=={}", count);
		return count;
	}

	public boolean updateById(Map<String, Object> par) {

		DBObject query = new BasicDBObject();
		query.put(MongoEntity._id, par.get(MongoEntity._id));
		DBObject set = new BasicDBObject();
		set.putAll(par);
		set.removeField(MongoEntity._id);
		WriteResult result = update(query, set);
		return result.isUpdateOfExisting();
	}

	/**
	 * Remove documents from a collection.
	 * 
	 * @param o
	 *            the deletion criteria using query operators. Omit the query
	 *            parameter or pass an empty document to delete all documents in
	 *            the collection.
	 * @param concern
	 *            {@code WriteConcern} to be used during operation
	 * @param encoder
	 *            {@code DBEncoder} to be used
	 * @return the result of the operation
	 */
	public WriteResult remove(DBCollection collection, DBObject o, WriteConcern concern,
			DBEncoder encoder) {

		if (collection == null)
			collection = getColl();
		if (concern == null)
			concern = collection.getWriteConcern();

		return collection.remove(o, concern, encoder);
	}

	/**
	 * @see #remove(DBCollection, DBObject, WriteConcern, DBEncoder)
	 */
	public WriteResult remove(DBObject object) {

		return remove(null, object, null, null);
	}

	/**
	 * delete all documents in the collection
	 * 
	 * @see #remove(DBObject)
	 */
	public WriteResult remove() {

		return remove(new BasicDBObject());
	}

	/**
	 * @see #remove(DBObject)
	 */
	public int removeN(DBObject object) {

		WriteResult result = remove(object);
		int count = result.getN();
		logger.debug("remove count=={}", count);
		return count;
	}

	/**
	 * 按主键删除
	 * 
	 * @see #remove(DBObject)
	 * @param _id
	 *            主键
	 * @return
	 */
	public WriteResult remove(String _id) {

		return remove(new BasicDBObject(MongoEntity._id, _id));
	}

	/**
	 * 数据库连接认证
	 * 
	 * @param db
	 *            数据库
	 * @param username
	 *            用户名
	 * @param password
	 *            密码
	 * @return
	 */
	public boolean auth(DB db, String username, String password) {

		return db.authenticate(username, password.toCharArray());
	}

	/**
	 * Atomically modify and return a single document. By default, the returned
	 * document does not include the modifications made on the update.
	 * 
	 * @param query
	 *            specifies the selection criteria for the modification
	 * @param fields
	 *            a subset of fields to return
	 * @param sort
	 *            determines which document the operation will modify if the
	 *            query selects multiple documents
	 * @param remove
	 *            when true, removes the selected document
	 * @param returnNew
	 *            when true, returns the modified document rather than the
	 *            original
	 * @param update
	 *            the modifications to apply
	 * @param upsert
	 *            when true, operation creates a new document if the query
	 *            returns no documents
	 * @return the document as it was before the modifications, unless
	 *         {@code returnNew} is true, in which case it returns the document
	 *         after the changes were made
	 */
	public DBObject findAndModify(DBCollection collection, DBObject query, DBObject fields,
			DBObject sort, boolean remove, DBObject update, boolean returnNew, boolean upsert) {

		if (collection == null)
			collection = getColl();
		return collection.findAndModify(query, fields, sort, remove, update, returnNew, upsert);
	}

	/**
	 * getCollectionNames
	 */
	public Set<String> getCollectionNames(DB db) {

		return db.getCollectionNames();
	}

	/**
	 * getCollection
	 */
	public DBCollection getCollection(DB db, String name) {

		return db.getCollection(name);
	}

	/**
	 * getDatabaseNames
	 * 
	 * @return
	 */
	public List<String> getDatabaseNames() {

		return getClient().getDatabaseNames();
	}

	/**
	 * getDB
	 * 
	 * @param dbname
	 * @return
	 */
	public DB getDB(String dbname) {

		return getClient().getDB(dbname);
	}

	/**
	 * save，文档不存在时插入，存在时更新
	 */
	public WriteResult save(DBCollection collecion, DBObject jo, WriteConcern concern) {

		return collecion.save(jo, concern);
	}

	/**
	 * 查询返回游标
	 * 
	 * @param collecion
	 *            数据表
	 * @return 游标
	 */
	public DBCursor find(DBCollection collecion) {

		DBCursor cursor = collecion.find();

		return cursor;
	}

	/**
	 * 查询结果集游标转换为List集合
	 * 
	 * @param cursor
	 *            游标
	 * @return List集合
	 */
	public List<Map<String, Object>> cursorToList(DBCursor cursor) {

		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		while (cursor.hasNext()) {
			list.add(cursor.next().toMap());
		}
		cursor.close();
		return list;
	}

	/**
	 * 查询结果集游标转换为List集合
	 * 
	 * @param cursor
	 *            游标
	 * @return List集合
	 */
	public List<DBObject> cursorToObjects(DBCursor cursor) {

		List<DBObject> list = new ArrayList<DBObject>();
		while (cursor.hasNext()) {
			list.add(cursor.next());
		}
		cursor.close();
		return list;
	}

	/**
	 * Map to DBObject
	 */
	public <T extends Object> DBObject mapToDBObject(Map<String, T> map, String[] names,
			boolean uuid, boolean lower) {

		if (map == null)
			return null;

		DBObject dbObject = new BasicDBObject();

		if (names == null) {

			Set<Entry<String, T>> set = map.entrySet();
			Iterator<Entry<String, T>> iterator = set.iterator();
			Entry<String, T> entry = null;
			while (iterator.hasNext()) {
				entry = iterator.next();
				if (lower)
					dbObject.put(entry.getKey().toLowerCase(), entry.getValue());
				else
					dbObject.put(entry.getKey(), entry.getValue());
			}

			if (uuid) {
				dbObject.put("_id", map.get("ID"));
			}

		} else {

			for (String name : names) {
				if (name.indexOf("@") == -1) {
					if (lower)
						dbObject.put(name.toLowerCase(), map.get(name));
					else
						dbObject.put(name, map.get(name));
				} else {
					String[] array = name.split("@");
					dbObject.put(array[1], map.get(array[0]));
				}
			}

			if (uuid) {
				dbObject.put("_id", map.get("ID"));
			}
		}

		return dbObject;
	}

	/**
	 * json to map
	 * 
	 * @param json
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Object> jsonToMap(DBObject json) {

		if (json == null)
			return null;

		return json.toMap();
	}

	/**
	 * 查询字段筛选
	 * 
	 * @see #queryFilter(String[], String[])
	 * @param queryNames
	 *            字段数组
	 * @return 查询字段集合
	 */
	public DBObject queryFilter(String[] queryNames) {

		return queryFilter(queryNames, null);
	}

	/**
	 * 查询字段筛选
	 * 
	 * @param queryNames
	 *            查询字段数组
	 * @param filterNames
	 *            过滤字段数组
	 * @return 查询字段集合
	 */
	public DBObject queryFilter(String[] queryNames, String[] filterNames) {

		DBObject filter = new BasicDBObject();
		if (queryNames != null) {
			for (String name : queryNames) {
				filter.put(name, 1);
			}
		}
		if (filterNames != null) {
			for (String name : filterNames) {
				filter.put(name, 0);
			}
		}
		return filter;
	}

	public WriteResult insert(E e) {

		DBObject object = ObjectUtils.javaObjectToDBObject(e);
		return insert(null, object);
	}

	public WriteResult insert(List<E> es) {

		List<DBObject> dboList = new ArrayList<>();
		for (E e : es) {
			DBObject object = ObjectUtils.javaObjectToDBObject(e);
			dboList.add(object);
		}
		return insert(null, dboList);
	}

	/**
	 * 添加或者更新时验证是否存在
	 */
	public boolean checkUnique(String[] uks, Object[] ukParams, String[] pks, Object[] pkParams) {

		if (uks == null) {
			return false;
		}
		DBObject query = new BasicDBObject();
		if (uks.length == ukParams.length && uks.length > 1) {
			List<DBObject> params = new ArrayList<DBObject>();
			for (int i = 0; i < uks.length; i++) {
				params.add(new BasicDBObject(uks[i], ukParams[i]));
			}
			query.put(QueryOperators.AND, params);
		} else if (uks.length == ukParams.length && uks.length == 1) {
			query.put(uks[0], ukParams[0]);
		} else {
			return false;
		}
		DBObject where = new BasicDBObject();
		DBObject query2 = new BasicDBObject();
		if (pks != null && pkParams.length > 0 && pks.length == pkParams.length) {
			if (pks.length == pkParams.length && pks.length > 1) {
				List<DBObject> params = new ArrayList<DBObject>();
				for (int i = 0; i < pks.length; i++) {
					params.add(new BasicDBObject(pks[i],
							new BasicDBObject(QueryOperators.NE, pkParams[i])));
				}
				query2.put(QueryOperators.OR, params);
			} else if (pks.length == pkParams.length && pks.length == 1) {
				query2.put(pks[0], new BasicDBObject(QueryOperators.NE, pkParams[0]));
			} else {
				return false;
			}
			where.put(QueryOperators.AND, new DBObject[] { query, query2 });

		} else {
			where = query;
		}

		long count = getCount(where);
		if (count > 0) {// 说明已存在
			return false;
		} else {
			return true;
		}
	}

	public MapReduceOutput mapReduce(String map, String reduce, String outputTarget,
			DBObject query) {

		return getColl().mapReduce(map, reduce, outputTarget, query);
	}

	public DBObject group(DBObject key, DBObject cond, DBObject initial, String reduce,
			String finalize) {

		return getColl().group(key, cond, initial, reduce, finalize);
	}

	public DBObject group(DBObject key, DBObject cond, DBObject initial, String reduce) {

		return group(key, cond, initial, reduce, null);
	}

	public List distinct(String key, DBObject query) {

		return getColl().distinct(key, query);
	}

}
