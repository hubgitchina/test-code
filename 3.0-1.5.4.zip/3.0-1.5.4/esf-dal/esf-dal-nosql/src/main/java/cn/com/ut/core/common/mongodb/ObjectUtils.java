/*
 * Copyright 2013 The UTFoodPortalSE Project. Zhuhai Unitech Power Technology Co.,Ltd. All Rights Reserved.
 */

package cn.com.ut.core.common.mongodb;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

/**
 * java对象到DBObject转换工具类
 * @author chexingyou
 * @since   2014-6-25
 */
public class ObjectUtils {

	private static final List<Class<?>> typePrimitive = Arrays.asList(new Class<?>[] {
			java.lang.Integer.class, java.lang.Boolean.class, java.lang.Character.class,
			java.lang.Byte.class, java.lang.Short.class, java.lang.Long.class,
			java.lang.Float.class, java.lang.Double.class, java.util.Date.class,
			java.lang.String.class, java.sql.Timestamp.class });

	
	/**
	 * java Object to DBObject
	 * @param javaObject
	 * @return DBObject
	 */
	public static DBObject javaObjectToDBObject(Object javaObject){
		
		DBObject object = new BasicDBObject();
		JSONObject map = (JSONObject) JSONObject.toJSON(javaObject);
		map.put("_id", map.get("id"));
		map.remove("id");
		object.putAll(map);
		return object;
	}

	/**
	 * dbObject to JavaObject
	 * @param obj
	 * @param clazz
	 * @return JavaObject
	 */
	public static <T> T dbObjectToJavaObject(DBObject obj, Class<T> clazz) {

		String jsonstr = JSONObject.toJSONString(obj).replace("\"_id\"", "\"id\"");
		return JSONObject.parseObject(jsonstr, clazz);
	}
	
	/**
	 * Object to map
	 * @param obj
	 * @return map或者null
	 */
	public static Map<String, Object> beanToMap(Object obj) {

		if (obj == null) {
			return null;
		}
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
			PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
			for (PropertyDescriptor property : propertyDescriptors) {
				String key = property.getName();
				Class<?> type = property.getPropertyType();
				if (type.isPrimitive() || typePrimitive.contains(type)) {
					// 过滤class属性
					if (!key.equals("class")) {
						// 得到property对应的getter方法
						Method getter = property.getReadMethod();
						Object value = getter.invoke(obj);
						map.put(key, value);
					}
				}
			}
		} catch (Exception e) {
			System.out.println("transBean2Map Error " + e);
		}
		return map;
	}
}
