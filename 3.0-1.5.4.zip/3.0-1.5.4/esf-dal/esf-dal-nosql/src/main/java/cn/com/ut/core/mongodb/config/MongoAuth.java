package cn.com.ut.core.mongodb.config;

public class MongoAuth {

	private String cluster;
	private DbInfo dbInfo;

	public String getCluster() {

		return cluster;
	}

	public void setCluster(String cluster) {

		this.cluster = cluster;
	}

	public DbInfo getDbInfo() {

		return dbInfo;
	}

	public void setDbInfo(DbInfo dbInfo) {

		this.dbInfo = dbInfo;
	}

}
