package cn.com.ut.core.mongodb;

public interface MongoDAO {

}
