package cn.com.ut.core.mongodb.manager;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.springframework.stereotype.Component;

import cn.com.ut.core.common.util.io.FileUtil;
import cn.com.ut.core.common.util.xml.XmlUtil;
import cn.com.ut.core.mongodb.element.HostElement;
import cn.com.ut.core.mongodb.element.MongoResourceElement;
import cn.com.ut.core.mongodb.element.ServerElement;

/**
 * 服务器集群连接管理
 * 
 * @author wuxiaohua
 * @since 2015-12-30
 */
//@Component
public class MongoServerManager {

	/**
	 * mongo-server 配置文件路径
	 */
	public static final String MONGO_SERVER_PATH = "cn/com/ut/config/mongodb/mongo-server.xml";

	private final Map<String, ServerElement> serverMap = new TreeMap<String, ServerElement>();

	public Map<String, ServerElement> getServerElements() {

		return serverMap;
	}

	public ServerElement getServerElement(String name) {

		if (name == null) {
			throw new IllegalArgumentException("name is null");
		}

		return serverMap.get(name);
	}

	/**
	 * 解析服务器集群连接，构建服务器连接对象
	 */
	@PostConstruct
	public void init() {

		Document doc = null;
		Element root = null;
		try {
			doc = XmlUtil.readXml(MONGO_SERVER_PATH);
			root = doc.getRootElement();
		} catch (DocumentException e) {
			e.printStackTrace();
			return;
		}

		putServerElement(root);

		List<MongoResourceElement> resourceElements = XmlUtil
				.toElementList(root.selectNodes("resources/resource"), MongoResourceElement.class);

		if (resourceElements != null && !resourceElements.isEmpty()) {
			for (MongoResourceElement r : resourceElements) {
				List<URL> urls = FileUtil.listUrls(r.getName(), null);
				if (urls != null) {
					for (URL url : urls) {
						Document resDoc = null;
						try {
							resDoc = XmlUtil.readXml(url);
						} catch (DocumentException e) {
						}
						if (resDoc != null) {
							putServerElement(resDoc.getRootElement());
						}
					}
				}
			}
		}
	}

	/**
	 * 解析服务器连接对象
	 * 
	 * @param root
	 *            文档元素
	 */
	private void putServerElement(Element root) {

		List<Element> servers = root.elements("server");
		if (servers != null && !servers.isEmpty()) {
			for (Element server : servers) {

				ServerElement serverElement = XmlUtil.toElement(server, ServerElement.class);
				List<HostElement> hosts = XmlUtil.toElementList(server.elements(),
						HostElement.class);
				serverElement.setHosts(hosts);
				serverMap.put(serverElement.getName(), serverElement);
			}
		}
	}

	@PreDestroy
	public void destroy() {

		serverMap.clear();
	}

	public static void main(String[] args) {

		MongoServerManager m = new MongoServerManager();
		m.init();
		// System.out.println(m.serverMap);
	}
}
