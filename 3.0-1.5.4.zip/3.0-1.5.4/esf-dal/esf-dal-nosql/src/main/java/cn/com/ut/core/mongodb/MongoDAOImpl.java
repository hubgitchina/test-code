package cn.com.ut.core.mongodb;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.springframework.stereotype.Repository;

import cn.com.ut.core.common.util.ArrayUtil;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBEncoder;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.ReadPreference;
import com.mongodb.WriteConcern;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.WriteResult;

/**
 * @author wuxiaohua
 * @since 2015-12-30
 * @see MongoOperation
 */
@Repository
public class MongoDAOImpl implements MongoDAO {

	private MongoClient mongoClient;
	private MongoClientOptions mongoClientOptions;
	private ServerAddress serverAddress;
	private List<ServerAddress> serverAddressList;
	private List<MongoCredential> credentialsList;
	private MongoCredential credentials;

	public static final int DEFAULT_PORT = 27017;

	private String mongos = "192.168.30.233:27020";

	// private String mongos = "192.168.50.233:27017,192.168.50.233:27018,192.168.50.233:27019;

	private MongoDAOImpl() {

	}

	public MongoDAOImpl(String mongos) {

		if (mongos != null)
			this.mongos = mongos;

		final String mechanism = MongoCredential.MONGODB_CR_MECHANISM;
		final String userName = "root";
		final String database = "db1";
		final char[] password = "123456".toCharArray();
		credentials = MongoCredential.createMongoCRCredential(userName, database, password);

		try {
			serverAddressList = parseMongoAddress(this.mongos);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		Builder builder = MongoClientOptions.builder();
		// Sets the maximum number of connections per host.
		builder.connectionsPerHost(1);

		mongoClientOptions = builder.build();

		credentialsList = Arrays.asList(credentials);
		mongoClient = new MongoClient(serverAddressList, null, mongoClientOptions);
	}

	protected List<ServerAddress> parseMongoAddress(String mongos) throws UnknownHostException {

		List<ServerAddress> list = new ArrayList<ServerAddress>();

		if (mongos == null || mongos.trim().length() == 0)
			return list;

		String[] urls = mongos.split(",");
		for (String url : urls) {
			String[] array = url.split(":");
			if (array.length == 2) {
				list.add(new ServerAddress(array[0], Integer.parseInt(array[1])));
			} else {
				list.add(new ServerAddress(array[0], DEFAULT_PORT));
			}
		}

		return list;
	}

	/**
	 * getWriteConcern
	 */
	public WriteConcern getWriteConcern(DB db) {

		return db.getWriteConcern();
	}

	/**
	 * getReadPreference
	 */
	public ReadPreference getReadPreference(DB db) {

		return db.getReadPreference();
	}

	/**
	 * DBEncoder
	 */

	/**
	 * count
	 */
	public long getCount(DBCollection collection, DBObject query, DBObject fields, long limit,
			long skip, ReadPreference readPrefs) {

		return collection.getCount(query, fields, limit, skip, readPrefs);
	}

	/**
	 * findOne
	 */
	public DBObject findOne(DBCollection collection, DBObject o, DBObject fields, DBObject orderBy,
			ReadPreference readPref) {

		return collection.findOne(o, fields, orderBy, readPref);
	}

	/**
	 * DBCursor
	 */
	public DBCursor find(DBCollection collection, DBObject ref, DBObject keys) {

		return collection.find(ref, keys);
	}

	/**
	 * QueryOpBuilder
	 */

	/**
	 * QueryBuilder
	 */

	/**
	 * QueryOperators
	 */

	/**
	 * ReadPreference
	 */

	/**
	 * orderBy
	 */

	/**
	 * query，返回List<Map<String, Object>>
	 */

	/**
	 * limit，skip
	 */

	/**
	 * Insert documents into a collection. If the collection does not exists on
	 * the server, then it will be created. If the new document does not contain
	 * an '_id' field, it will be added.
	 * 
	 * insert，map，java（部分或全部字段），uuid
	 */
	public WriteResult insert(DBCollection collection, List<DBObject> list, WriteConcern concern,
			DBEncoder encoder) {

		return collection.insert(list, concern, encoder);
	}

	/**
	 * insert
	 * 
	 * @param collecion
	 * @param Object
	 * @return
	 */

	public WriteResult insert(DBCollection collecion, DBObject Object) {

		WriteResult writeResult = collecion.insert(Object);
		return writeResult;
	}

	/**
	 * update，where字段，update字段
	 */
	public WriteResult update(DBCollection collection, DBObject q, DBObject o, boolean upsert,
			boolean multi, WriteConcern concern, DBEncoder encoder) {

		return collection.update(q, o, upsert, multi, concern, encoder);
	}

	/**
	 * remove，where字段
	 */
	public WriteResult remove(DBCollection collection, DBObject o, WriteConcern concern,
			DBEncoder encoder) {

		return collection.remove(o, concern, encoder);
	}

	/**
	 * where字段，order字段，group
	 */

	/**
	 * map reduce
	 */

	/**
	 * Write Concern
	 */

	/**
	 * Aggregation
	 */

	/**
	 * index
	 */

	/**
	 * DBCollection
	 */

	/**
	 * DBCollectionImpl
	 */

	/**
	 * PageBean
	 */

	/**
	 * array push
	 */

	/**
	 * array pop
	 */

	/**
	 * auth
	 */
	public boolean auth(DB db, String username, String password) {

		return db.authenticate(username, password.toCharArray());
	}

	/**
	 * slaveOk废弃， Replaced with {@link ReadPreference#secondaryPreferred()}
	 */

	/**
	 * findAndModify
	 */
	public DBObject findAndModify(DBCollection collection, final DBObject query,
			final DBObject fields, final DBObject sort, final boolean remove,
			final DBObject update, final boolean returnNew, final boolean upsert) {

		return collection.findAndModify(query, fields, sort, remove, update, returnNew, upsert);
	}

	/**
	 * findAndRemove
	 */

	/**
	 * getCollectionNames
	 */
	public Set<String> getCollectionNames(DB db) {

		return db.getCollectionNames();
	}

	/**
	 * getCollection
	 */
	public DBCollection getCollection(DB db, String name) {

		return db.getCollection(name);
	}

	/**
	 * getDatabaseNames
	 * 
	 * @return
	 */
	public List<String> getDatabaseNames() {

		return mongoClient.getDatabaseNames();
	}

	/**
	 * getDB
	 * 
	 * @param dbname
	 * @return
	 */
	public DB getDB(String dbname) {

		return mongoClient.getDB(dbname);
	}

	/**
	 * upsert，
	 */

	/**
	 * save，文档不存在时插入，存在时更新
	 */
	public WriteResult save(DBCollection collecion, DBObject jo, WriteConcern concern) {

		return collecion.save(jo, concern);
	}

	/**
	 * update batch
	 */

	/**
	 * findAndModify
	 */

	public DBCursor find(DBCollection collecion) {

		DBCursor cursor = collecion.find();

		return cursor;
	}

	public void foreach(DBCursor cursor, boolean close) {

		while (cursor.hasNext()) {
			DBObject object = cursor.next();
			System.out.println(object.toString());
			Map map = object.toMap();
			System.out.println(map);
		}
		if (close)
			cursor.close();
	}

	/**
	 * Map to DBObject
	 */
	public <T extends Object> DBObject mapToDBObject(Map<String, T> map, String[] names,
			boolean uuid, boolean lower) {

		if (map == null)
			return null;

		DBObject dbObject = new BasicDBObject();

		if (uuid) {
			names = ArrayUtil.joinArray(names, new String[] { "ID@_id" });
		}

		if (names == null) {

			Set<Entry<String, T>> set = map.entrySet();
			Iterator<Entry<String, T>> iterator = set.iterator();
			Entry<String, T> entry = null;
			while (iterator.hasNext()) {
				entry = iterator.next();
				if (lower)
					dbObject.put(entry.getKey().toLowerCase(), entry.getValue());
				else
					dbObject.put(entry.getKey(), entry.getValue());
			}
		} else {
			for (String name : names) {
				if (name.indexOf("@") == -1) {
					if (lower)
						dbObject.put(name.toLowerCase(), map.get(name));
					else
						dbObject.put(name, map.get(name));
				} else {
					String[] array = name.split("@");
					dbObject.put(array[1], map.get(array[0]));
				}
			}
		}

		return dbObject;
	}

}
