package cn.com.ut.core.dal.constant;

public class DALConstant {

}
