package cn.com.ut.core.dal.jdbc;

/**
 * DAO方法标识性参数
 * 
 * @author wuxiaohua
 * @since 2014-3-11
 */
public interface DAOParameter {

}
