package cn.com.ut.core.dal.beans;

public class SQLElement extends BaseElement {

	private static final long serialVersionUID = 3780001603056455361L;
	
	
}
