package cn.com.ut.core.common.util.reflect;
/**
* 反射异常
* @author wuxiaohua
* @since 2013-12-22下午2:27:50
*/
public class ReflectException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1886313802782081622L;

	public ReflectException() {

		super();
		// TODO Auto-generated constructor stub
	}

	public ReflectException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {

		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ReflectException(String message, Throwable cause) {

		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ReflectException(String message) {

		super(message);
		// TODO Auto-generated constructor stub
	}

	public ReflectException(Throwable cause) {

		super(cause);
		// TODO Auto-generated constructor stub
	}

}
