package cn.com.ut.core.dal.beans;

public class LogicSchemaVO extends BaseElement {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	public LogicSchemaVO() {

	}

	public LogicSchemaVO(String name) {

		this.name = name;
	}
}
