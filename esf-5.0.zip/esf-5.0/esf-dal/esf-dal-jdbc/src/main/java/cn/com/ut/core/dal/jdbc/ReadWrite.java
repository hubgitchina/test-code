package cn.com.ut.core.dal.jdbc;

public enum ReadWrite {

	READ, WRITE;
}
