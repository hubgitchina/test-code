package cn.com.ut.core.dal.beans;

public class ResourceElement extends BaseElement {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

}
