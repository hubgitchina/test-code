package cn.com.ut.core.dal.beans;

public class TableVO extends BaseElement {

	private static final long serialVersionUID = 8689422580133905691L;
	
}
