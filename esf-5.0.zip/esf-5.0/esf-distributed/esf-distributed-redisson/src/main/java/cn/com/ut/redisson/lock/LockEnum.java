package cn.com.ut.redisson.lock;

/**
 * @author wuxiaohua
 * @since 2018/10/30
 */
public enum LockEnum {

	FairLock, Lock, ReadLock, WriteLock;
}
