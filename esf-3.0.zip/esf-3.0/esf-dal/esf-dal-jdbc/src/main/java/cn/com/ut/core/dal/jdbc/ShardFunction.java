package cn.com.ut.core.dal.jdbc;


public class ShardFunction {

	public static final int MOD = 2;
	
	public static void main(String[] args) {

		
	}
}
