package cn.com.ut.core.mongodb.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.com.ut.core.mongodb.MongoDAOImpl;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.QueryOperators;
import com.mongodb.WriteConcern;
import com.mongodb.WriteResult;

public class MongoDAOTest {

	private static final Logger logger = LoggerFactory.getLogger(MongoDAOTest.class);

	private MongoDAOImpl mgDAO;
	private DB db;
	private DBCollection coll;

	@BeforeClass
	public static void setup() {

	}

	@Before
	public void init() {

		String mongos = "127.0.0.1:27020";
		mongos = "127.0.0.1:27017,127.0.0.1:27018,127.0.0.1:27019";
		mgDAO = new MongoDAOImpl(mongos);
		db = mgDAO.getDB("db1");
		// db.authenticate("root", "123456".toCharArray());
		coll = db.getCollection("c1");
	}

	@Test
	public void mongoRemoveAll() {

		mgDAO.remove(coll, new BasicDBObject(), db.getWriteConcern(), null);
	}

	@Test
	public void mgFindOne() {

		DBObject object = mgDAO.findOne(coll, new BasicDBObject(), new BasicDBObject(),
				new BasicDBObject(), db.getReadPreference());
		Object _id = object.get("_id");
		System.out.println(_id instanceof ObjectId);
		System.out.println(_id);
	}

	@Test
	public void mgGetCount() {

		BasicDBObject fields = new BasicDBObject();
		BasicDBObject query = new BasicDBObject();

		query.append("sex", new BasicDBObject("$exists", false));

		long count = mgDAO.getCount(coll, query, fields, 0, 0, db.getReadPreference());
		System.out.println("count==" + count);
	}

	@Test
	public void mgFindAll() {

		BasicDBObject ref = new BasicDBObject();

		BasicDBObject ageRef = new BasicDBObject();
		ageRef.append(QueryOperators.GTE, 1);
		ageRef.append(QueryOperators.LTE, 100);
		// ageRef.append(QueryOperators.IN, new int[] { 5, 10, 15, 20, 25, 30
		// });
		ref.append("age", ageRef);

		BasicDBObject nameRef = new BasicDBObject();
		nameRef.append(QueryOperators.OR, new BasicDBObject[] { new BasicDBObject("name", "n1"),
				new BasicDBObject("name", "n2"), new BasicDBObject("name", "n58") });

		ref.append(QueryOperators.OR, nameRef.get(QueryOperators.OR));

		BasicDBObject keys = new BasicDBObject();
		keys.append("_id", 0);
		keys.append("name", 1);
		keys.append("age", 1);
		keys.append("email", 1);
		keys.append("sub", 1);
		keys.append("sex", 1);

		DBCursor cursor = mgDAO.find(coll, ref, keys);

		// cursor.addSpecial("temp", new Random().nextInt(1000));

		cursor.skip(0); // skip
		cursor.limit(10); // limit
		// cursor.sort(new BasicDBObject("name", 1).append("age", -1)); // sort

		System.out.println("Query==" + cursor.getQuery());
		System.out.println("Keys==" + cursor.getKeysWanted());

		System.out.println(cursor.count());

		// while (cursor.hasNext()) {
		// Map map = cursor.next().toMap();
		// System.out.println(map);
		// }

		List<Map<String, Object>> itemList = new ArrayList<Map<String, Object>>();
		List<DBObject> rs = cursor.toArray();
		for (DBObject o : rs) {
			itemList.add(o.toMap());
		}
		System.out.println("many==" + itemList);

		// DBObject one = cursor.one();
		// System.out.println("one==" + one);

	}

	@Test
	public void mgUpdateBySetter() {

		boolean multi = false;
		boolean upsert = true;

		BasicDBObject nameRef = new BasicDBObject();
		nameRef.append(QueryOperators.OR, new BasicDBObject[] { new BasicDBObject("name", "n1"),
				new BasicDBObject("name", "n2") });

		BasicDBObject set = new BasicDBObject();

		set.append("email", "eqqcom");
		set.append("sex", 0); // test upsert

		BasicDBObject object = new BasicDBObject();
		object.append("$set", set);
		object.append("$inc", new BasicDBObject("age", 2));

		mgDAO.update(coll, nameRef, object, upsert, multi, db.getWriteConcern(), null);

	}

	@Test
	public void mgSave() {

		BasicDBObject object = new BasicDBObject();
		object.put("name", "wu");
		object.put("email", "wu@163.com");
		object.put("age", "17");
		mgDAO.save(coll, object, db.getWriteConcern());

		DBObject doc = mgDAO.findOne(coll, new BasicDBObject("_id", new ObjectId(
				"537f004048e678ceada29ff2")), null, null, db.getReadPreference());
		System.out.println("save==" + doc);
	}

	@Test
	public void mgFindAndModify() {

		BasicDBObject query = new BasicDBObject();

		BasicDBObject nameRef = new BasicDBObject();
		nameRef.append(QueryOperators.OR, new BasicDBObject[] { new BasicDBObject("name", "n1"),
				new BasicDBObject("name", "n2") });
		query = nameRef;

		BasicDBObject fields = new BasicDBObject("name", 1).append("age", 1).append("email", 1);
		BasicDBObject sort = new BasicDBObject("name", -1);
		boolean remove = false;
		BasicDBObject update = new BasicDBObject("$set", new BasicDBObject("email", "e126com"));
		boolean returnNew = true;
		boolean upsert = false;
		DBObject returnDoc = mgDAO.findAndModify(coll, query, fields, sort, remove, update,
				returnNew, upsert);
		System.out.println("modify==" + returnDoc);
	}

	@Test
	public void mgInsertList() {

		int N = 20;
		int index = 1;
		List<DBObject> list = new ArrayList<DBObject>();
		for (; index < N; index++) {
			BasicDBObject obj = new BasicDBObject();
			obj.append("_id", "id" + index);
			obj.append("name", "n" + index);
			obj.append("email", "e" + index);
			obj.append("age", index);
			BasicDBObject sub = new BasicDBObject();
			sub.append("car", new String[] { "奔驰" + index, "宝马" + index });
			sub.append("city", "纽约" + index);
			obj.append("sub", sub);
			list.add(obj);
		}

		db.setWriteConcern(WriteConcern.ACKNOWLEDGED);
		WriteResult wr = mgDAO.insert(coll, list, db.getWriteConcern(), null);
		System.out.println("n==" + wr.getN());
	}

	@Test
	public void mongoInsert() {

		Map<String, Object> map = new HashMap<String, Object>();
		int N = 21;
		map.put("ID", "id" + N);
		map.put("name", "n" + N);
		map.put("age", N);
		map.put("email", "e" + N);
		map.put("grade", 0.25 + N);
		map.put("time", new Date());

		DBObject object = mgDAO.mapToDBObject(map, new String[] { "name", "age", "grade", "time" },
				true, true);
		// System.out.println(object.toMap());

		WriteResult wr = mgDAO.insert(coll, mgDAO.mapToDBObject(map, new String[] { "name", "age",
				"grade", "time", "email" }, true, true));
		System.out.println(wr.getN());
		System.out.println("==");

	}

	@Test
	public void dynamicWhere() {
		
		String exp = "(nick=? OR pwd=?) AND ((name=? AND age>?) OR (email=? OR city=?))";
		
		BasicDBObject o1 = new BasicDBObject().append("$or", new BasicDBObject[]{new BasicDBObject("nick", ""),new BasicDBObject("pwd", "")});
	}

	@Test
	public void dynamicOrderBy() {

	}
}
