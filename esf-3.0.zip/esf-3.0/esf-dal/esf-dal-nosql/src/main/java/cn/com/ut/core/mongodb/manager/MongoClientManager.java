package cn.com.ut.core.mongodb.manager;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientOptions.Builder;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.mongodb.config.MongoAddress;
import cn.com.ut.core.mongodb.config.MongoAuth;
import cn.com.ut.core.mongodb.config.MongoConfig;

/**
 * 数据库连接管理
 * 
 * @author wuxiaohua
 * @since 2015-12-30
 */
@Component
public class MongoClientManager {

	@Autowired
	private MongoConfig config;

	/**
	 * 数据库客户端连接管理
	 */
	private final Map<String, MongoClient> clients = new TreeMap<String, MongoClient>();

	/**
	 * 数据库客户端连接参数
	 */
	private MongoClientOptions mongoClientOptions;

	/**
	 * 根据集群名称获取客户端连接对象
	 * 
	 * @param name
	 *            集群名称
	 * @return
	 */
	public MongoClient getMongoClient(String name) {

		if (name == null) {
			throw new IllegalArgumentException("Argument is null");
		}

		return clients.get(name);
	}

	public MongoClientManager() {

		mongoClientOptions = buildMongoClientOptions();
	}

	/**
	 * 构建客户端连接参数
	 * 
	 * @return
	 */
	private MongoClientOptions buildMongoClientOptions() {

		Builder builder = MongoClientOptions.builder();
		builder.connectionsPerHost(3);
		builder.threadsAllowedToBlockForConnectionMultiplier(10);
		MongoClientOptions mongoClientOptions = builder.build();
		return mongoClientOptions;
	}

	/**
	 * 解析服务器连接、数据库连接认证，构建客户端连接对象
	 */
	@PostConstruct
	public void init() {

		if (!ConstantUtil.FLAG_TRUE.equals(config.getEnable()))
			return;

		if (CollectionUtil.isEmptyCollection(config.getMongoAddress()))
			return;

		for (MongoAddress mongoAddress : config.getMongoAddress()) {
			List<ServerAddress> serverAddressList = new ArrayList<ServerAddress>();
			String[] serverArray = mongoAddress.getAddress().split(",");
			for (String server : serverArray) {
				String[] addr = server.split(":");
				try {
					ServerAddress address = new ServerAddress(addr[0], Integer.parseInt(addr[1]));
					serverAddressList.add(address);
				} catch (NumberFormatException e) {
				} catch (UnknownHostException e) {
				}
			}

			List<MongoCredential> mongoCredentials = new ArrayList<MongoCredential>();
			if (!CollectionUtil.isEmptyCollection(config.getMongoAuths())) {

				for (MongoAuth mongoAuth : config.getMongoAuths()) {
					if (!CommonUtil.isEmpty(mongoAuth.getDbInfo().getUserName())
							&& mongoAddress.getCluster().equals(mongoAuth.getCluster())) {
						MongoCredential mongoCredential = MongoCredential.createMongoCRCredential(
								mongoAuth.getDbInfo().getUserName(),
								mongoAuth.getDbInfo().getName(),
								mongoAuth.getDbInfo().getPassword().toCharArray());
						mongoCredentials.add(mongoCredential);
					}
				}
			}

			MongoClient mongoClient = new MongoClient(serverAddressList, mongoCredentials,
					mongoClientOptions);

			clients.put(mongoAddress.getCluster(), mongoClient);

		}

	}

	@PreDestroy
	public void destroy() {

		clients.clear();
	}
}
