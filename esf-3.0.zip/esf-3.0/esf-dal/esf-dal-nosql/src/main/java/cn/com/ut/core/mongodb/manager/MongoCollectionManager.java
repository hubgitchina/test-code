package cn.com.ut.core.mongodb.manager;

public class MongoCollectionManager {

}
