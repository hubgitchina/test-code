package cn.com.ut.core.mongodb;

import java.util.List;

import com.mongodb.DBObject;
import com.mongodb.WriteResult;

public interface MongoOperationApi<E extends MongoEntity> {

	public WriteResult insert(E e);

	public WriteResult insert(List<E> es);

	public WriteResult update(DBObject query, DBObject object, boolean upsert, boolean multi);

	public boolean checkUnique(String[] uks, Object[] ukParams, String[] pks, Object[] pkParams);

	public long getCount(DBObject query);
}
