package cn.com.ut.core.common.mongodb;
/**
* mongodb数据库操作符常量
* @author wuxiaohua
* @since 2013-12-22下午2:17:45
*/
public class MongoOperatorConstant {

	/**
	 * $inc
	 */
	public static final String INC = "$inc";
	/**
	 * $set
	 */
	public static final String SET = "$set";
	/**
	 * $unset
	 */
	public static final String UNSET = "$unset";
	/**
	 * $push
	 */
	public static final String PUSH = "$push";
	/**
	 * $pop
	 */
	public static final String POP = "$pop";
	/**
	 * $pull
	 */
	public static final String PULL = "$pull";
	/**
	 * $addToSet
	 */
	public static final String ADDTOSET = "$addToSet";
	/**
	 * $slice对数组分页用
	 */
	public static final String SLICE = "$slice";

	/**
	 * ASC
	 */
	public static final int SORT_ASC = 1;
	/**
	 * DESC
	 */
	public static final int SORT_DESC = -SORT_ASC;
}
