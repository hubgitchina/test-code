package cn.com.ut.core.mongodb.manager;

import java.net.URL;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.springframework.stereotype.Component;

import cn.com.ut.core.common.util.io.FileUtil;
import cn.com.ut.core.common.util.xml.XmlUtil;
import cn.com.ut.core.mongodb.element.DBElement;
import cn.com.ut.core.mongodb.element.MongoResourceElement;
import cn.com.ut.core.mongodb.element.ServerElement;

/**
 * 数据库认证管理
 * 
 * @author wuxiaohua
 * @since 2015-12-30
 */
//@Component
public class MongoAuthManager {

	/**
	 * mongo-auth 配置文件路径
	 */
	public static final String MONGO_AUTH_PATH = "cn/com/ut/config/mongodb/mongo-auth.xml";

	/**
	 * 服务器连接管理
	 */
	@Resource
	private MongoServerManager mongoServerManager;

	public MongoServerManager getMongoServerManager() {

		return mongoServerManager;
	}

	/**
	 * 初始化，解析数据库认证配置xml
	 */
	@PostConstruct
	public void init() {

		Document doc = null;
		Element root = null;
		try {
			doc = XmlUtil.readXml(MONGO_AUTH_PATH);
			root = doc.getRootElement();
		} catch (DocumentException e) {
			e.printStackTrace();
			return;
		}

		putDBElement(root);

		List<MongoResourceElement> resourceElements = XmlUtil
				.toElementList(root.selectNodes("resources/resource"), MongoResourceElement.class);

		if (resourceElements != null && !resourceElements.isEmpty()) {
			for (MongoResourceElement r : resourceElements) {
				List<URL> urls = FileUtil.listUrls(r.getName(), null);
				if (urls != null) {
					for (URL url : urls) {
						Document resDoc = null;
						try {
							resDoc = XmlUtil.readXml(url);
						} catch (DocumentException e) {
						}
						if (resDoc != null) {
							putDBElement(resDoc.getRootElement());
						}
					}
				}
			}
		}
	}

	/**
	 * 解析数据库
	 * 
	 * @param root
	 *            文档元素
	 */
	private void putDBElement(Element root) {

		List<Element> servers = root.elements("server");
		if (servers != null && !servers.isEmpty()) {
			for (Element server : servers) {

				String serverName = server.attributeValue("name");

				List<Element> dbElements = server.elements();
				if (dbElements != null && !dbElements.isEmpty()) {

					for (Element dbElement : dbElements) {

						DBElement db = XmlUtil.toElement(dbElement, DBElement.class);
						ServerElement serverElement = mongoServerManager
								.getServerElement(serverName);
						db.setServer(serverElement);
						serverElement.getDbs().put(db.getName(), db);

					}
				}

			}
		}
	}

	@PreDestroy
	public void destroy() {

	}

}
