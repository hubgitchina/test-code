package cn.com.ut.core.mongodb.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.alibaba.fastjson.JSON;

import cn.com.ut.core.common.util.CollectionUtil;

@Configuration
@ConfigurationProperties(prefix = "mongo")
public class MongoConfig {

	private String enable;
	private String ormapper;
	private List<String> auth;
	private List<String> address;

	public String getEnable() {

		return enable;
	}

	public void setEnable(String enable) {

		this.enable = enable;
	}

	public String getOrmapper() {

		return ormapper;
	}

	public void setOrmapper(String ormapper) {

		this.ormapper = ormapper;
	}

	public List<String> getAuth() {

		return auth;
	}

	public void setAuth(List<String> auth) {

		this.auth = auth;
	}

	public List<String> getAddress() {

		return address;
	}

	public void setAddress(List<String> address) {

		this.address = address;
	}

	public List<MongoAddress> getMongoAddress() {

		List<MongoAddress> mongoAddressList = new ArrayList<MongoAddress>();
		if (!CollectionUtil.isEmptyCollection(getAddress())) {
			for (String auth : getAddress()) {
				mongoAddressList.add(JSON.parseObject(auth, MongoAddress.class));
			}
		}
		return mongoAddressList;
	}

	public List<MongoAuth> getMongoAuths() {

		List<MongoAuth> mongoAuthList = new ArrayList<MongoAuth>();
		if (!CollectionUtil.isEmptyCollection(getAuth())) {
			for (String auth : getAuth()) {
				mongoAuthList.add(JSON.parseObject(auth, MongoAuth.class));
			}
		}
		return mongoAuthList;
	}
}
