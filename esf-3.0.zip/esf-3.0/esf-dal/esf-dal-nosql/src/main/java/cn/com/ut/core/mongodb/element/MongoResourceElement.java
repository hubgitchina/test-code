package cn.com.ut.core.mongodb.element;

public class MongoResourceElement extends MongoBaseElement {

	private static final long serialVersionUID = 4247884566739807787L;

}
