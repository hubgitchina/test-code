package cn.com.ut.core.mongodb.element;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ServerElement extends MongoBaseElement {

	private static final long serialVersionUID = -4108288981739496970L;

	private List<HostElement> hosts = new ArrayList<HostElement>();
	private Map<String, DBElement> dbs = new TreeMap<String, DBElement>();

	public List<HostElement> getHosts() {

		return hosts;
	}

	public void setHosts(List<HostElement> hosts) {

		this.hosts = hosts;
	}

	public Map<String, DBElement> getDbs() {

		return dbs;
	}

	public void setDbs(Map<String, DBElement> dbs) {

		this.dbs = dbs;
	}

}
