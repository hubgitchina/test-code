package cn.com.ut.core.mongodb.config;

public class MongoAddress {

	private String cluster;
	private String address;

	public String getCluster() {

		return cluster;
	}

	public void setCluster(String cluster) {

		this.cluster = cluster;
	}

	public String getAddress() {

		return address;
	}

	public void setAddress(String address) {

		this.address = address;
	}

}
