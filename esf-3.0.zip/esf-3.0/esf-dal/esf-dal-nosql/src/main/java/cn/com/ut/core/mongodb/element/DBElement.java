package cn.com.ut.core.mongodb.element;

import java.util.Set;
import java.util.TreeSet;

public class DBElement extends MongoBaseElement implements Comparable<DBElement> {

	private static final long serialVersionUID = -6345810090910956171L;

	private String userName;
	private String password;
	private String auth;
	private ServerElement server;
	private Set<CollElement> colls = new TreeSet<CollElement>();

	public Set<CollElement> getColls() {

		return colls;
	}

	public void setColls(Set<CollElement> colls) {

		this.colls = colls;
	}

	public String getUserName() {

		return userName;
	}

	public void setUserName(String userName) {

		this.userName = userName;
	}

	public String getPassword() {

		return password;
	}

	public void setPassword(String password) {

		this.password = password;
	}

	public String getAuth() {

		return auth;
	}

	public void setAuth(String auth) {

		this.auth = auth;
	}

	public ServerElement getServer() {

		return server;
	}

	public void setServer(ServerElement server) {

		this.server = server;
	}

	@Override
	public int compareTo(DBElement another) {

		return getName().compareTo(another.getName());
	}

}
