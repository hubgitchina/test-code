package cn.com.ut.core.threadpool;

/**
*
* @author wuxiaohua
* @since 2013-12-22下午2:27:50
*/public interface Worker {

	public void doWork();
}
