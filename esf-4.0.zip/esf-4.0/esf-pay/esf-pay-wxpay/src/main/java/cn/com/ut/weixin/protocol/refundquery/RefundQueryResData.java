package cn.com.ut.weixin.protocol.refundquery;

public class RefundQueryResData {

}
