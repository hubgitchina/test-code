package cn.com.ut.core.restful;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import cn.com.ut.auth.exception.AuthException;
import cn.com.ut.core.common.constant.ConstantUtil;
import cn.com.ut.core.common.exception.ServiceException;
import cn.com.ut.core.common.exception.ValidateException;
import cn.com.ut.core.common.util.CollectionUtil;
import cn.com.ut.core.common.util.CommonUtil;
import cn.com.ut.core.common.util.ExceptionUtil;

/**
 * 全局异常处理，只对业务Controller生效(basePackages用于排除系统Controller)
 * 
 * -1 表示程序员可预见主动抛出的异常，-2表示预料之外的异常
 * 
 * @author wuxiaohua
 *
 */
@RestControllerAdvice(annotations = RestController.class, basePackages = { "cn.com.ut.biz" })
public class ExceptionHandlerAdvice {

	@ExceptionHandler({ AuthException.class })
	@ResponseStatus(value = HttpStatus.UNAUTHORIZED)
	@ResponseBody
	public ResponseWrap deal(AuthException ex) {

		ExceptionUtil.logError(ex);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setCodeMsg(-1,
				CommonUtil.isEmpty(ex.getMessage()) ? "auth failure" : ex.getMessage());
		return responseWrap;
	}

	@ExceptionHandler({ ValidateException.class })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseWrap deal(ValidateException ex) {

		ExceptionUtil.logError(ex);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setCodeMsg(-1, ex.getMessage());
		return responseWrap;
	}

	@ExceptionHandler({ ServiceException.class })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseWrap deal(ServiceException ex) {

		ExceptionUtil.logError(ex);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setCodeMsg(ConstantUtil.BIZ_ERR_CODE, ex.getMessage());
		return responseWrap;
	}

	@ExceptionHandler({ RuntimeException.class })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseWrap deal(RuntimeException ex) {

		ExceptionUtil.logError(ex);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setCodeMsg(ConstantUtil.UNKNOWN_ERR_CODE, "发生系统错误： " + ex.getMessage());
		return responseWrap;
	}

	@ExceptionHandler({ Exception.class })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseWrap deal(Exception ex) {

		ExceptionUtil.logError(ex);
		ResponseWrap responseWrap = ResponseWrap.builder();
		responseWrap.setCodeMsg(ConstantUtil.UNKNOWN_ERR_CODE, "发生系统错误： " + ex.getMessage());
		return responseWrap;
	}

	@ExceptionHandler({ MethodArgumentNotValidException.class, BindException.class })
	@ResponseStatus(value = HttpStatus.OK)
	@ResponseBody
	public ResponseInfo dealValidException(Exception ex) {

		ExceptionUtil.logError(ex);
		ResponseInfo responseInfo = ResponseInfo.build();
		responseInfo.setCode(-1);
		List<FieldError> fes = null;
		if (ex instanceof MethodArgumentNotValidException) {
			fes = ((MethodArgumentNotValidException) ex).getBindingResult().getFieldErrors();
		} else {
			fes = ((BindException) ex).getFieldErrors();
		}
		responseInfo.setMsg(buildErrors(fes));
		return responseInfo;
	}

	private String buildErrors(List<FieldError> fes) {

		StringBuilder builder = new StringBuilder();
		if (CollectionUtil.isEmptyCollection(fes)) {
			return "";
		} else {
			fes.forEach((fe) -> builder.append(fe.getField() + " " + fe.getDefaultMessage() + ";"));
			builder.deleteCharAt(builder.length() - 1);
		}
		return builder.toString();
	}
}
